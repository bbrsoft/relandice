<?php
	
	function digits($num){
		if(strlen($num) == 1){
			return "0".$num;
		} else {
			return $num ; 
		}
	}
	
	
	function star($star){
		$star = round($star);
		for ($i = 1; $i <= $star; $i++) {
			echo('<i class="fa fa-star"></i>') ; 
		} 
		
		for ($i = 1; $i <= (5 - $star); $i++) {
			echo('<i class="fa fa-star-o"></i>') ; 
		} 		
	}
	
	

	function angka($data){ 
	$data2 = str_replace(",", "",$data); 
	$data2 = preg_replace("/[^0-9.]/", "",$data2);  return $data2;
	}
	
	function check_mime($text){
		
		$mime = "mp4";
		if(strpos('mp4',$text) >= 1){ $mime = "mp4"; } 
		if(strpos('mkv',$text) >= 1){ $mime = "mkv"; } 
		if(strpos('avi',$text) >= 1){ $mime = "avi"; } 
		if(strpos('mpeg',$text) >= 1){ $mime = "mpeg"; } 
		
		return $mime; 
		
	}
	
	
	function waktu($time){ 


		$date = date_create(date('Y-m-d'));
		$date2 = date_create($time);
		
		$s  = date_diff( $date, $date2);
		$selisih= $s->days;
		
		$text = "";
		if($selisih == 0){
			$text = "Hari Ini";
		} else {
			if($selisih <= 29){
				$text = $selisih." Hari Lalu"; 
			} else 
			if($selisih <= 50){
				$text = "1 Bulan Lalu"; 
			} else 
			if($selisih <= 80){
				$text = "2 Bulan Lalu"; 
			} else {
				$text = $time;
			}
		} 
		
		
		return $text;
		
	}
	
	function comment_plain($data){
		$data = str_replace('%','',$data);
		$data = htmlspecialchars($data , ENT_QUOTES);
		$data = htmlentities($data);
		return $data;
		
	}
	
	
	
	function in($data){
		$data = htmlspecialchars($data , ENT_QUOTES);
		$data = htmlentities($data);
		return $data;
	}

	function inx($data){
		$data = htmlspecialchars($data , ENT_QUOTES);
		$data= trim(preg_replace('/\s\s+/', ' ', $data));
		$data = preg_replace('~[\r\n]+~', '', $data);
		$data = str_replace("'",'',$data);
		$data = str_replace('"','',$data);
		return $data;
	}
	
	
	function ssl($str){	$str = str_replace("_","__9*",$str);	$str = str_replace("a","__8*",$str);	$str = str_replace("b","__7*",$str);	$str = str_replace("c","__6*",$str);	$str = str_replace("d","__5*",$str);	$str = str_replace("e","__4*",$str);	$str = str_replace("f","__3*",$str);	$str = str_replace("g","__2*",$str);	$str = str_replace("h","__1*",$str);	$str = str_replace("i","__9#",$str);	$str = str_replace("j","__8#",$str);	$str = str_replace("k","__7#",$str);	$str = str_replace("l","__6#",$str);	$str = str_replace("m","__5#",$str);	$str = str_replace("n","__4#",$str);	$str = str_replace("o","__3#",$str);	$str = str_replace("p","__2#",$str);	$str = str_replace("q","__1#",$str);	$str = str_replace("r","__9",$str);	$str = str_replace("s","__8",$str);	$str = str_replace("t","__7",$str);	$str = str_replace("u","__6",$str);	$str = str_replace("v","__5",$str);	$str = str_replace("w","__4",$str);	$str = str_replace("x","__3",$str);	$str = str_replace("y","__2",$str);	$str = str_replace("z","__1",$str);	$str = base64_encode(base64_encode($str));	return $str;}
	function de_ssl($str){	$str = base64_decode(base64_decode($str));	$str = str_replace("__9*","_",$str);	$str = str_replace("__8*","a",$str);	$str = str_replace("__7*","b",$str);	$str = str_replace("__6*","c",$str);	$str = str_replace("__5*","d",$str);	$str = str_replace("__4*","e",$str);	$str = str_replace("__3*","f",$str);	$str = str_replace("__2*","g",$str);	$str = str_replace("__1*","h",$str);	$str = str_replace("__9#","i",$str);	$str = str_replace("__8#","j",$str);	$str = str_replace("__7#","k",$str);	$str = str_replace("__6#","l",$str);	$str = str_replace("__5#","m",$str);	$str = str_replace("__4#","n",$str);	$str = str_replace("__3#","o",$str);	$str = str_replace("__2#","p",$str);	$str = str_replace("__1#","q",$str);	$str = str_replace("__9","r",$str);	$str = str_replace("__8","s",$str);	$str = str_replace("__7","t",$str);	$str = str_replace("__6","u",$str);	$str = str_replace("__5","v",$str);	$str = str_replace("__4","w",$str);	$str = str_replace("__3","x",$str);	$str = str_replace("__2","y",$str);	$str = str_replace("__1","z",$str);	return $str;}
	
	function upload_name($title){
		$title = str_replace(' ','-',$title);
		$title = strtolower($title);
		$title = preg_replace("/[^.A-Za-z0-9_-]/", '', $title);
		return $title;
	}	
	
	
	
	
	function eksekusi($pdo, $query,$type = "mysql"){ 	
		if(strtolower($type) == "postgresql"){
			$query2 = str_replace('`','"',$query);
		} else {
			$query2 = $query ;
		} 
		try{
			$exe = $pdo->prepare($query2); 	
			$exe->execute(); 	
			return "success";	
		}  catch (Exception $e) { 
			return $e;
		} 
		
	}
	
	
	function select($pdo,$query , $type = "mysql"){ 
		$query2 = str_replace('`','"',$query);
		$type = strtolower($type);
		
		if($type == "mysql"){
			$x = $pdo->prepare($query); 
		} if($type == "postgresql"){
			$x = $pdo->prepare($query2); 
		} else {
			$x = $pdo->prepare($query); 
		}
		return $x; 
	}
	
	
	
	
	function row($var){ return $var->rowCount(); }
	function fetch($var){ return $var->fetch(PDO::FETCH_BOTH); }
	function fetch_obj($var){ return $var->fetch(PDO::FETCH_OBJ); }
	function uang($money, $round = 2){
		if (( $money <> 0 ) and ($money <> '')) {
			$uang = number_format((float)$money, $round, '.', ',');
			return $uang;
		}
		else{
			$uang = "0";return $uang;
		}
	}
	
	
	function plain($title){$title = strtolower($title);$title = preg_replace("/[^A-Za-z0-9_ -]/", '', $title);$t = explode(' ',$title);$txx = "";$x =0;foreach($t as $tx){		if($tx != ""){		if($x == 0){		$txx = $tx;	} else {		$txx .= "-".$tx;	}	$x++;	}}return $txx;}	
	function plain2($title){$title = strtolower($title);$title = preg_replace("/[^A-Za-z0-9_ ,-]/", '', $title);$t = explode(' ',$title);$txx = "";$x =0;foreach($t as $tx){		if($tx != ""){		if($x == 0){		$txx = $tx;	} else {		$txx .= "-".$tx;	}	$x++;	}}return $txx;}	
	
	function title($title){$title = strtolower($title);$title = preg_replace("/[^A-Za-z0-9_ ]/", '', $title);$t = explode(' ',$title);$txx = "";$x =0;foreach($t as $tx){		if($tx != ""){		if($x == 0){		$txx = $tx;	} else {		$txx .= "-".$tx;	}	$x++;	}}return $txx;}	
	function judul($title,$count){$t = explode(' ',$title);$txx = "";$x =0;$xxx = "";foreach($t as $tx){		if($x <> $count){	if($x == 0){		$txx = $tx;	} else {		$txx .= " ".$tx;	}	$x++;	} else {		$xxx = "...";	}}return $txx.$xxx;}   
	function respon_exists(){ return "<h4 class='mb-0'> Error </h4> - This Data Is Already Exists"; }
	function respon_success(){ return "<h4 class='mb-0'> Success </h4>  <p> Data Entered Successfully  </p>"; }
	function respon_primary(){ return "<h4 class='mb-0'> Error </h4>  <p> Error At Get Last ID Primary  </p>"; }
	

	function test_connect($host, $user_db,$password_db,$database,$type,$port)
	{
		$return = "Type Database Is Not Support";
	
		if(strtolower($type) == "mysql"){
			try {
			$pdo = new PDO("mysql:host=$host;dbname=$database", $user_db, $password_db);
			$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
				$return = "success";
			} catch(PDOException $e) {
				$return = "Connection failed: " . $e->getMessage();
			}
		} 
		
		if(strtolower($type) == "postgresql"){	
			try {
				$pdo = new PDO("pgsql:host=$host;port=$port;dbname=$database;", $user_db, $password_db);
				$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
				$return =  "success";
			} catch(PDOException $e) {
				$return =  "Connection failed: " . $e->getMessage();
			}
		} 
		
		return $return;	
	}
	
	
	
	function connect($database)
	{
		
		$host = $database->host_db;
		$user_db = $database->user_db;
		$password_db = $database->password_db;
		$db_name = $database->database_name;
		$type = $database->type;
		$port = $database->port;
		
		$pdo = "ERROR CONNECTED";
		
		if(strtolower($type) == "mysql"){
			try {
				$pdo = new PDO("mysql:host=$host;dbname=$db_name", $user_db, $password_db, array( PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION ));
			} catch(PDOException $e) {
				$pdo = "ERROR CONNECTED";
			}
		} else 
		if(strtolower($type) == "postgresql"){
			try {
				$pdo = new PDO("pgsql:host=$host;port=$port;dbname=$db_name;", $user_db, $password_db);
				$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			} catch(PDOException $e) {
				$pdo = "ERROR CONNECTED";
			}
		} 
		
		
		return $pdo;	
	}
	
	function ext($name){		
		$type_list = explode('.',$name);
		$type = $type_list[count($type_list)-1]; 
		return $type;
	}	
	
	
	function check_saldo($crypto , $token){
		$saldo = 0 ;
		
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, 'https://wolf.bet/api/v1/user/balances');
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');

	 
		$headers = array();
		$headers[] = 'X-Requested-With: XMLHttpRequest';
		$headers[] = 'Authorization: Bearer '.$token;
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

		$result = curl_exec($ch); 
		if (curl_errno($ch)) {
			echo 'Error:' . curl_error($ch);
		}
 
		curl_close($ch);  		
		if(!empty($result)){			
			$result = json_decode($result);  
			if(empty($result->error)){  
				foreach($result->balances as $data){
					if($data->currency == $crypto){
						$saldo = $data->amount; 
					} 				
				}
			}
		}
		 
		return $saldo ; 
		
	}
	
	
	
	
	function random($amin, $amax){
		$min = $amin;
		$max= $amax; 
		if($amin >= $amax){
			$min = $amax; 
			$max = $amin;
		} 
		
		$min = $min - 0.01;
		$max = $max - 0.01;
		
		$min_ar = explode('.',$min);
		$max_ar = explode('.',$max);
		
		$bulat_min = $min_ar[0];
		$bulat_max = $max_ar[0];
		
		$bulat_rand = rand($bulat_min, $bulat_max);
		
		if($bulat_rand >= $bulat_max){
			$koma_rand = rand( 1, $max_ar[1] ); 
			if(strlen($koma_rand) == 1){
				$koma_rand = "0".$koma_rand;
			} 
		} else {
			$koma_rand = rand( 10, 99 ); 
		}
 
		
		
		return $bulat_rand.".".$koma_rand; 
	}
	
	
	
	function remove_enter($text){
		$text = str_replace('\r\n','<br /> ',$text);
		$text = str_replace('\n\r','<br /> ',$text);
		$text = str_replace('\n','<br />',$text);
		$text = str_replace('\r','<br />',$text);
		$text = str_replace(PHP_EOL,'<br />',$text);
		$text = preg_replace('/\R+/', " ", $text);

		return $text;
	}
	 
	 

	function rounds($total, $r){
		$total = round($total, $r);
		$x = explode('.',$total);
		
		$x1 = $x[0];
		if(!empty($x[1])){
			if(strlen($x[1]) == 1){ $x2 = $x[1]."0000000"; } 
			if(strlen($x[1]) == 2){ $x2 = $x[1]."000000"; } 
			if(strlen($x[1]) == 3){ $x2 = $x[1]."00000"; } 
			if(strlen($x[1]) == 4){ $x2 = $x[1]."0000"; } 
			if(strlen($x[1]) == 5){ $x2 = $x[1]."000"; } 
			if(strlen($x[1]) == 6){ $x2 = $x[1]."00"; } 
			if(strlen($x[1]) == 7){ $x2 = $x[1]."0"; } 
		} else {
			$x2 = "00000000";
		} 
		
		$total = $x1.".".$x2;
		return $total;	
	}
	

	function logout(){
			$_SESSION['user'] = ""; 
			$_SESSION['arcur'] = ""; 
			$_SESSION['broker'] = ""; 
			$_SESSION['session_code'] = "";
	}
	

?>