<?php 
$table = "crypto";
$sql = "`nama`='shib'";
$row = $this->model->row($table,$sql);
if($row >= 1){
	$data = $this->model->get_obj($table,$sql)[0];

 ?>
 

<div class="tab-pane" role="tabpanel" id="tab-8"> 
<div class="tab_8x" id="tab_8_list">
<div class="pl-3 pr-3 pt-1 pb-2">
<h5 class="d-flex align-items-center justify-content-between"> 
<div class="">
<i class="fa fa-indent px-1"  style="font-weight : 300!important;" >  </i> SHIB/USDT Perp <b class="text-success"> $<?php echo($data->usd) ;  ?> </b> 
</div>
<a class="" > <i class="fa fa-chart-candlestick">  </i> </a> 	
</h5> 

</div>





<section class="bg-header pt-2 border-top"  style="border-color:black!important;" > 
<div class="tab_manual" style="margin-top: -10px; border-bottom:1px solid black;" >
	<a class="tab_manual_item active bold fs-15" id="ai1" onclick="toggle_tab_manual('#tab_8_1','#ai1','tab-8')"  > Copy Strategy </a> 
	<a class="tab_manual_item  bold fs-15"  id="ai2"  onclick="toggle_tab_manual('#tab_8_2','#ai2','tab-8')" > History </a> 
</div> 
 
<?php include("tab_8_1.php"); ?>
<?php include("tab_8_2.php"); ?>

</section>
</div>


<div class="px-3 pt-2 d-none tab_8x" id="tab_8_form">
		
	<h4 class="fs-16"> <i  style="font-weight : 300!important" id="back_ai"  class="la la-arrow-left">  </i> 	Input Investment Amount </h4> 
	
	<div class="p-3 border radius-5"  style="border-color:black!important " >
		
		<b class="fs-16"> Bullish Trand - Moderate <span class="badge badge-sm bg-dark"> 5x </span>  </b>
		<p> The following parameters are based on 30-day data backtesting and are for reference only </p> 
		
		<div class="d-flex align-items-center mb-1 justify-content-between">
			<span  class="text-secondary"> Strategy Source </span> 
			<b> Pionex </b>
		</div>
		
		<div class="d-flex align-items-center mb-1 justify-content-between">
			<span  class="text-secondary"> Arbitrage APY </span> 
			<b class="text-success"> +410.96% </b>
		</div>
		
		<div class="d-flex align-items-center mb-1 justify-content-between">
			<span  class="text-secondary"> Mark Drawdown </span> 
			<b class="text-success"> -10.79% </b>
		</div>
		
		<hr  style="border-color:black!important;" >
		<div class="" align="center">
			<span  class="text-secondary"> Price Range (USDT)</span> 
			<p class="mb-1" align="center"><b>  0.0000014239 - 0.0000017214 </b> </p> 
		</div>	
		
		<div class="" align="center">
			<span class="text-secondary"> Profit/Grid (fee deducted) </span> 
			<p class="mb-1" align="center"><b>  0.14% - 0.24% (181 grids) </b> </p> 
		</div>	
		
		<div class="d-flex align-items-center mt-2 mb-1 justify-content-between">
			<span class="text-secondary"> Liq. Price  </span> 
			<b class="text-success"><b> 0.0000014239 USDT  </b></b>
		</div>
		
		<span class="text-danger"> Not satisfied? Costomize ></span> 
		<div class="d-flex align-items-center justify-content-between">
			<span> Investment </span> 
			<span><i class="fa fa-check-square">  </i> Auto Reverse <i class="la la-info-circle">  </i></span> 
		</div>
		
		<div class="border radius-5 mt-1"  style="border-color:black!Important;" >
			<input type="number" required class="form-control mb-0 text-light d-block" name="name" value="0" placeholder=""    />
			<div class="pt-1 pb-2 px-2">
				<small> Actual Investment (--) + Extra margin (--) USDT </small> 
			</div>
		</div>
		
		
		
		
		
		
		<div class="pt-1">
			<input class="w-100" max="100" min="1" id="percentage" type='range' step="0.01" value='50'>
			<div class="d-flex align-items-center mt-n2 justify-content-between fs-10">
				<span> 0% </span> 
				<span> 25% </span> 
				<span> 50% </span> 
				<span> 75% </span> 
				<span> 100% </span> 
			</div>
		</div>
		
		
		
		
		
		<div class="d-flex pt-2 pb-0 fs-14 align-items-center justify-content-between">
			<span> Percentage </span> 
			<span id="percentage_respon"> 50% </span> 
		</div>
		
		<div class="d-flex pt-0 pb-3 fs-14 align-items-center justify-content-between">
			<span> Available </span> 
			<span> 0 USDT </span> 
		</div>
		
		
		
		<a class="btn btn-dark w-100 form-control" > CREATE </a> 
	</div>
	
</div>
</div>


<script>  


$('#percentage').on('change',function(){
	$('#percentage_respon').html($(this).val()+"%");
});
$('#percentage').on('scrool',function(){
	$('#percentage_respon').html($(this).val()+"%");
});
</script> 



<script>  
$('#copy_bot').click(function(){
	show_tab8('#tab_8_form');
});
$('#back_ai').click(function(){
	show_tab8('#tab_8_list');
});


function show_tab8(id){
	$('.tab_8x').addClass('d-none');
	$(id).removeClass('d-none');
}
  </script> 



<?php } ?>

