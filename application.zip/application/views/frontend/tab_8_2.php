<div class="tab_manual_content"   id="tab_8_2">
<div class="px-3">
	<div class="d-flex align-items-center justify-content-between pt-2 pb-2">
		<span class="fs-16 text-light" > <i class="fa fa-check-square text-warning mr-1">  </i> Show All </span> 
		<a class="btn px-3 btn-dark btn-sm" >   Close All </a> 
	
	</div>
		
</div>

<div class="pt-2">
<div class="p-3"  style="background: rgba(0,0,0,0.1)" >
	<div class="d-flex align-items-center justify-content-between">
		<div class="w-50">
			<h5 class="fs-16 mb-0"> <b> SHIBUSDT </b> <span class="badge bg-dark badge-sm text-success"> Short </span>  </h5> 
			<small class="fs-12 text-secondary"> Cross 9.50x </small> 
		</div>
		<div class="w-50" align="right">
			<small align="right" class="fs-12 text-secondary"> Unrealized P&L </small> 
			<h5 align="right" class="fs-16 text-success"> 454.00 (451.95%) </h5> 
		</div>
	</div>
	
	<div class="d-flex align-items-center justify-content-between">
		<div class="">
			<small class="text-secondary fs-12"> Position Size </small> 		
			<h5 class="fs-16 mb-0 text-success"> 6.09 </h5> 
		</div>
		<div class="">
			<small class="text-secondary fs-12"> Entry Price </small> 		
			<h5 class="fs-16 mb-0"> 1,556.00</h5> 
		</div>
		<div class="">
			<small class="text-secondary fs-12"> Mark Price </small> 		
			<h5 class="fs-16 mb-0"> 1,631.81 </h5> 
		</div>
		<div class="">
			<small class="text-secondary fs-12"> Est. Liq Price </small> 		
			<h5 class="fs-16 mb-0 text-warning"> 1,476.00 </h5> 
		</div>
	</div>
	<div class="d-flex mt-3 justify-content-between align-items-center gap-1">
		<a class="btn btn-dark w-50" > <span class="text-success"> 1,785.00</span> / <span class="text-warning"> 1,548.00 </span>   </a> 
		<a class="btn btn-dark w-50" > Close By </a> 
	</div>

</div>
</div>


</div>
