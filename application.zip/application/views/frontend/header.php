
<div class="header_style">
<img onclick="document.location.href='<?php echo($site) ?>';" src="<?php echo($site) ?>image/<?php echo($settings->favicon) ;  ?>"  style="height: 35px"  class="" />
<div onclick="document.location.href='<?php echo($site) ?>';" class=""  style="line-height:11px" >
<h5 class="mb-0"  style="margin-top: -5px;" > <?php echo($settings->nama) ;  ?></h5> 
<small  style="font-size : 10px" > Play with bot and get profit every time </small> 

</div> 
<a class=""  href="<?php echo($site) ?>?page=profile" style="position:absolute; right:1rem; top:12px;color:white; line-height:11px" align="center"  > 
	<i class="fa fa-user-circle" style="font-size : 20px"  >  </i> 
	<small class="d-block fs-10"  style=" <?php if(empty($user)){echo('color:red!Important;') ; }  ?>" > Account </small>  
</a> 

</div>