<script type="module"> 
var wait = false ; 
var datetime_start = 0 ;
var ar_saldo = [];
var ar_bet = [];
var ar_profit_now = [];
var ar_profit_all = [];
var ar_price_usd = [];
var ar_price_rp = [];

var id_user = "<?php echo($user->id) ;  ?>";
var min_bet = <?php echo($min_bet_active) ;  ?>;
var bet_limit = 0;		<?php if($user->secret <> ''){?>  bet_limit = <?php echo($user->bet) ;  ?>; <?php  }  ?>
var token = "<?php echo($user->token) ;  ?>";
var id_admin = <?php echo($id_admin) ;  ?> ; 
var saldo_active = 0; 
var crypto_active = "<?php echo strtolower($crypto_active) ;  ?>";
var start_bet = <?php echo($min_bet_active) ;  ?> 
var cur_reland = "<?php echo($cur_reland) ;  ?>";


if(token){
var stop_now = false; 
var sudah_stop = false;
var strategy = "";
var r_amount = '';
var r_hash = '';
var r_currency = '';
var r_profit= '';
var r_multiplier= '';
var r_bet_value= '';
var r_result_value= ''; 
var r_state= '';
var r_balance= 0;
var r_rule = '';
var r_nonce = '';
var cur_code = '<?php echo($cur_code) ;  ?>';
	

<?php foreach($price_rp as $name => $val){ ?> 
	ar_profit_now["<?php echo($name) ;  ?>"] = 0; 
	ar_profit_all["<?php echo($name) ;  ?>"] = 0; 
	ar_saldo["<?php echo($name) ;  ?>"] = 0; 
	ar_bet["<?php echo($name) ;  ?>"] = "<?php echo($min_bet[$name]) ;  ?>"; 
	ar_price_rp["<?php echo($name) ;  ?>"] = string_number2("<?php echo($price_rp[$name]) ;  ?>"); 
	ar_price_usd["<?php echo($name) ;  ?>"] = string_number2("<?php echo($price_usd[$name]) ;  ?>"); 
<?php }  ?>  

ar_saldo['rfc'] = <?php echo($user->bet) ;  ?>;
	
	
function change_crypto(crypto){
	crypto = String(crypto).toLowerCase();
	
	crypto_active = crypto;
	$('.crypto_active').html(crypto);	
	saldo_active = ar_saldo[crypto] ;   
	
	
	if((cur_reland == "idr") || (cur_reland == "IDR")){
		saldo_active = Number(saldo_active) * Number(ar_price_rp[crypto]);
	} 
	if((cur_reland == "usd") || (cur_reland == "USD")){
		saldo_active = Number(saldo_active) * Number(ar_price_usd[crypto]);
	}
	
	saldo_active = Number(saldo_active).toFixed(4);
	ar_saldo[crypto] = saldo_active;
	
	
	min_bet = ar_bet[crypto];
	$('.saldo_active').html(saldo_active);
	$('#bet').val(min_bet);
	$('#bet').attr('min',min_bet);
	 
}


var error = "No";

function check_balance_now(){
	var curl_saldo = new XMLHttpRequest();
	curl_saldo.onload = () => {	
	if(curl_saldo.readyState == 4){
		
		if(curl_saldo.response){
			var res = JSON.parse(curl_saldo.response); 
			if(res.balances){
			res.balances.forEach(function(item, index){
				ar_saldo[item.currency] = item.amount;
			});
			change_crypto(crypto_active);
			} else {
				error = "Yes";
				alert('Your API Key Is Wrong/Expired , Click Account -> Change Token ');
			}
		} 
	} else {
		if(curl_saldo.response){
			console.log(curl_saldo.response);
		} 
	}
	}
	 
	
	
	
	curl_saldo.open("GET", 'https://wolfbet.com/api/v1/user/balances');
	curl_saldo.setRequestHeader("Authorization", 'Bearer '+token);
	curl_saldo.send();

}


check_balance_now();

	
	
	
var money = "usd";
var status_game = "Stop";
var interval_time = 200;
var chance = 49.99; 
var multiplier = 1.98; 
var amount = <?php echo($min_bet_active) ;  ?>;
var stop_win = false ; 
var total_profit = 0;
var berjalan = false; 
var inter = "" ;
var default_chance = 0 ; 
var auto_reset = false; 
var reset_now = false; 
var reset_manual = true; 
var auto_play_stop = false;
var relax_time = 20;
var check_reset = false;
var reset_profit = 0 ;
var balance_default = 0; 
var is_break = false ;  
var status_bot = "stop";
var respon = '';
var response = '';
var respon_balance = '';
var old_chance = '';
var total_profit_all = 0 ; 
var active_developer = false; 
var old_amount = 0 ;
var next_amount = 0 ;

var old_state = "";
var old_bet = 0;
var old_chance = 0 ;
var max_balance = saldo_active; 
var stop_history = false;


var max_total_bet = 0 ;
var max_balance_down = 0 ;
var total_down_max_balance = 0 ;
var sub_total_down_max_balance  = 0 ;

var total_ls = 0 ;
var total_ws = 0 ;


var amount2 = 0 ;
var resetstreak = '';
var y = 0 ;
var class_profit = '';
var string_profit = '';
var amount_post = 0;
var xmlhttp=new XMLHttpRequest();
var formData = new FormData();
var chax = 0;
var percent_under = 0.99;
var bet_val_setup = 0;
var multi = 0; 
var random_cache = Math.random();
var url = 'https://wolfbet.com/api/v1/bet/place/?r='+random_cache ; 
var tick_now = 0 ; 
var total_bt = 0;
var bt_storage = 0 ;


function fixed_amount(){
	
	if(cur_reland == "idr"){ amount= Number(amount).toFixed(2); } else  
	if(cur_reland == "usd"){ amount= Number(amount).toFixed(5); } else{
		amount= Number(amount).toFixed(8);
	}
	amount = Number(amount) + 0 ; 
	
	
}



$('#marti_amount').on('keyup',function(){
	$('.btn_marti_up .value').html($(this).val());
	$('.btn_marti_down .value').html($(this).val());
	
})
	

	
$('.btn_marti_up').click(function(){
	let up_marti = $('#up_marti').val();
	let marti_amount = $('#marti_amount').val();  
	let totalx = Number(marti_amount) * Number(up_marti);
	  
	
	$('.btn_marti_up .value').html(totalx);
	$('.btn_marti_down .value').html(totalx);
	if(Number(totalx)){
		next_amount = totalx; 
		$('#bet').val(totalx);
	} 
	
	$('#marti_amount').val(totalx);
	
});


 
$('.btn_marti_down').click(function(){
	let up_marti = $('#up_marti').val();
	let marti_amount =  $('#marti_amount').val();  
	let totalx = Number(marti_amount) / Number(up_marti);
	if(Number(totalx) < Number(min_bet)){
		totalx = min_bet; 
	} 
	$('.btn_marti_up .value').html(totalx);
	$('.btn_marti_down .value').html(totalx);
	if(Number(totalx)){
		next_amount = totalx; 
		$('#bet').val(totalx);
	} 
	
	$('#marti_amount').val(totalx);
});




function hapus_fitur(){
	$('#active_fitur').html('');
}


function tambah_fitur(judul, id_developer, class_fitur = ""){
	$('#active_fitur').append('<div class="box_developer '+class_fitur+'" id="'+id_developer+'" >'+judul+' <span class="value"> </span> </div>');
}


function add_history_developer(judul){
	if(stop_history == false){
		$('#respon_developer').prepend('<span class="item_respon2"> '+judul+'</span> ');
		if($(".item_respon2:nth-child(100)").length){
			$(".item_respon2:nth-child(100)").remove();
		} 
	}
}
 

$('.change_bet').click(function(){
	let multi = $(this).attr('multi');
	if((multi != "0") && (multi != 0)){
		next_amount = Number(amount) * Number(multi);
		$('#bet').val(next_amount);
	} else {
		next_amount = start_bet;
		$('#bet').val(next_amount);
	}
});




function reset_bettinglosestreak(){
	bettinglosetreak.active = false; 
	bettinglosetreak.total_losestreak = 0 ; 
	bettinglosetreak.total_winstreak = 0 ; 
	bettinglosetreak.save_bet = 0 ;
	bettinglosetreak.total_profit = 0 ;
	bettinglosetreak.max_total_profit = Number(total_profit); 
	amount = start_bet; 
}




function reset_lcp(){
	lcp.terkumpul = 0 ;
	lcp.total_profit = 0 ;
	lcp.total_lose = 0 ;
	lcp.start_balance = Number(r_balance);
	lcp.max_balance = Number(r_balance);
	lcp.lost_balance = 0 ; 
	lcp.balance_default = Number(r_balance);
	lcp.active = false; 
	add_history_developer('Reset System LCP ');

	$('#lcp_start_balance .value').html(r_balance);
	$('#lcp_balance .value').html(r_balance);


}




function restart_bot(){
	status_game = "Stop";
	interval_time = 200;
	chance = 49.99; 
	multiplier = 1.98;  
	stop_win = false ; 
	total_profit = 0;
	berjalan = false; 
	inter = "" ;
	default_chance = 0 ; 
	auto_reset = false; 
	reset_now = false; 
	reset_manual = true; 
	auto_play_stop = false;
	relax_time = 20;
	check_reset = false;
	reset_profit = 0 ;
	balance_default = 0; 
	is_break = false ;  
	status_bot = "stop";
	respon = '';
	response = '';
	respon_balance = '';
	old_chance = '';
	total_profit_all = 0 ; 
	active_developer = false; 
	old_amount = 0 ;
	next_amount = 0 ;
	old_state = "";
	old_bet = 0;
	old_chance = 0 ; 
	stop_history = false; 
	max_balance_down = 0 ;
	total_down_max_balance = 0 ;
	sub_total_down_max_balance  = 0 ;
	amount2 = 0 ;
	resetstreak = '';
	y = 0 ;
	class_profit = '';
	string_profit = '';
	amount_post = 0;
	xmlhttp=new XMLHttpRequest();
	formData = new FormData();
	chax = 0;
	percent_under = 0.99;
	bet_val_setup = 0;
	multi = 0; 
	random_cache = Math.random();
	url = 'https://wolfbet.com/api/v1/bet/place/?r='+random_cache ; 
	tick_now = 0 ; 
	
	amount = start_bet; 
	$('#bet').val(amount);
	saldo_active = Number(r_balance); 
	$('#saldo_active').html(saldo_active);
	
	$('#total_down_max_balance').val(sub_total_down_max_balance);


	/*
	 * 	
	total_bt = 0;
	bt_storage = 0 ;
	total_ls = 0 ;
	total_ws = 0 ;

	 * --------------
	 */
	

}





		
function Streak(){ 
	this.now_win_streak = 0 ;
	this.now_lose_streak = 0 ;
	this.total_max_winstreak = 0;
	this.total_max_losestreak= 0 ;
	this.total_win = 0 ;
	this.total_lose = 0 ;
	this.total_bt = 0 ;
	this.bt_storage = 0 ;
	
	
	
	
	tambah_fitur('Win Streak', 'fitur_ws','text-success');
	tambah_fitur('Lose Streak', 'fitur_ls','text-danger');
	
	this.setup_streak = function(){
		$('#fitur_ws .value').html(" : "+this.now_win_streak+"x");
		$('#fitur_ls .value').html(" : "+this.now_lose_streak+"x");
		
		if(r_state == "win"){
			this.now_lose_streak = 0 ;
			this.now_win_streak++; 
			this.total_win++;  
			bt_storage = 0 ; 
		} else {
			this.total_lose++;
			this.now_lose_streak++;
			this.now_win_streak = 0 ;
			bt_storage = Number(bt_storage) + Number(r_profit);
		}
		
		
		
		$('.now_losestreak').html(String(this.now_lose_streak)+"x");
		if(this.now_win_streak > this.total_max_winstreak){
			this.total_max_winstreak = this.now_win_streak;
			$('.now_winstreak').html(String(this.now_win_streak)+"x");
		} 
		
		
		if(this.now_lose_streak > this.total_max_losestreak){
			this.total_max_losestreak = this.now_lose_streak;
			$('.now_lose_streak').html(String(this.now_lose_streak)+"x");
		} 
		
	 
		if(Number(total_bt) > Number(bt_storage) ){ 
			total_bt = Number(bt_storage).toFixed(4); 
			$('#total_bt').html(total_bt);
		}
		
		
		
		if(this.now_win_streak >= total_ws){
			total_ws = this.now_win_streak; 
		} 
		if(this.now_lose_streak >= total_ls){
			total_ls = this.now_lose_streak; 
		} 
		
		$('#total_ws').html(total_ws+"x");
		$('#total_ls').html(total_ls+"x");
		
		
	}
} 
var streak = '';




function ResetStreak(){ 
	this.check_max_win_streak = $("#check_max_win_streak").is(":checked") ;
	this.check_max_lose_streak = $("#check_max_lose_streak").is(":checked") ;
	this.max_win_streak = $('#max_win_streak').val();
	this.max_lose_streak = $('#max_lose_streak').val();	
	this.win_streak_now = 0;
	this.lose_streak_now = 0;
	
	
	
	if((this.check_max_win_streak == true) || (this.check_max_win_streak == "true")){
		tambah_fitur('Reset If WS '+this.max_win_streak, 'fitur_reset_ws','text-yellow');
	}
	
	if((this.check_max_lose_streak == true) || (this.check_max_lose_streak == "true")){
		tambah_fitur('Reset If LS'+this.max_lose_streak, 'fitur_reset_ls','text-yellow');
	}

	this.reset_winstreak = function(){
		if(r_state == "win"){
			this.win_streak_now++; 
			this.lose_streak_now = 0 ;
		} 
		if((this.check_max_win_streak == true) || (this.check_max_win_streak == "true")){
			if(Number(this.win_streak_now) >= Number(this.max_win_streak)){
				this.win_streak_now = 0 ;
				amount = start_bet; 
				
				reset_sistem();
				add_history_developer('Reset At Winstreak '+this.max_win_streak+'x Active - Reset Bet ');		
				
			} 
		}
	}
									
	
	this.reset_losestreak = function(){								
		if(r_state == "loss"){
			this.lose_streak_now++; 
			this.win_streak_now = 0 ;
		} 
		if((this.check_max_lose_streak == true) || (this.check_max_lose_streak == "true")){
			if(Number(this.lose_streak_now) >= Number(this.max_lose_streak)){
				this.lose_streak_now = 0 ;
				amount = start_bet;
				reset_sistem();
				add_history_developer('Reset At Losestreak '+this.max_lose_streak+'x Active - Reset Bet ');		
				
			} 
		} 
	}					
} 



function Constant(){ 
	this.ganda_win = $('#ganda_win').val();
	this.ganda_lose = $('#ganda_lose').val(); 
	this.ganda_win_default = $('#ganda_win').val();
	this.ganda_lose_default = $('#ganda_lose').val(); 
	
	this.active_marti = false; 
	this.active_marti_win = false;  
	
	this.level_marti = $('#level_marti').val();
	this.level_marti_win = $('#level_marti_win').val();
	this.check_win_bet = $("#check_win_bet").is(":checked");
	this.check_lose_bet = $("#check_lose_bet").is(":checked");
	this.reset_win_bet = $('#reset_win_bet').val();
	this.reset_lose_bet = $('#reset_lose_bet').val();			

	this.total_winstreak = 0;
	this.total_losestreak = 0 ;
	
	
	this.total_win_bet = 0;
	this.total_lose_bet = 0 ;
	
	if(Number(this.ganda_win) > 0){ this.ganda_check = true;  } 
	if(Number(this.ganda_lose) > 0){ this.ganda_check = true;  } 
	
	
	
	if(this.ganda_check == true){
		
		tambah_fitur('If Win x'+this.ganda_win  , 'marti_win','text-warning');
		tambah_fitur('If Lose x'+this.ganda_lose  , 'marti_lose','text-warning');
		
		if(this.check_win_bet == true ){ tambah_fitur('Reset If Win '+this.reset_win_bet+'x'  , 'check_reset_marti_win','text-warning'); } 
		if(this.check_lose_bet == true ){ tambah_fitur('Reset If Lose '+this.reset_lose_bet+'x'  , 'check_reset_marti_lose','text-warning'); } 
		 
		if((this.ganda_win_default == "0") || (this.ganda_win_default == "") ){  this.ganda_win_default = 1; } 
		if((this.ganda_lose_default == "0") || (this.ganda_lose_default == "") ){  this.ganda_lose_default = 1; } 		
		if((this.ganda_win == "0") || (this.ganda_win == "") ){  this.ganda_win = 1; } 
		if((this.ganda_lose == "0") || (this.ganda_lose == "") ){  this.ganda_lose = 1; } 		
		if((this.reset_win_bet == "0") || (this.reset_win_bet == "") ){   this.reset_win_bet= 1; } 
		if((this.reset_lose_bet == "0") || (this.reset_lose_bet == "") ){   this.reset_lose_bet= 1;} 	
		
	} 

	
	
	
	 
	
	 
	this.check_marti = function(){	
	
		if(r_state == "win"){
			this.total_losestreak = 0 ;
			this.total_winstreak++; 
		} else { 
			this.total_losestreak++;
			this.total_winstreak = 0 ;
		}
		
		if(Number(this.ganda_win) > 0){ this.ganda_check = true;  } 
		if(Number(this.ganda_lose) > 0){ this.ganda_check = true;  } 
		
		if(this.ganda_check == true){
			if((this.ganda_win_default == "0") || (this.ganda_win_default == "") ){  this.ganda_win_default = 1; } 
			if((this.ganda_lose_default == "0") || (this.ganda_lose_default == "") ){  this.ganda_lose_default = 1; } 	
			if((this.ganda_win == "0") || (this.ganda_win == "") ){ this.ganda_win = 1; } 
			if((this.ganda_lose == "0") || (this.ganda_lose == "") ){ this.ganda_lose = 1; } 		
			if((this.reset_win_bet == "0") || (this.reset_win_bet == "") ){ this.reset_win_bet= 1; } 
			if((this.reset_lose_bet == "0") || (this.reset_lose_bet == "") ){ this.reset_lose_bet= 1;} 		
		} 
		
	
	
		if(this.active_marti == false){
			if(Number(this.total_losestreak) >= Number(this.level_marti)){
				if(Number(this.ganda_lose) > 0){
					this.active_marti = true; 
					add_history_developer('Marti Lose Trigger Losestreak = '+this.level_marti);	
				}
			} 
		}
		 
		if(this.active_marti_win == false){
			if(Number(this.total_winstreak) >= Number(this.level_marti_win)){
				if(Number(this.ganda_win) > 0){				
					this.active_marti_win = true; 
					add_history_developer('Marti Win Trigger Losestreak = '+this.level_marti_win);		
				}
			} 
		}
		
		
		if((this.active_marti_win == true) || (this.active_marti_win == "true")){
			if(this.ganda_check == true){
				if(r_state == "win"){
					if((this.ganda_win != "") && (this.ganda_win != "0") &&(this.ganda_win != "1")){
						
						
						
						
						if(prediction.prediction_check == true){  
							if(Number(prediction.prediction_step) >= 1){
								prediction.prediction_total = Number(amount);
								
								for (let i = 1; i <= Number(prediction.prediction_step); i++) {
									prediction.prediction_total = Number(prediction.prediction_total) * Number(this.ganda_win);
								}
								prediction.prediction_total = Number(prediction.prediction_total).toFixed(2);
								if(Number(balance_default) < Number(prediction.prediction_total)){
									if(prediction.prediction_stop_win == true){
										prediction.active = true; 
									}
									if(prediction.prediction_stop_profit == true){
										prediction.active_stop_profit = true; 
									}
									
									add_history_developer('Prediction, Balance not enought after '+prediction.prediction_step+' step');		
									add_history_developer('Prediction Is '+prediction.prediction_total);	
									add_history_developer('Start Balance Is '+balance_default);

								} 
							}  
						} 
						
						
						
						
						
						amount = Number(Number(amount) * Number(this.ganda_win)).toFixed(9); 
						amount = string_number(amount);
						amount2 = string_number2(Number(amount).toFixed(9));
						add_history_developer('Marti '+this.ganda_win+'x At Win - Bet = '+amount);		

					
						if(Number(amount) <= ar_bet[r_currency]){
							amount = ar_bet[r_currency];
						} 
					}
				}  
			} 
		}  
		
		
		if((this.active_marti == true) || (this.active_marti == "true")){
			if(this.ganda_check == true){
				if(r_state != "win"){ 
					if((this.ganda_lose != "") && (this.ganda_lose != "0") &&(this.ganda_lose != "1")){
						
						
						 
						if(prediction.prediction_check == true){  
							if(Number(prediction.prediction_step) >= 1){
								prediction.prediction_total = Number(amount);
								
								for (let i = 1; i <= Number(prediction.prediction_step); i++) {
									prediction.prediction_total = Number(prediction.prediction_total) * Number(this.ganda_lose);
								}
								prediction.prediction_total = Number(prediction.prediction_total).toFixed(2);
								if(Number(balance_default) < Number(prediction.prediction_total)){
									if(prediction.prediction_stop_win == true){
										prediction.active = true; 
									}
									if(prediction.prediction_stop_profit == true){
										prediction.active_stop_profit = true; 
									}
									
									add_history_developer('Prediction, Balance not enought after '+prediction.prediction_step+' step');		
									add_history_developer('Prediction Is '+prediction.prediction_total);	
									add_history_developer('Start Balance Is '+balance_default);

								} 
							}  
						} 
						
						
						
						
						amount = Number(Number(amount) * this.ganda_lose).toFixed(9); 
						add_history_developer('Marti '+this.ganda_lose+'x At Lose - Bet = '+amount);				
						amount = string_number(amount);
						amount2 = string_number2(Number(amount).toFixed(9));
						if(Number(amount) <= ar_bet[r_currency]){
							amount = ar_bet[r_currency]; 
						}  
						
						
						
						
						
						
						
						
						
						
						
						
						 
					} 
				} 
			} 
		}  
	};
	
	
	
	
	
	this.reset_streak = function(){ 
		if(r_state == "win"){
			this.total_win_bet++;
		} else {
			this.total_lose_bet++;
		}
		
		 
		if(this.check_win_bet == true){ 
			if(r_state == "win"){	 
				if(Number(this.total_win_bet) >= Number(this.reset_win_bet)){
					this.active_marti = false; 
					this.active_marti_win = false; 
					this.total_win_bet = 0 ;
					this.total_lose_bet = 0 ;
					
					amount = start_bet; 
					reset_sistem(); 
					
					add_history_developer('Reset At Bet Win '+this.reset_win_bet+'x Active - Reset System ');		
					chance = default_chance;
					
					
				} 
			}		
		}
		
		
		
		if(this.check_lose_bet == true){ 
			if(r_state != "win"){ 	 
				if(Number(this.total_lose_bet) >= Number(this.reset_lose_bet)){							
					add_history_developer('Reset At Bet Lose '+this.reset_lose_bet+'x Active - Reset System ');		
					amount = start_bet;	
					chance = default_chance; 
					reset_sistem();  
					this.active_marti = false; 
					this.active_marti_win = false; 
					this.total_win_bet = 0 ;
					this.total_lose_bet = 0 ;
					
				}
			} 						
		}
	}
}
var constant = '';











function Rule(){ 
	this.rule = $('#rule').val();
	this.r_rules = $('#rule').val();
	this.rule_start = $('#rule').val();
	this.rule_change_at = $('#high_low_after_bet').val();
	this.rule_change_total = 0;
	this.high_low_after_bet = $('#high_low_after_bet').val();
	this.high_low_after_win = $('#high_low_after_win').val() ;
	this.hilo_win_total = 0 ;
	
	
	if(this.rule != "Random"){
		if(this.rule_change_at >= 1){
			if(high_low_after_win >= 1){
				tambah_fitur('Hi/Lo If Win'+this.high_low_after_win  , 'marti_win','text-warning');
			} else {
				tambah_fitur('Hi/Lo '+this.rule_change_at+'x bet'  , 'marti_win','text-warning');
			}
		} 
	}else {
		if(this.rule_change_at > 1){
			tambah_fitur('Rule Random '+this.rule_change_at+'x bet'  , 'marti_win','text-warning');
		}else {
			tambah_fitur('Rule Random'  , 'marti_win','text-warning');
		}
	}
	
	
	
	
	
	
	this.atur_rule = function(){
		if(this.rule_start != "Random"){				
		this.rule_change_total ++ ;
		if(this.rule_change_at >= 1){
			if(this.rule_change_total == this.rule_change_at){
				this.rule_change_total = 0 ;
				if(this.rule == "over"){
					this.rule = "under"; 
					this.hilo_win_total = 0 ; 
				} else {
					this.rule = "over";
					this.hilo_win_total = 0 ; 
				}
				
				add_history_developer('Change Rule '+this.rule);	
			} else {
				 
				if(this.high_low_after_win >= 1){
					if(this.hilo_win_total >= this.high_low_after_win){
						if(this.rule == "over"){
							this.rule = "under"; 
							this.hilo_win_total = 0 ; 
						} else {
							this.rule = "over";
							this.hilo_win_total = 0 ;  
						} 
						add_history_developer('Change Rule '+this.rule);	
					} 
				} 
				
			} 				
		}
		}
		if(r_state == "win"){
			this.hilo_win_total = Number(this.hilo_win_total) + 1;							
		}  
			
			
	}		
} 
var rule = '';




function Balanceup(){ 	
	this.balance_up_check = $("#balance_up_check").is(":checked") ;
	this.balance_up = $('#balance_up').val();
	this.balance_up_target = Number(this.balance_up) + Number(balance_default);  
	
	if(this.balance_up_check == true){
		tambah_fitur('Reset If Up'+this.balance_up  , 'marti_win','text-warning');
	} 
	
    this.check_reset = function(){
		if(this.balance_up_check == true){
		if(Number(r_balance) >= Number(this.balance_up_target)){
			amount = start_bet;
			reset_sistem();  
			reset_bettinglosestreak();
				
			this.balance_up_target = Number(r_balance) + Number(this.balance_up);
			add_history_developer('Reset System At Balance Up , Target Reset Next = '+this.balance_up_target);	
		} 
		} 
    }
}  
var balanceup = '';





function Bettinglosetreak(){ 	
	this.betting_losestreak = $('#betting_losestreak').val();
	this.betting_winstreak = $('#betting_winstreak').val();
	this.active = false; 
	this.total_profit = 0 ; 
	this.total_losestreak = 0 ; 
	this.total_winstreak = 0 ; 
	this.max_total_profit = 0 ;
	this.save_bet = 0 ; 
	this.betting_plus_mp = $("#betting_plus_mp").is(":checked");
	this.betting_green_2_reset = $("#betting_green_2_reset").is(":checked");
	this.betting_plus_tm = $("#betting_plus_tm").is(":checked");
	this.betting_plus_compound = $("#betting_plus_compound").is(":checked");
	this.betting_check = $("#betting_check").is(":checked");
	this.betting_plus_bet = $("#betting_plus_bet").is(":checked");
	this.betting_plus_input_check = $("#betting_plus_input_check").is(":checked");
	this.betting_plus_input = $('#betting_plus_input').val();
	this.before_amount = 0;
	let storage_1 = 0 ;
	let storage_2 = 0 ;
	let storage_3 = 0 ; 
	let storage_4 = 0 ; 
	
	this.total_green = 0 ;
	 
	
	if(this.betting_plus_input == ""){
		this.betting_plus_input = 0 ; 
	}  
	
	if(Number(this.betting_losestreak) >= 1){
		tambah_fitur('BettingLosestreak '+this.betting_losestreak+'x'  , 'betting_lose','text-warning');
	} 
	if(Number(this.betting_winstreak) >= 1){
		tambah_fitur('BettingWinstreak '+this.betting_winstreak+'x'  , 'betting_win','text-warning');
	} 
	
	if((this.betting_plus_input_check == false) || (this.betting_plus_input_check == "false")){
		this.betting_plus_input = 0 ; 	
	} 
	
	if(this.betting_plus_input == ""){
		this.betting_plus_input = 0 ; 
	}  
	
	
	/*
	 * If Active 
	 * --------------
	 */
	 
	 
	
    this.active_bet = function(){
		
		
		
		if((this.betting_check == "true") || (this.betting_check == true)){
		storage_1 = 0 ;
		storage_2 = 0 ;
		storage_3 = 0 ;
		storage_4 = 0 ;
		let text= '';
		
		
		
		if((this.betting_plus_tm == "true") || (this.betting_plus_tm == true)){
			if(total_profit <= 0){ 
				storage_1 = Number(Math.abs(total_profit)).toFixed(4);
				text += 'TM Now('+storage_1+') '; 
			}	  else {
				 text += 'TM Now(0) '; 
			}	
		} else {
			
			if(this.total_profit <= 0){ 
				storage_1 = Number(Math.abs(this.total_profit)).toFixed(4);
				text += 'TM Accumulate('+storage_1+') '; 
			}	  else {
				 text += 'TM Accumulate (0) '; 
			}	 
		} 
				
		
		
		if((this.betting_plus_bet == true) || (this.betting_plus_bet == "true")){
			storage_2 = Number(old_bet);
			storage_2 += Number(0);
			text += ' +'+String(storage_2) ;
		}
		
		if((this.betting_plus_input_check == true) || (this.betting_plus_input_check == "true")){
			storage_3 = Number(this.betting_plus_input); 
			storage_3 += Number(0);
			text += ' +'+String(storage_3);
		}
				
		if((this.betting_plus_mp == true) || (this.betting_plus_mp == "true")){
			if(Number(total_profit) > 0){
				storage_4 = Number(this.max_total_profit) - Number(total_profit) ; 
				text += ' +'+String(storage_4);
			} 
		} 
		
		
		this.active = true;
		amount = Number(storage_1) + Number(storage_2) + Number(storage_3) + Number(storage_4); 
		text += ' = '+String(amount);
		
		
		

		/* * Prediction  * -------------- */ 
		
		
		if(prediction.prediction_check == true){  
		if(Number(prediction.prediction_step) >= 1){
			prediction.prediction_total = Number(amount);

			add_history_developer('Prediction SBA ');		
			for (let i = 1; i <= Number(prediction.prediction_step); i++) {
				
				if(Number(this.betting_losestreak) >= 1){
					if((this.betting_plus_bet == true) || (this.betting_plus_bet == "true")){
						prediction.prediction_total = Number(prediction.prediction_total) * (Number(this.betting_losestreak) + 1 );
					} else {
						prediction.prediction_total = Number(prediction.prediction_total) * Number(this.betting_losestreak);	
					}
				} else 
				if(Number(this.betting_winstreak) >= 1){
					if((this.betting_plus_bet == true) || (this.betting_plus_bet == "true")){
						prediction.prediction_total = Number(prediction.prediction_total) * (Number(this.betting_winstreak) + 1) ;	
					} else {
						prediction.prediction_total = Number(prediction.prediction_total) * Number(this.betting_winstreak) ;	
					}
				}
 
				if((this.betting_plus_input_check == true) || (this.betting_plus_input_check == "true")){
					prediction.prediction_total = Number(prediction.prediction_total) + Number(this.betting_plus_input); 
				}
				add_history_developer(i+ ' = '+prediction.prediction_total);		
			}
			
			prediction.prediction_total = Number(prediction.prediction_total).toFixed(2);
			if(Number(balance_default) < Number(prediction.prediction_total)){
				
				if(prediction.prediction_stop_win == true){
					prediction.active = true; 
				}
				if(prediction.prediction_stop_profit == true){
					prediction.active_stop_profit = true; 
				}
				
				add_history_developer('Prediction Adj, Not enought after '+prediction.prediction_step+' step');		
				add_history_developer('Prediction Is '+prediction.prediction_total);	
				add_history_developer('Start Balance Is '+balance_default);

			} 
		}  
		}
		
		/* * Close Prediction  * -------------- */

		
		
		add_history_developer(text); 
		  
		this.total_winstreak = 0 ; 
		this.total_losestreak= 0 ;
		
		
		if(cur_reland == "idr"){ amount = Number(amount).toFixed(2); } else 
		if(cur_reland == "usd"){ amount = Number(amount).toFixed(4); } else 
		{ amount = Number(amount).toFixed(4); } 
		
		
		
		}
	}
	
	
	
	
	 
	/*
	 * Check Active Or Not 
	 * --------------
	 */
	
	
	
    this.check = function(){
		
		if(this.active == true){
			if(r_state == "win"){
				this.total_green = Number(this.total_green) + 1; 
			} 
		} 
		
		
		this.total_profit = Number(this.total_profit) + Number(r_profit);	
		
		if(Number(this.max_total_profit) < Number(total_profit)){
			this.max_total_profit = Number(total_profit);
		} 




		
		if((Number(this.betting_losestreak) >= 1) || (Number(this.betting_winstreak) >= 1)){			
			if(r_state == "loss"){
				this.total_losestreak++;
				this.total_winstreak = 0 ;
			} else{
				this.total_losestreak= 0 ;
				this.total_winstreak++;
			}
		}
		
		
	 
		if(Number(this.betting_losestreak) >= 1){
			if(Number(this.total_losestreak) >= Number(this.betting_losestreak)){
				 this.active_bet();
			} 
		}
		
		if(Number(this.betting_winstreak) >= 1){
			if(Number(this.total_winstreak) >= Number(this.betting_winstreak)){
				 this.active_bet();
			} 
		}
		
		
		
		if(this.active == true){
			
			
		} 
		
	 
		
	}
}  
var bettinglosetreak = '';








function Stopif(){ 
	this.check_max_balance = $("#max_balance_check").is(":checked");
	this.check_max_bet = $("#max_bet_check").is(":checked");
	this.check_max_profit = $("#max_profit_check").is(":checked");
	this.max_balance = $('#max_balance').val();
	this.max_bet = $('#max_bet').val();
	this.max_profit = $('#max_profit').val();
	
	
	this.check_reset_target = $("#check_reset_target").is(":checked") ; 
	this.profit_target = $('#profit_target').val();
	this.total_profit_target = $('#profit_target').val();
	
	if(this.check_max_balance){
		tambah_fitur('Stop if balance >= '+this.max_balance  , 'stop_balance','text-warning');
	} 
	
	if(this.check_max_bet){
		tambah_fitur('Stop if bet >= '+this.max_bet  , 'stop_bet','text-warning');
	} 
	
	if(this.check_max_profit){
		tambah_fitur('Stop if profit >= '+this.max_profit  , 'stop_profit','text-warning');
	} 
	
	
    this.reset_if_profit = function(){				
		if(this.check_reset_target == true){
			if(Number(total_profit) >= Number(this.total_profit_target)){
				amount = start_bet; 
				reset_sistem();				
				this.total_profit_target = Number(Number(total_profit) + Number(this.profit_target)).toFixed(20); 
				this.total_profit_target= string_number(this.total_profit_target);		 
				reset_bettinglosestreak();
				
				add_history_developer('Reset System At Profit , Target Reset Next = '+this.total_profit_target);	

				
			} 
		}  		
	};
	
	
	
    this.check_profit = function(){
		if(this.check_max_profit == true){
			if(Number(total_profit) >= Number(this.max_profit)){
				is_break = true; 
				reset_manual = true ;	
				stop_game(); 
				berjalan = false ; 
				add_history_developer('Stop System At Max Profit '+this.max_profit+' Active') ;	


			} 
		} 
	};
	 
	
    this.check_balance = function(){
		if(this.check_max_balance == true){
			if(Number(saldo_active) >= Number(this.max_balance)){
				is_break = true; 
				reset_manual = true ;	
				stop_game(); 
				berjalan = false ; 		
				
				add_history_developer('Stop System At Balance '+this.max_balance+' Active');	

			} 
		} 
	};
	
	
    this.check_bet = function(){				
		if(this.check_max_bet == true){
			if(Number(amount) >= Number(this.max_bet)){
				is_break = true; 
				reset_manual = true ;	
				stop_game(); 
				berjalan = false ; 
				
				add_history_developer('Stop System At Max Bet '+this.max_bet+' Active');	
			} 
		} 
	};
	
	
} 
var stopif = '';
		
		





function Shownumber(){ 			
	this.show_number_check_reset = $("#show_number_check_reset").is(":checked") ;
	this.show_number_check = $("#show_number_check").is(":checked") ;
	this.show_number = $('#show_number').val();
	this.show_now = 0 ;
	
	
	if(this.show_number_check == true){
		tambah_fitur('SOW If show '+this.show_number  , 'sow_if_show','text-warning');
	} 
	
	if(this.show_number_check_reset == true){
		tambah_fitur('Reset If show '+this.show_number  , 'reset_if_show','text-warning');
	} 
		
	
	this.check_stop_win = function(){				
	if(this.show_number_check == true){
		if(Number(this.show_number) > 0){
			this.show_now = Math.abs(r_profit);											
			if(Number(this.show_now) >= Number(this.show_number)){
				active_stop_win();
				
				add_history_developer('Stop On Win Active - Show Number >= '+this.show_number+' ');
			} 
		} 
	} 		
	};
	 
	
	this.check_reset = function(){				
		if(this.show_number_check_reset == true){
		if(Number(this.show_number) > 0){
			this.show_now = Math.abs(r_profit);		
				if(Number(this.show_now) >= Number(this.show_number)){
					amount = Number(start_bet);	 
					reset_sistem();
					reset_lcp();
					reset_bettinglosestreak();
					add_history_developer('Reset System Active - Show Number >= '+this.show_number+' ');
					
				} 		
			} 
		}       	
	};
} 
var show = '';		
	
	
	
	
	
	
	
function Ifbet(){ 
	this.if_bet_win = $('#if_bet_win').val();
	this.if_bet_win_total = $('#if_bet_win_total').val();
	this.if_bet_win_total_total = 0 ;
	
	this.if_bet_lose = $('#if_bet_lose').val();
	this.if_bet_lose_total = $('#if_bet_lose_total').val();
	this.if_bet_lose_total_total = 0 ;
	
	this.total_shownostreak = 0 ;
	this.with_win_streak = $("#with_win_streak").is(":checked") ;
	this.with_win_nostreak = $("#with_win_nostreak").is(":checked") ;
	this.last_profit_streak = 0;
	
	
	if((this.if_bet_win >= 1) && (this.if_bet_win_total >= 1)){
		if(this.with_win_streak == true){
			tambah_fitur('Reset If bet >= '+this.if_bet_win+' WS '+this.if_bet_win_total+'x '  , 'if_bet_winstreak','text-warning');
		}
		if(this.with_win_nostreak == true){
			tambah_fitur('Reset If bet >= '+this.if_bet_win+' Win '+this.if_bet_win_total+'x '  , 'if_bet_winnostreak','text-warning');
		}
	} 
	
	if((this.if_bet_lose >= 1) && (this.if_bet_lose_total >= 1)){
		tambah_fitur('Reset If bet >= '+this.if_bet_win+' LS '+this.if_bet_win_total+'x '  , 'if_bet_losestreak','text-warning');
	}
	
	 
	 
	this.check_win_no_streak = function(){		
		if((this.with_win_nostreak == true) || (this.with_win_nostreak == "true")){
		if(Number(this.if_bet_win_total) >= 1){
		 if(Number(this.if_bet_win) >= 1){
			if(Number(r_profit) >= 1){
				if(Number(r_amount) >= Number(this.if_bet_win)){
					this.total_shownostreak++;
					if(this.total_shownostreak >= this.if_bet_win_total){												
						reset_sistem();
						amount = start_bet;	
						this.total_shownostreak =0 ;
						
						add_history_developer('Reset System Active - If Bet '+this.if_bet_win_total+'x Win ');
				
					} 
				} 
			} 
		}  
		}  
		}  
	}
	
	
	this.check_win_streak  = function(){						
		if((this.with_win_streak == true) || (this.with_win_streak == "true")){
		 if(Number(this.if_bet_win_total) >= 2){
		 if(Number(this.if_bet_win) >= 1){
		 if(Number(r_profit) >= 1){
			 if(Number(r_amount) >= Number(this.if_bet_win)){									
				 this.last_profit_streak++;
				 if(Number(this.last_profit_streak) >= Number(this.if_bet_win_total)){
					
					reset_sistem();
					amount = start_bet;	
					this.last_profit_streak =0 ;
					add_history_developer('Reset System Active - If Bet '+this.if_bet_win_total+'x Winstreak ');

				 } 
			 } else {
				 this.last_profit_streak = 0 ; 
			 }
			 
			 
		 } else {
			 this.last_profit_streak = 0 ; 
		 }
		 }
		 
		 
		 } else {
			if(Number(this.if_bet_win) >= 1){
				if(Number(r_profit) >= 1){
					if(Number(r_amount) >= Number(this.if_bet_win)){
						reset_sistem();
						amount = start_bet; 
						this.last_profit_streak =0 ;
						add_history_developer('Reset System Active - If Bet 1x Win ');

					}
				} 
			}  
		 }  
		}
	}
	
	
	
	this.check_lose_streak  = function(){						
		 if(Number(this.if_bet_lose_total) >= 2){
		 if(Number(this.if_bet_lose) >= 1){
		 if(Number(r_profit) <= 0){
			 
			 if(Number(r_amount) >= Number(this.if_bet_lose)){									
				 this.if_bet_lose_total_total++;
				 if(Number(this.if_bet_lose_total_total) >= Number(this.if_bet_lose_total)){
					reset_sistem();
					amount = start_bet;	
					this.if_bet_lose_total_total =0 ;
					add_history_developer('Reset System Active - If Bet '+this.if_bet_lose_total+'x Losetreak ');
				 } 
			 } else {
				 this.if_bet_lose_total_total = 0 ; 
			 }
			 
			 
		 } else {
			 this.if_bet_lose_total_total = 0 ; 
		 }
		 }
		 } else {
			  
		 if(Number(this.if_bet_lose) >= 1){
			 if(Number(r_profit) <= 0 ){
				 if(Number(r_amount) >= Number(this.if_bet_lose)){
					reset_sistem();
					amount = start_bet;	
					this.if_bet_lose_total_total =0 ;
					add_history_developer('Reset System Active - If Bet 1x Lose ');

				 }
			 } 
			} 
		 }  
	}
	
	
} 
var ifbet = '';


function Recovery(){ 			
	this.losetreak_max_check = $("#losetreak_max_check").is(":checked") ;
	this.losetreak_max = $('#losetreak_max').val();
	this.losetreak_chance = $('#losetreak_chance').val();
	this.losetreak_x = $('#losetreak_x').val();
	this.max_recovery_active = $('#max_recovery_active').val(); ;
	this.total_recovery_active = 0 ;
	this.recovery_target = 0 ;
	this.recovery_active = false ; 
	this.recovery_waiting = false ; 
	this.recovery_profit = 0 ;
	 
	
	if(this.losetreak_max_check == true){
		tambah_fitur('RCV x'+this.losetreak_x+'Total Lose At Active '  , 'rcv','text-warning');
		tambah_fitur('Active RCV At Losestreak '+this.losetreak_max+'x '  , 'rcv2','text-warning');
	}	
	
		
	this.check_recovery = function(){			
		if(this.losetreak_max_check == true){ 
		if(this.recovery_active == false){ 
		if(this.recovery_waiting == true){ 
			if(r_state == "win"){
				this.recovery_active = true; 
				this.total_recovery_active++;
				
				$('#rcv').addClass('active');
				$('#rcv2').addClass('active');
				
				amount = Number(Math.abs(this.recovery_profit) * Number(this.losetreak_x)).toFixed(0);
				this.recovery_target = Number(Math.abs(this.recovery_profit)) + 1 ; 
				if(this.losetreak_chance >= 1){
					chance = this.losetreak_chance;
					add_history_developer('Recovery Active Bet = '+amount+' Until '+this.max_recovery_active+'x Play ');
				}
			} 
		} 
		}
		}
	};
	
	
	this.check_waiting = function(){					
		if(this.recovery_active == false){
		if(this.losetreak_max_check == true){
			if(r_state == "loss"){  
				if(this.losetreak_max >= 1){
					if(streak.now_lose_streak >= this.losetreak_max){													
						this.recovery_waiting = true; 
					}  
				}  
			}  
		}
		}
	};
	
	
	this.finish_recovery = function(){																
		if(this.recovery_active == true){ 
				if(this.max_recovery_active >= 1){
					if(Number(this.total_recovery_active) >= Number(this.max_recovery_active)){
						amount = start_bet;
						chance = default_chance; 
						this.recovery_active = false;
						this.recovery_waiting = false; 
						this.recovery_target = 0 ; 
				
						$('#rcv').removeClass('active');
						$('#rcv2').removeClass('active');

						reset_sistem();
						amount = start_bet;
						chance = default_chance; 
						this.recovery_active = false;
						this.recovery_waiting = false; 
						this.recovery_target = 0 ; 
						this.total_recovery_active = 0 ; 
						this.recovery_profit = 0 ; 
						$('#total_profit2').html('0');
						add_history_developer('Recovery Stop , Total Recovery Active = '+this.max_recovery_active+'x ');
					} 
				} 
		} 
		
	};
	
} 
var recovery = '';		
	

function Emergency(){ 
	this.emergency_chance = $('#emergency_chance').val();
	this.emergency_max = $('#emergency_max').val();
	this.emergency_active = false; 
	this.max_emergency_active = $('#max_emergency_active').val();
	
	if(this.emergency_max >= 1){
		tambah_fitur('Emergency At '+this.emergency_max+'Losestreak '  , 'emergency','text-warning');
	}	
	

		
	this.reset_emergency = function(){		 
		if(this.emergency_active == true){
			if(Number(total_profit) >  0){
				this.emergency_active = false;  
				chance = default_chance;  
				add_history_developer('Emergency Is Stop , Bot Is Profit');
				$('#emergency').removeClass('active');

			}  
		} 
	};
	
	
	this.check_active = function(){					
		if((this.emergency_max != "") && (this.emergency_max != "0") && (this.emergency_max != 0)){
			if(Number(streak.now_lose_streak) >= Number(this.emergency_max)){
				if((this.emergency_chance != "") && (this.emergency_chance != "0") && (this.emergency_chance != 0)){
					this.emergency_active = true; 
					chance = this.emergency_chance;  
					add_history_developer('Emergency Is Stop , Bot Is Profit');
					$('#emergency').addClass('active');
				}
			} 
		} 							
	};
	
	
	this.finish_recovery = function(){																
		 
	};
	
} 
var emergency = '';	




function Stepmarti(){ 
	
	this.step_marti_lose = $("#step_marti_lose").is(":checked") ;
	this.marti_list = [];
	this.marti_list[0] = 1;
	this.marti_list[2] = 1;
	this.marti_list[3] = 1;
	this.marti_list[4] = 1;
	this.marti_list[5] = 1;
	this.marti_list[6] = 1;
	this.marti_list[7] = 1;
	this.marti_list[8] = 1;
	this.marti_list[9] = 1;
	
	this.marti_position = 0 ;
	
	this.waiting = false;
	this.waiting_total = 0 ;
	this.martix = 1 ; 
	
	
	if((this.step_marti_lose  == true) || (this.step_marti_lose == "true")){
		tambah_fitur('Step Marti Lose'  , 'sml','text-warning');
		
		if($('#sl_1').val != ""){ this.marti_list[0] = Number($('#sl_1').val()) ; } 
		if($('#sl_2').val != ""){ this.marti_list[1] = Number($('#sl_2').val()) ; } 
		if($('#sl_3').val != ""){ this.marti_list[2] = Number($('#sl_3').val()) ; } 
		if($('#sl_4').val != ""){ this.marti_list[3] = Number($('#sl_4').val()) ; } 
		if($('#sl_5').val != ""){ this.marti_list[4] = Number($('#sl_5').val()) ; } 
		if($('#sl_6').val != ""){ this.marti_list[5] = Number($('#sl_6').val()) ; } 
		if($('#sl_7').val != ""){ this.marti_list[6] = Number($('#sl_7').val()) ; } 
		if($('#sl_8').val != ""){ this.marti_list[7] = Number($('#sl_8').val()) ; } 
		if($('#sl_9').val != ""){ this.marti_list[8] = Number($('#sl_9').val()) ; } 
		if($('#sl_10').val != ""){ this.marti_list[9] = Number($('#sl_10').val()) ; } 
	
	}	
	
		
		
		
		
	this.marti = function(){		 
		if((this.step_marti_lose  == true) || (this.step_marti_lose == "true")){
			
			
			if((this.waiting == false) || (this.waiting == "false")){
				if((Number(this.marti_position) < 10)){
					
					if(r_state == "loss"){
						this.martix = Number(this.marti_list[Number(this.marti_position)]);
						amount = Number(amount) * Number(this.martix);
						
						
						if(cur_reland == "usd"){ amount = Number(amount).toFixed(4); } else 
						if(cur_reland == "idr"){ amount = Number(amount).toFixed(2); } else {
							amount = Number(amount).toFixed(4);
						}
												
						this.marti_position = Number(this.marti_position) + 1 ; 
						add_history_developer('Marti Step '+this.marti_position+' (x'+this.martix+') = '+amount);
				
					}
					
				} else {
					if(r_state == "win"){
						this.marti_position = 0; 
						this.waiting = true;
						this.waiting_total = 0 ; 
					} else {
						amount = Number(amount) * Number(this.marti_list[9]);
						
						if(cur_reland == "usd"){ amount = Number(amount).toFixed(4); } else 
						if(cur_reland == "idr"){ amount = Number(amount).toFixed(2); } else {
							amount = Number(amount).toFixed(4);
						}
						
						add_history_developer('Marti Step '+this.marti_position+' (x'+this.martix+') = '+amount);
						
						
					}
				}
				
			
			} else {
				this.waiting_total = Number(this.waiting_total) + 1; 
				if(Number(this.waiting_total) >= 2){
					this.waiting = false; 
					this.marti_position = 0 ;
					this.waiting_total = 0 ; 
				} 
			}
			
			
			
			 
			
		} 
	};
	
	
} 
var stepmarti = '';	




function Balanceadd(){ 
	this.waiting_profit = false;
	this.balance_start_lose = 0 ;
	this.balance_start_add = $('#balance_start_add').val();
	this.balance_start_profit = 0;
	
	
	if(this.balance_start_add > 0){
		tambah_fitur('Balance Add '+this.balance_start_add+' Reset Bet'  , 'balance_add','text-warning');
	}	
	

	this.waiting_check = function(){
		if(Number(this.balance_start_add) > 0){
			
		if(this.balance_start_profit == 0){
			this.balance_start_profit = r_balance; 
		} 
		
		if(Number(r_profit) < 0){
			if((this.waiting_profit == "false") || (this.waiting_profit == false)){
				this.balance_start_lose = r_balance;
				this.waiting_profit  = true; 
				this.balance_start_profit = r_balance; 
				add_history_developer(' First Lose , Balance Add Active . Waiting Balance > '+this.balance_start_lose);
				
				
				$('#balance_add').addClass('active');
				$('#balance_add').removeClass('text-yellow');
				$('#balance_add').addClass('text-success');  
			} 
		} 
		}		
	};  
	
	
	this.profit_finish = function(){
		
		if(Number(this.balance_start_add) >= 1){
			if(Number(r_balance) > (Number(this.balance_start_profit) + Number(this.balance_start_add)) ){
				add_history_developer('Now Balance > '+r_balance+" , Reset System ");
				
				
				reset_sistem();
				amount = start_bet;	
				this.waiting_profit = false ; 
				this.balance_start_lose = 0 ;
				this.balance_start_profit = r_balance;  
				$('#balance_add').removeClass('active');
				$('#balance_add').addClass('text-yellow');
				$('#balance_add').removeClass('text-success'); 
				reset_bettinglosestreak();
				
				
			}
		} 
		
		
		if(this.waiting_profit == true){ 
			if(r_profit > 0){
				if(Number(r_balance) > (Number(this.balance_start_lose) + Number(this.balance_start_add)) ){
					add_history_developer('Now Balance > '+this.balance_start_lose+" , Reset System ");
					reset_sistem();
					amount = start_bet;	
					this.waiting_profit = false ; 
					this.balance_start_lose = 0 ;
					this.balance_start_profit = r_balance;  
				
					reset_bettinglosestreak();
				
					
					$('#balance_add').removeClass('active');
					$('#balance_add').addClass('text-yellow');
					$('#balance_add').removeClass('text-success');
				} 
			} 
		} 
	};  
	
	
} 

var balanceadd = '';	












function Profitadd(){ 
	this.waiting_profit = false;
	this.balance_start_lose = 0 ;
	this.profit_start_add = $('#profit_start_add').val();
	this.balance_start_profit = 0;
	
	this.profit_add_stop = $("#profit_add_stop").is(":checked") ;
	this.profit_add_reset = $("#profit_add_reset").is(":checked") ;
	
	
	
	if(this.profit_start_add > 0){
		if((this.profit_add_reset == true) || (this.profit_add_reset == "true")){
			tambah_fitur('Profit Add '+this.profit_start_add+' Reset Bet'  , 'profit_add','text-warning');
		} 
		if((this.profit_add_stop == true) || (this.profit_add_stop == "true")){
			tambah_fitur('Profit Add '+this.profit_start_add+' Stop game'  , 'profit_add','text-warning');		
		}
	}	
	

	this.waiting_check = function(){
		if(Number(this.profit_start_add) > 0){
		
		if((this.profit_add_reset == true) || (this.profit_add_reset == "true") || (this.profit_add_stop == true) || (this.profit_add_stop == "true")){
			
			if(this.balance_start_profit == 0){
				this.balance_start_profit = total_profit_all; 
			} 
			
			if(Number(r_profit) < 0){
				if((this.waiting_profit == "false") || (this.waiting_profit == false)){
					this.balance_start_lose = total_profit_all;
					this.waiting_profit  = true; 
					this.balance_start_profit = total_profit_all; 
					add_history_developer(' First Lose , Profit Add Active . Waiting Profit > '+(Number(this.balance_start_lose) + Number(this.profit_start_add) ));
				
					$('#profit_add').addClass('active');
					$('#profit_add').removeClass('text-yellow');
					$('#profit_add').addClass('text-success');  
				} 
			} 
		
		}		
		}		
		
	};  
	
	
	this.profit_finish = function(){
		if(Number(this.profit_start_add) > 0){
			if(Number(total_profit_all) > (Number(this.balance_start_profit) + Number(this.profit_start_add)) ){

				if((this.profit_add_reset == true) || (this.profit_add_reset == "true")){
					add_history_developer('Now Profit > '+total_profit_all+" , Reset System ");
					 
					reset_sistem();
					reset_bettinglosestreak();
				
					amount = start_bet;	
					this.waiting_profit = false ; 
					this.balance_start_lose = 0 ;
					this.balance_start_profit = total_profit_all;  
					$('#profit_add').removeClass('active');
					$('#profit_add').addClass('text-yellow');
					$('#profit_add').removeClass('text-success'); 
				} else 
				if((this.profit_add_stop == true) || (this.profit_add_stop == "true") ){
					add_history_developer('Now Profit > '+total_profit_all+" , Reset System ");

					reset_manual = true ;
					stop_game(); 
					berjalan = false ; 
					
					
				} 
				
			}
		} 
		
		
		if(this.waiting_profit == true){ 
			if(r_profit > 0){
				if(Number(total_profit_all) > (Number(this.balance_start_lose) + Number(this.profit_start_add)) ){
					
					if((this.profit_add_reset == true) || (this.profit_add_reset == "true")){
						add_history_developer('Now Profit > '+this.balance_start_lose+" , Reset System ");
					
						reset_sistem();
						amount = start_bet;	
						this.waiting_profit = false ; 
						this.balance_start_lose = 0 ;
						this.balance_start_profit = total_profit_all;  
						reset_bettinglosestreak();
				
						
						$('#profit_add').removeClass('active');
						$('#profit_add').addClass('text-yellow');
						$('#profit_add').removeClass('text-success');
					} else 						
					if((this.profit_add_stop == true) || (this.profit_add_stop == "true") ){
						add_history_developer('Now Profit > '+this.balance_start_lose+" , Reset System ");
					
						reset_manual = true ;
						stop_game(); 
						berjalan = false ; 
					
					
					} 
					
				} 
			} 
		} 
	};  
} 

var profitadd = '';	


function StepPO(){ 
	this.po_start = $('#po_start').val();
	this.po_stop = $('#po_stop').val();
	this.po_step  =$('#po_step').val();
	this.po_always = $("#po_always").is(":checked") ;
	this.po_check = $("#po_check").is(":checked") ;
	this.po_now = this.po_start;

	this.setup_chance = function(){	
		if((this.po_check == true) || (this.po_check == "true")){
			chance = Number(this.po_start);
			default_chance = Number(this.po_start); 
		} 
	}; 
	
	
	
	if(this.po_check >= 1){
		tambah_fitur('CH '+this.po_start+' - '+this.po_stop+' ('+this.po_step+' Step)'  , 'po','text-warning');
		if(this.po_stop >= 98){
			this.po_stop = 98;
		} 
	}	
	
	
	this.chance_change = function(){	
		
		if((this.po_check == true) || (this.po_check == "true")){
			if((this.po_always == false) || (this.po_always == "false")){
			this.po_now = Number(this.po_now) + Number(this.po_step);
			if(Number(this.po_now) > Number(this.po_stop)){
				this.po_now = Number(this.po_start); 
			} 
			chance = Number(this.po_now).toFixed(2);  
			}
		} 
		
	};  
	
	
	this.chance_change_always = function(){	
		if((this.po_check == true) || (this.po_check == "true")){
			if((this.po_always == true) || (this.po_always == "true")){
			this.po_now = Number(this.po_now) + Number(this.po_step);
			if(Number(this.po_now) > Number(this.po_stop)){
				this.po_now = this.po_start; 
			} 
			chance = Number(this.po_now).toFixed(2); 
			}
		} 
		
	};  
} 
var po = '';	








function Rolls(){ 
	this.rolls_step_win = $('#rolls_step_win').val();
	this.rolls_step_lose = $('#rolls_step_lose').val();
	this.rolls_active_at  =$('#rolls_active_at').val();
	this.rolls_streak = $("#rolls_streak").is(":checked") ;
	this.rolls_nostreak = $("#rolls_nostreak").is(":checked") ;
	 
	this.rolls_check = $("#rolls_check").is(":checked") ;
	this.active_rolls = false ; 
	
	
	if(this.po_check >= 1){
		if(this.rolls_step_win > 0){
			tambah_fitur('MartiRolls Win +'+this.rolls_step_win  , 'rolls_win','text-warning');
		} 
		if(this.rolls_step_lose > 0){
			tambah_fitur('MartiRolls Lose +'+this.rolls_step_lose  , 'rolls_lose','text-warning');
		} 
	}	
	 
	
	
	
	this.up_marti = function(){		
		if(r_state == "win"){ 
			if(Number(this.rolls_step_win) > 0){
				constant.ganda_win = Number(constant.ganda_win) + Number(this.rolls_step_win); 
				add_history_developer('Rolls , Marti Win +'+this.rolls_step_win+" , IfWin x"+constant.ganda_win);
			} 
		} else {
			if(Number(this.rolls_step_lose) > 0){
				constant.ganda_lose = Number(constant.ganda_lose) + Number(this.rolls_step_win); 
				add_history_developer('Rolls , Marti Lose +'+this.rolls_step_lose+" , IfLose x"+constant.ganda_lose);
			} 
		} 
		
		this.ganda_check == true; 
		
		if(constant.active_marti == false){
			if(Number(streak.now_lose_streak) >= Number(constant.level_marti)){
				constant.active_marti = true; 
			} 
		}
		 
		if(constant.active_marti_win == false){
			if(Number(streak.now_win_streak) >= Number(constant.level_marti_win)){
				constant.active_marti_win = true; 
			} 
		}
		
		
	}
	
	
	
	this.step = function(){		
		if((this.rolls_check == true) || (this.rolls_check == "true")){
			
			
			if((this.active_rolls == false) || (this.active_rolls == "false")){
				if((this.rolls_streak == true) || (this.rolls_streak == "true")){
					if(streak.now_lose_streak >= this.rolls_active_at){
						this.active_rolls = true; 
						add_history_developer('Active Rolls System - Total Losestreak '+this.rolls_active_at+'x ');
						this.up_marti();
					} 
				} 
			
				if((this.rolls_nostreak == true) || (this.rolls_nostreak == "true")){
					if(streak.total_lose >= this.rolls_active_at){
						this.active_rolls = true; 
						add_history_developer('Active Rolls System - Total Lose '+this.rolls_active_at+'x ');
						this.up_marti();
					} 
				} 
			} else{
				this.up_marti();
			} 	 
		
		  
		}
	};  
} 
var rolls = '';	




function ResetAt(){ 
	this.check_reset = $("#check_reset").is(":checked") ;
	this.reset_profit = $('#reset_profit').val();


	if(this.check_reset == true){
		tambah_fitur('Clear At Profit +'+this.reset_profit  , 'clear_profit','text-warning');
	}	
	

	this.reset = function(){		
		if((this.check_reset == true) || (this.check_reset == "true")){
			if(Number(total_profit) >= Number(this.reset_profit)){
				reset_sistem2(); 
				add_history_developer('Clear System , Profit > '+this.reset_profit+" ");
			} 
		} 

	}; 
	this.chance_change = function(){	 
	};  
} 
var reset_at_profit = '';	
		




function Disabled_feature(){ 
	this.disabled_lose = $("#disabled_lose").is(":checked") ;
} 

var disabled_feature = ''; 




function Chance_random(){ 
	this.check_random = $("#chance_random").is(":checked") ;
	this.min_chance = $('#chance_min').val();
	this.max_chance = $('#chance_max').val();
	
	if (this.check_random == true){
		chance = randomNumber(this.min_chance , this.max_chance);
		tambah_fitur('CH Random'  , 'clear_profit','text-warning');
	}	
	
	this.setup_chance = function(){	
		if (this.check_random == true){
		chance = randomNumber(this.min_chance , this.max_chance);		
		}
	};  
	if(chance >= 98){
		chance = 98;
	}  	 
} 
var chance_random = new Chance_random(); 







function Betting_level(){ 
	this.betting_adjust_check = $("#betting_adjust_check").is(":checked") ;
	this.betting_level_check = $("#betting_level_check").is(":checked") ;
	this.betting_adjust = $('#betting_adjust').val();
	this.betting_level_lose = $('#betting_level_lose').val();
	this.betting_reset_win = $('#betting_reset_win').val();
	this.betting_bet_accumulate = 0 ; 
	this.total_losestreak = 0 ; 
	this.total_win = 0 ;
	this.active_bet = false; 
	this.active_adjust = false ;
	this.total_adjust= 0 ; 
	 
	if (this.betting_level_check == true){
		tambah_fitur('Betting Level '+this.betting_level_lose  , 'bl_check','text-warning');
		tambah_fitur('Adjust +'+this.betting_adjust  , 'bl_adjust','text-warning');
	}	
	
	
	
	this.check = function(){	
		if (this.betting_level_check == true){
			
			if(r_state == "win"){
				this.total_win = Number(this.total_win) + 1; 
				this.total_losestreak = 0 ; 
				this.betting_bet_accumulate = 0; 
			} else {
				this.total_losestreak = Number(this.total_losestreak) + 1; 
				this.betting_bet_accumulate = Number(this.betting_bet_accumulate) + Number(r_amount) ; 
			}
			
			
		
			
			if(Number(this.total_losestreak) >= Number(this.betting_level_lose)){
				amount = Number(this.betting_bet_accumulate) ; 
				this.active_bet = true; 
				this.total_losestreak = 0 ; 
				this.betting_bet_accumulate = 0 ; 
				this.total_win = 0 ; 
				
				if (this.betting_adjust_check == true){
					let new_amount = Number(amount) + Number(this.betting_adjust);
					add_history_developer(amount + " + "+this.betting_adjust +" = "+new_amount);
					amount = new_amount;
				} 
								
			
				this.total_adjust = Number(this.betting_adjust) * Number(this.betting_level_lose); 
				if(this.active_adjust == true){
					let new_amount = Number(amount) - Number(this.total_adjust);
					add_history_developer(amount + " - "+this.total_adjust +" = "+new_amount);
					amount = new_amount; 
				} 				
				
				
				
				
				
				/* * Prediction  * -------------- */ 
					if(prediction.prediction_check == true){  
						if(Number(prediction.prediction_step) >= 1){
							prediction.prediction_total = Number(amount);
							
							for (let i = 1; i <= Number(prediction.prediction_step); i++) {
								prediction.prediction_total = Number(prediction.prediction_total) * Number(this.betting_level_lose);
								prediction.prediction_total = Number(prediction.prediction_total) - Number(Number(this.betting_adjust) * Number(this.betting_level_lose)) ;  
							}
							
							prediction.prediction_total = Number(prediction.prediction_total).toFixed(2);
							if(Number(balance_default) < Number(prediction.prediction_total)){
								
								if(prediction.prediction_stop_win == true){
									prediction.active = true; 
								}
								if(prediction.prediction_stop_profit == true){
									prediction.active_stop_profit = true; 
								}
								
								add_history_developer('Prediction Adj, Not enought after '+prediction.prediction_step+' step');		
								add_history_developer('Prediction Is '+prediction.prediction_total);	
								add_history_developer('Start Balance Is '+balance_default);

							} 
						}  
					}
				/* * Close Prediction  * -------------- */
				
				
		
				
				
				
				this.active_adjust=  true ;
				add_history_developer('Betting Lose Active , Bet = '+amount);
			} 
		
		
		
		
		
		
		
		
			
			if(r_state == "win"){
				if(Number(this.total_win) >= Number(this.betting_reset_win) ){
					this.total_win = 0 ;
					this.betting_bet_accumulate = 0 ;
					this.total_losestreak = 0;
					this.active_bet = false; 
					this.active_adjust = false ;
					
					amount = start_bet;  
					
				} 
			} 
			
			
			
			fixed_amount();
			
		}			
	};   
} 
var betting_level = ''; 








function Zigzag(){ 
	this.check_zigzag = $("#check_zigzag").is(":checked") ;
	this.max_zigzag = $('#max_zigzag').val();
	this.total_zigzag = 0 ;
	this.before_zigzag = "" ;
	

	if (this.check_zigzag == true){
		tambah_fitur('Zigzag '+this.max_zigzag+'x Reset Bet'  , 'zigzag','text-warning');
	}	
	
	
	this.check_reset = function(){	
		if(this.check_zigzag == true){
			if(this.before_stat == ""){
				this.before_stat = r_state ; 
				this.total_zigzag = 1; 
			} else {
				if(this.before_stat != r_state){
					this.total_zigzag++;
				} else{
					this.total_zigzag = 1; 
				}	
			}
			
			if(this.total_zigzag >= this.max_zigzag){
				this.total_zigzag = 0; 
				this.before_stat = ""; 
				
				add_history_developer('Zigzag Trigger  '+this.max_zigzag+"x , Reset System ");
				reset_sistem();
				amount = start_bet;	
			} 	
		}
	};  
	
} 
var zigzag = ''; 







function Strategy_reset(){ 
	this.st_check = $("#st_check").is(":checked") ;
	this.total_winstreak = 0 ;
	this.total_losestreak = 0 ;
	this.total_win = 0 ;
	this.total_lose = 0 ;
	this.waiting_win = false; 
	
	if((this.st_check == true) || (this.st_check == "true")){
		this.st_streak = $("#st_streak").is(":checked") ;
		this.st_nostreak = $("#st_nostreak").is(":checked") ;
		this.st_amount = $('#st_amount').val();
		this.st_max_total_lose = $('#st_max_total_lose').val();
		this.st_max_total_win = $('#st_max_total_win').val(); 
		tambah_fitur('Strategy Reset'  , 'strategy_reset','text-warning');
	}
	
	
	this.check_reset = function(){	
		if((this.st_check == true) || (this.st_check == "true")){
		
			if(Number(r_amount) >= Number(this.st_amount)){
				if(r_state == "win"){
					this.total_win++;
					this.total_winstreak++;
					this.total_losestreak = 0 ;
				} else {
					this.total_lose++;
					this.total_losestreak++;
					this.total_winstreak = 0 ; 
				}
			} else {
				this.total_winstreak = 0 ;
				this.total_losestreak = 0 ;
			}
			
			
			
			if((this.waiting_win == false) || (this.waiting_win == "false")){
				if((this.st_streak == true) || (this.st_streak == "true")){
					if(Number(this.total_losestreak) >= Number(this.st_max_total_lose)){
						this.waiting_win = true; 
						add_history_developer('Trigger Strategy Waiting Win  ');
						this.total_win = 0 ;
					} 
				} else {
					if(Number(this.total_lose) >= Number(this.st_max_total_lose)){
						this.waiting_win = true;
						add_history_developer('Trigger Strategy Waiting Win  ');
						this.total_win = 0 ;
					} 
				} 
			}
			
			
			if((this.waiting_win == true) || (this.waiting_win == "true")){
	
				if(Number(this.st_max_total_win) >= 1){
					if(Number(this.total_win) >= Number(this.st_max_total_win)){
						
						this.total_winstreak = 0 ;
						this.total_losestreak = 0 ;
						this.total_lose = 0 ;
						this.total_win = 0 ;
						this.waiting_win = false ; 
						
						add_history_developer('Trigger Strategy Reset , Reset System ');
						reset_sistem();
						amount = start_bet;	
						
					} 
				} else {
					
						this.total_winstreak = 0 ;
						this.total_losestreak = 0 ;
						this.total_lose = 0 ;
						this.total_win = 0 ;
						this.waiting_win = false ; 
						
						add_history_developer('Trigger Strategy Reset , Reset System ');
						reset_sistem();
						amount = start_bet;	
						
				}
			} 
			 
		} 
	};  
} 

var strategy_reset = "" ; 


function Bad_history(){ 
	this.bad_check_reset = $("#bad_check_reset").is(":checked") ;
	this.bad_total = $('#bad_total').val();
	this.bad_win = $('#bad_win').val();
	this.bad_amount = $('#bad_amount').val();
	this.data = [];
	this.i = 0 ;
	this.total_win = 0;
	this.total_lose = 0 ;
	this.save_bet = 0 ;
	
	
	if((this.bad_check_reset == true) || (this.bad_check_reset == "true")){
		tambah_fitur('Strategy BadHistory '+this.bad_total  , 'bad_history','text-warning');
	} 
	 
	this.check_reset = function(){	
		if((this.bad_check_reset == true) || (this.bad_check_reset == "true")){
			
			if(Number(this.data.length) >= Number(this.bad_total)){
				this.data.shift(); 
			}
			this.data.push(r_state);		
			
			if(Number(this.data.length) >= Number(this.bad_total)){
				this.total_win = 0 ;
				this.total_lose= 0 ;
				
				for (this.i = 0; this.i < this.bad_total; this.i++) {	
					if(this.data[this.i] == "win"){
						this.total_win++; 
					} else {
						this.total_lose++; 
					}
				}
				
				
				if(Number(this.total_win) <= Number(this.bad_win)){
					if(Number(r_amount) >= Number(this.bad_amount)){
						
						this.save_bet = r_amount;
						add_history_developer('Trigger Bad History , Reset System ');
						reset_sistem();
						amount = start_bet;	
						this.data = [];
						 
					} 
				} 
				
				
				
			}
			
			
			
		}
	};  
} 

var bad_history = "" ; 




function Prediction(){ 
	this.prediction_check = $("#prediction_check").is(":checked") ;
	this.prediction_stop_win = $("#prediction_stop_win").is(":checked") ;
	this.prediction_stop_profit = $("#prediction_stop_profit").is(":checked") ;
	this.prediction_step = $('#prediction_step').val();
	this.active = false ; 
	this.active_stop_profit = false ; 
	this.prediction_total = 0 ; 
	
	if((this.prediction_check == true) || (this.prediction_check == "true")){
		tambah_fitur('Strategy Prediction '+this.prediction_step  , 'prediction','text-warning');
	} 
	 
} 


var prediction = "" ; 


function Lack(){ 
	this.lack_check = $("#lack_check").is(":checked") ;
	this.lack_bet = $('#lack_bet').val();
	this.lack_percent_bet = $('#lack_percent_bet').val();
	this.lack_ws = $('#lack_ws').val();
	this.lack_ls = $('#lack_ls').val();
	this.lack_stop_if = $('#lack_stop_if').val();
	this.now_win_streak = 0;
	this.now_lose_streak = 0 ; 
	this.bet = 0 ;
	
	
	this.lack_balance_down = $('#lack_balance_down').val();
	this.selisih = 0 ; 
	this.lack_stop = false; 
	
	
	if((this.lack_check == true) || (this.lack_check == "true")){ 
		tambah_fitur('Lack Bet '+this.lack_bet  , 'lack','text-warning');
	}  
	
	
	this.check = function(){
		if(r_state == "win"){
			this.now_lose_streak = 0 ;
			this.now_win_streak++; 
		} else {
			this.now_lose_streak++;
			this.now_win_streak = 0 ;
		}
		
	
		if((this.lack_check == true) || (this.lack_check == "true")){
			
			if(Number(this.lack_ws) >= 1){
				if(Number(this.now_win_streak) >= Number(this.lack_ws)){
					if(Number(sub_total_down_max_balance) >= 0){
						this.bet = Number(Number(sub_total_down_max_balance) * Number(this.lack_percent_bet)) / 100 ;
						if(Number(this.bet) >= Number(min_bet)){
							amount = this.bet; 
							add_history_developer('Lack Bet = '+this.lack_percent_bet+'% From '+sub_total_down_max_balance);
							add_history_developer('Bet = '+amount);
							
							this.now_win_streak = 0 ;
						} 
					} 
				} 
			}
			
			
			if(Number(this.lack_ls) >= 1){
				if(Number(this.now_lose_streak) >= Number(this.lack_ls)){
					if(Number(sub_total_down_max_balance) >= 0){
						this.bet = Number(Number(sub_total_down_max_balance) * Number(this.lack_percent_bet)) / 100 ;
						if(Number(this.bet) >= Number(min_bet)){
							amount = this.bet; 
							add_history_developer('Lack Bet = '+this.lack_percent_bet+'% From '+sub_total_down_max_balance);
							add_history_developer('Bet = '+amount);
							
							this.now_lose_streak = 0 ;
						} 
					} 
				} 
			}
			
			if(Number(r_balance) >= Number(Number(this.lack_stop_if) + Number(balance_default) )){
				reset_manual = true; 
				stop_game();
				add_history_developer('Lack Stop Game - Reset All Feature');
				restart_bot();
			} 
			 
			
			
		this.selisih = Number(max_balance) - Number(r_balance); 
		sub_total_down_max_balance = Number(Number(total_down_max_balance) + Number(lack.selisih)).toFixed(4);
		$('#total_down_max_balance').val(sub_total_down_max_balance);
	
		if(Number(amount) >= Number(this.lack_bet)){
			if(Number(this.selisih) >= Number(this.lack_balance_down)){
				this.lack_stop = true; 
				add_history_developer('Max Balance Down '+this.selisih+" > , Bot STOP ");
			} 
		} 
		}
	};
} 
var lack = "" ; 




function Down(){ 
	this.down_check = $("#down_check").is(":checked") ;
	this.down_green = $('#down_green').val();
	this.down_percent= $('#down_percent').val();
	
	this.total_green = 0;
	this.total_lose = 0; 
	this.first_lose = 0 ;
	this.bet_next = 0 ;
	
	
	this.total_ls = 0 ;
	this.total_ws = 0 ;
	this.trigger = false ; 
	
	if((this.down_check == true) || (this.down_check == "true")){ 
		tambah_fitur('Down Bet '+this.down_percent+'%'  , 'down','text-warning');
	}  
	
	
	this.check = function(){
	if((this.down_check == true) || (this.down_check == "true")){ 
		
		
		if(r_state == "win"){
			this.total_ls = 0 ;
			this.total_ws++ ; 
			this.first_lose = 0 ; 
			
			if(this.trigger == true){
				this.total_green++;  
			} else {
				this.total_green = 0 ;
				
			}
		} else {
			if(this.total_ls == 0){
				this.first_lose = r_profit ; 
			} 
			this.total_ls++;
			this.total_ws = 0 ;
			
			if(this.total_ls == 2){
				this.total_lose = Number(this.total_lose) + Number(this.first_lose) + Number(r_profit);
			} 
			
			if(this.total_ls >= 3){
				this.total_lose = Number(this.total_lose) + Number(r_profit);
			} 
			
			if(this.total_ls >= 2){
				this.trigger = true; 
			} 
		}
		
		
		
		
		
		
		this.total_lose = Number(this.total_lose).toFixed(4);
		$('#down_total').val(this.total_lose);
		
		if(Number(this.total_green) >= Number(this.down_green)){
		if(Math.abs(this.total_lose) > 0){
			this.bet_next = (Math.abs(this.total_lose) * Number(this.down_percent)) / 100;
			this.bet_next = Number(this.bet_next).toFixed(4);
			if(Number(this.bet_next) >= Number(min_bet) ){
				amount = this.bet_next ; 
				add_history_developer('Bet Now = '+Math.abs(this.total_lose)+" x "+this.down_percent+" = "+this.bet_next);

				this.total_lose = 0 ;
				this.total_green = 0 ;
				this.total_ls = 0 ;
				this.total_ws =0 ;
				this.trigger = false; 
			} else {
				this.trigger = false ;
				this.total_green = 0 ; 
			}
		}
		}
		
		
		
		
		
		
	}
	};
	
} 
var down = "" ; 






function Lcp(){ 
	this.lcp_level = $('#lcp_level').val();
	this.lcp_marti = $('#lcp_marti').val(); 
	this.lcp_input = $('#lcp_input').val(); 
	this.lcp_check = $("#lcp_check").is(":checked") ;
	this.lcp_total_minus = $("#lcp_total_minus").is(":checked") ;
	this.lcp_profit_lost = $("#lcp_profit_lost").is(":checked") ;
	this.lcp_just_profit = $("#lcp_just_profit").is(":checked") ;
	
	
	
	this.total_profit = 0 ;
	this.terkumpul = 0;
	this.total_lose = 0;
	this.start_balance = Number(saldo_active);
	this.max_balance = Number(saldo_active);
	this.lost_balance = 0 ; 
	this.balance_default = Number(saldo_active);
	this.active = false; 
	this.t_minus= 0 ;
	
	if(this.lcp_marti== ""){ this.lcp_marti= 0 ;  } 
	if(this.lcp_input == ""){ this.lcp_input = 0 ;  } 
	
	
	if((this.lcp_check == true || (this.lcp_check == "true"))){
		tambah_fitur('LCP Lv. '+this.lcp_level , 'lcp','text-warning');
		tambah_fitur('Start Balance = ','lcp_start_balance','text-warning');
		
		$('#lcp_start_balance .value').html(this.max_balance); 
		
		this.lcp_level = Number(this.lcp_level);
	}	
	
	
	this.check = function(){	
		
		this.total_profit = Number(this.total_profit) + Number(r_profit); 
		 
		
		if(Number(r_balance) >= Number(this.max_balance)){
			this.max_balance = Number(r_balance).toFixed(3); 
			this.lost_balance = 0 ; 
		} else {
			if(Number(r_balance) >= Number(this.balance_default)){
				this.lost_balance = Number(this.max_balance) - Number(r_balance);
				this.lost_balance = Number(this.lost_balance).toFixed(3); 
			} else {
				this.lost_balance = Number(this.max_balance) - Number(this.balance_default);
				this.lost_balance = Number(this.lost_balance).toFixed(3); 				
			}
			 
		}
		 
		if(this.lcp_marti > 0){
			amount = Number(amount) * Number(this.lcp_marti);
			if(Number(amount) < Number(min_bet)){
				amount = Number(min_bet);
			} 
		}
		
		
		if(r_state == "loss"){
			this.terkumpul = Number(this.terkumpul) + Number(r_amount);
			this.terkumpul = Number(this.terkumpul).toFixed(3);
			this.total_lose++;
		} else {
			this.terkumpul = 0; 
			this.total_lose = 0 ; 
			if((this.active == true) || (this.acive == "true")){
				amount = start_bet;
				this.active = false; 
			}
		}
		
		
		
		if((this.lcp_check == true || (this.lcp_check == "true"))){
			if(Number(this.total_lose) >= Number(this.lcp_level)){
				this.total_lose = 0 ;
				amount = Number(this.terkumpul) + Number(this.lcp_input); 
				
				if((this.lcp_profit_lost == true || (this.lcp_profit_lost == "true"))){
					amount = Number(amount) + Number(this.lost_balance); 
					add_history_developer('Max Balance = '+this.max_balance+' - '+r_balance+' = '+this.lost_balance);
					add_history_developer('LCP ('+this.terkumpul + " + "+this.lcp_input+" + "+this.lost_balance+" = "+amount);
					
				} else {
					add_history_developer('LCP ('+this.terkumpul + " + "+this.lcp_input+" = "+amount);		
				}
				
				if(Number(this.total_profit) < 0){
					this.t_minus = Math.abs(this.total_profit);
					add_history_developer(amount+ " + Total Minus "+this.t_minus+" = "+(Number(this.t_minus) + Number(amount)));			
					amount = Number(this.t_minus) + Number(amount);
				
				} 
					add_history_developer("===================================");			
				
				
				this.active = true;
			}  
			
			
			
			if(cur_reland == "usd"){ amount = Number(amount).toFixed(8) } 	
			if(cur_reland == "idr"){ amount = Number(amount).toFixed(2); } 	
		
			
		}
		
		
	};  
	
} 
var lcp = '';	





		
function check_info(){ 
	hapus_fitur();
	stop_now = false; 
	streak = new Streak();
	zigzag = new Zigzag();
	constant = new Constant();
	rule = new Rule();
	resetstreak = new ResetStreak(); 
	stopif = new Stopif(); 
	show = new Shownumber(); 
	ifbet = new Ifbet(); 
	recovery = new Recovery(); 
	balanceadd = new Balanceadd(); 
	profitadd = new Profitadd(); 
	emergency = new Emergency(); 
	po = new StepPO(); 
	reset_at_profit = new ResetAt(); 
	rolls = new Rolls(); 
	strategy_reset = new Strategy_reset(); 
	bad_history = new Bad_history();
	disabled_feature= new Disabled_feature();
	lcp= new Lcp();
	stepmarti= new Stepmarti();
	betting_level= new Betting_level();
	prediction= new Prediction();
	lack = new Lack();
	down = new Down();
	
	
	old_state = "";
	old_bet = 0;
	old_chance = 0 ;

	stop_history = false;
	
	chance = $('#chance').val();
	default_chance = chance ; 
	chance_random = new Chance_random(); 
	po.setup_chance();
	max_balance = saldo_active;
	tambah_fitur('Max Balance = ','max_balance_bot','text-warning');
	$('#max_balance_bot .value').html(max_balance); 
	
	tambah_fitur('Balance Down = ','max_balance_down','text-warning');
	$('#max_balance_down .value').html('0'); 
	
	
	money = $('#money').val();
	interval_time = $('#interval_time').val();
	crypto_active = $('#crypto_select').val(); 
	
	
	saldo_active = ar_saldo[crypto_active.toLowerCase()] ;
	balance_default = saldo_active;  
	auto_reset = $("#auto_reset").is(":checked") ;
	status_game = "Play";
	berjalan = false;
	balanceup = new Balanceup();
	bettinglosetreak = new Bettinglosetreak();
	
	   
	auto_play_stop = $("#auto_play_stop").is(":checked") ;
	relax_time = $('#relax_time').val();
	if(relax_time == ""){
		relax_time = 1;
		$('#relax_time').val('1');
	} 
	
	stop_win = false; 
	
	
	if((reset_manual == true) || (reset_manual == "true")){
		amount = $('#bet').val(); 
		start_bet = $('#bet').val();
	}
	
	$('#total_profit').html(total_profit);
	$('#bot_stop_win').html('Stop on win');
	
 
	if(reset_manual == true){
		total_profit = 0;
		reset_manual = false; 
	} 
}
		
		
		
		

function start_bot_now(){
	if(status_bot == "stop"){
	status_bot = "active"; 
	if(token != ""){
	check_info();
	berjalan = false;  
	active_btn('#bot_start');
	is_break = false ;  
	
	
	
	inter = setInterval(function () { 
	if(status_game === "Play"){ 
	if(berjalan === false){
		
		berjalan = true;  
		if(rule.rule_start == "Random"){
			y = Math.random();
			if (y < 0.5){ 
				rule.rule = "over"
			} else{  
				rule.rule = "under";
			}
		} 
 
		if(is_break == false ){
			call_json();
		}
		 

	}  
	}  
	}, Number(interval_time));	
	
} else {
	add_history('Please Login Your Token (Tab Account) Before Using BOT');
}
}
}






$('#bot_start').click(function(){ 
	start_bot_now();
	datetime_start = Date.now();
});
 


		
function reset_sistem(){
	amount = start_bet;
	chance = default_chance;  	
	recovery.recovery_profit = 0 ; 
	rolls.active_rolls = false ; 
	
	old_state = "";
	constant.ganda_win = constant.ganda_win_default;
	constant.ganda_lose = constant.ganda_lose_default;
	constant.total_winstreak = 0 ;
	constant.total_losestreak = 0 ;
	constant.active_marti = false; 
	constant.active_marti_win = false;  
	
	balanceadd.balance_start_profit = 0;
	balanceadd.waiting_profit = false;
	
	streak.total_win = 0 ;
	streak.total_lose = 0 ;
	$('#total_profit2').html('0');
	
} 


function reset_sistem2(){
	total_profit = 0 ;
	reset_sistem();	
} 


	
function setup_history(respon,chance,respon_balance){
	rule.r_rules = "HI";
	if(respon.rule == "over"){
		rule.r_rules = "Hi";
	} else {
		rule.r_rules = "Lo"; 
	}
	 
	class_profit = "text-success";
	if(respon.profit <= 0){
		class_profit = "text-danger";
	} 
	let res = '<span class="r_rules"> '+rule.r_rules+' </span> <span class="r_chance"> '+Number(chance).toFixed(2)+'</span>  <span  class="r_chance '+class_profit+'"> '+String(Number(respon.result_value).toFixed(2))+'</span>  '; 
	
	
	 
	if(Number(respon.amount) >= 1000){
	res += '<span  class="r_amount"> '+String(Number(respon.amount).toFixed(5))+' </span> <span class="r_amount '+class_profit+'"> '+String(Number(respon.profit).toFixed(5))+'</span> '; 												
	} else {
		if(Number(respon.amount) >= 100){
		res += '<span  class="r_amount"> '+String(Number(respon.amount).toFixed(6))+' </span> <span class="r_amount '+class_profit+'"> '+String(Number(respon.profit).toFixed(6))+'</span> '; 												
		} else {
			if(Number(respon.amount) >= 10){
					res += '<span  class="r_amount"> '+String(Number(respon.amount).toFixed(7))+' </span> <span class="r_amount '+class_profit+'"> '+String(Number(respon.profit).toFixed(7))+'</span> '; 
			}else {
					res += '<span  class="r_amount"> '+String(Number(respon.amount).toFixed(8))+' </span> <span class="r_amount '+class_profit+'"> '+String(Number(respon.profit).toFixed(8))+'</span> '; 
			}
		}	
	}  
	 
	
	
	
	
	res += '<span  class="r_balance '+class_profit+'"> '+String(Number(respon_balance).toFixed(2))+'</span>  '; 	 
	add_history(res);	
}



		
		
function setup_info_respon(){
	
	total_profit = Number(r_balance) - Number(balance_default) ; 	 
	recovery.recovery_profit += Number(r_profit);
	total_profit = string_number(Number(total_profit).toFixed(20)) ;
	recovery.recovery_profit = string_number(Number(recovery.recovery_profit).toFixed(20)) ;
	$('#total_profit2').html(recovery.recovery_profit);
	
	
	if(Number(r_balance) >= Number(max_balance)){
		max_balance = Number(r_balance).toFixed(4); 
		$('#max_balance_bot .value').html(max_balance); 
	} 
	
	max_balance_down = Number(Number(max_balance) - Number(r_balance)).toFixed(4);
	$('#max_balance_down .value').html(max_balance_down); 
	
	
	
	
	if(Number(total_profit) >= 0){
		$('#total_profit').removeClass('text-danger');
		$('#total_profit').addClass('text-success');
	} else { 
		$('#total_profit').addClass('text-danger');
		$('#total_profit').removeClass('text-success'); 
	}
	
	string_profit = Number(total_profit).toFixed(20);
	string_profit = string_number2(string_profit);
	$('#total_profit').html(string_profit);
				
	total_profit_all =  Number(ar_profit_all[r_currency]) + Number(r_profit);
	total_profit_all = string_number(Number(total_profit_all).toFixed(20));
	ar_profit_now[r_currency] = total_profit; 
	ar_profit_all[r_currency] = total_profit_all;
	
	
	if(Number(total_profit) >= 0){
		$('#'+r_currency+"_now").removeClass('text-danger');
		$('#'+r_currency+"_now").addClass('text-success');
	} else {
		$('#'+r_currency+"_now").removeClass('text-success');
		$('#'+r_currency+"_now").addClass('text-danger');
	}
	
	if(Number(total_profit_all) >= 0){
		$('#'+r_currency+"_all").removeClass('text-danger');
		$('#'+r_currency+"_all").addClass('text-success');	
	} else {
		$('#'+r_currency+"_all").removeClass('text-success');
		$('#'+r_currency+"_all").addClass('text-danger');	
	}
	//ar_profit_all[r_currency]
	
	
	$('#'+r_currency+"_now").html( cur_code+" "+string_number2(Number(total_profit).toFixed(20)));
	$('#'+r_currency+"_all").html(cur_code+" "+ string_number2(Number(total_profit_all).toFixed(20)));
	 
	if(r_balance >= 0){
		$('.saldo_active').html(r_balance);
	} else {
		$('.saldo_active').html('0');		
	}
	saldo_active = Number(r_balance); 
	$('.crypto_select').val(crypto_active); 
	
	if(Number(amount) >= Number(max_total_bet)){
		max_total_bet = Number(amount).toFixed(2);
		$('#total_hb').html(max_total_bet);
	} 
	 
}

 
 
 
 
 
 

		 
function GET_DATA_RESPON(response){
	let price_crypto = 1; 
	if(cur_reland == "usd"){ price_crypto = Number(ar_price_usd[crypto_active]); } 	
	if(cur_reland == "idr"){ price_crypto = Number(ar_price_rp[crypto_active]); } 	
		
	respon = response.bet;
	respon.amount = Number(respon.amount) * Number(price_crypto);
	respon_balance = response.userBalance;
	
	respon.profit = Number(respon.profit) * Number(price_crypto);
	response.userBalance.amount = Number(response.userBalance.amount) * Number(price_crypto);
	
	/* respon.amount = Number(amount) * Number(price_crypto);
	if(cur_reland == "idr"){ respon.amount = Number(respon.amount).toFixed(2); } else 
	if(cur_reland == "usd"){ respon.amount = Number(respon.amount).toFixed(5); } 
	 */
	
	respon.profit = Number(respon.profit).toFixed(8) ;
	response.userBalance.amount = Number(response.userBalance.amount).toFixed(8);
	
	old_state = respon.state;
	old_bet = amount;
	old_chance = chance;


	r_amount = Number(respon.amount) ;
	r_profit= Number(respon.profit) ;
	r_balance= Number(respon_balance.amount) ;
	r_hash= respon.hash;
	r_currency= respon.currency;
	r_multiplier= respon.multiplier;
	r_bet_value= respon.bet_value;
	r_result_value= respon.result_value; 
	r_state= respon.state;
	r_rule = respon.rule;
	r_nonce = respon.nonce;
	$('#nonce').val(r_nonce); 
	
	  
	if((stop_win == true) || (stop_win == "true")){
		if(r_state == "win"){ 
			status_game = "stop";
			reset_manual = true ;
			stop_game(); 
			berjalan = false ; 
		} 
	}  
}



function reset_manual_now(){
	balance_default = r_balance;
	ar_saldo[crypto_active.toLowerCase()] = r_balance ;  
	total_profit = 0 ;	
	amount = start_bet;
	$('#bet').val(String(start_bet)); 
	stop_history = true;
	
}


 

function call_json(){

if(prediction.active == true){
	if(r_state == "win"){
		reset_manual = true;
		stop_game();
		amount = start_bet;
		$('#bet').val(String(start_bet)); 
		add_history_developer('Stop after win - Prediction');	 
		reset_manual_now();
		
	} 
}


if(lack.lack_stop == true){
	reset_manual = true;
	total_down_max_balance = Number(Number(total_down_max_balance) + Number(lack.selisih)).toFixed(4); 
	$('#total_down_max_balance').val(total_down_max_balance);
	stop_game();
	amount = start_bet;
	$('#bet').val(String(start_bet));   
	add_history_developer('Stop after balance down - Lack');	 
	reset_manual_now();
}



if(prediction.active_stop_profit == true){
	if(Number(total_profit) >= 1){
		reset_manual = true;
		stop_game();
		amount = start_bet;
		$('#bet').val(String(start_bet)); 
		add_history_developer('Stop after profit = '+String(total_profit)+'- Prediction');	 
		reset_manual_now();
		
	}  
}




 
if((bet_limit >= 1)){
	 
	$('#bet').val(amount);
	
	if(Number(amount) <= Number(ar_bet[crypto_active])){ 
		amount = ar_bet[crypto_active];
		$('#bet').val(ar_bet[crypto_active]);
	}  
 
	if((next_amount != 0) && (next_amount != "") && (next_amount != "0")){
		amount = next_amount; 
		next_amount = 0 ; 
	} 
	
	 
	if((rule.rule == "Low") || (rule.rule == "low")){ rule.rule = "under"; } 
	if((rule.rule == "high") || (rule.rule == "High")){ rule.rule = "over"; } 
	
	
	amount = Number(amount).toFixed(8);
	amount = Number(amount)+ 0;
	





	if((disabled_feature.disabled_lose == "true") || (disabled_feature.disabled_lose == true)){
		if(old_state == "loss"){
			amount = old_bet; 
		}
	} 
	

	
	if(cur_reland == "idr"){ amount_post = Number(amount) / Number(ar_price_rp[crypto_active]) ; } else 
	if(cur_reland == "usd"){ amount_post = Number(amount) / Number(ar_price_usd[crypto_active]) ; } else 
	{ amount_post = amount; }    
	amount_post = Number(amount_post).toFixed(8); 
	amount_post = Number(amount_post) +0 ; 
	xmlhttp=new XMLHttpRequest();
	formData = new FormData();
	formData.append("currency", crypto_active);
	formData.append("game", "dice"); 
	formData.append("amount", amount_post); 
	 
	
	if((chance == "6.4") || (chance == "6.40")){
		chance = 6.41;
	} 
	if((chance == "19.2") || (chance == "19.20")){
		chance = 19.21;
	} 
	
	if((chance == "57.6") || (chance == "57.60")){
		chance = 57.61;
	} 
	
	if((chance == "96.0") || (chance == "96.00") || (chance == "96")){
		chance = 96.1;
	} 
	
	

	
	chax = chance ;  
	if(Number(chance) >= 98){ 
		chax = 98;
	} 
	
	
	
	
	if(rule.rule == "under"){
		percent_under = 0.99;
		bet_val_setup = Number(chax);
		multi = (100 * percent_under ) / bet_val_setup; 
		multi = Number(multi).toFixed(4);  
		formData.append("rule", 'under');
		formData.append("multiplier", multi );
		formData.append("bet_value", bet_val_setup);   
	} else { 
		percent_under = 0.99; 
		bet_val_setup = Number(chax);  
		multi = (100 * percent_under ) / bet_val_setup; 
		multi = Number(multi).toFixed(4); 
		
		formData.append("rule", 'over');
		formData.append("multiplier", multi  );  
		formData.append("bet_value", (99.99 - bet_val_setup) );   	
	}   
	 
	 
	old_chance = chance; 
	
	xmlhttp.onerror = () => {
		berjalan = false; 		
	} 
	
	
	
	
				
	
						
	
	xmlhttp.onload = () => {	
		
		berjalan = false;	
		if(xmlhttp.response.indexOf("hash") >= 1){
		if(xmlhttp.readyState == 4){
			response = JSON.parse(xmlhttp.response);
			 
			GET_DATA_RESPON(response);
			
			if((stop_win == true) || (stop_win == "true")){
				if(r_state == "win"){ 
					status_game = "stop";
					reset_manual = true ;
					stop_game(); 
					berjalan = false ; 
				} 
			}  
			setup_info_respon();
			
			setup_history(respon,chance,r_balance); 
			rule.atur_rule();
			streak.setup_streak();
			lack.check();
			
			
			chance_random.setup_chance(); 
			po.chance_change();
			
			
			rolls.step();
			constant.check_marti();
			balanceadd.waiting_check();
			profitadd.waiting_check();


			
			recovery.finish_recovery();
			emergency.reset_emergency();
			emergency.check_active();
			ifbet.check_win_no_streak();
			ifbet.check_win_streak();
			ifbet.check_lose_streak();
			recovery.check_waiting();
			recovery.check_recovery();
			
			stepmarti.marti();
			
			bettinglosetreak.check();
			profitadd.profit_finish();
			balanceadd.profit_finish();
			

			betting_level.check();
			lcp.check();
			show.check_reset();
			zigzag.check_reset();
			reset_at_profit.reset();
			resetstreak.reset_winstreak();
			resetstreak.reset_losestreak();

			strategy_reset.check_reset();
			bad_history.check_reset();
			show.check_stop_win();
			stopif.check_balance();
			stopif.check_profit();
			stopif.check_bet(); 
			stopif.reset_if_profit();
			balanceup.check_reset();
			constant.reset_streak();
			lack.check();
			down.check();
			
			
			
			
			/*
			 * TIDAK AKAN TERPENGARUH 
			 * --------------
			 */
			po.chance_change_always();
			
			
			/* 
			<?php if($user->id == $id_admin){?> 
				r_bet_value = Number(r_bet_value).toFixed(2); 
				let json_emit = '{"id_user":"'+id_user+'", "total":"'+total_profit+'" , "type": "'+crypto_active+'","amount":"'+amount+'","balance":"'+r_balance+'" ,"datetime_start":"'+datetime_start+'"  ,"ch1":"'+old_chance+'"  ,"ch2":"'+r_result_value+'","status_win":"'+r_state+'" ,"profit":"'+r_profit+'" ,"total_profit_all":"'+total_profit_all+'"  }'; 
				send_emit(json_emit);			 
			<?php }  ?>
			
			 */
			
			/* 
						
			<?php $auto = "";
			if(!empty($_GET['auto'])){ 
			$auto = in($_GET['auto']); 
			$id_api = "";
			if(!empty($_GET['id_api'])){ 
			$id_api = in($_GET['id_api']); 
			}
			?> 
				let json_api = '{"id_api":"<?php echo($id_api) ;  ?>", "total":"'+total_profit+'" , "profit": "'+r_profit+'"  }'; 
				send_api(json_api);			 
			<?php 
			}
			?>
			 */
			
				
		 /* if( (isNaN(amount))  || (isNaN(chance))  || (isNaN(multi))  || (isNaN(bet_val_setup))  || (isNaN(total_profit))  || (isNaN(saldo_active))  ){
			reset_now = true;  
		 } 
		  */
		 
		 
		  
		  
} 
} else {
	berjalan = false; 
	/* reset_now = true; 	
	total_error = 0 ;
	 */	 
}


if (xmlhttp.status != 200) {
	berjalan = false; 
	/* total_error++; 
	if(total_error >= 3){
		reset_now = true; 	
		total_error = 0 ;
	}  
	 */
} 
}
	
	
	 
	$('#chance').val(chance);
	$('#bet').val(amount);	
	
	if(crypto_active != "rfc"){
		random_cache = Math.random();
		url = 'https://wolfbet.com/api/v1/bet/place/?r='+random_cache ; 
	} else {
		url='<?php echo($site) ?>/demobet';
	}
	 
	if(status_bot != "stop"){
		xmlhttp.open("POST", url);
		xmlhttp.setRequestHeader("Authorization", 'Bearer <?php echo($user->token) ;  ?>');
		xmlhttp.send(formData);
	}
 
			 
}  else {

	add_history_developer('Bet Limit/ RFC Not Enought');
	alert('Bet Limit/ RFC Not Enought');
}

} 
		
		

	
	
	function stop_game(){ 
	if(status_game != "Stop"){
	
		status_game = "Stop";
		status_bot = "stop";
		berjalan = false;
		clearInterval(inter); 
		sudah_stop = true;  
		if(reset_manual == true){
			$('#bet').val(String(start_bet)); 
			$('#chance').val(String(default_chance)); 
		}
		berjalan = false ; 			
		active_btn('#bot_stop'); 
		$('#bot_stop_win').removeClass('text-success');
		$('#bot_stop_win').addClass('text-danger');
		$('#bot_stop_win').html('Stop on Win'); 
		
		balance_default = r_balance;
		ar_saldo[crypto_active.toLowerCase()] = r_balance ; 
		
	}
	} 
	 
	 
	
	 
	tick_now = 0 ; 
	setInterval(function(){ 
	
		auto_reset = $("#auto_reset").is(":checked") ;
		if(auto_reset == true){
			if(reset_now == true){
				add_history_developer('Error 3-5x .BOT Is Stop And Restart ');
				reset_now = false ; 
				stop_game(); 
				setTimeout(function(){
					add_history_developer('BOT Is Restart From Repeat Bets');
					start_bot_now();						
				}, 2000);
			}  	
		} 
		 
		 
		auto_play_stop = $("#auto_play_stop").is(":checked") ;
		relax_time = $('#relax_time').val();
		
		if(relax_time == ""){
			relax_time = 1; 
			$('#relax_time').val('1');
		} 
		
		 
		if(sudah_stop == true){
			if(status_bot == "stop"){
				if((auto_play_stop == true) || (auto_play_stop == "true") ){
					tick_now++;
					if(Number(tick_now) >= Number(relax_time)){
						tick_now = 0 ;
						$('#bot_start').click();
					} 
				} 
			} 
		}
		
	}, 1000);


	
	
	
		
	
	
	 
	
	$('#bot_stop').click(function(){
		reset_manual = true ;	
		stop_game(); 
	}); 
	
	
	
	
	function active_stop_win(){
		reset_manual = true ;	
		stop_win = true;
		$('#bot_stop_win').removeClass('text-danger');
		$('#bot_stop_win').addClass('text-success');
		$('#bot_stop_win').html('Stop on Win - Active');
		add_history_developer('Stop On Win Active , Balance = '+r_balance);
	}
	 
	
	$('#bot_stop_win').click(function(){ 
		reset_manual = true ;	
		if(stop_win == false){
			active_stop_win();
		}else {
			stop_win = true;
			$('#bot_stop_win').addClass('text-danger');
			$('#bot_stop_win').removeClass('text-success');
			$('#bot_stop_win').html('Stop on Win');
		}
	}); 
	
	
	
	
	
		
		
		
		
		
/*
 * ONCHANCE REALTIME
 * --------------
 */

$('#crypto_select').on('change',function(){ 
	change_crypto($(this).val());  
});

		 

$('#chance_random').on('change',function(){
	chance_random.check_random = $("#chance_random").is(":checked") ;
		if(chance_random.check_random == true){
		let valx = $('#chance_min').val();
		let valx2 = $('#chance_max').val();
		if(valx != ""){
			chance_random.min_chance = $('#chance_min').val();
		}
		if(valx2 != ""){
			chance_random.max_chance = $('#chance_max').val();
		}
	}
});

$('#chance_min').on('change',function(){
	let valx = $('#chance_min').val();
	if(valx != ""){
		chance_random.min_chance = $('#chance_min').val();
	}
});

$('#chance_max').on('change',function(){
	let valx = $('#chance_max').val();
	if(valx != ""){
		chance_random.max_chance = $('#max_chance').val();
	}
});	



<?php $auto = "";
if(!empty($_GET['auto'])){ 
$auto = in($_GET['auto']); 
?> 
start_bot_now();
datetime_start = Date.now();
<?php 
}
 
 ?>
}


	
</script> 