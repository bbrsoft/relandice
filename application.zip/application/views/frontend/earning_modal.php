
<audio src="<?php echo($site) ?>/audio/click1.wav" id="audio1"></audio>
<audio src="<?php echo($site) ?>/audio/click2.wav" id="audio2"></audio>

 
<script>
function showbank(){
	$('#modal_bank').modal('show'); 
}
function show_deposit(){
	$('#tab_manual_deposit').addClass('active');
	$('#tab_manual_withdraw').removeClass('active');
	$('#tab_3_deposit').addClass('active');
	$('#tab_3_withdraw').removeClass('active');
}

function show_withdraw(){
	$('#tab_manual_deposit').removeClass('active');
	$('#tab_manual_withdraw').addClass('active');
	
	$('#tab_3_deposit').removeClass('active');
	$('#tab_3_withdraw').addClass('active');
}

</script>

<div class="modal fade" id="modal_bank" role="dialog" style="display: none; margin-top:0px;">
 <div class="modal-dialog"style="border-radius:0px !Important ">
	 <div class="modal-content"style="border-radius:0px !Important ">
		 <div class="modal-header" style="border-radius:0px !Important ">
			 <span class="modal-title fs-20"  style="font-weight : 500" >Transaction Forms </span>
			 <button type="button"  style="color:white!Important; "  class="close" data-dismiss="modal">x</button>
		 </div>
		 <div class="modal-body p-0">
		 
		  
<div class="tab_manual m-0"  style="border-bottom:1px solid black;" >
	<a class="tab_manual_item active"  style="cursor:pointer;"  id="tab_3_deposit" onclick="show_deposit()"  > Deposit </a> 
	<a class="tab_manual_item"   style="cursor:pointer;" id="tab_3_withdraw"  onclick="show_withdraw()" > Withdraw </a> 
</div> 



<div class="p-3">
<div class="tab_manual_content active m-0" id="tab_manual_deposit">
	<form method="post" class="w-100 p-2 m-0 relative" enctype="multipart/form-data"> 
		<span class="d-block mb-2"> Deposit Form (Rp. <?php echo uang($usdt_idr,0) ;  ?> / USDT) </span> 

		<small align="left" class="d-block m-0 ">  Transfer Destination </small> 
		<select required name="paid_with" id="paid_with" class="w-100 form-control m-0"  style="color:white!Important;"  >
			<option  value=""  >Transfer Destination</option>
			<option  value="bri"  >Bank Rakyat Indonesia (Virtual)</option>
			<option  value="qris"  >QRIS</option>
			<option  value="dana"  >E-Wallet DANA</option>
			<option  value="usdt"  >USDT (BEP20)</option>
		</select>
		
		<div id="div_deposit_idr" class="w-100 m-0">
		<small align="left" class="d-block m-0 pt-2"> Deposit By IDR </small> 
		<input type="number" required min="20000" class="form-control m-0" name="deposit_idrx" id="deposit_idrx" value="" placeholder="Total Deposit (IDR)"    />
		</div>
		
		
		<small align="left" class="d-block m-0 pt-2">  Deposit By USDT </small> 
		<input type="number" required step="0.00000001" class="form-control m-0" name="deposit_usdtx" id="deposit_usdtx" value="" placeholder="Total Deposit (USDT)"    />
		
		
		<div class="d-flex align-items-center justify-content-between pt-3 pb-2 m-0 gap-1">
			<a class="btn btn-dark btn-sm  radius-5 w-50 m-0" href="<?php echo($site) ?>?page=deposit_history" >History Deposit </a>
			<button type="submit" class="btn btn-dark btn-sm w-50  radius-5  m-0"  name="deposit_now_usdt_earn">Deposit Now</button>
		</div>
	</form>
</div>








<div class="tab_manual_content  " id="tab_manual_withdraw">
	<form method="post" class="w-100 m-0 p-2 " enctype="multipart/form-data"> 
		<span class="d-block mb-2"> Withdrawal Form (Balance : <?php echo($user->usdt_earn_all) ;  ?> USDT) </span> 
		
		<small align="left" class="d-block m-0 pt-2">  Withdraw Destination </small> 
		<select required name="type" class="w-100 form-control js-example-basic-single  m-0"  style="color:white!Important;"  >
			<option >Wallet USDT(BEP20)</option> 
			<?php
			$table = "bank_api";
			$sql = "`id`<>-1";
			$row = $this->model->row($table,$sql);
			if($row >= 1){
				$dd = $this->model->get_obj($table,$sql);
				foreach($dd as $bank){
					?> 
							<option  value="<?php echo($bank->kode) ;  ?>"  ><?php echo($bank->bank_nama) ;  ?></option>
						<?php 
					}
				} 
				?>
		</select> 
		
		<small align="left" class="d-block m-0 pt-2">  Account Number/ Wallet </small> 
		<input type="text" required class="form-control m-0" name="wallet" value="" placeholder="Account Number/Wallet Address"    />
		 
		
		<small align="left" class="d-block m-0 pt-2">  Total Withdraw (USDT)</small> 
		<input type="number" step="0.0000000000000001" max="<?php echo($user->usdt_earn_all) ;  ?>" min="1" required class="form-control m-0" name="total"  value="" placeholder="Total Withdrawal"    />
		 
		<div class="d-flex gap-1 pt-3 pb-2">
			<a href="<?php echo($site) ?>?page=withdraw_history" class="btn btn-dark btn-sm  radius-5 w-50"  >History</a>
			<button type="submit" class="btn btn-dark btn-sm  radius-5 w-50"  name="withdraw_now_usdt_earn">Withdraw Now</button>
		</div>
	</form>



</div>
</div>

		 
			
			 
		 
		 
		 </div> 
	 </div>
 </div>
</div>




