<div class="tab-pane" role="tabpanel" id="tab-2">
<section class="bg-header min-100"> 

<div class="tab_manual"  style="margin-top: -10px; border-bottom:1px solid black;" >
	<a class="tab_manual_item active" id="s1" onclick="toggle_tab_manual('#strategy_auto','#s1','tab-2')"  > Strategy Auto </a> 
	<a class="tab_manual_item"  id="s2"  onclick="toggle_tab_manual('#strategy_manual','#s2','tab-2')" > Strategy Manual </a> 
</div> 
 
<?php include("tab_2_1.php"); ?>
<?php include("tab_2_2.php"); ?>

</section>
</div>

  