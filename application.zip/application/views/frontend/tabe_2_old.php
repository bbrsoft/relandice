
<div class="tab-pane" role="tabpanel" id="tab-2">
<section class="bg-header min-100"> 
<form class="w-100" method="post" enctype="multipart/form-data"> 
<?php 
if(isset($_POST['save'])){
	$data = '';
	foreach($_POST as $name => $val){
		if($data == ""){
			$data .= $name.":".$val; 
		} else {
			$data .= ",".$name.":".$val ; 
		}
	}
	if($data){
		$row = $this->model->row("user_settings","id_user='$id_user' ");
		if($row >= 1){
			$this->db->query("UPDATE user_settings SET `settings`='$data' WHERE id_user='$id_user'  ");
			
		}else {
			$this->db->query("INSERT INTO `user_settings`(`id_user`, `settings`) VALUES ('$id_user','$data') ");
		}
	} 
}  
?>

	<div class="flex-center flex-border">
		<span>Currency</span> 
		<select id="money" name="money" class="width-130">
			<option value="idr">IDR</option>
			<option value="usd" selected>USD</option>
		</select> 
	</div>


	<div class="flex-center flex-border">
		<select id="rule" class="width-100" name="rule">
			<option value="Random">Random</option>
			<option value="over" selected>Hi</option>
			<option value="under">Low</option>
		</select><span>&nbsp;Hi / Low after</span>
		<input type="number" class="width-60"  value="0"   onkeyup="check_low_after(this.value)"  id="rule_change_at" name="rule_change_at" ><span>bets</span>
	</div>
	
	
	<div class="flex-center flex-border">
		<span>&nbsp;Hi / Low after</span> 
		<input type="number" id="high_low_after_bet" name="high_low_after_bet" onkeyup="check_low_after(this.value)"  class="width-60" value="0">
		<span>bets</span>
		
		<input type="number" id="high_low_after_win"  name="high_low_after_win"   class="width-60" value="0">
		<span>win</span>
	</div>
	
	 

	<div class="flex-center">
		<div class="d-flex align-items-center">
			<input type="checkbox" id="ganda_check" name="ganda_check"  value="Yes"   class="mb-0 mt-0">
			<label class="mb-0 mt-0" for="ganda_check">Constant Divider</label>
		</div>
		<input type="number" class="width-40 text-center" value="1"><span>from balance&nbsp;</span>
	</div>
	
	
	
	<div class="flex-center flex-border pt-0 d-none"><span>Bet ammount 0.00000001 Doge</span></div>
	
	<div class="flex-center">
		<span>If win</span>
		<input type="number" step="0.01" id="ganda_win" name="ganda_win"   class="width-40 text-center" value="1">
		
		<span>If lose</span>
		<input type="number" step="0.01" id="ganda_lose"  name="ganda_lose" class="width-40 text-center" value="2">
	</div>
	
	<div class="flex-center">
		<span>Level Marti Win</span>
		<input type="number" id="level_marti_win"  step="1" name="level_marti_win"    class="width-40 text-center" value="1">
		<span>x win streak is active</span>
	</div>
	<div class="flex-center">
		<span>Level Marti Lose</span>
		<input type="number" id="level_marti"  step="1"  name="level_marti"    class="width-40 text-center" value="1">
		<span>x lose streak is active</span>
	</div>
	
	<div class="flex-center">
		<div class="d-flex align-items-center">
			<input type="checkbox" value="Yes"  name="check_win_bet"  id="check_win_bet" class="mb-0 mt-0" >
			<label class="mb-0 mt-0" for="check_win_bet">Reset if win</label>
		</div>
		<input type="number" id="reset_win_bet"  name="reset_win_bet"    class="width-40 text-center" value="1">
		<span>bets</span>
	</div>
	
	
	<div class="flex-center flex-border pt-0">
		<div class="d-flex align-items-center">
			<input type="checkbox" value="Yes" name="check_lose_bet" id="check_lose_bet" class="mb-0 mt-0">
			<label class="mb-0 mt-0" for="check_lose_bet">Reset if lose</label>
		</div>
		<input type="number" name="reset_lose_bet" id="reset_lose_bet"   class="width-40 text-center" value="1">
		<span>bets</span>
	</div>
	
	 
	 <!-- Close Constant Divider  --> 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	
	<div class="">
	<div class="flex-center">
		<div class="d-flex align-items-center">
			<input type="checkbox" value="Yes" name="check_max_win_streak"id="check_max_win_streak" class="mb-0 mt-0" >
			<label class="mb-0 mt-0" for="check_max_win_streak">Reset if winstreak</label>
		</div>
		<input type="number" name="max_win_streak"    id="max_win_streak"    class="width-40 text-center" value="1">
		<span>bets</span>
	</div>
	<div class="flex-center flex-border pt-0">
		<div class="d-flex align-items-center">
			<input type="checkbox" value="Yes" name="check_max_lose_streak" id="check_max_lose_streak" class="mb-0 mt-0">
			<label class="mb-0 mt-0" for="check_max_lose_streak">Reset if losestreak</label>
		</div>
		<input type="number" name="max_lose_streak"   id="max_lose_streak"   class="width-40 text-center" value="1">
		<span>bets</span>
	</div>
	</div>
	
	
	
	
	 
	 
	 
	<div class="flex-center flex-border pt-0 input_row_flex">
		<div align="center" style="background: rgba(0,0,0,0.2)!Important; margin-bottom: 0px!Important; border-radius:5px;padding-top:5px; line-height:12px; width : 22%!important" >
			<span class="d-block  m-0" align="left" style="padding-left:7px; padding-bottom:5px!Important; font-size : 10px" > RBA </span> 		
			<div class="m-0 p-0 d-flex align-items-center justify-content-between"  style="padding-right:5px!Important; background: black" >
				<input type="number" class="input_1"  id="balance_up"  name="balance_up"    class="text-center" value="0">	
				<input type="checkbox"  value="Yes" id="balance_up_check" name="balance_up_check"   class="mb-0 mt-0">				
			</div>
		</div>  
		<div align="center"  style="background: rgba(0,0,0,0.2)!Important; margin-bottom: 0px!Important; border-radius:5px;padding-top:5px; line-height:12px;width : 22%!important" >
			<span class="d-block  m-0" align="left" style="padding-left:7px; padding-bottom:5px!Important; font-size : 10px" > Max Bet </span> 		
			<div class="m-0 p-0 d-flex align-items-center justify-content-between"  style="padding-right:5px!Important; background: black" >
				<input type="number"  class="input_1" id="max_bet"  name="max_bet"    class="width-60 text-center" value="0">	
				<input type="checkbox" value="Yes" id="max_bet_check" name="max_bet_check"   class="mb-0 mt-0">				
			</div>
		</div> 
		<div align="center"  style="background: rgba(0,0,0,0.2)!Important; margin-bottom: 0px!Important; border-radius:5px;padding-top:5px; line-height:12px;width : 22%!important" >
			<span class="d-block  m-0" align="left" style="padding-left:7px; padding-bottom:5px!Important; font-size : 10px" > If Balance </span> 		
			<div class="m-0 p-0 d-flex align-items-center justify-content-between"  style="padding-right:5px!Important; background: black" >
				<input type="number" class="input_1"  id="max_balance_check"  name="max_balance_check"    class="width-60 text-center" value="0">	
				<input type="checkbox" value="Yes" id="max_balance_check" name="max_balance_check"   class="mb-0 mt-0">				
			</div>
		</div>
		 
		<div align="center"  style="background: rgba(0,0,0,0.2)!Important; margin-bottom: 0px!Important; border-radius:5px;padding-top:5px; line-height:12px;width : 22%!important" >
			<span class="d-block  m-0" align="left" style="padding-left:7px; padding-bottom:5px!Important; font-size : 10px" > If Profit </span> 		
			<div class="m-0 p-0 d-flex align-items-center justify-content-between"  style="padding-right:5px!Important; background: black" >
				<input type="number" class="input_1" id="max_profit"  name="max_profit"    class="width-60 text-center" value="0">	
				<input type="checkbox" value="Yes" id="max_profit_check" name="max_profit_check"   class="mb-0 mt-0">				
			</div>
		</div>
	</div>
	 
	 
	
	<div class="flex-center flex-border">
		<span> If profit </span> 
		<input type="number" class="width-130 text-center" value="0" name="profit_target" id="profit_target">
		<div class="d-flex align-items-center">
			<input type="checkbox" value="Yes" name="check_reset_target" id="check_reset_target" class="mb-0 mt-0">
			<label class="mb-0 mt-0" for="check_reset_target">reset bet</label>
		</div>
	</div> 
	
	<div class="flex-center flex-border">
		<span> If Zigzag Total </span> 
		<input type="number" class="width-130 text-center" value="0" id="max_zigzag" name="max_zigzag">
		<div class="d-flex align-items-center">
			<input type="checkbox" value="Yes" name="check_zigzag" id="check_zigzag" class="mb-0 mt-0">
			<label class="mb-0 mt-0" for="check_zigzag">reset bet</label>
		</div>
	</div> 
		
	
	
	<div class="flex-center flex-border">
		<span>If Show Number</span>
		<input type="number" id="show_number"   name="show_number"    style="width : 80px!important;"  class="width-130 text-center" value="0">
		<div class="">
		
		<div class="d-flex align-items-center">
			<input type="checkbox" value="Yes" name="show_number_check"id="show_number_check"  class="mb-0 mt-0">
			<label class="mb-0 mt-0" for="show_number_check">active stop on win </label>
		</div>
		
		<div class="d-flex align-items-center">
			<input type="checkbox"  value="Yes" name="show_number_check_reset"id="show_number_check_reset"  class="mb-0 mt-0">
			<label class="mb-0 mt-0" for="show_number_check_reset">active reset bet</label>
		</div>
		
		</div>
	</div>
	
	


	
	
	<div class="flex-center flex-border">
		<div class="" align="center">
		<span>If Bet >= </span>
		<input type="number" name="if_bet_win" id="if_bet_win"   class="width-130 text-center" value="0"> 
		<input type="number" name="if_bet_win_total"id="if_bet_win_total"   class="width-60 text-center" value="0">x Win  
		<br />
		<span class="d-block"> Reset To Default Bet </span>   
		<div class="w-100" align="center">
			<input type="checkbox" checked name="with_win_streak"id="with_win_streak"   class="with_win_streak"  value="Yes" > 
			<label for="with_win_streak" class="mr-3">With Streak</label>
			  
			<input type="checkbox" name="with_win_nostreak" id="with_win_nostreak"   class="with_win_nostreak"  value="Yes"  > 
			<label for="with_win_nostreak">NoStreak</label>
		</div>
		</div>
	</div>
	
	
	 
	
	<div class="flex-center flex-border"  >
		<div class="" align="center">
		<span>If Bet >= </span>
		<input type="number" id="if_bet_lose"   name="if_bet_lose"   class="width-130 text-center" value="0"> 
		<input type="number" id="if_bet_lose_total" name="if_bet_lose_total"   class="width-60 text-center" value="0">x Lose Streak 
		<br />
		<span> Reset To Default Bet </span>   
		</div>
	</div>
	  
	  
	  
	<div class="flex-center  ">
		<div class="d-flex align-items-center"> 
			<input type="checkbox" value="Yes" id="losetreak_max_check" name="losetreak_max_check" class="mb-0 mt-0">
			<label class="mb-0 mt-0" for="losetreak_max_check">x<input type="number"  step="0.01" id="losetreak_x" name="losetreak_x" class="width-40 text-center" value="4" > total losses at lose </label>
		</div>	
		<input type="number" id="losetreak_max" name="losetreak_max" class="width-40 text-center" value="0" > <span> times</span> 
	</div>
	
	<div class="flex-center ">
		<div class="d-flex align-items-center">
			<label class="mb-0 mt-0" >Using Chance</label>
		</div>
		<input type="number" class="width-130 text-center" value="0" id="losetreak_chance" name="losetreak_chance">
	</div>
	
	<div class="flex-center flex-border">
		<label class="mb-0 mt-0" >Reset settings at active </label>
		<input type="number" class="width-60 text-center" value="0" id="max_recovery_active" name="max_recovery_active">x
	</div>
	 
	  
	 
 
	<div class="flex-center flex-border ">
		<div >
		<span>Emergency Losestreak </span> 
		<input type="number" id="emergency_max" name="emergency_max" class="width-40 text-center" value="0" > <span>x </span> 
		
		<div class="d-flex align-items-center">
			<label class="mb-0 mt-0" >Using Chance</label>
			<input type="number" class="width-60 text-center" value="50" id="emergency_chance" name="emergency_chance"> until profit
		</div>
		
		</div>
	</div>				 
	
	

	
	
	<div class="flex-center flex-border">
		<span>If Balance Add </span>
		<input type="number" id="balance_start_add"  name="balance_start_add"    class="width-40 text-center" value="0">
		<span>Reset</span>
	</div>
	
	 
	<div class="flex-center flex-border btn-rounded-all2">
		<span> System </span> 
		<button class="btn btn-dark" id="strategy" name="strategy" type="button">STRATEGY</button>
	</div> 
	  
	 
	<div class="flex-center flex-border">
		<div class="" align="center">
		<input type="checkbox" value="Yes" name="po_check"id="po_check"   class="mb-0 mt-0"> <label class="mb-0 mt-0" for="po_check">Active Step PO Chance </label>
		<div class="d-flex align-items-center">
		<span>Chance </span>
		<input type="number" name="po_start" id="po_start" style="width : 60px!important;"  class="width-60 text-center" value="45">
		<span> - </span>
		<input type="number" name="po_stop" id="po_stop" style="width : 60px!important;"  class="width-60 text-center" value="78">
		</div> 
		<span>Step : </span>
		<input type="number" name="po_step" id="po_step" step="0.1" style="width : 60px!important;"  class="width-60 text-center" value="1">
	</div> 
	</div> 
	
	
	
	 
	<div class="flex-center flex-border">
		<div class="">
		<div class="d-flex align-items-center">
		<span>Reset System At Profit > </span>
		<input type="number" id="reset_profit"  name="reset_profit"    style="width : 60px!important;"  class="width-60 text-center" value="0">
		<input type="checkbox" value="Yes" id="check_reset" name="check_reset"   class="mb-0 mt-0">
		<label class="mb-0 mt-0" for="check_reset"> Active </label>
		</div> 
	</div> 
	</div> 
	 
		
	 
	 
	
	<div class="flex-center flex-border">
		<div class="">
		<div class="d-flex align-items-center">
			<input type="checkbox"  value="Yes"id="auto_play_stop"   name="auto_play_stop"   class="mb-0 mt-0">
			<label class="mb-0 mt-0" for="auto_play_stop"> Autoplay After Bot Stop </label>
		</div> 
		
		<div class="d-flex align-items-center">
		<span>Relaxtime</span>
		<input type="number" name="relax_time"    id="relax_time"    style="width : 60px!important;"  class="width-60 text-center" value="20">
		<span>Second</span>
		</div>
		
	</div> 
	</div> 
		
		
	<div class="flex-center btn-rounded-all2">
		<button class="btn btn-dark" id="reset" type="button">Reset Settings</button>
		<button class="btn btn-dark" name="save" type="submit">Save</button>
		 
	</div> 
</form>
</section>
</div>



<script>  
<?php 
$id_user = $user->id;

$table = "user_settings";
$sql = "`id_user`='$id_user'";
$row = $this->model->row($table,$sql);


if($row >= 1){
$data = $this->model->get_obj($table,$sql)[0];
$settings = $data->settings;


$ar = explode(',',$settings);
foreach($ar as $set){

$setx = explode(':',$set);
$name = $setx[0];
$val = $setx[1];
if($val <> "Yes"){
	?> 
	$('#<?php echo($name) ;  ?>').val('<?php echo($val) ;  ?>');
	<?php 
} else {?> 
	$('#<?php echo($name) ;  ?>').prop('checked', true);
<?php }
}
} 
?>


</script> 