<div class="pl-3 pr-3 pt-3">
	<a class="btn btn-dark btn-sm" href="<?php echo($site) ?>" > &lt; Back To Home</a> 
	<br />
	 
	<h5 class="d-block mt-3"> Withdrawal History </h5> 
	<p> Here is a history of your 10 most recent withdrawal requests. </p> 
	<hr>
	
	<?php 
	$secret = $user->secret;
	$table = "withdraw";
	$sql = "`secret`='$secret' ORDER BY id DESC LIMIT 10  ";
	$row = $this->model->row($table,$sql);
	if($row >= 1){
		$dd = $this->model->get_obj($table,$sql);
		foreach($dd as $data){
			$cl = "warning";
			if($data->status == "Finish"){ $cl = "success"; } 
			if($data->status == "Reject"){ $cl = "danger"; } 
			
			?> 
				<div class="p-2 radius-5 mt-3"  style="background: rgba(0,0,0,0.2)!important; border:1px solid black; " >
					<small  class="text-secondary"> Date : <?php echo(date('d M Y H:i:s', strtotime($data->date))) ;  ?></small>  <br />
					<div class="d-flex align-items-center justify-content-between">
						<span class="text-secondary"> Withdraw USDT </span> 
						<span> <?php echo($data->total) ;  ?> USDT </span> 
					</div>
					
					<?php if($type <> "Wallet USDT(BEP20)"){?> 
					<div class="d-flex align-items-center justify-content-between">
						<span class="text-secondary"> IDR Convert </span> 
						<span> <?php echo($data->total_text) ;  ?></span> 
					</div>
					<?php }  ?>
					
					
					<div class="d-flex align-items-center justify-content-between">
						<span class="text-secondary"> Status  </span> 
						<span class="text-<?php echo($cl) ;  ?>"> <?php echo strtoupper($data->status) ;  ?> </span> 
					</div>
					 <hr>
					 
					 <div class="">
						<b> Withdrawal Destination  </b> <br /> 
						<?php echo($data->wallet) ;  ?>
					 </div>
					 
				
				</div>
			<?php 
		}
	} 
	 ?>
	
	
</div>





