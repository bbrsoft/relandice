<div class="tab_manual_content  " id="strategy_manual">
<form class="w-100" method="post" enctype="multipart/form-data"> 

	
	
	<div class="p-3 " style="margin-bottom: 10px!important; background: rgba(0,0,0,.5)" >
		<h5  style="font-size : 18px!Important"  align="center" class="m-0"> SETUP YOUR STRATEGY </h5> 
	</div>
	
	<div class="px-3">
	
		
		<div id="respon_strategy">
			
			<div class="p-3 bg-dark">
				<p class="m-0"> You Dont Have Any Condition About Your strategy . You can add condition first </p> 
			</div>
		</div>
		
		
		
	
		<div class="mt-5">
			<a class="btn btn-dark form-control" onclick="show_modal_condition()"> Add Condition </a> 
		</div>
		<br /> 
		<br /> 
	
	
	
	</div>
	 
</form>
</div>


<script>  
function show_modal_condition(){
	$('#then').val('Add Martingle');
	$('#then_div').removeClass('d-none');
	$('#then_div').addClass('d-flex');
	$('#then_val').val('2');
	$('#then_span').html('x');
	
	
	
	$('#if_1').val('');
	$('#if_step_2').removeClass('d-flex');
	$('#if_step_2').addClass('d-none');
	$('#if_1_div').removeClass('d-flex');
	$('#if_1_div').addClass('d-none');
	
	
	$('#id_condition').val('');
	$('#type_condition').val('new');
	$('#modal_condition').modal('show'); 
	 
			
	
}


var	condition = [];
var data_condition = [];  


function setup_strategy(){	
	$('#respon_strategy').html('');
	condition.forEach(function(item, index){
	index_now = Number(index)+ 1; 
	up = "up('"+index+"')";
	down = "down('"+index+"')";
	edit = "edit('"+index+"')";
	trash = "trash('"+index+"')";

	div = '';
	div += '<div class="mb-3 pb-2">';
	div += '<span> Condition #'+index_now+'</span> ';
	div += '<div class="strategy_box">';
	div += '<span> '+item+' </span> 		';
	div += '<div class="strategy_btn_group">';
	div += '<a class="btn btn-dark up_strategy" valx="'+index+'"  > <i class="fa fa-chevron-up">  </i> </a> ';
	div += '<a class="btn btn-dark down_strategy" valx="'+index+'"    > <i class="fa fa-chevron-down">  </i> </a> ';
	div += '<a class="btn btn-dark edit_strategy" valx="'+index+'"    > <i class="fa fa-pencil">  </i> </a> ';
	div += '<a class="btn btn-dark delete_strategy" valx="'+index+'"    > <i class="fa fa-trash">  </i> </a> ';
	div += '</div>';
	div += '</div>';
	div += '</div>';
	$('#respon_strategy').append(div);
	});
			
}


	$('#if_1').on('change',function(){
		valx = $(this).val(); 
 
		if(valx == ""){
			$('#if_1_div').removeClass('d-flex'); 
			$('#if_1_div').addClass('d-none'); 
			$('#if_step_2').addClass('d-none');
		} else {
			$('#if_1_div').addClass('d-flex'); 
			$('#if_1_div').removeClass('d-none'); 
			$('#if_step_2').removeClass('d-none');
		}
		
		
		
		
		if(valx == "If Lose"){ $('#if_1_span').html('x'); } 
		if(valx == "If Win"){ $('#if_1_span').html('x'); } 
		if(valx == "If Winstreak"){ $('#if_1_span').html('x'); } 
		if(valx == "If Losestreak"){ $('#if_1_span').html('x'); } 
		if(valx == "If Bet >="){ $('#if_1_span').html(''); } 
		if(valx == "If Bet <="){ $('#if_1_span').html(''); } 
		if(valx == "If Bet >="){ $('#if_1_span').html(''); } 
		if(valx == "If Bet <="){ $('#if_1_span').html(''); } 
		if(valx == "If Balance <="){ $('#if_1_span').html(''); } 
		if(valx == "If Balance >="){ $('#if_1_span').html(''); } 
		if(valx == "If Balance Up"){ $('#if_1_span').html(''); } 
		if(valx == "If Profit"){ $('#if_1_span').html(''); } 
		if(valx == "If Total Profit >="){ $('#if_1_span').html(''); } 
		if(valx == "If Total Profit <="){ $('#if_1_span').html(''); } 
		if(valx == "If Amount Lose >="){ $('#if_1_span').html(''); } 
		if(valx == "If Amount Lose <="){ $('#if_1_span').html(''); } 
		if(valx == "If Amount Win >="){ $('#if_1_span').html(''); } 
		if(valx == "If Amount Win <="){ $('#if_1_span').html(''); } 
		
		
		
	});
	
	 	
	
	
	$('#then').on('change',function(){
		valx = $(this).val();  
 
		if(valx == "Add Martingle"){$('#then_div').addClass('d-flex'); $('#then_div').removeClass('d-none');  $('#then_val').val('2'); $('#then_span').html('x'); } 
		if(valx == "Set Chance"){$('#then_div').addClass('d-flex'); $('#then_div').removeClass('d-none'); $('#then_val').val('50');  $('#then_span').html('%'); } 
		if(valx == "Increase Chance"){$('#then_div').addClass('d-flex'); $('#then_div').removeClass('d-none'); $('#then_val').val('10');  $('#then_span').html('%'); } 
		if(valx == "Decrease Chance"){$('#then_div').addClass('d-flex'); $('#then_div').removeClass('d-none'); $('#then_val').val('10');  $('#then_span').html('%'); } 
		if(valx == "Set Bet"){ $('#then_div').addClass('d-flex'); $('#then_div').removeClass('d-none'); $('#then_val').val('1'); $('#then_span').html(''); } 
		if(valx == "Increase Bet"){ $('#then_div').addClass('d-flex'); $('#then_div').removeClass('d-none'); $('#then_val').val('10'); $('#then_span').html('%'); } 
		if(valx == "Decrease Bet"){ $('#then_div').addClass('d-flex'); $('#then_div').removeClass('d-none'); $('#then_val').val('10'); $('#then_span').html('%'); } 
		if(valx == "Set Interval"){$('#then_div').addClass('d-flex'); $('#then_div').removeClass('d-none'); $('#then_val').val('200');  $('#then_span').html('ms'); } 
		
		if(valx == "Reset Chance"){$('#then_div').removeClass('d-flex');  $('#then_div').addClass('d-none'); $('#then_val').val(''); $('#then_span').html(''); } 
		if(valx == "Reset Bet"){$('#then_div').removeClass('d-flex');  $('#then_div').addClass('d-none'); $('#then_val').val(''); $('#then_span').html(''); } 
		if(valx == "Reset System (All)"){$('#then_div').removeClass('d-flex');  $('#then_div').addClass('d-none'); $('#then_val').val(''); $('#then_span').html(''); } 
		if(valx == "Switch Under/Over"){$('#then_div').removeClass('d-flex');  $('#then_div').addClass('d-none'); $('#then_val').val(''); $('#then_span').html(''); } 
		if(valx == "Set To Under"){$('#then_div').removeClass('d-flex');  $('#then_div').addClass('d-none'); $('#then_val').val(''); $('#then_span').html(''); } 
		if(valx == "Set To Over"){$('#then_div').removeClass('d-flex');  $('#then_div').addClass('d-none'); $('#then_val').val(''); $('#then_span').html(''); } 
		if(valx == "Stop Game"){$('#then_div').removeClass('d-flex');  $('#then_div').addClass('d-none');  $('#then_val').val(''); $('#then_span').html(''); } 
		if(valx == "Stop If Win"){$('#then_div').removeClass('d-flex'); $('#then_div').addClass('d-none');  $('#then_val').val(''); $('#then_span').html(''); }  
	});
	
	
	
	
	$('#add_new_condition').click(function(){
		type  = $('#type_condition').val();
		
		if(type == "new"){			
			len = condition.length;
			data_condition[len] = [];
			data_condition[len]['if'] =  $('#if_1').val();
			data_condition[len]['if_val'] =  $('#if_1_val').val();
			data_condition[len]['if_span'] =  $('#if_1_span').html();
			data_condition[len]['then'] =  $('#then').val();
			data_condition[len]['then_val'] =  $('#then_val').val();
			data_condition[len]['then_span'] =  $('#then_span').html();
			
			condition[len] = $('#if_1').val() +" <b>"+ $('#if_1_val').val()+""+$('#if_1_span').html() + "</b>  >  " + $('#then').val() +" <b> "+$('#then_val').val()+""+$('#then_span').html()+" </b>"  ;
		} else {
			id_condition = $('#id_condition').val();
			data_condition[id_condition] = [];
			data_condition[id_condition]['if'] =  $('#if_1').val();
			data_condition[id_condition]['if_val'] =  $('#if_1_val').val();
			data_condition[id_condition]['if_span'] =  $('#if_1_span').html();
			data_condition[id_condition]['then'] =  $('#then').val();
			data_condition[id_condition]['then_val'] =  $('#then_val').val();
			data_condition[id_condition]['then_span'] =  $('#then_span').html();
			
			condition[id_condition] = $('#if_1').val() +" <b>"+ $('#if_1_val').val()+""+$('#if_1_span').html() + "</b>  >  " + $('#then').val() +" <b> "+$('#then_val').val()+""+$('#then_span').html()+" </b>"  ;
		}
		

		setup_strategy();
		$('#modal_condition').modal('hide'); 

	});

	
$('#respon_strategy').on('click', '.down_strategy', function () {
	index_data = $(this).attr('valx') ;
	condition = down_data(condition, index_data);
	data_condition = down_data(data_condition, index_data); 
	setup_strategy();
});


$('#respon_strategy').on('click', '.up_strategy', function () {
	index_data = $(this).attr('valx') ;
	condition = up_data(condition, index_data);
	data_condition = up_data(data_condition, index_data); 
	setup_strategy();
});


$('#respon_strategy').on('click', '.delete_strategy', function () {
	index_data = $(this).attr('valx') ;
	condition.splice(index_data, 1);
	data_condition.splice(index_data,1);
	setup_strategy();
});



$('#respon_strategy').on('click', '.edit_strategy', function () {
	index_data = $(this).attr('valx') ;
	
	$('#if_1').val(data_condition[index_data]['if']); 
	$('#if_1_val').val(data_condition[index_data]['if_val']);
	$('#if_1_span').html(data_condition[index_data]['if_span']);
	$('#then').val(data_condition[index_data]['then']);
	$('#then_val').val(data_condition[index_data]['then_val']);
	$('#then_span').html(data_condition[index_data]['then_span']);
	
	$('#if_1').trigger('change');
	$('#then').trigger('change'); 
	
	$('#id_condition').val(index_data);
	$('#type_condition').val('edit');
	$('#modal_condition').modal('show');  

});




function up_data(array, index){ 
	new_index = Number(index); 
	if(Number(index) > 0){
		new_index = Number(index) - 1 ; 
	
	
	new_array = [] ;
	array.forEach(function(item,i){
		if(Number(index) != Number(i)){
			if(Number(new_index) == Number(i)){
				new_array.push(array[Number(index)]);
			} 
			new_array.push(item);
		} 
	});
	
	return new_array; 
	} else {
		return array; 
	}
	
}

 

function down_data(array, index){
	
	len = Number(array.length) - 1; 
	new_index = Number(index);   
	if(Number(index) < Number(len)){ 
		new_index = Number(index) + 1 ; 
	
		new_array = [] ;
		array.forEach(function(item,i){ 
			
			if(Number(index) != Number(i)){
				new_array.push(item); 
				if(Number(new_index) == Number(i)){ 
					new_array.push(array[Number(index)]);
				}
				
			}
		});
	
	
	return new_array; 
	
	} else {
		return array; 
	}
	
}







 
	
</script> 