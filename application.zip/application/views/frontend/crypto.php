<!-- //bitcoin,ethereum,tether,bnb,usd-coin,xrp,cardano,staked-ether,dogecoin,lido-staked-ether,solana,matic-network,polkadot,tron
,litecoin,binance-usd,shiba-inu,avalanche-2,near-protocol,
,dai,wrapped-bitcoin,uniswap,chainlink,leo-token,cosmos,monero,the-open-network,okb
,vectorium,ethereum-classic,stellar,internet-computer,bitcoin-cash,true-usd,first-blood,
filecoin,power-cash,lido-dao,hedera-hashgraph,aptos,crypto-com-chain,quant-network,
arbitrum,near,vechain,apecoin,algorand,paxos-standard,the-graph,hedera,fantom,frax,
edgecoin-2,elrond-erd-2,eos,the-sandbox,theta-network,theta-token,elrond,rocket-pool,
bittorrent-old,aave,blockstack,pepe,decentraland,tezos,axie-infinity,flow,bittorrent-2,
radix,kucoin-shares,usdd,immutable-x,bitdao,gatechain-token,bitcoin-sv,bitget-token,
whitebit,render-token,curve-dao-token,havven,neo,rocket-pool-eth,klaytn,sui,klay-token,
chiliz,gemini-dollar,bittorrent,maker,cloutcontracts,optimism,casper-network,gmx,
terra-luna,conflux-token,pax-gold,sapphire,humans-ai,ecash,tokenize-xchange,mina-protocol,
tether-gold,injective-protocol,bitcoin-cash-abc-2,iota,kava,xdce-crowd-sale,compound-ether,
halo-coin,trust-wallet-token,frax-share,dash,huobi-token,flare-networks,compound-usd-coin,
woo-network,zilliqa,nexo,pancakeswap-token,osmosis,kaspa,celo-gold,floki,loopring,thorchain,
convex-finance,frax-ether,nxm,dydx,1inch,enjincoin,yooshi,btse-token,arweave,baby-doge-coin,
basic-attention-token,singularitynet,oec-token,holotoken,mask-network,gnosis,nem,zcash,
ftx-token,liquity-usd,cdai,safemoon,mx-token


ada,sushi
 --> 

<h6 class="mt-3">Realtime Price</h6>
<div class="div-card">

	<script src="https://www.cryptohopper.com/widgets/js/script"></script>
	<div class="cryptohopper-web-widget" data-id="9" data-text_color="#ffffff" data-theme="dark" data-background_color="#000000" 
data-coins="cardano,bitcoin-cash-sv,bnb,bitcoin,dogecoin,polkadot,ethereum-classic,ethereum,litecoin,shiba-inu,sushi,tron,uniswap,tether,stellar,xrp,matic-network,optimism" data-multi_currencies="USD" data-realtime="on">
	</div> 
 
</div>
 