<div class="tab-pane" role="tabpanel" id="tab-5">
<section class="bg-header min-100">
<div class="p-2">
	<p class="text-center">Realdice Bot will help automate Btc, Etc,Lth,Doge,Usdt,Shiba,Xlm coins on your smartphone device . If you do not have an account at Wolf.bet, you must first register throught the Account tab or at Wolf.bet.com and recomend making minimum Deposit of 0.010000000 BTC.&nbsp;</p>
	<p class="text-center mb-1">If you need support how to use Realdice Bot,<br></p>
	<p class="text-center mb-1">Please contact us :<br></p>
	<p class="text-center mb-1"><a href="https://www.facebook.com/profile.php?id=61559915580167&mibextid=ZbWKwL">https://www.facebook.com/profile.php?id=61559915580167&mibextid=ZbWKwL</a><br></p>
	<p class="text-center mb-1">Telegram : Stigma_apps<br></p>
	<p class="text-center">Email : Relandice_wolfbet@gmail.com <br></p> 
	<p class="text-center">Android/Dekstop Apps : <a class="btn btn-sm btn-success" id="installApp" > Install Now </a>  <br></p> 
	<p class="text-center">If you like this app please send you <b class="text-warning"> donation </b> . just tap to copy the address to the clipboard<br></p>
	<div align="center"><div class="btn-group-vertical width-150 margin-all" role="group">

<?php $table = "crypto";
$sql = "`id`<>-1";
$row = $this->model->row($table,$sql);
if($row >= 1){
$dd = $this->model->get_obj($table,$sql); 
foreach($dd as $data){
?> 
<button class="btn btn-dark wallet <?php if(!empty($data->wallet)){echo("text-success") ; }  ?>" wallet="<?php echo($data->wallet) ;  ?>" type="button"><?php echo(strtoupper($data->nama)) ;  ?></button>
<?php }
}
?>

</div>
</div>
<p class="text-center">RFC Balance Is Bet Limit Balance you can use this for testing BOT <br></p>

<small class="d-block text-center pt-5">Version 1.01</small> 
</div>
</section>
</div>


<script>  

let deferredPrompt;
    window.addEventListener('beforeinstallprompt', (e) => {
        deferredPrompt = e;
    });

    const installApp = document.getElementById('installApp');
    installApp.addEventListener('click', async () => {
        if (deferredPrompt !== null) {
            deferredPrompt.prompt();
            const { outcome } = await deferredPrompt.userChoice;
            if (outcome === 'accepted') {
                deferredPrompt = null;
            }
        }
    });

</script> 