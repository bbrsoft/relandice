<?php 
$id_admin = 0;
$table = "copy_trade";
$sql = "`id`<>-1 LIMIT 1";
$row = $this->model->row($table,$sql);
if($row >= 1){
	$dd = $this->model->get_obj($table,$sql)[0];
	$secret = $dd->secret;
	
	$table = "user";
	$sql = "`secret`='$secret'";
	$row = $this->model->row($table,$sql);
	if($row >= 1){
		$admin = $this->model->get_obj($table,$sql)[0];
		$id_admin = $admin->id;
	} 
}


$cur_code = "";


function normal_number(float $f) {
    $s = (string)$f;
    if (!strpos($s,"E")) return $s;
    list($be,$ae)= explode("E",$s);
    $fs = "%.".(string)(strlen(explode(".",$be)[1])+(abs($ae)-1))."f";
    return sprintf($fs,$f); 
}
 

if($user->cur_reland == "usd"){ 
	$cur_code = "$";
}  else 
if($user->cur_reland == "idr"){ 
	$cur_code = "Rp. ";
	
}   




foreach($min_bet as $cur => $min){				
	if($user->cur_reland == "usd"){
		$min_bet[$cur] =  ($min_bet[$cur] *  $price_usd[$cur]) + 0 ; 
		$min_bet[$cur] = normal_number($min_bet[$cur]); 
		
		if($min_bet[$cur] < 0.0001){
			$min_bet[$cur] = 0.0001;
		} 
		$min_bet[$cur] = normal_number($min_bet[$cur]); 
		$cur_code = "$";
	}  else 
	if($user->cur_reland == "idr"){
		$min_bet[$cur] = round($min_bet[$cur] *  $price_rp[$cur]) ; 
		$min_bet[$cur] = normal_number($min_bet[$cur]); 
		
		if($min_bet[$cur] < 0.3){
			$min_bet[$cur] = 0.3 ;
		} 
		
		$min_bet[$cur] = normal_number($min_bet[$cur]); 
		
		if($min_bet[$cur] == 0){
			$min_bet[$cur] = 1; 
		} 
		
		$cur_code = "Rp. ";		
	}  
}
  




$cur_reland = "default";
if(!empty($user->cur_reland)){
	$cur_reland = $user->cur_reland;
} 

?>




<div class="tab-pane active h-100 overflow_hidden"  style=" "  role="tabpanel" id="tab-1">
		
		
<div class="button_list d-none">
	<div class="" align="center">
	<div class="button_list_show">
		<a class="btn_list_item change_bet" multi="2" > 2x </a> 
		<a class="btn_list_item change_bet" multi="4" > 4x </a> 
		<a class="btn_list_item change_bet" multi="5" > 5x </a> 
		<a class="btn_list_item change_bet" multi="10" > 10x </a> 
		<a class="btn_list_item change_bet" multi="0" > <i class="fa fa-refresh">  </i> </a> 
	</div>
	<a class="button_list_icon" > <i class="fa fa-play">  </i> </a> 
	</div>
</div>

		
		<section class="bg-header tab1 min-100">
			<div class="flex-horizontal">
				<div class="w-100">
					<div class="flex-center"><span>Client Seed :&nbsp;</span>
					<input type="number" id="nonce" class="width-100" value="284560">
						<div class="d-flex align-items-center">
						<input type="checkbox" id="ch1" class="mb-0 mt-0" checked=""><label class="mb-0 mt-0" for="ch1">Auto</label></div>
						<select class="width-70 crypto_select" id="crypto_select" >
						<?php 
						$min_bet_active = 0 ;  
						$table = "crypto";
						 
						if(!empty($_SESSION['test'])){  
							$sql = "`id`<>-1   ";
						}else {
							$sql = "`id`<>-1 and nama <> 'rfc' ";
						}						 
 
						
						$row = $this->model->row($table,$sql);
						if($row >= 1){ 
							$dd = $this->model->get_obj($table,$sql);
							foreach($dd as $data){
								
								if(!empty($_SESSION['test'])){
								if($data->nama == $_SESSION['test']){ 
									$crypto_active = $data->nama; 
									$saldo_active = $saldo[$data->nama];
									$min_bet_active = $min_bet[$data->nama]; 
								} 
								} else {
									if($data->nama == "shib"){
										$crypto_active = $data->nama; 
										$saldo_active = $saldo[$data->nama];
										$min_bet_active = $min_bet[$data->nama]; 
									}
								}
								?> 
								<option  value="<?php echo($data->nama) ;  ?>"   <?php if($data->nama == $crypto_active){echo(" selected ") ; }  ?>><?php echo strtoupper($data->nama ) ;  ?></option> 
								<?php 
							} 
						} 
						 ?>	 
						</select>   
					</div> 
					<div class="flex-center">
						<span class="crypto_active"><?php echo($crypto_active) ;  ?> </span>
						<span>Balance</span>	
						<span> = <?php echo($cur_code) ;  ?> </span> 
						<span class="text-success saldo_active" ><?php echo($saldo_active) ;  ?> </span>
						
					</div>					
					
					 
					<div class="flex-center"><span>Chance %&nbsp;</span> 
						<input type="number"   id="chance"  class="width-70 text-center" value="49.99">
						<div class="d-flex align-items-center"> 
							<input type="checkbox" id="chance_random" class="mb-0 mt-0">
							<label class="mb-0 mt-0" for="chance_random">Auto</label>
						</div> 
						<input type="number" class="width-40 text-center" id="chance_min"   value="5"><span>-</span>
						<input type="number" class="width-40 text-center" id="chance_max"   value="95">
					</div>
					
					<?php 	
						$interval = 200 ; 
						$repeat = "";
						if(!empty($_SESSION['test'])){
							$interval = 2000;
						} 
						
						if(!empty($user)){
							if($user->id == -1){
								$interval = 2000; 
								$repeat = "checked";
							} 
						} 
					?>
					 
					<div class="flex-center">
						<span> <?php if(!empty($cur_code)){  echo($cur_code) ;  } else {echo("Amount") ; }?></span>
						<input type="number"  id="bet" min="<?php echo($min_bet_active) ;  ?>" class="width-120 text-center" value="<?php echo($min_bet_active) ;  ?>">
						<span> Interval</span> 
						<input type="number"    id="interval_time" class="width-60 text-center" value="<?php echo($interval) ;  ?>">
						<span> 'ms</span> 
					</div>
					 
					<div class="flex-center ">
						<div class="d-flex m-0 align-items-center">
							<label class="mb-0 mt-0" for="auto_reset"><i class="la la-refresh">  </i></label>
							<input type="checkbox" <?php echo($repeat) ;  ?> id="auto_reset"   class="mb-0 mt-0">
							<label class="mb-0 mt-0" for="auto_reset">Repeat Bets </label>
						</div> 
					</div> 
					
					<div class="flex-center" >	
						<span>WS : </span> <span class="text-success " id="total_ws">0</span> 
						<span class="pl-3">LS : </span> <span class="text-danger " id="total_ls">0</span>  
						<span class="pl-3">HB : </span> <span class="text-success " id="total_hb">0</span>  
						<span class="pl-3">BT : </span> <span class="text-danger " id="total_bt">0</span>  
						
					</div> 
					 
					
					<div class="flex-center">	
						<span>Profit</span>
						<span class="crypto_active"  ><?php echo strtoupper($crypto_active) ;  ?></span> <span>  = <?php echo($cur_code) ;  ?> </span> 
						<span class="number-success " id="total_profit">0&nbsp;</span>
						<span class="d-none" id="profit_convert"> </span> 
					</div> 
					

					<div class="flex-center"  style="display:none!Important" >	
						<span>Profit Sementara&nbsp;</span>
						<span class="number-success " id="total_profit2">0&nbsp;</span> 
					</div> 
					 
					
					<div class="flex-center btn-group btn-rounded-all">
						<button class="btn btn-dark text-secondary mr-5" type="button" id="bot_start" >Start</button>
						<button class="btn btn-dark text-danger" type="button" id="bot_stop"  >Stop</button>
						<button class="btn btn-dark text-danger" type="button" id="bot_stop_win"   >Stop on win</button>
					</div> 
				</div> 
				 
				 
				 <textarea class="textarea-full d-none" readonly="true" id="respon"></textarea>



					<div class="h-100 w-100 bg-area relative pt-1" id="respon_page">  
						<?php if(!empty($alert_withdraw)){?> 
							<div class="item_respon"><?php echo($alert_withdraw) ;  ?></div>
						<?php }  ?>
					</div>
			</div>  
		</section>
		 

<div align="center" class="swipe_left" >
	<div class="d-inline-flex align-items-center"  style="margin:auto;background: rgba(0,0,0,0.3)!important;padding: 5px; padding-left: 10px; padding-right: 10px; border-radius: 10px;border-top-left-radius:0px!IMportant;border-top-right-radius:0px!IMportant;" >
		<span class="pr-2"> Amount </span> 
		<input type="text" id="marti_amount" value="<?php echo($min_bet_active) ;  ?>"   style="box-shadow:none!important; outline:none!important;height: 25px;padding:0px!important;display:flex;align-items:center;justify-content:center;text-align:center; width : 150px; background: rgba(0,0,0,.5);color:white;border:0px;border-radius:3px; " value="" placeholder=""/>
	</div>

	 
	 <div class="d-flex gap-1 pt-2 align-items-center justify-content-between"  style="gap:5px;position:relative; " >
		<div class="btn_marti_up"  style="width : 50%!Important;font-size : 20px; padding-left:1rem;height: 65px; 
		border-radius:5px; background: green; display:flex; padding-top:3px!Important; align-items:center;justify-content:start;position:relative" >
			<span class="value">10</span> 
			<small  style="position:absolute; left:5px; top:5px; font-size : 10px;color:white;opacity:0.7" > UP Marti </small> 
		</div>
		
		 <div class="btn_marti_down"  style="width : 50%!Important;font-size : 20px; padding-right:1rem;height: 65px; 
		border-radius:5px; background: red; display:flex; padding-top:3px!Important; align-items:center;justify-content:end;text-align:right;position:relative" >
			<span class="value"  style="display:block; width : 100%!important; text-align:right;" >10</span> 
			<small  style="position:absolute; right:5px; top:5px; font-size : 10px;color:white;opacity:0.7" > DOWN Marti </small> 
		</div>
		
		  
		<div  style="width : 120px; padding:5px; padding-top:0px!important;position:absolute; top:8px; left:calc((100% - 120px) / 2);background: #1b1b1b; border-bottom-left-radius:5px;border-bottom-right-radius:5px;" >
		 <select class="selectx"  style="width : 100%;" align="center" id="up_marti" style="" >
			<option  value="10"  >10x</option>
			<option  value="5"  >5x</option>
			<option  value="4"  >4x</option>
			<option  value="2"  >2x</option>
		</select>
		</div>
		
		
		
	 </div>
	 
</div> 

<script>  
	$('.button_list_icon').click(function(){
		$('.button_list').toggleClass('active');
	});
</script>  

</div>


<?php include("tab_1_play_script.php"); ?>