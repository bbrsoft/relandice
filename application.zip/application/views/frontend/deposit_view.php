<?php $inv = "";
if(!empty($_GET['inv'])){ 
$inv = in($_GET['inv']); 


if(isset($_POST['upload_evidence'])){
	require_once("isset_image.php");
	if(!empty($image)){
		
		$this->db->query("UPDATE deposit SET `bukti`='$image', `status_bukti`='Checked' WHERE invoice='$inv'  ");
		
		
	} 
} 












$table = "deposit";
$sql = "`invoice`='$inv'";
$row = $this->model->row($table,$sql);
if($row >= 1){
$data = $this->model->get_obj($table,$sql)[0];
?>

<div class="pl-3 pr-3 pt-3">
	<a class="btn btn-dark btn-sm" href="<?php echo($site) ?>" > &lt; Back To Home</a> 
	
	<span align="center" class="fs-13 mt-3 d-block">Buy RFC</span> 
	<span align="center" class="fs-18 d-block">#<?php echo($data->invoice) ;  ?> </span> 
	<div class="" align="center">
		
		<table class="table table-dark mt-3 w-100 table-striped table-bordered"> 
			<tbody>
			<tr> 
				<td> Total RFC </td>
				<td align="right" class="text-success"> <?php echo uang($data->total_rfc, 2) ;  ?> RFC </td>
			</tr>
			<tr> 
				<td> Total IDR </td>
				<td align="right" class="text-success"> Rp. <?php echo uang($data->total, 0) ;  ?> </td>
			</tr>
			<tr> 
				<td> Status </td>
				<td align="right">   <?php echo ($data->status) ;  ?> </td>
			</tr>
			<tr> 
				<td> Evidence </td>
				<td align="right"> 
				<?php if(!empty($data->bukti)){?> 
				<img src="<?php echo($site) ?>image/<?php echo($data->bukti) ;  ?>"  style="height: 30px"  />
				<?php }  ?>
				
				</td>
			</tr>
			
			<tr> 
				<td> Evidence Status </td>
				<td align="right">   <?php echo ($data->status_bukti) ;  ?> </td>
			</tr>
			
			</tbody>
		</table> 
		
		<h5 class="mb-0"> Payment Destination </h5> 
		<p> Please Re-check payment destination before transfer your payments </p> 
		<div class="p-3 mb-3"  style="background: rgba(0,0,0,0.5);border-radius:5px;  " >
			<?php echo($data->tujuan) ;  ?> <br />
			<span class="fs-18"> Total Payments : Rp. <a class="text-success" ><?php echo(uang($data->total, 0)) ;  ?>  </a> 
			</span> 
		</div>
		<?php if($data->status == "Waiting Payments"){?> 
		 
		<h5 class="mb-0"> Evidence </h5> 
		<p> Upload Screenshot Proof of payments on this form </p> 
		
		<form method="post" enctype="multipart/form-data" align="left"> 
			<span> Evidence </span> 
			<input type="file" required class="form-control" name="image" value="" placeholder=""    />
			<br />
			<button type="submit" class="btn btn-dark w-100" name="upload_evidence">Upload Evidence</button> 
		</form>
		<?php }  ?>
		
		<br />
		<br />
		  
		
	
	</div>

</div>

<?php } 
}
 
 ?>

