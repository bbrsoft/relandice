<div class="tab_manual_content active " id="strategy_auto">
<form class="w-100" method="post" enctype="multipart/form-data"> 

	<div class="p-3 " style="margin-bottom: 10px!important; background: rgba(0,0,0,.5)" >
		<h5  style="font-size : 18px!Important"  align="center" class="m-0"> BASIC SETUP</h5> 
	</div>
	 
	<div class="">
		<span class="d-block pl-3 mb-1 fs-12"> <i class="fa fa-gear mr-2">  </i> CURR & RULE  </span> 
	</div>
	<div class="flex-center flex-border pt-0 input_row_flex">
		<div align="center" class="box_row" >
			<span class="label_row" align="left"  > Curr </span> 		
			<div class="box_row2" >
				<select id="money" name="money" class="input_1">
					<option value="default" selected>DEFAULT</option>
					<option value="idr">IDR</option>
					<option value="usd" >USD</option>
				</select> 
			</div>
		</div> 
		<div align="center" class="box_row" >
			<span class="label_row" align="left"  > Rule </span> 		
			<div class="box_row2" >
				<select id="rule" class="input_1"  name="rule">
					<option value="Random">Random</option>
					<option value="over" selected>Hi</option>
					<option value="under">Low</option>
				</select>
			</div>
		</div> 
		<div align="center" class="box_row" >
			<span class="label_row" align="left"  >Rule Change At </span> 		
			<div class="box_row2" >
				<input type="number"class="input_1" id="high_low_after_bet" name="high_low_after_bet"  value="0">
			</div>
		</div> 
		
		<div align="center" class="box_row" >
			<span class="label_row" align="left"  >In Total Win</span> 		
			<div class="box_row2" >
				<input type="number" class="input_1"id="high_low_after_win"  name="high_low_after_win"  value="0">
			</div>
		</div> 
	</div>
  
	 
	 
	<div class="">
		<span class="d-block pl-3 mt-2 mb-1 fs-12"> <i class="fa fa-gear mr-2">  </i> CONSTANT DIVIDER / MARTI </span> 
	</div>
	<div class="flex-center flex-border pt-0 input_row_flex"> 
		<div align="center" class="box_row" >
			<span class="label_row" align="left"  >If Win X</span> 		
			<div class="box_row2" >
				<input type="number" step="0.01" id="ganda_win" name="ganda_win"   class="input_1" value="1">
			</div>
		</div> 
		
		<div align="center" class="box_row" >
			<span class="label_row" align="left"  >If Lose X</span> 		
			<div class="box_row2" >
				<input type="number" step="0.01" id="ganda_lose"  name="ganda_lose" class="input_1" value="1">
			</div>
		</div> 
		<div align="center" class="box_row" >
			<span class="label_row" align="left"  >Active if WS</span> 		
			<div class="box_row2" >
				<input type="number" id="level_marti_win"  step="1" name="level_marti_win"    class="input_1" value="1">
			</div>
		</div> 
		<div align="center" class="box_row" >
			<span class="label_row" align="left"  >Active if LS</span> 		
			<div class="box_row2" >
				<input type="number" id="level_marti"  step="1" name="level_marti"    class="input_1" value="1">
			</div>
		</div> 
	</div>
	
	<style>
		.input-group-10 input{width : calc(100% / 10)!important; margin:0px !important;font-size : 13px!important;padding:0px!Important; 
display:flex; align-items:center; justify-content:center!important; border-right:1px solid darkgray!Important;
text-align:center!Important;
color:white!Important;
border-radius:0px!important;
		}
	</style>
	
	<div class="d-flex align-items-center justify-content-start pl-3 pb-2 pt-2">
		<input type="checkbox" value="Yes" id="step_marti_lose" name="step_marti_lose" class="mb-0 mt-0"> 
		<label for="step_marti_lose" class="m-0 fs-12 pl-2">  <i class="fa fa-gear mr-2">  </i> STEP MARTI LOSE</label>
	</div>
	<div class="flex-center flex-border pt-0 input_row_flex"> 
		<div class="d-flex input-group-10  justify-content-between"  style="gap:0px!Important; width : calc(100% - 28px)!important;" >
		<input type="number" step="0.001"required class="form-control" name="sl_1" id="sl_1" value="1" placeholder="S1"    />
			<input type="number" step="0.001"required class="form-control" name="sl_2" id="sl_2" value="1" placeholder="S2"    />
			<input type="number" step="0.001"required class="form-control" name="sl_3" id="sl_3" value="1" placeholder="S3"    />
			<input type="number" step="0.001"required class="form-control" name="sl_4" id="sl_4" value="1" placeholder="S4"    />
			<input type="number" step="0.001"required class="form-control" name="sl_5" id="sl_5" value="1" placeholder="S5"    />

			<input type="number" step="0.001"required class="form-control" name="sl_6" id="sl_6" value="1" placeholder="S6"    />
			<input type="number" step="0.001"required class="form-control" name="sl_7" id="sl_7" value="1" placeholder="S7"    />
			<input type="number" step="0.001"required class="form-control" name="sl_8" id="sl_8" value="1" placeholder="S8"    />
			<input type="number" step="0.001"required class="form-control" name="sl_9" id="sl_9" value="1" placeholder="S9"    />
			<input type="number" step="0.001"required class="form-control" name="sl_10" id="sl_10" value="1" placeholder="S10"    />
		</div>
	</div>
	
	
	
	
	<div class="">
		<span class="d-block pl-3 mt-2 mb-1 fs-12"> <i class="fa fa-gear mr-2">  </i> RESET SYSTEM #1</span> 
	</div>
	<div class="flex-center flex-border pt-0 input_row_flex"> 
		<div align="center" class="box_row" >
			<span class="label_row" align="left"  >Reset If Win</span> 		
			<div class="box_row2" >
				<input type="number" step="0.01" id="reset_win_bet" name="reset_win_bet"   class="input_1" value="1">
				<input type="checkbox" value="Yes"  name="check_win_bet"  id="check_win_bet"   >
			</div>
		</div> 
		
		<div align="center" class="box_row" >
			<span class="label_row" align="left"  >Reset If Lose</span> 		
			<div class="box_row2" >
				<input type="number" step="0.01" id="reset_lose_bet" name="reset_lose_bet"   class="input_1" value="1">
				<input type="checkbox" value="Yes"  name="check_lose_bet"  id="check_lose_bet"   >
			</div>
		</div> 
		<div align="center" class="box_row" >
			<span class="label_row" align="left"  >Reset If WS</span> 		
			<div class="box_row2" >
				<input type="number" step="0.01" id="max_win_streak" name="max_win_streak"   class="input_1" value="1">
				<input type="checkbox" value="Yes"  name="check_max_win_streak"  id="check_max_win_streak"   >
			</div>
		</div> 
		<div align="center" class="box_row" >
			<span class="label_row" align="left"  >Reset If LS</span> 		
			<div class="box_row2" >
				<input type="number" step="0.01" id="max_lose_streak" name="max_lose_streak"   class="input_1" value="1">
				<input type="checkbox" value="Yes"  name="check_max_lose_streak"  id="check_max_lose_streak"   >
			</div>
		</div> 
	</div>
	
	
	<div class="">
		<span class="d-block pl-3 mt-2 mb-1 fs-12"> <i class="fa fa-gear mr-2">  </i> RESET SYSTEM #2</span> 
	</div>
	<div class="flex-center flex-border pt-0 input_row_flex"> 
		<div align="center" class="box_row" >
			<span class="label_row" align="left"  > At Balance Up </span> 		
			<div class="box_row2" >
				<input type="number" class="input_1"  id="balance_up"  name="balance_up"  value="0">	
				<input type="checkbox"  value="Yes" id="balance_up_check" name="balance_up_check"   class="mb-0 mt-0">				
			</div>
		</div>  
		<div align="center" class="box_row" >
			<span class="label_row" align="left"  > If Profit </span> 		
			<div class="box_row2" >
				<input type="number" class="input_1"  id="profit_target"  name="profit_target"  value="0">	
				<input type="checkbox"  value="Yes" id="check_reset_target" name="check_reset_target"   class="mb-0 mt-0">				
			</div>
		</div>  
		
		<div align="center" class="box_row" >
			<span class="label_row" align="left"  > If Zigzag  </span> 		
			<div class="box_row2" >
				<input type="number" class="input_1"  id="max_zigzag"  name="max_zigzag"  value="0">	
				<input type="checkbox"  value="Yes" id="check_zigzag" name="check_zigzag"   class="mb-0 mt-0">				
			</div>
		</div>  
		
	</div>
	  
		
	
	
	
	 
	
	<div class="">
		<span class="d-block pl-3 mt-2 mb-1 fs-12"> <i class="fa fa-gear mr-2">  </i> STOP AT </span> 
	</div>
	<div class="flex-center   pt-0 input_row_flex">
		<div align="center" class="box_row" >
			<span class="label_row" align="left"  > If Bet  </span> 		
			<div class="box_row2" >
				<input type="number"  class="input_1" step="0.0001" id="max_bet"  name="max_bet"  value="0">	
				<input type="checkbox" value="Yes" id="max_bet_check" name="max_bet_check"   class="mb-0 mt-0">				
			</div>
		</div> 
		<div align="center" class="box_row" >
			<span class="label_row" align="left"  > If Balance </span> 		
			<div class="box_row2" >
				<input type="number" class="input_1" step="0.0001" id="max_balance"  name="max_balance"     value="0">	
				<input type="checkbox" value="Yes" id="max_balance_check" name="max_balance_check"   class="mb-0 mt-0">				
			</div>
		</div>
		<div align="center" class="box_row" >
			<span class="label_row" align="left"  > If Profit </span> 		
			<div class="box_row2" >
				<input type="number" class="input_1" step="0.000001" id="max_profit"  name="max_profit"    value="0">	
				<input type="checkbox" value="Yes"  id="max_profit_check" name="max_profit_check"   class="mb-0 mt-0">				
			</div>
		</div>
	</div>
	 
	 
	<div class="p-3 " style="margin-top: 20px!important; background: rgba(0,0,0,.5)" >
		<h5  style="font-size : 18px!Important"  align="center" class="m-0"> ADVANCED SETUP</h5> 
	</div>
	 
	 
	 
	
	
	<div class="flex-center flex-border"  style="padding-left:7px!important" >
		<div class=""  style="width : 50%;" >
			<span class="fs-10 d-block">If Show Number</span>
			<input type="number" id="show_number" step="0.0001"  name="show_number"    style="width:100%;"  class=" text-center" value="0">
		</div> 
		
		
		<div class=""  style="width : 50%;" >
		<div class="d-flex align-items-center">
			<input type="checkbox" value="Yes" name="show_number_check"id="show_number_check"  class="mb-0 mt-0">
			<label class="mb-0 mt-0" for="show_number_check">Active stop on win </label>
		</div>
		
		<div class="d-flex align-items-center">
			<input type="checkbox"  value="Yes" name="show_number_check_reset"id="show_number_check_reset"  class="mb-0 mt-0">
			<label class="mb-0 mt-0" for="show_number_check_reset">Active reset bet</label>
		</div>
		
		</div>
	</div>
	
	


	
	
	
	
	<div class="flex-center flex-border"  style="padding-left:7px!important" >
		<div class="d-flex align-items-center justify-content-between"  style="width : 60%;" >
			<div class="">
				<span class="fs-11 d-block">Reset If Bet >= </span>
				<input type="number" id="if_bet_win" step="0.0001"  name="if_bet_win"    style="width:100%;"  class=" text-center" value="0">
			</div>
			<div class="">
				<span class="fs-11 d-block">If Total Win </span>
				<input type="number" id="if_bet_win_total"  step="0.0001" name="if_bet_win_total"    style="width:100%;"  class=" text-center" value="0">
			</div>
		</div> 
		
		
		<div class=""  style="width : 40%;" >
		<div class="d-flex align-items-center">
			<input type="checkbox" value="Yes" name="with_win_streak" id="with_win_streak"  class="mb-0 mt-0">
			<label class="mb-0 mt-0" for="with_win_streak">Must Streak </label>
		</div>
		
		<div class="d-flex align-items-center">
			<input type="checkbox"  value="Yes" name="with_win_nostreak" id="with_win_nostreak"  class="mb-0 mt-0">
			<label class="mb-0 mt-0" for="with_win_nostreak">NoStreak</label>
		</div>
		
		</div>
	</div>
	

	
	<div class="flex-center flex-border"  style="padding-left:7px!important" >
		<div class="d-flex align-items-center justify-content-between"  style="width : 60%;" >
			<div class="">
				<span class="fs-11 d-block">Reset If Bet >= </span>
				<input type="number" id="if_bet_lose" step="0.0001"  name="if_bet_lose"    style="width:100%;"  class=" text-center" value="0">
			</div>
			<div class="">
				<span class="fs-11 d-block">If Total Lose </span>
				<input type="number" id="if_bet_lose_total" step="0.0001"  name="if_bet_lose_total"    style="width:100%;"  class=" text-center" value="0">
			</div>
		</div> 
		
		
		<div class=""  style="width : 40%;" >
		<div class="d-flex align-items-center">
			<input type="checkbox"  value="Yes" name="with_lose_streak" id="with_lose_streak"  class="mb-0 d-none mt-0">
			<label class="mb-0 mt-0" for="with_lose_streak">Must Streak </label>
		</div>
		 
		
		</div>
	</div>
	


	   
	
	<div class="d-flex align-items-center justify-content-start pl-3 pb-2 pt-2">
		<input type="checkbox" value="Yes" id="losetreak_max_check" name="losetreak_max_check" class="mb-0 mt-0"> 
		<label for="losetreak_max_check" class="m-0 fs-12 pl-2">STRATEGY RECOVERY (Marti All Total Lose) </label>
	</div>
	
	<div class="flex-center flex-border pt-0 input_row_flex"> 
		<div align="center" class="box_row" >
			<span class="label_row" align="left"  > Total Marti </span> 		
			<div class="box_row2" >
				<input type="number" class="input_1"  id="losetreak_x"  name="losetreak_x"  value="0">	 			
			</div>
		</div>  
		<div align="center" class="box_row" >
			<span class="label_row" align="left"  > At Total Lose </span> 		
			<div class="box_row2" >
				<input type="number" class="input_1" step="0.0001" id="losetreak_max"  name="losetreak_max"  value="0">	 			
			</div>
		</div>  
		
		<div align="center" class="box_row" >
			<span class="label_row" align="left"  > Set Chance  </span> 		
			<div class="box_row2" >
				<input type="number" class="input_1" step="0.01" id="losetreak_chance"  name="losetreak_chance"  value="0">	 			
			</div>
		</div>  
		
		<div align="center" class="box_row" >
			<span class="label_row" align="left"  > Reset If Active </span> 		
			<div class="box_row2" >
				<input type="number" class="input_1" id="max_recovery_active"  name="max_recovery_active"    value="0">	 		
			</div>
		</div>
	</div>
	  
	 
	  
	  
	
		
	<div class="d-flex align-items-center justify-content-start pl-3 pb-2 pt-2">
		<input type="checkbox" value="Yes" id="po_check" name="po_check" class="mb-0 mt-0"> 
		<label for="po_check" class="m-0 fs-12 pl-2">STRATEGY PO CHANCE</label>
	</div>
	 
	
	<div class="flex-center flex-border pt-0 input_row_flex"> 
		<div align="center" class="box_row"   >
			<span class="label_row" align="left"  > Start CH </span> 		
			<div class="box_row2" >
				<input type="number" class="input_1" step="0.01" id="po_start"  name="po_start"  value="45">	 			
			</div>
		</div>  
		<div align="center" class="box_row"  >
			<span class="label_row" align="left"  > Stop CH </span> 		
			<div class="box_row2" >
				<input type="number" class="input_1"  step="0.01"  id="po_stop"  name="po_stop"  value="78">	 			
			</div>
		</div>  
		<div align="center" class="box_row"  >
			<span class="label_row" align="left"  > Step CH </span> 		
			<div class="box_row2" >
				<input type="number" class="input_1" step="0.01"  step="0.1"  id="po_step"  name="po_step"  value="0.1">	 			
			</div>
		</div>  
		
		<div align="center" class="box_row"  >
			<div class="d-flex align-items-center">
				<input type="checkbox" value="Yes" name="po_always"   id="po_always"  class="mb-0 mt-0">
				<label class="mb-0 mt-0" for="po_always" >Always Active </label>
			</div>
		</div>  
		
		
		
		
	</div>
		 
	

	
	
	
	
		
	<div class="d-flex align-items-center justify-content-start pl-3 pb-0 pt-2">
		<input type="checkbox" value="Yes" id="rolls_check" name="rolls_check" class="mb-0 mt-0"> 
		<label for="rolls_check" class="m-0 fs-12 pl-2">STRATEGY MARTI ROLLS</label>
	</div>
	
	
	<div class="flex-center flex-border pt-0 input_row_flex"> 
		<div align="center" class="box_row" >
			<span class="label_row" align="left"  > +If Win </span> 		
			<div class="box_row2" >
				<input type="number" class="input_1" step="0.001" id="rolls_step_win"  name="rolls_step_win"  value="0">	 			
			</div>
		</div>   
		<div align="center" class="box_row" >
			<span class="label_row" align="left"  > +If Lose </span> 		
			<div class="box_row2" >
				<input type="number" class="input_1" step="0.001" id="rolls_step_lose"  name="rolls_step_lose"  value="1">	 			
			</div>
		</div>  
	
		<div align="center" class="box_row" >
			<span class="label_row" align="left"  > Active If Lose </span> 		
			<div class="box_row2" > 
				<input type="number" class="input_1" step="1" id="rolls_active_at"  name="rolls_active_at"  value="0">	 			
			</div>
		</div>  
	
		<div align="center" class="box_row"  style="background: transparent!Important" >
			<div class="d-flex align-items-center">
				<input type="checkbox" value="Yes" name="rolls_streak"   id="rolls_streak"  class="mb-0 mt-0">
				<label class="mb-0 mt-0" for="rolls_streak" >Losestreak </label>
			</div>
			
			<div class="d-flex align-items-center"> 
				<input type="checkbox"  value="Yes" name="rolls_nostreak" id="rolls_nostreak"  class="mb-0 mt-0">
				<label class="mb-0 mt-0" for="rolls_nostreak" >Lose</label>
			</div>
			
		</div>  
	
	</div>   
	

	  
	  
	
		
		
	   
	<div class="">
		<span class="d-block pl-3 mt-2 mb-1 fs-12"> <i class="fa fa-gear mr-2">  </i> RESET SYSTEM #3 </span> 
	</div>
	 
	
	<div class="flex-center flex-border pt-0 input_row_flex"> 
		<div align="center" class="box_row" >
			<span class="label_row" align="left"  > If Balance Add </span> 		
			<div class="box_row2" >
				<input type="number" class="input_1"  step="0.000001"  id="balance_start_add"  name="balance_start_add"    value="0">	
			</div>
		</div>
		<div align="center" class="box_row" >
			<span class="label_row" align="left"  > If Total Profit > </span> 		
			<div class="box_row2" >
				<input type="number" class="input_1"  step="0.0001"   id="reset_profit"  name="reset_profit"    value="0">	
				<input type="checkbox" value="Yes" id="check_reset" name="check_reset"   class="mb-0 mt-0">				
			</div>
		</div>
		
		<div class="d-flex align-items-center justify-content-between "  style="width : 50%!important; background: black!Important; border-radius:5px!Important; " >
			<div align="center" class="box_row"  style="width : 50%!Important; margin-right: 0px!important"  >
				<span class="label_row" align="left"  > If Profit Add </span> 		 
				<div class="box_row2" >
					<input type="number" class="input_1" step="0.000001"  style="background: 	#2f2f2f!important;"   id="profit_start_add"  name="profit_start_add"    value="0">	
				</div>
			</div>
			<div class="fs-14  pt-1 "  style="background: black!important; width : 50%!important" >
				<div class="d-flex align-items-center">
					<input type="checkbox" value="Yes" name="profit_add_stop"   id="profit_add_stop"  class="mb-0 mt-0">
					<label class="mb-0 mt-0 fs-12" for="profit_add_stop" >Stop </label>
				</div>
				
				<div class="d-flex align-items-center"> 
					<input type="checkbox"  value="Yes" name="profit_add_reset" id="profit_add_reset"  class="mb-0 mt-0">
					<label class="mb-0 mt-0 fs-12" for="profit_add_reset" >Reset</label>
				</div>
			</div>
		
		</div>
				
		
	</div>
	
	
		
	
		
	   
	<div class="">
		<span class="d-block pl-3 mt-2 mb-1 fs-12"> <i class="fa fa-gear mr-2">  </i> STRATEGY  EMERGENCY </span> 
	</div>
	
	<div class="flex-center flex-border pt-0 input_row_flex"> 
		<div align="center" class="box_row" >
			<span class="label_row" align="left"  > At Losestreak </span> 		
			<div class="box_row2" >
				<input type="number" class="input_1"  id="emergency_max"  name="emergency_max"  value="0">	 			
			</div>
		</div>  
		<div align="center" class="box_row" >
			<span class="label_row" align="left"  > Set Chance </span> 		
			<div class="box_row2" >
				<input type="number" class="input_1"  step="0.01"   id="emergency_chance"  name="emergency_chance"  value="50">	 			
			</div>
		</div>  
	</div>
		
		
	
	   
		
	<div class="d-flex align-items-center justify-content-start pl-3 pb-0 pt-2">
		<input type="checkbox" value="Yes" id="st_check" name="st_check" class="mb-0 mt-0"> 
		<label for="st_check" class="m-0 fs-12 pl-2">STRATEGY  RESET </label>
	</div> 
	<div class="flex-center flex-border pt-0 input_row_flex"> 
		<div align="center" class="box_row" >
			<span class="label_row" align="left"  > If Bet > </span> 		
			<div class="box_row2" >
				<input type="number" class="input_1"  step="0.0001"   id="st_amount"  name="st_amount"  value="1">	 			
			</div>
		</div>  
		<div align="center" class="box_row" >
			<span class="label_row" align="left"  > & Lose/LS </span> 		
			<div class="box_row2" >
				<input type="number" class="input_1"  id="st_max_total_lose"  name="st_max_total_lose"  value="1">	 			
			</div>
		</div>  
		<div align="center" class="box_row" >
			<span class="label_row" align="left"  > & Win After Lose </span> 		
			<div class="box_row2" >
				<input type="number" class="input_1"  id="st_max_total_win"  name="st_max_total_win"  value="0">	 			
			</div>
		</div> 
		<div align="center" class="box_row" >
			<div class="d-flex align-items-center">
				<input type="checkbox" value="Yes" name="st_streak"   id="st_streak"  class="mb-0 mt-0">
				<label class="mb-0 mt-0" for="st_streak" >Losestreak </label>
			</div>
			
			<div class="d-flex align-items-center"> 
				<input type="checkbox"  value="Yes" name="st_nostreak" id="st_nostreak"  class="mb-0 mt-0">
				<label class="mb-0 mt-0" for="st_nostreak" >Lose</label>
			</div>
		</div>  
	</div>
		
		
	   
	   
	<div class="">
		<span class="d-block pl-3 mt-2 mb-1 fs-12"> <i class="fa fa-gear mr-2">  </i>STRATEGY BAD HISTORY </span> 
	</div>
	
	<div class="flex-center flex-border pt-0 input_row_flex"> 
		<div align="center" class="box_row" >
			<span class="label_row" align="left"  > If Total Game </span> 		
			<div class="box_row2" >
				<input type="number" class="input_1"  id="bad_total"  name="bad_total"  value="10">	 			
			</div>
		</div>  
		<div align="center" class="box_row" >
			<span class="label_row" align="left"  > & Win Just </span> 		
			<div class="box_row2" >
				<input type="number" class="input_1"  id="bad_win"  name="bad_win"  value="3">	 			
			</div>
		</div>  
		<div align="center" class="box_row" >
			<span class="label_row" align="left"  > & Bet > </span> 		
			<div class="box_row2" >
				<input type="number" class="input_1"  step="0.0001"   id="bad_amount"  name="bad_amount"  value="100">	 			
			</div>
		</div> 
		<div align="center" class="box_row" >
			<div class="">
			
			<div class="d-flex align-items-center"> 
				<input type="checkbox"  value="Yes" name="bad_check_reset" id="bad_check_reset"  class="mb-0 mt-0">
				<label class="mb-0 mt-0" for="bad_check_reset" >Reset </label>
			</div>
			
			</div>
		</div>  
	</div>
	    
		
 
 
 
 
	<div class=""> 
	
	<div class="d-flex align-items-center justify-content-start pl-3 pb-0 pt-2">
		<input type="checkbox" value="Yes" id="betting_check" name="betting_check" class="mb-0 mt-0"> 
		<label for="betting_check" class="m-0 fs-12 pl-2">STRATEGY  BETTING LOSE </label>
	</div> 
	
	
	<div class="flex-center   pt-0 input_row_flex"> 
		<div align="center" class="box_row" style="width : 31%!important;"  >
			<span class="label_row" align="left"  > After Losestreak </span> 		
			<div class="box_row2" >
				<input type="number" class="input_1"  id="betting_losestreak"  name="betting_losestreak"  value="0">	 			
			</div>
		</div>  
		
		<div align="center" class="box_row" style="width : 31%!important;"  >
			<span class="label_row" align="left"  > After Winstreak </span> 		
			<div class="box_row2" >
				<input type="number" class="input_1"  id="betting_winstreak"  name="betting_winstreak"  value="0">	 			
			</div>
		</div>    
		
		
		<div align="center" class="box_row"  style="width : 31%!important"  >
			<div class="d-flex align-items-center">
				<input type="checkbox" value="Yes" name="betting_plus_bet"   id="betting_plus_bet"  class="mb-0 mt-0">
				<label class="mb-0 mt-0" for="betting_plus_bet" >+Bet</label>
			</div>
			<div class="d-flex align-items-center">
				<input type="checkbox" value="Yes" name="betting_plus_tm"   id="betting_plus_tm"  class="mb-0 mt-0">
				<label class="mb-0 mt-0" for="betting_plus_tm" >+T.Minus</label>
			</div>
			<div class="d-flex align-items-center">
				<input type="checkbox" value="Yes" name="betting_plus_mp"   id="betting_plus_mp"  class="mb-0 mt-0">
				<label class="mb-0 mt-0" for="betting_plus_mp" >+Minus Profit</label>
			</div>
			<div class="d-none align-items-center">
				<input type="checkbox" value="Yes" name="betting_plus_compound"   id="betting_plus_compound"  class="mb-0 mt-0">
				<label class="mb-0 mt-0" for="betting_plus_compound" >+BaseBet </label>
			</div>
			
			<div class="d-none align-items-center">
				<input type="checkbox" value="Yes" name="betting_green_2_reset"   id="betting_green_2_reset"  class="mb-0 mt-0">
				<label class="mb-0 mt-0" for="betting_green_2_reset" >Green 2 Reset</label>
			</div>
			
		</div>  
	</div> 
	</div> 
	
	
	
	
	
	
	
	<div class="flex-center pt-0 input_row_flex"> 
		<div align="center" class="box_row"  style="width : 31%!important" >
			<span class="label_row" align="left"  > + Amount If Active </span> 		
			<div class="box_row2" >
				<input type="number" class="input_1"  step="0.0001"   id="betting_plus_input"  name="betting_plus_input"    value="0">	
				<input type="checkbox" value="Yes" id="betting_plus_input_check" name="betting_plus_input_check"   class="mb-0 mt-0">				
			</div>
		</div>
		 
	</div> 
	
	
	
	
	<div class="flex-center   pt-0 input_row_flex"> 
		<div align="center" class="box_row"  style="width : 31%!important" >
			<span class="label_row" align="left"  > Level Lose </span> 		
			<div class="box_row2" >
				<input type="number" class="input_1"  id="betting_level_lose"  name="betting_level_lose"    value="0">	
			</div>
		</div>
		
		
		<div align="center" class="box_row"  style="width : 31%!important" >
			<span class="label_row" align="left"  > Total Green - Reset </span> 		
			<div class="box_row2" >
				<input type="number" class="input_1"  id="betting_reset_win"  name="betting_reset_win"    value="0">	
			</div>
		</div>
		
		<div align="center" class="box_row"  style="width : 31%!important" >
			<div class="d-flex align-items-center">
				<input type="checkbox" value="Yes" name="betting_level_check"   id="betting_level_check"  class="mb-0 mt-0">
				<label class="mb-0 mt-0" for="betting_level_check" >Active Level Lose </label>
			</div>
			
		</div>
		 
	</div> 
	
	
	
	
	
	<div class="flex-center flex-border pt-0 input_row_flex"> 
		<div align="center" class="box_row"  style="width : 64%!important" >
			<span class="label_row" align="left"  > Adjust </span> 		
			<div class="box_row2" >
				<input type="number" class="input_1"  id="betting_adjust"  name="betting_adjust"    value="0">	
			</div>
		</div>
		 
		
		<div align="center" class="box_row"  style="width : 31%!important" >
			<div class="d-flex align-items-center">
				<input type="checkbox" value="Yes" name="betting_adjust_check"   id="betting_adjust_check"  class="mb-0 mt-0">
				<label class="mb-0 mt-0" for="betting_adjust_check" >+ Adjust</label>
			</div>
			
		</div>
		 
	</div> 
	
	
	
	
	
	
	
 
	<div class="">
	<div class="d-flex align-items-center justify-content-start pl-3 pb-0 pt-2">
		<input type="checkbox" value="Yes" id="lcp_check" name="lcp_check" class="mb-0 mt-0"> 
		<label for="lcp_check" class="m-0 fs-12 pl-2">STRATEGY  LCP </label>
	</div> 
	<div class="flex-center   pt-0 input_row_flex"> 
		<div align="center" class="box_row" style="width : 31%!important;"  >
			<span class="label_row" align="left"  > Level Lose </span> 		
			<div class="box_row2" >
				<input type="number" class="input_1"  id="lcp_level"  name="lcp_level"  value="0">	 			
			</div>
		</div>  
		
		<div align="center" class="box_row" style="width : 31%!important;"  >
			<span class="label_row" align="left"  > + Amount If Active </span> 		
			<div class="box_row2" >
				<input type="number" class="input_1" step="0.000001" id="lcp_input"  name="lcp_input"  value="0">	 			
			</div>
		</div>    
		 
		<div align="center" class="box_row" style="width : 31%!important;"  >
			<div class="">
				
				<div class="d-flex align-items-center"> 
					<input type="checkbox"  value="Yes" name="lcp_profit_lost" id="lcp_profit_lost"  class="mb-0 mt-0">
					<label class="mb-0 mt-0 fs-13" for="lcp_profit_lost" >+ Profit Lost </label>
				</div>
			
				<div class="d-flex align-items-center"> 
					<input type="checkbox"  value="Yes" name="lcp_just_profit" id="lcp_just_profit"  class="mb-0 mt-0">
					<label class="mb-0 mt-0 fs-13" for="lcp_just_profit" > Last Profit </label>
				</div>
			
			</div>
		</div>  
	</div> 
	</div> 
	
	
	<div class=""> 
	<div class="flex-center flex-border  pt-0 input_row_flex"> 
		<div align="center" class="box_row" style="width : 31%!important;"  >
			<span class="label_row" align="left"  > Step Bet </span> 		
			<div class="box_row2" >
				<input type="number" class="input_1"  id="lcp_marti" step="0.001" name="lcp_marti"  value="1">	 			
			</div>
		</div>  
		
	
		
		<div align="center" class="box_row" style="width : 31%!important;"  >
			<div class="">
				
				<div class="d-flex align-items-center"> 
					<input type="checkbox"  value="Yes" name="lcp_total_minus" id="lcp_total_minus"  class="mb-0 mt-0">
					<label class="mb-0 mt-0 fs-13" for="lcp_total_minus" >+ T.Minus</label>
				</div> 
			
			</div>
		</div>  
		 
	</div> 
	</div> 
	
	
	
	
	
	
	
	
	
	
	
	
	
	<div class="">
	<div class="d-flex align-items-center  justify-content-start pl-3 pb-0 pt-2">
		<input type="checkbox" value="Yes" id="prediction_check" name="prediction_check" class="mb-0 mt-0"> 
		<label for="prediction_check" class="m-0 fs-12 pl-2">STRATEGY PREDICTION </label>
	</div> 
	
	<div class="flex-center  flex-border  pt-0 input_row_flex"> 
		<div align="center" class="box_row" style="width : 31%!important;"  >
			<span class="label_row" align="left"  > Prediction In Step </span> 		
			<div class="box_row2" >
				<input type="number" class="input_1"  id="prediction_step"  name="prediction_step"  value="0">	 			
			</div>
		</div>  


	<div align="center" class="box_row" style="width : 31%!important;"  >
		<div class="">
			
			<div class="d-flex align-items-center"> 
				<input type="checkbox"  value="Yes" name="prediction_stop_profit" id="prediction_stop_profit"  class="mb-0 mt-0">
				<label class="mb-0 mt-0 fs-13" for="prediction_stop_profit" > Stop If Profit </label>
			</div>
		
			<div class="d-flex align-items-center"> 
				<input type="checkbox" value="Yes" name="prediction_stop_win" id="prediction_stop_win"  class="mb-0 mt-0">
				<label class="mb-0 mt-0 fs-13" for="prediction_stop_win" > Stop If Win </label>
			</div>
		
		</div>
	</div>  
	
	
	</div> 
	</div> 
	
	
	
	
	
	
	
	<div class="">
	<div class="d-flex align-items-center justify-content-start pl-3 pb-0 pt-2">
		<input type="checkbox" value="Yes" id="lack_check" name="lack_check" class="mb-0 mt-0"> 
		<label for="lack_check" class="m-0 fs-12 pl-2">STRATEGY LACK </label>
	</div> 
	
	<div class="flex-center   pt-0 input_row_flex"> 
		<div align="center" class="box_row" style="width : 31%!important;"  >
			<span class="label_row" align="left"  >If Bet > </span> 		
			<div class="box_row2" >
				<input type="number" class="input_1"  id="lack_bet"  name="lack_bet"  value="0">	 			
			</div>
		</div>  

		<div align="center" class="box_row" style="width : 31%!important;"  >
			<span class="label_row" align="left"  >Max Balance Down</span> 		
			<div class="box_row2" >
				<input type="number" class="input_1"  id="lack_balance_down"  name="lack_balance_down"  value="0">	 			
			</div>
		</div>  
		
		<div align="center" class="box_row" style="width : 31%!important;"  >
			<span class="label_row" align="left"  > Total Down </span> 		
			<div class="box_row2"  style="background: transparent!Important; " >
				<input type="string" disabled readonly class="input_1"  style="background: transparent!Important; " id="total_down_max_balance"  value="0">	 			
			</div>
		</div>  
	</div> 
	
	
	<div class="flex-center   pt-0 input_row_flex"> 
		<div align="center" class="box_row" style="width : 31%!important;"  >
			<span class="label_row" align="left"  >Bet = % Total Down</span> 		
			<div class="box_row2" >
				<input type="number" class="input_1"  id="lack_percent_bet"  name="lack_percent_bet"  value="0">	 			
			</div>
		</div>  
		
		<div align="center" class="box_row" style="width : 20.5%!important;"  >
			<span class="label_row" align="left"  >If WS</span> 		
			<div class="box_row2" >
				<input type="number" class="input_1"  id="lack_ws"  name="lack_ws"  value="0">	 			
			</div>
		</div>  
		
		<div align="center" class="box_row" style="width : 20.5%!important;"  >
			<span class="label_row" align="left"  >If LS</span> 		
			<div class="box_row2" >
				<input type="number" class="input_1"  id="lack_ls"  name="lack_ls"  value="0">	 			
			</div>
		</div>  
		
		
		<div align="center" class="box_row" style="width : 20.5%!important;"  >
			<span class="label_row" align="left"  >S.If Profit</span> 		
			<div class="box_row2" >
				<input type="number" class="input_1"  id="lack_stop_if"  name="lack_stop_if"  value="0">	 			
			</div>
		</div>  
		
		
	
	</div> 
	</div> 
	
	
	
	
	
	
	
	<div class="">
	<div class="d-flex align-items-center justify-content-start pl-3 pb-0 pt-2">
		<input type="checkbox" value="Yes" id="down_check" name="down_check" class="mb-0 mt-0"> 
		<label for="down_check" class="m-0 fs-12 pl-2">STRATEGY ACCUMULATE LS <b class="text-warning"> Testing </b>  </label>
	</div> 
	
	<div class="flex-center   pt-0 input_row_flex"> 
		<div align="center" class="box_row" style="width : 31%!important;"  >
			<span class="label_row" align="left"  > Total Down </span> 		
			<div class="box_row2"  style="background: transparent!Important; " >
				<input type="string" disabled readonly class="input_1"  style="background: transparent!Important; " id="down_total"  value="0">	 			
			</div>
		</div>  
		
		<div align="center" class="box_row" style="width : 31%!important;"  >
			<span class="label_row" align="left"  >If Green </span> 		
			<div class="box_row2" >
				<input type="number" class="input_1"  id="down_green"  name="down_green"  value="0">	 			
			</div>
		</div>  

		<div align="center" class="box_row" style="width : 31%!important;"  >
			<span class="label_row" align="left"  >Bet % From Down </span> 		
			<div class="box_row2" >
				<input type="number" class="input_1"  id="down_percent"  name="down_percent"  value="0">	 			
			</div>
		</div>  
		
	</div> 
	</div> 
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
 
	<div class="">
		<span class="d-block pl-3 mt-2 mb-1 fs-12"> <i class="fa fa-gear mr-2">  </i>DISABLED FEATURED</span> 
	</div>
	<div class="flex-center flex-border  pt-0 input_row_flex" >  
		<div align="center" class="box_row"  style="width : 43%!important; background: black!important"  >
			<div class="d-flex align-items-center">
				<input type="checkbox" value="Yes" name="disabled_lose"   id="disabled_lose"  class="mb-0 mt-0">
				<label class="mb-0 mt-0 mb-0" align="left" for="disabled_lose" >Disabled Featured At Lose</label>
			</div>
		</div>   
	</div> 
	 
	 
	 
		
		
	   
	<div class="">
		<span class="d-block pl-3 mt-2 mb-1 fs-12"> <i class="fa fa-gear mr-2">  </i> AUTO PLAY </span> 
	</div>
	
	<div class="flex-center flex-border pt-0 input_row_flex"> 
		<div align="center" class="box_row"  style="width : 50%!important" >
			<span class="label_row" align="left"  > Play If Stop (Delay Second)</span> 		
			<div class="box_row2" >
				<input type="number" class="input_1" id="relax_time"  name="relax_time"    value="0">	
				<input type="checkbox" value="Yes" id="auto_play_stop" name="auto_play_stop"   class="mb-0 mt-0">				
			</div>
		</div>
	</div>
		
		 
	  
		
		
	<div class="flex-center btn-rounded-all2 btn-group">
		<a class="btn btn-dark" >Strategy</a>
		<button class="btn btn-dark" id="reset" type="button">Reset Settings</button>
		<button class="btn btn-dark" name="save_settings" id="save_button" type="submit">Save</button>
		 
	</div> 
</form>
</div>





<script>  
/* 
 * FROM DATABASE
 * --------------
 */

<?php 
$id_user = $user->id;

if($id_user <> -1){
$table = "user_settings";
$sql = "`id_user`='$id_user' and id_user<>''";
$row = $this->model->row($table,$sql);
} else {

$id_strategy = "";
if(!empty($_GET['id_strategy'])){ 
$id_strategy = in($_GET['id_strategy']); 
}
	
$table = "strategy_view";
$sql = "`id`='$id_strategy' ";
$row = $this->model->row($table,$sql);
?> 
/* 
 * STRATEGY FROM ADMIN 
 * --------------
 */
<?php 
}




if($row >= 1){
$data = $this->model->get_obj($table,$sql)[0];
$settings = $data->settings;
$ar = explode(',',$settings);
foreach($ar as $set){

$setx = explode(':',$set);
$name = $setx[0];
$val = $setx[1];
if($val <> "Yes"){
	?> 
	$('#<?php echo($name) ;  ?>').val('<?php echo($val) ;  ?>');
	<?php 
} else {?> 
	$('#<?php echo($name) ;  ?>').prop('checked', true);
<?php }
}
} 
?>



$('#money').on('change',function(){
	
	$('#save_button').click();
	
}); 
</script> 
