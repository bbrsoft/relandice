
<div class="modal fade show" role="dialog" tabindex="-1" id="modal_strategy">
<div class="modal-dialog" role="document">
	<div class="modal-content"> 
		<div class="modal-body"    >
			<h4 class="mb-3" style="color:#dddddd!important; " > Choose System </h4> 
			
			<?php $table = "strategy";
			$sql = "`id`<>-1";
			$row = $this->model->row($table,$sql);
			if($row >= 1){
				$dd = $this->model->get_obj($table,$sql);
				foreach($dd as $data){
					?> 
						<a class="list_item_strategy" onclick="select_strategy('<?php echo($data->nama) ;  ?>')" ><?php echo($data->nama) ;  ?></a> 
					<?php 
				}
			} 
			 ?>
			
			<div class="" align="right">
				<a id="cancel_strategy" class="btn btn-dark text-success" onclick="cancel_strategy()" > Cancel / Clear </a> 
				
			</div>
			
		</div>
	</div>
</div>
</div>
	
	 
	 
	 
<?php 
$if = array();
$if[] = 'If Lose';
$if[] = 'If Win';
$if[] = 'If Winstreak';
$if[] = 'If Losestreak';
$if[] = 'If Bet >=';
$if[] = 'If Bet <=';
$if[] = 'If Balance Up';
$if[] = 'If Balance >= ';
$if[] = 'If Balance <= ';
$if[] = 'If Profit';
$if[] = 'If Total Profit >=';
$if[] = 'If Total Profit <=';
$if[] = 'If Amount Lose >= ';
$if[] = 'If Amount Lose <= ';
$if[] = 'If Amount Win >= ';
$if[] = 'If Amount Win <= ';


$then = array();
$then[] = 'Add Martingle';
$then[] = 'Set Chance';
$then[] = 'Increase Chance';
$then[] = 'Decrease Chance';
$then[] = 'Set Bet';
$then[] = 'Increase Bet';
$then[] = 'Decrease Bet';
$then[] = 'Set Interval'; 
$then[] = 'Reset Chance';   
$then[] = 'Reset Bet';   
$then[] = 'Reset System (All)';
$then[] = 'Switch Under/Over';  
$then[] = 'Set To Under';  
$then[] = 'Set To Over';  
$then[] = 'Stop If Win'; 
$then[] = 'Stop Game'; 

?>
	 

<div class="modal fade hide" role="dialog" tabindex="-1" id="modal_condition">
<div class="modal-dialog" role="document">
<div class="modal-content"> 
	<div class="modal-body">
		
		<h3 align="center"  style="color:#dddddd!important; " > Add Condition </h3> 
		
		<div class="">
			<span> Add Condition </span> 
			<div class="d-flex"  style="gap:10px;" >
				<select class="input_1" id="if_1" style="width : 60%; border-radius:5px!Important; background: black!important;" >
					<option  value=""  >Select Condition</option>
					<?php foreach($if as $ifx){
						echo("<option>".$ifx."</option>") ; 
					} ?>
				</select>
				<div class="d-none" id="if_1_div" style="width : 40% ; background: black; border-radius:5px!Important;overflow:hidden; " >
				<input type="text" id="if_1_val" required class="input_1"  style="width : calc(100% - 40px); border-radius:0px; "  value="1" placeholder=""    />				
				<span class="input_1" id="if_1_span" style="background: black!important;line-height:0px!Important;width : 40px;display:flex; align-items:center;justify-content:center; background: black; border-radius:0px; " >x</span> 
				</div>
			</div>
			
			<div class="d-none" id="if_step_2">
			<span align="center" class="d-block pt-1 pb-1"  style="font-size : 16px!Important" > <i class="fa fa-long-arrow-down">  </i> </span> 
			
			<div class="d-flex"  style="gap:10px;" >
				<select class="input_1" id="then" style="width : 60%;background: black!important; border-radius:5px!Important; " >
					<?php foreach($then as $thenx){
						echo("<option>".$thenx."</option>") ; 
					} ?>
				</select>
				<div class="d-flex" id="then_div" style="width : 40% ; background: black; border-radius:5px!Important;overflow:hidden; " >
				<input type="text" id="then_val" required class="input_1"  style="width : calc(100% - 40px); border-radius:0px; "  value="2" placeholder=""    />				
				<span class="input_1" id="then_span" style="background: black!important;line-height:0px!Important;width : 40px;display:flex; align-items:center;justify-content:center; background: black; border-radius:0px; " >x</span> 
				</div>
			</div>
			
			<input type="hidden" required class="form-control" id="id_condition" value="" placeholder=""    />
			<input type="hidden" required class="form-control" id="type_condition" value="" placeholder=""    />
			
			
			
			<a class="btn btn-dark btn-sm w-100 d-block mt-3" id="add_new_condition" > Add New Condition </a> 
			</div>
		</div>
	
		
	</div>
</div>
</div>
</div>
	
	




	
	
	
	
	 
	<script>
function showinfo(text){
 $('#info_text').html(text); 
 $('#modal_info').modal('show'); 
}
function cancel_delete(){ $('#modal_info').modal('hide'); }
</script>

<div class="modal fade" id="modal_info" role="dialog" style="display: none; margin-top:0px;">
 <div class="modal-dialog"style="border-radius:0px !Important ">
	 <div class="modal-content"style="border-radius:0px !Important ">
		 <div class="modal-header" style="border-radius:0px !Important ">
			 <span class="modal-title">Information</span>
			 <button type="button" class="close" data-dismiss="modal">x</button>
		 </div>
		 <div class="modal-body" id="info_text">
		 
		 </div> 
	 </div>
 </div>
</div>
 
 