</div>

<?php include("home_setup.php"); ?>


<?php  if(!empty($alert)){ ?>
	<div class="alert alert-<?php echo($alert) ;  ?> bg-<?php echo($alert) ;  ?> alert-dismissable"  style="color:white; position:absolute; right:10px; bottom:0px; border:0px; " >
	<a class="close" data-dismiss="alert" aria-label="close">&times;</a>
	 <?php echo($respon) ;  ?> 
</div> <?php }  ?>			

 
 
<?php include("mode_developer.php"); ?>

</section>




</main>
    <div class="modal fade hide" role="dialog" tabindex="-1" id="modal-1">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Wallet&nbsp;<span id="wallet_type">BTC</span></h4>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                </div>
                <div class="modal-body">
				<textarea  style="color:white!important; background: black!important;font-size : 14px"  type="text" id="wallet_input" class="form-control" ></textarea>
				<a class="text-warning" id="copy_wallet"  > Copy Wallet </a> 
				</div>
                <div class="modal-footer"><button class="btn btn-danger" type="button" data-dismiss="modal">Close</button></div>
            </div>
        </div>
    </div>
    <script src="<?php echo($site);?>assets_landing/bootstrap/js/bootstrap.min.js"></script> 
	
	
	
	
	
<script>  
$('#copy_wallet').click(function(){

  var copyText = document.getElementById("wallet_input");
  copyText.select();
  copyText.setSelectionRange(0, 99999); // For mobile devices
  navigator.clipboard.writeText(copyText.value);
  alert("Copied the text: " + copyText.value);
  
});


class TouchEvent {
    static SWIPE_THRESHOLD = 50; // Minimum difference in pixels at which a swipe gesture is detected

    static SWIPE_LEFT   = 1;
    static SWIPE_RIGHT  = 2;
    static SWIPE_UP     = 3;
    static SWIPE_DOWN   = 4;

    constructor(startEvent, endEvent) {
        this.startEvent = startEvent;
        this.endEvent = endEvent || null;
    }

    isSwipeLeft() {
        return this.getSwipeDirection() == TouchEvent.SWIPE_LEFT;
    }

    isSwipeRight() {
        return this.getSwipeDirection() == TouchEvent.SWIPE_RIGHT;
    }

    isSwipeUp() {
        return this.getSwipeDirection() == TouchEvent.SWIPE_UP;
    }

    isSwipeDown() {
        return this.getSwipeDirection() == TouchEvent.SWIPE_DOWN;
    }

    getSwipeDirection() {
        if (!this.startEvent.changedTouches || !this.endEvent.changedTouches) {
            return null;
        }

        let start = this.startEvent.changedTouches[0];
        let end = this.endEvent.changedTouches[0];

        if (!start || !end) {
            return null;
        }

        let horizontalDifference = start.screenX - end.screenX;
        let verticalDifference = start.screenY - end.screenY;

        // Horizontal difference dominates
        if (Math.abs(horizontalDifference) > Math.abs(verticalDifference)) {
            if (horizontalDifference >= TouchEvent.SWIPE_THRESHOLD) {
                return TouchEvent.SWIPE_LEFT;
            } else if (horizontalDifference <= -TouchEvent.SWIPE_THRESHOLD) {
                return TouchEvent.SWIPE_RIGHT;
            }

        // Vertical or no difference dominates
        } else {
            if (verticalDifference >= TouchEvent.SWIPE_THRESHOLD) {
                return TouchEvent.SWIPE_UP;
            } else if (verticalDifference <= -TouchEvent.SWIPE_THRESHOLD) {
                return TouchEvent.SWIPE_DOWN;
            }
        }

        return null;
    }

    setEndEvent(endEvent) {
        this.endEvent = endEvent;
    }
}

let touchEvent = null;


document.addEventListener('touchstart', (event) => {
    touchEvent = new TouchEvent(event);
});
document.addEventListener('touchend', handleSwipe);




function handleSwipe(event) {
    if (!touchEvent) {
         return;
    }

    touchEvent.setEndEvent(event);

    if (touchEvent.isSwipeRight()) {
        $('.swipe_left').addClass('active');    
    } else if (touchEvent.isSwipeLeft()) {
        $('.swipe_left').removeClass('active');
    }

    // Reset event for next touch
    touchEvent = null;
}
 

if($('form').length >= 1){
document.querySelector("form").addEventListener("submit", function(e){
	$('.loading_now').addClass('active');
}); 
}

$('a[href]').click(function(){ 
	href = $(this).attr('href');
	if(href.indexOf("#") <= -1 ){
		$('.loading_now').addClass('active');
	}
});
</script>  






<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script>  

$(document).ready(function() {
    $('.js-example-basic-single').select2();
});  
</script> 


<?php 

	
	$total_deposit = $settings->earn_deposit; 
	$total_profit = 0;
	$profit = array();
	 
	
	
	
	$table = "earn_history";
	$sql = "`id_user`='$id_user' and sudah_reset='No' ";
	$row = $this->model->row($table,$sql);
	$total_active = $row;
	
	if($row >= 1){
		$dd = $this->model->get_obj($table,$sql);
		foreach($dd as $data){
			$selected[] = $data->target; 
			$profit[$data->target] = "$".round($data->profit,4) ; 
		}
	} 
	
 ?>

<script type="module"> 
import { io } from "https://cdn.socket.io/4.7.5/socket.io.esm.min.js";
const socket = io('wss://77.37.47.67:3001');



var status_now = "";
var status = "";
var time = 0;
var menit =0;
var detik = 0 ; 
var data_msg = "";
var id_user = <?php echo($user->id) ;  ?>;
var total_deposit = <?php echo($settings->earn_deposit) ;  ?>;
var sudah_klik = "no";
var total_deposit_user = <?php echo($user->usdt_earn_deposit) ;  ?>;

var earn_total_profit = <?php echo($user->earn_total_profit) ;  ?>;
var max_profit_user = <?php echo($user->usdt_earn_max) ;  ?>;




<?php 
if(!empty($_GET['page'])){ 
$page = in($_GET['page']); 
if($page == "earning"){ 

?>


socket.on('info', function(msg) {
	data_msg = JSON.parse(msg); 
});





function reset_kolom(){
	$('#earn_total_select').html('0'); 
	for (let i = 1; i <= 25; i++) {
		$('#box_'+i).removeClass('active');
		$('#box_'+i).html(i);
	}

}




socket.on('set', function(msg) {
if(msg.indexOf(':') >= 1){
data_msg = JSON.parse(msg); 
console.log(data_msg);
total_deposit = Number(data_msg.total_deposit).toFixed(8);
status = data_msg.status;
time = data_msg.time;
menit = Math.floor(Number(time) / 60);
detik = Number(time) - Number(menit * 60); 


$('#earn_total_deposit').html(total_deposit);
 
if(String(menit).length == 1){ menit = "0"+String(menit)  } 
if(String(detik).length == 1){ detik = "0"+String(detik)  } 



if(status_now != status){
	sudah_klik = "no";
		
	if(status == "waiting"){
		$('#earn_status').html('Starting in '); 
		$('#earn_time').html(menit+":"+detik+" seconds");
		$('.box_size').addClass('disable');
	} else {
		$('#earn_status').html('Select Before '); 
		$('#earn_time').html(menit+":"+detik+" seconds");
		$('.box_size').removeClass('disable');
	}
	
	if(Number(total_active) >= 25){
		reset_kolom(); 
		total_active = 0 ;
	} 
	
					
} 
}
});





setInterval(function(){
	if(Number(time) >= 1){
		time = Number(time) - 1;
		
		menit = Math.floor(Number(time) / 60);
		detik = Number(time) - Number(menit * 60); 

		if(String(menit).length == 1){ menit = "0"+String(menit)  } 
		if(String(detik).length == 1){ detik = "0"+String(detik)  } 
		
		$('#earn_time').html(menit+":"+detik+" seconds");
		
	} 
}, 1010);











var audio1 = document.getElementById('audio1');
var audio2 = document.getElementById('audio2');
	

function pause_all(){
	audio1.pause();
	audio2.pause();
	audio1.currentTime = 0
	audio2.currentTime = 0
}

function click1() {
	pause_all();
	audio1.play();
}

function click2() {
	pause_all();
	audio2.play();
}




function remove_ar(arr, value) {
  var index = arr.indexOf(value);
  if (index > -1) {
    arr.splice(index, 1);
  }
  return arr;
}

var active_no = [] ; 
var total_active = <?php echo($total_active) ;  ?> ;


$('.box_size').click(function(){
	toggle_active($(this).attr('valx')); 
});






var wait = false;
var ada_respon = "yes";
function toggle_active(id){
	
	
if(Number(total_deposit_user) >= 1){
if(status == "selected"){
	
if(Number(max_profit_user) > Number(earn_total_profit)){

	if(sudah_klik == "no"){
	if(wait == false ){
	wait = true ;
	click1();
	
	if($('#box_'+id+".active").length <= 0){
		$('#box_'+id).html('<i class="fa fa-spinner">  </i>');
		
		ada_respon = "no"; 
		socket.emit('selected', '{"id_user":"'+id_user+'", "no":"'+String(id)+'" } ', function (msg) {
			wait = false ;
			if(msg.indexOf(':') >= 1){ 
				ada_respon = "yes";
				data_msg = JSON.parse(msg);
				
				total_deposit = Number(data_msg.total_deposit).toFixed(8);
				earn_total_profit = Number(data_msg.earn_total_profit).toFixed(8);
				
				$('#earn_total_profit').html(earn_total_profit); 
				$('#earn_total_select').html(data_msg.earn_total_select); 
				$('#usdt_profit_now').html(Number(data_msg.profit_now).toFixed(8));
				$('#usdt_earn_all').html(data_msg.usdt_earn_all);
				$('#earn_total_deposit').html(total_deposit);
			
				let success_post = data_msg.success_post;
				let profit_now = Number(data_msg.profit_now).toFixed(4);
				
				$('#box_'+id).html(' <small class="text-success fs-10">$'+profit_now+'</small>');
				
				if(success_post == "yes"){
					$('#box_'+id).addClass('active');
					active_no.push(id);
					total_active = Number(total_active) + 1 ; 
					sudah_klik = "yes";
				}
				
				$('.box_size').addClass('disable');

				
				
			}		
		});
		
		
		setTimeout(function(){
			if(ada_respon == "no"){
				alert('Click opportunity is over. Please try again.');
				location.reload();
			} 
		},20000);
		
		
		 
		
		
	}
	} else {
		click2();
	}
	} else {
		click2();
	}

} else {
	alert('Sorry , Your maximum profit is '+max_profit_user+', You can re-deposit for reset Total Profit');
}
} else {
	click2();
}
} else {
	alert('Sorry , Your account is not active . Please deposit before select box');
}






}







var divx = '';

socket.on('info_history', function(msg) {
	if(Array.isArray(msg)){
		$('#earn_history').html('');
		msg.forEach(function(item){
			
			divx = '';
			divx += '<div class="d-flex align-items-center justify-content-between w-100">';
			divx += '<div class="td1"> '+item.time+' </div>';
			divx += '<div class="td2" > '+item.secret+'</div>';
			divx += '<div class="td3" align="center"> '+item.target+'</div>';
			divx += '<div class="td4 text-success"> +'+item.profit+' </div>';
			divx += '</div>';
			
			$('#earn_history').append(divx);
		});
	
	}
	
});




socket.on('info_deposit', function(msg) {
	if(Array.isArray(msg)){
		total_deposit = Number(msg[0].earn_deposit).toFixed(8);
		$('#earn_total_deposit').html(total_deposit);
		console.log(total_deposit);
	}
});



<?php } 
} ?>

var session_code = "<?php echo($_SESSION['session_code']) ;  ?>";


<?php if(!empty($_SESSION['logout_all'])){
	if($_SESSION['logout_all'] == "yes"){
		$_SESSION['logout_all'] = ""; 
		$session_code = $_SESSION['session_code']; 
		?> 
		socket.emit('login', '{"id_user":"'+id_user+'", "session_code":"<?php echo($session_code) ;  ?>" } ', function (msg) {
			console.log('Logout To All Account'); 
		});
		<?php 
	} 
}  ?>


socket.on('logout', function(msg) {
	if(msg.indexOf(':') >= 1){ 
		data_msg = JSON.parse(msg);
		let ses = data_msg.session_code ; 
		let id_ux = data_msg.id_user; 
		if(id_ux == "<?php echo($user->id) ;  ?>"){
			if(ses != session_code){
				alert('Your account is logout because login in different device . ');
				document.location.href="<?php echo($site) ?>/page/logout"; 
			} 
		} 
	}
});

</script>









<?php 
if(!empty($user)){
if(empty($_SESSION['broker'])){
	include("broker.php");
}  
}  
?>
</body>
</html>



