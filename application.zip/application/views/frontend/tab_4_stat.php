<div class="tab-pane" role="tabpanel" id="tab-4">
	<section class="bg-header min-100">
		<div class="p-2"><p class="text-center fs-18"><strong>Profit</strong></p>

		<?php $table = "crypto";
		$sql = "`id`<>-1";
		$row = $this->model->row($table,$sql);
		if($row >= 1){
		$dd = $this->model->get_obj($table,$sql);
		foreach($dd as $data){
			?> 
				<p class="text-center mb-0">Now <strong> <?php echo strtoupper($data->nama) ;  ?></strong> : <span ><strong class="text-success" id="<?php echo($data->nama) ;  ?>_now">0</strong></span><br /></p>
				<p class="text-center mb-2">Total <strong> <?php echo strtoupper($data->nama) ;  ?></strong> : <span ><strong class="text-success" id="<?php echo($data->nama) ;  ?>_all">0</strong></span><br /></p>
			<?php   
		}
		}  
		?>
		
		<p class="text-center mb-0">Win Streak Now: <span class="text-success"><strong class="now_winstreak">0x</strong></span><br></p>
		<p class="text-center mb-1">Lose Streak Now : <span class="text-danger"><strong class="now_losestreak">0x</strong></span><br></p>
		  
		
		<div class="mt-3" align="center">
		<div class="btn-group-vertical width-200 margin-all" role="group"><button class="btn btn-dark" type="button"><i class="la la-list-ol mr-2"></i>Bet History</button></div>
		</div><small class="d-block text-center pt-5">Version 2.15</small>
		</div>
	</section>
</div>

