<?php 
$usdt_idr = 15208.0;

$table = "crypto";
$sql = "`nama`='usdt'";
$row = $this->model->row($table,$sql);
if($row >= 1){
	$data = $this->model->get_obj($table,$sql)[0];
	$usdt_idr = $data->idr; 

}



$id = "Not Login";;
if(!empty($user)){
	$id = $user->id;


	if(isset($_POST['send_limit'])){
		$send_secret = in($_POST['send_secret']);
		$send_total = in($_POST['send_total']);
		if($send_total >= 1){
		if($user->bet >= $send_total){

			$row = $this->model->row("user","`secret`='$send_secret'  ");
			if($row >= 1){ 
				 
				$id_user = $user->id;
				$this->db->query("UPDATE user SET `bet`=`bet`-$send_total WHERE id='$id_user'  ");
				$this->db->query("UPDATE user SET `bet`=`bet` +$send_total WHERE `secret`='$send_secret'   ");
					
				$table = "user";
				$sql = "`id`='$id_user'";
				$row = $this->model->row($table,$sql);
				if($row >= 1){ 
					$user = $this->model->get_obj($table,$sql)[0];
					$respon_send = "Success Send To $send_secret $send_total REFIL";
					$respon_alert = "success";
				} 

			} else {
			$respon_send = "Sorry . User Secret  $send_secret  Has Not Found ";
			$respon_alert = "danger";
			}

		} else {
		$respon_send = "Sorry . You Refil Has Not Enought";
		$respon_alert = "danger";

		}   
		}   
	} 


	} 
	
	
$client_seed_interval = 5;
if(isset($_POST['save_session'])){
	$client_seed_interval = in($_POST['client_seed_interval']);
	$_SESSION['client_seed_interval'] = $client_seed_interval ; 
} 

if(!empty($_SESSION['client_seed_interval'])){
	$client_seed_interval = $_SESSION['client_seed_interval'];
} 

?>




<div class="d-none">
	<div class="flex-center"><span>Deposit Address&nbsp;&nbsp;</span><button class="btn btn-dark btn-sm btn-rounded" type="button">Get</button></div>
</div>

<?php if(!empty($_SESSION['broker'])){?> 
<div class="bg_black_5">
	<form method="post" enctype="multipart/form-data" class="d-flex  align-items-center justify-content-between">
		<button type="submit"  name="wolf" class="<?php if($_SESSION['broker'] == "wolf"){echo("text-success") ; }  ?> w-50 py-2"  style="color:white;font-weight : 500; background: transparent!Important;border:0px;border-right:1px solid black!important;box-shadow:none!Important;outline:none!Important;"  >Login Wolfbet.com</button>
		<button type="submit" name="copytrade" class="<?php if($_SESSION['broker'] == "copytrade"){echo("text-success") ; }  ?>  w-50 py-2" style="color:white;font-weight : 500; background: transparent!Important;border:0px!Important;box-shadow:none!Important;outline:none!Important;"  >Login Arbitrage </button>
	</form>
</div>
<?php }  ?>
 
<section class="bg-header ">
<div class="w-100">
	
	<div class="flex-center flex-border"><span>Account ID :&nbsp;</span><span class="text-success"><?php echo($id) ;  ?> 
	<?php if(!empty($user)){?> 
	<?php if($user->kyc_status <> 'Approve'){?> 
	<a class="btn btn-light btn-sm btn-kyc" onclick="$('#kyc_form').toggleClass('active')" style=""  > KYC </a>  
	<?php } else {?> 
	<a class="btn btn-light btn-sm btn-kyc " onclick="$('#kyc_form').toggleClass('active')" style="width : 80px!Important;"  > Verified  </a>   
	<?php } ?>
	<?php }  ?>
	
	</span></div>
	<?php include("dropdown/kyc.php"); ?>
	
	<?php if(!empty($user)){?> 
	<div class="flex-center flex-border">
			<span class="pl-3"> REFIL : </span> <span class="bet_limit text-success"><?php echo uang($user->bet,2) ;  ?> RFC</span>  
			<a onclick="$('#send_limit').toggleClass('active')" class="btn btn-dark btn-sm btn-rounded" > Send </a> 
			<a href="<?php echo($site) ?>?page=deposit_rfc" class="btn btn-dark btn-sm btn-rounded" > Buy </a> 
	</div>
	<?php if(!empty($respon_send)){
		?> 
		<p align="center" class="text-<?php echo($respon_alert) ;  ?>"> <?php echo($respon_send) ;  ?></p>  
		<?php 
	}  ?> 

<div class="pl-3 pr-3" id="send_limit" >
<form method="post" enctype="multipart/form-data"> 
	<div class="flex-center pt-2 justify-content-between">Secret ID<input type="text" name="send_secret" class="width-200 text-center" value="" placeholder="Secret ID" ></div>
	<div class="flex-center pt-0 justify-content-between ">Send REFIL<input type="number" name="send_total" max="<?php echo($user->bet) ;  ?>" class="width-200  text-center" value="" placeholder="MAX <?php echo uang($user->bet,0) ;  ?>"></div>	
	<button type="submit" class="btn mb-3 btn-dark btn-sm w-100" name="send_limit">Send Now</button>
</form>
</div>



	<?php }  ?>
	
	 
	<?php if(empty($user)){?>   
	<div class="flex-center flex-border pl-3 pr-3 pt-0">
		<div class="" align="center" style="height: auto!important; white-space: normal!important;"  >
			<form method="post" enctype="multipart/form-data"> 
				<span> SECRET LOGIN </span> 
				<input type="text" class="w-100 text-center radius-5" name="secret" required value="" placeholder="Secret Login / Username">
				<input type="text" class="w-100 text-center radius-5 password" name="password" required value="" placeholder="Password Login">
				
				<div class="d-flex align-items-center justify-content-start">
				 
				<div class="d-flex align-items-center" >
					<input type="radio" id="wolf_login" checked required name="broker" value="wolf"  />
					<label for="wolf_login" class="m-0 px-1"> Login Wolfbet</span> 
				</div>
				
				<div class="d-flex align-items-center px-2" >
					<input type="radio" id="arbitrage_login" required name="broker" value="arbitrage"  />
					<label for="arbitrage_login" class="m-0 px-1"> Login Arbitrage</span> 
				</div> 
				
				
				</div>
				
				 <button class="btn btn-dark btn-sm radius-5 w-100 pl-3 pr-3" name="login_secret" type="submit">Login With SECRET <i class="fa fa-sign-in">  </i></button>
			</form>
		</div>
	</div>
	
	<div class="flex-center flex-border pl-3 pr-3 pt-0">
		<div class="" align="center" style="height: auto!important; white-space: normal!important;"  >
			<p> Or Register New Account If You Dont Have Secret</p> 
			<a class="btn btn-dark btn-sm btn-rounded pl-3 pr-3" id="register_secret">Register New Account <i class="fa fa-edit">  </i></a>
		</div>
	</div>
	
	<?php }else {  ?>
	
	
	<div class="d-flex align-items-center justify-content-center flex-border ">
	<div class="w-100 relative" align="center">
	<span class="text-success"><?php echo uang($user->usdt, 7) ;  ?> </span><span> USDT&nbsp;&nbsp;</span> 
	<button class="btn btn-dark btn-sm btn-rounded" id="withdraw2" type="button">Wallet </button> 
	<a class="btn btn-dark btn-sm btn-rounded" href="<?php echo($site) ?>?page=referral" >Referral</a> 
	
	<div class="w-100 relative" id="withdrawal_form2">
	<div class="input_white p-3 m-0 w-100"  style="background: rgba(0,0,0,0.5)" id="" align="center" >
		<?php include("tab_3_account_wallet.php"); ?>
	</div>
	</div>
	
	</div>
	</div>
	
	
	
	 
	<div class="d-none flex-border ">
	<div class="" align="center">
	<span>Deposit Address&nbsp;&nbsp;</span><button class="btn btn-dark btn-sm btn-rounded" type="button">Get Wallet Address</button> <br />
	</div>
	</div>
	
	<div class="d-none flex-border ">
	
	<div align="center"> 
	<select style="width : 100px"  id="crypto_withdraw" >
	<option  value=""  >Select Crypto</option>
	<?php 
	$min_bet_active = 0 ;  
	$table = "crypto";
	$sql = "`id`<>-1 and nama<>'rfc'";
	$row = $this->model->row($table,$sql);
	if($row >= 1){ 
		$dd = $this->model->get_obj($table,$sql);
		foreach($dd as $data){
			?> 
			<option  value="<?php echo($data->nama) ;  ?>"    ><?php echo strtoupper($data->nama ) ;  ?></option> 
			<?php 
		} 
	}  
	 ?>	 
	</select>   
	<button class="btn btn-dark btn-sm btn-rounded" type="button" id="withdraw" name="withdraw">Withdrawal </button> 
	
	<div class="" id="withdrawal_form">
	<div class="p-2 input_white"  style="background: rgba(0,0,0,0.5)" id="" align="center" >
		
		<span class="d-block mb-2"> Withdrawal Form </span> 
		<select class="w-100" id="network_withdraw" >
			<option  value=""  >Select Network </option>
		</select> 
		<input type="text" required class="form-control" name="wallet" id="withdraw_wallet" value="" placeholder="Wallet Address"    />
		<input type="text" required class="form-control" name="total" id="withdraw_total" value="" placeholder="Total Withdrawal"    />
		<hr>
		
		<input type="text" required class="form-control" name="withdraw_username" id="withdraw_username" value="" placeholder="Username Wolf"    />
		<input type="password" required class="form-control" name="withdraw_password" id="withdraw_password" value="" placeholder="Password Wolf"    />
		<input type="text" required class="form-control" name="withdraw_2fa" id="withdraw_2fa" value="" placeholder="Two Factor Authenticator (2FA)"    />
		 
		<div class="d-block"> Your Balance : <span id="withdraw_balance">0</span> <span class="withdraw_coin">Coin</span>  
		<br />
		 Minimum Withdraw : <span id="withdraw_min">0</span> <span class="withdraw_coin">Coin</span>  
		</div>  
		
		<div class="d-block">
			<button type="submit" class="btn btn-dark btn-sm btn-rounded" id="withdraw_now">Withdraw Now</button>
		</div>
	
	</div>
	</div>
	</div>
	</div>
	
	
	
	<div class="flex-border" align="center">
	<a class="btn btn-dark btn-sm btn-rounded m-1 pl-3 pr-3" href="<?php echo($site) ?>page/logout" >Logout Account </a>	
	
	<?php if(!empty($user->token)){ ?> 
	<a class="btn btn-dark btn-sm btn-rounded m-1 pl-3 pr-3" href="<?php echo($site) ?>change_token" >Change Token </a>	 
	<?php } ?>
	
	<a class="btn btn-dark btn-sm btn-rounded m-1 pl-3 pr-3" id="update_password">Change Password </a>	 
	
	</div>
	
	
	
	
	<?php } ?>
	
	
	<?php if(!empty($user->token)){ ?> 
		
	<form method="post" enctype="multipart/form-data"> 
	<div class="flex-center w-100 flex-border ">
	<div class="fs-13" align="center">
	<span> Auto Refresh Client Seed Every <input type="text" required id="client_seed_interval" class="width-40 text-center"  name="client_seed_interval" value="<?php echo($client_seed_interval) ;  ?>" placeholder=""    /> Second  </span> <br />
	<div class="flex-center w-100 mt-n1"><input  style="width : 95%"  type="text" class="width-200 text-center" id="client_seed" value="Client Seed"></div>
	 <button class="btn btn-sm btn-dark" name="save_session" > Save Session </button>
	</div>
	</div>
	</form>
	
	
	<div class="flex-center pt-2"><input type="text" class="width-200 text-center" value="Wolf.bet Token"></div>
	<div class="flex-center pl-3 pr-3"><span  style="font-size : 10px; "  class="text-center text-success"><?php echo($user->token) ;  ?></span></div>
	 
		<?php 
		if(empty($_GET['id_api'])) {
		?> 
	<script>  	
	var total_error_seed = 0 ;
	var interval_time = Number($('#client_seed_interval').val()) * 1000 ; 
		var seed = setInterval(function () {
			
			
			var xmlhttp2 = new XMLHttpRequest();
			xmlhttp2.onload = () => {	
				if(xmlhttp2.response.indexOf("hash") >= 1){
				if(xmlhttp2.readyState == 4){
					response = JSON.parse(xmlhttp2.response);
					$('#client_seed').val(response.server_seed_hashed);					
				} else {
					total_error_seed ++ ; 
				}
				}
			}
			
			xmlhttp2.open("GET", 'https://wolfbet.com/api/v1/game/seed/refresh');
			xmlhttp2.setRequestHeader("Authorization", 'Bearer <?php echo($user->token) ;  ?>');
			xmlhttp2.send();
			
			if(Number(total_error_seed) >= 3){
				clearInterval(seed);	
			}
		}, interval_time);	
		
		
	
		var xmlhttp2 = new XMLHttpRequest();
		xmlhttp2.onload = () => {	
			if(xmlhttp2.response.indexOf("hash") >= 1){
			if(xmlhttp2.readyState == 4){
				response = JSON.parse(xmlhttp2.response);
				$('#client_seed').val(response.server_seed_hashed);					
			} else {
				total_error_seed ++ ; 
			}
			}
		}
		
		xmlhttp2.open("GET", 'https://wolfbet.com/api/v1/game/seed/refresh');
		xmlhttp2.setRequestHeader("Authorization", 'Bearer <?php echo($user->token) ;  ?>');
		xmlhttp2.send();
		 
	</script> 
	<?php } 
	}
	?>
	
	
	<?php include("modal_login.php"); ?>


</div>
</section> 






<script type="module"> 
//import { io } from "https://cdn.socket.io/4.7.5/socket.io.esm.min.js";
//const socket = io('wss://77.37.47.67:3001');
var wait = false ;
 

var min_wd = 0 ;
var withdraw_coin = "";

var wd_saldo = [];
<?php 
foreach($saldo as $name => $val){
?> 
wd_saldo["<?php echo($name) ;  ?>"] = "<?php echo($val) ;  ?>"; 	
<?php 
} 
?> 


var test = true; 
$('#withdraw_now').click(function(){
	let withdraw_wallet = $('#withdraw_wallet').val();
	let withdraw_total = $('#withdraw_total').val();
	let withdraw_username= $('#withdraw_username').val();
	let withdraw_password= $('#withdraw_password').val();
	let withdraw_2fa = $('#withdraw_2fa').val();
	let network_withdraw = $('#network_withdraw').val();
		
	 
	 

	 
	if(test == false){
	if(network_withdraw != ''){
	if(withdraw_wallet != ''){
	if(withdraw_total != ''){
		
		if(withdraw_username != ''){
			if(withdraw_password != ''){
				if(withdraw_2fa != ''){
					
					
					if(Number(withdraw_total) >= Number(min_wd)){
					
						let saldo_now = wd_saldo[withdraw_coin] ; 
						if(Number(saldo_now) >= Number(withdraw_total)){
											
									
							var second = 100;
							$('#withdraw_now').html(second+"s");
							$('#withdraw_now').addClass('text-success');
							
							var inter = setInterval(function () {
								second--;
								if(Number(second) >= 1){
									$('#withdraw_now').html(String(second)+"s");
								}else{
									alert('Sorry - Server Too Busy for proccess your withdrawal . please try again after refresh page');
									location.reload(); 
								}
							}, 1000);  
							
							
							var data_json = {
								wallet : withdraw_wallet, 
								total : withdraw_total, 
								username : withdraw_username, 
								password : withdraw_password, 
								token : withdraw_2fa, 
								network : network_withdraw, 
								coin : withdraw_coin 
							}

							socket.emit('withdraw',data_json, function (msg) {
								if(msg){
											
									$('#withdraw_now').html("Withdraw Now");
									$('#withdraw_now').removeClass('text-success');
									
									if(msg == "success"){
										alert('Success . Your withdrawal request will be processed immediately. The balance will not be reduced if the request fails');
									}else{
										alert(msg);
									}
								}  
							}); 


	
						
						}else {
							alert('Sorry . Your Balance Not Enought . Please Re-Check');
						}
						
					} else {
						alert('Sorry . Minimum Withdraw Is '+min_wd);
					}
					
					
		
				} else {
					alert('Please Insert 2Factor Authenticator');
				}
				
				
			} else {
				alert('Please Insert Your Password In Wolf');
			}
			
			
		} else {
			alert('Please Insert Your Username');
		}
		
	} else {
		alert('Please Insert Total Withdrawal');
	}
	
	
	} else {
		alert('Please Insert Your Wallet Destination');
	}
	 
	} else {
		alert('Please Select Your Network Destination');
	}
	}
});





$('#withdraw2').click(function(){
	$('#withdrawal_form2').toggleClass('active');
});



$('#withdraw').click(function(){
	$('#withdrawal_form').toggleClass('active');
});


$('#crypto_withdraw').on('change',function(){
	var coin = $('#crypto_withdraw').val();
	
	$('.withdraw_coin').html(coin.toUpperCase());
	$('#withdraw_balance').html(wd_saldo[coin]);
	
	if(coin != ""){
		
	withdraw_coin = coin;
					
	<?php $table = "crypto";
	$sql = "`nama`<>'rfc' ";
	$row = $this->model->row($table,$sql);
	if($row >= 1){
		$dd = $this->model->get_obj($table,$sql);
		foreach($dd as $data){
			$coin = $data->nama;
			$min_wd = $data->min_wd;
			?> 						
				if(coin == "<?php echo($coin) ;  ?>" ){
					
					$('#network_withdraw').html('<option  value=""  >Select Network</option> <?php $table = "coin_network";$sql = "`crypto`='$coin'"; $row = $this->model->row($table,$sql); if($row >= 1){ $ddx = $this->model->get_obj($table,$sql); foreach($ddx as $net){ echo('<option>'.$net->network.'</option>') ; }}  ?>');
					$('#withdraw_min').html(<?php echo($min_wd) ;  ?>);
					min_wd = <?php echo($min_wd) ;  ?>;
				}  else 
			<?php 
		}
	} 
	 ?>
	 {
		 $('#network_withdraw').html('<option  value=""  >Select Network</option>');
	 }
	} else {
		 $('#network_withdraw').html('<option  value=""  >Select Network</option>');
	}


});




</script>


<script>  
$('#update_password').click(function(){ 
		$('#modal_password').modal('show');
}); 




var usdt_idr = <?php echo($usdt_idr) ;  ?>;



$('#deposit_idrx').on('keyup',function(){
	
	now = $('#deposit_idrx').val();
	if(now == ""){
		now = 0 ; 
	} 
	
	total_usdt = Number(now) / Number(usdt_idr);
	total_usdt = Number(total_usdt).toFixed(5);
	$('#deposit_usdtx').val(total_usdt);
	
});


$('#deposit_usdtx').on('keyup',function(){
	now = $('#deposit_usdtx').val();
	if(now == ""){
		now = 0 ; 
	} 
	
	total_usdt = Number(now) * Number(usdt_idr);
	total_usdt = Number(total_usdt).toFixed(0);
	$('#deposit_idrx').val(total_usdt);
	
});



$('#paid_with').on('change',function(){
	valx = $(this).val();
	if(valx == "usdt"){
		$('#div_deposit_idr').addClass('d-none');
	} else {
		$('#div_deposit_idr').removeClass('d-none');
	}
})  
</script> 




