<?php 
	$this->db->query("UPDATE `user` set `bet`= 0 WHERE  `bet` < 0  ");
	$id = ""; 
	if(!empty($_GET['id'])){ 
	$id = in($_GET['id']); 
	}
	$test = "";
	if(!empty($_GET['test'])){ 
	$test = in($_GET['test']); 
	$_SESSION['test'] = $test; 
	}

	if(!empty($_SESSION['test'])){
		$test= $_SESSION['test']; 
	} 
	
	
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title><?php echo($settings->nama) ;  ?></title>
	<link rel="icon" type="image/x-icon" href="<?php echo($site) ?>/image/32.png">
    <link rel="stylesheet" href="<?php echo($site) ?>/assets_landing/bootstrap/css/bootstrap.min.css">
	<link rel="manifest" href="<?php echo($site) ?>/manifest.webmanifest" />
    <link rel="stylesheet" href="<?php echo($site) ?>/assets_landing/fonts/line-awesome.min.css">
    <link rel="stylesheet" href="<?php echo($site) ?>/assets_landing/css/styles.css?random_data=<?php echo(rand(0,99999)) ;  ?>">
	<meta property="og:url" content="<?php echo($site) ?>" />
	<?php include("style.php"); ?>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha512-SfTiTlX6kk+qitfevl/7LibUOeJWlt9rbyDn92a1DqWOw9vWG2MFoays0sgObmWazO5BQPiFucnnEAjpAB+/Sw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="<?php echo($site) ?>/assets_landing/js/jquery.min.js"></script>
    <script src="<?php echo($site) ?>/assets_landing/js/first.js?random_data=<?php echo(rand(0,99999)) ;  ?>"></script>
		
	<script src="<?php echo($site) ?>assets/modules/datatables/datatables.min.js?id=1"></script>
	<script src="<?php echo($site) ?>assets/modules/datatables/DataTables-1.10.16/js/dataTables.bootstrap4.min.js"></script>
	<script src="<?php echo($site) ?>assets/modules/datatables/Select-1.2.4/js/dataTables.select.min.js"></script>
	<script>  
	
		kode_uang = "<?php echo($kode_uang) ;  ?>";
		round_uang = <?php echo($round_uang) ;  ?>;
		kali_uang = <?php echo($kali_uang) ;  ?>;
		
		$( document ).ready(function() {
		kali_uang= "<?php echo($kali_uang) ;  ?>"; 
		round_uang = "<?php echo($round_uang) ;  ?>"; 
		kode_uang = "<?php echo($kode_uang) ;  ?>"; 
		});
		
	</script> 


</head> 
 
<body> 
<main class="overflow-style" >
<div class="loading_progress"><div class="loading_width"><div class="loading_now"></div></div></div>
 
<?php include("modal.php"); ?>
<section class="main-mobile overflow-style"  style="position:relative;" >
<div class="min-vh-100 w_normal border-active">