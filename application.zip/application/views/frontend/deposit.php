<?php 
if(!empty($user)){
$id_user = $user->id;
$secret = $user->secret; 
$table = "crypto";
$sql = "`nama`='rfc'";
$row = $this->model->row($table,$sql);
if($row >= 1){
$rfc = $this->model->get_obj($table,$sql)[0];
	

if(isset($_POST['deposit'])){
	$id_bank = in($_POST['id_bank']);
	$total = in($_POST['total']);	 
	
	
	$table = "bank";
	$sql = "`id`='$id_bank'";
	$row = $this->model->row($table,$sql);
	if($row >= 1){
		$dd = $this->model->get_obj($table,$sql)[0];
		$bank = '';
		$bank .= $dd->bank_jenis ."<br />"; 
		$bank .= "Account No : ".$dd->bank_rekening."<br /> " ;
		$bank .= "AN : ".$dd->bank_nama ;
	
		$invoice = "INV".date('ymdhis').$id_user;
		if($total >=1){
			$total_idr = $rfc->idr * $total;			
			$this->db->query("INSERT INTO `deposit`
			(`total_rfc`, `total`, `tujuan`, `id_user`, `invoice`,`secret`) VALUES 
			('$total','$total_idr','$bank', '$id_user','$invoice','$secret' ) ");
				redirect("?page=deposit&inv=".$invoice);

			 
		} 
	}
}  
}
}



include("deposit_view.php");
?>