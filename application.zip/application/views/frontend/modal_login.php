<style>
	.modal-dialog{
	width : 350px!important;
	max-width:100%!Important;
}

</style>
    <div class="modal fade hide" role="dialog" tabindex="-1" id="modal_register">
        <div class="modal-dialog" role="document">
            <div class="modal-content"> 
                <div class="modal-body">
					
					<h3 align="center"  style="color:#dddddd!important; " > Create a username and password </h3> 
					<p style="color:#dddddd!important;line-height:18px;font-size : 15px; "> 
					Creating a username and password allows you to access your account from bother browsers, computers, mobiles and also protects you from 
					losing your account if application crashes or if you 
					exit the bot . Make sure you remember or write down 
					your username and password 					
					</p> 
					
					<form method="post" enctype="multipart/form-data"> 
						<input type="text" class="w-100 text-center"  style="color:#dddddd!important;height: 35px!important; margin-bottom: 10px;border-radius:0px!important;font-size : 18px!important;font-weight : 500;display:flex; align-items:center; justify-content:center;box-shadow:none!important; border:0px!Important;outline:none!important; "  name="secret" required value="" placeholder="Username">
						<input type="password" class="w-100 text-center"  style="color:#dddddd!important;height: 35px!important; margin-bottom: 10px;border-radius:0px!important;font-size : 18px!important;font-weight : 500;display:flex; align-items:center; justify-content:center;box-shadow:none!important; border:0px!Important;outline:none!important; "  name="password" required value="" placeholder="Password">
						<input type="text" class="w-100 text-center"  style="color:#dddddd!important;height: 35px!important; margin-bottom: 10px;border-radius:0px!important;font-size : 18px!important;font-weight : 500;display:flex; align-items:center; justify-content:center;box-shadow:none!important; border:0px!Important;outline:none!important; "  name="referral" required value="" placeholder="Referral">
						
					<div class="pl-4 pr-4">
						<button class="btn btn-dark btn-sm w-100 pl-3 pr-3"  style="border-radius:5px!Important;font-size : 15px!important; 
						color:#dddddd!important; height: 30px!important;display:flex; align-items:center; justify-content:center;font-weight : 500;"  name="register_secret" type="submit">Create a username and password </button>
					</div>
					
					</form>
					
				</div>
            </div>
        </div>
    </div>
	
    <div class="modal fade hide" role="dialog" tabindex="-1" id="modal_password">
        <div class="modal-dialog" role="document">
            <div class="modal-content"> 
                <div class="modal-body">
					
					<h3 align="center"  style="color:#dddddd!important; " > Update Password </h3> 
					<p style="color:#dddddd!important;line-height:18px;font-size : 15px; "> 
						Save and Remember Your Password .
					</p> 
					
					<form method="post" enctype="multipart/form-data"> 
						<input type="text" class="w-100 text-center"  style="color:#dddddd!important;height: 35px!important; margin-bottom: 10px;border-radius:0px!important;font-size : 18px!important;font-weight : 500;display:flex; align-items:center; justify-content:center;box-shadow:none!important; border:0px!Important;outline:none!important; "  name="new_secret" required value="" placeholder="NEW USERNAME ">
						<input type="text" class="w-100 password text-center"  style="color:#dddddd!important;height: 35px!important; margin-bottom: 10px;border-radius:0px!important;font-size : 18px!important;font-weight : 500;display:flex; align-items:center; justify-content:center;box-shadow:none!important; border:0px!Important;outline:none!important; "  name="new_password" required value="" placeholder="NEW PASSWORD">
						<input type="text" class="w-100 password text-center"  style="color:#dddddd!important;height: 35px!important; margin-bottom: 10px;border-radius:0px!important;font-size : 18px!important;font-weight : 500;display:flex; align-items:center; justify-content:center;box-shadow:none!important; border:0px!Important;outline:none!important; "  name="old_password" required value="" placeholder="CONFIRM OLD PASSWORD">
						
						<div class="pl-4 pr-4">
							<button class="btn btn-dark btn-sm w-100 pl-3 pr-3"  style="border-radius:5px!Important;font-size : 15px!important; 
							color:#dddddd!important; height: 30px!important;display:flex; align-items:center; justify-content:center;font-weight : 500;"  name="update_password" type="submit">Update Access Login </button>
						</div>
					
					</form>
					
				</div>
            </div>
        </div>
    </div>
	
<script>  

$(document).ready(function() {
	$('#register_secret').click(function(){ 
		$('#modal_register').modal('show');
	}); 

}); 
</script> 