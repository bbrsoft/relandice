<?php if(!empty($user)){?> 
<?php 
$id_user = $user->id;
$total_ref = $this->model->row("user","referral='$id_user' ");

?> 

<div class="tab-pane" role="tabpanel" id="tab-6"> 

<div class="pl-3 pr-3">
	<a class="btn btn-dark btn-sm" onclick="show_tab('#tab-3')" > &lt; Back To Account </a> 
	<b class="fs-16 mt-1 d-block"> History Bonus Referral (Today) </b> 
	<p> Get more commision by referrer your friend to join in <?php echo($settings->name) ;  ?> , Ref Code = <?php echo($user->secret) ;  ?> . Total Ref = <span class="text-success">  <?php echo($total_ref) ;  ?> </span> User </p> 
	
	
	<table id="tables" class="table table-striped table-bordered">
		<thead>
		<tr>
			<th  style="width : 80px" > Datetime </th>
			<th  style="min-width : 100px" > Total </th>			
		</tr>
		</thead>
	</table> 
</div>



<div class="pl-3 pr-3"> 
	<b class="fs-16 mt-1 d-block"> Referral </b> 
	<p> You Have <span class="text-success">  <?php echo($total_ref) ;  ?></span> Total Referral Active  . </p> 
	
	
	<table class="table table-striped table-bordered">
		<thead>
		<tr>
			<th  style="width : 80px" > Secret Name </th> 		
		</tr>
		</thead>
		<tbody>
		<?php $table = "user";
		$sql = "`referral`='$id_user'";
		$row = $this->model->row($table,$sql);
		if($row >= 1){
			$dd = $this->model->get_obj($table,$sql);
			foreach($dd as $data){
				?> 
				<tr> 
					<td> <?php echo($data->secret) ;  ?> </td>
				</tr> 
				<?php 
			}
		} else {?> 
		<tr> 
			<td> You Dont Have Any Referral </td>
		</tr> 
		<?php }
		 ?>
		</tbody> 
	</table> 
</div>


<script>  
site ="<?php echo($site) ?>";
 
var tablex = $('#tables').dataTable( {
 "bProcessing": true,
 "bServerSide": true,  
 "order" : [[0, 'desc']],
    "ajax" : { 
        url:  site+"server/bonus.php?id_user=<?php echo($user->id) ;  ?>", 
        type:"POST"
    } ,
	
 "aoColumns": [
  
	{ "mclass":"wall", "mData": "0", "mRender": function ( data, type, full ) {
		return data+"<br />"+full[1];
	}},
	{ "mclass":"wall", "mData": "2", "mRender": function ( data, type, full ) {
		div = '<span class="text-success"> '+data+' USDT </span> <br /> <small> Profit - From '+full[3]+'</small> ';
		return div;
	}}
	
	
 ]
 } );
   
 


</script> 

</div>


  

 
<?php }  ?>
