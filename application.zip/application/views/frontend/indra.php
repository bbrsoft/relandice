<div class="d-flex gap-1">
<div class="box_size" role="button">1</div>
<div class="box_size" role="button">1</div>
<div class="box_size" role="button">1</div>
<div class="box_size" role="button">1</div>
<div class="box_size" role="button">1</div>
</div>

<style>
	
	 
</style>