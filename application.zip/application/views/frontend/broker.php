<?php if (($user->id <> -1) && ($user->strategy == "No") ) {
?> 
 
<div class="px-3"  style="position:fixed; top:0px!important;left:0px; width : 100%; height: 100%; background: rgba(0,0,0,0.7)" >
		<div class="row m-0 justify-content-center align-items-center h-100 w-100">
		<div class="col-lg-6 p-0 col-md-6 col-sm-12 col-xs-12 col-12 ">
		<div class="pt-3 pb-3"  style="border-radius:5px; background: rgba(0,0,0,0.8)" >
		<div class="" align="center">
			<h5 class="mb-0"> Broker Selected </h5> 
			<p> Please select the dice game broker you wish to use.  </p> 
		</div>
		<form method="post" enctype="multipart/form-data"> 
		<div class="" align="center"  style="gap:10px;" >
			
			<button name="wolf" class="btn btn-dark m-1" > WOLFBET.COM </button> 
			<button name="primedice" class="btn btn-dark m-1" > PRIMEDICE.COM </button> 
			<button name="copytrade" class="btn btn-dark m-1" > COPY TRADE </button> 
		</div>
		
			<?php if(isset($_POST['primedice'])){
				?> 
				<p class="fs-12 text-warning d-block px-3 mt-2 mb-0" align="center"> Sorry. BOT With Broker Primedice.com Is Maintennace. Please Try Later </p> 
				<?php 
			}  ?>
			
		</form>
		
		</div>
	
	</div>
	</div>
</div>

<?php }  ?>
