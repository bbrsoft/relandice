<?php if(!empty($user)){?> 
<?php 
$id_user = $user->id;
$total_ref = $this->model->row("user","referral='$id_user' ");

	
$total_komisi = 0 ;
$table = "user";
$sql = "`referral`='$id_user' and `total_lose` > 0 and `tersedia` > 0 ";
$row = $this->model->row($table,$sql);
if($row >= 1){
	$dd = $this->model->get_obj($table,$sql);
	foreach($dd as $ref){
		$total_dibagikan = ($ref->total_lose * $ref->tersedia_max)/ 100;
		if($total_dibagikan >= $ref->tersedia){
			$total_dibagikan = $ref->tersedia ; 
		} 
		$total_komisi += $total_dibagikan; 
	}
} 



?> 

<style>
	.absolute_top_right{  position:absolute;  top:0px!important;  right:0px!Important; }
	.absolute_top_left{  position:absolute;  top:0px!important;  left:0px!Important; }
	
</style>
<div class="bg_black_4 p-3">
	 
	<div class="bg-header relative radius-5 p-3">
		<div class="relative">
			<a class="absolute_top_right fs-20 text-light" onclick="showinfo('<?php echo remove_enter($settings->informasi_referral) ;  ?>')" > <i class="fa fa-info-circle">  </i> </a> 
			<span class="fs-13 text-secondary"> Referral Commision - Available </span> 
			<h5 class="text-success"> <?php echo uang($total_komisi,2 ) ;  ?> USDT </h5> 
			<form method="post" enctype="multipart/form-data"> 
				<button type="submit" name="claim" class="btn btn-sm form-control text-success fs-16 btn-dark"  style="font-weight : 500"  >Claim To Wallet </button>
			</form>
		</div>
	</div>
 
	<div class="bg-header radius-5 p-3 mt-3">
	<h5 class="mb-0 d-block"> Your Referral </h5> 
	<p class="mb-0 text-secondary"> You Have <span class="text-success">  <?php echo($total_ref) ;  ?></span> Total Referral Active  . </p> 
	</div>

	<div class="bg-header">
		 
		<?php $table = "user";
		$sql = "`referral`='$id_user' ORDER BY total_lose DESC , id DESC ";
		$row = $this->model->row($table,$sql);
		if($row >= 1){
			$dd = $this->model->get_obj($table,$sql);
			foreach($dd as $data){
				$open = ($data->total_lose * 3.5) / 100;
				$open = uang($open, 2); 
				
				if($open >= $data->tersedia){
					$open = $data->tersedia; 
				} 
				
				?> 
			<div class="d-flex bg_black_2 mb-2 px-3 pt-2 pb-2 align-items-center justify-content-between gap-2 ">
				<span class="fs-16" style="width : 40%!important;" > <?php echo ucfirst($data->secret) ;  ?></span> 
				<span  style="width : 30%!important; line-height:14px!important;" align="center" > <b class="text-success">  <?php echo ($data->tersedia) ;  ?> USDT </b> <small class="d-block"> Available </small>  </span> 
				<span  style="width : 30%!important; line-height:14px!important;" align="right"><b>  <?php echo uang($open,2) ;  ?> USDT </b> <small class="d-block"> Can be claimed </small></span> 
			</div>
 
				<?php 
			}
		} else {?>  
			<div class="p-3">
				You dont have a referrer 			
			</div>
		
		<?php }
		 ?>
		 
	
	</div>
 
</div>




  

 
<?php }  ?>

