<div class="min-vh-100 mode_developer w_normal"  style="height: 100%!important;background: #2f2f2f; overflow:hidden!important; " >
<span class="fs-11 text-success"  style="position:absolute; right:10px; top:5px" > Mode Developer </span> 
	<div class="p-3 pt-4 w-100"  style="background: rgba(0,0,0,0.2); height: auto!important;" id="active_fitur" >
		<div class="box_developer active">
			Bot Is Not Play
		</div>
	</div>
	
	<div class="p-3" id="respon_developer"  style="overflow:auto!important; height: 100%!important;width : 100%!important;" >
		<div class="item_respon2"> <span> Bot Is Not Play </span>  </div>
		
	</div>
	<a class="btn btn-dark w-100"  style="position:absolute; bottom:0px;" onclick="toggle_developer()" > Back To Normal Mode </a> 
</div>