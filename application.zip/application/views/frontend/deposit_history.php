<div class="pl-3 pr-3 pt-3">
	<a class="btn btn-dark btn-sm" href="<?php echo($site) ?>" > &lt; Back To Home</a> 
	<br />
	 
	<h5 class="d-block mt-3"> Deposit History </h5> 
	<p> Here is a history of your 10 most recent deposit requests. </p> 
	<hr>
	
	<?php $table = "deposit";
	$sql = "`id_user`='$id_user' and type='usdt' ORDER BY id DESC LIMIT 10  ";
	$row = $this->model->row($table,$sql);
	if($row >= 1){
		$dd = $this->model->get_obj($table,$sql);
		foreach($dd as $data){
			$cl = "warning";
			if($data->status == "Accept"){ $cl = "success"; } 
			if($data->status == "Expired"){ $cl = "danger"; } 
			
			?> 
				<div class="p-2 radius-5 mt-3"  style="background: rgba(0,0,0,0.2)!important; border:1px solid black; " >
					<small  class="text-secondary"> Date : <?php echo(date('d M Y H:i:s', strtotime($data->date))) ;  ?></small>  <br />
					<div class="d-flex align-items-center justify-content-between">
						<span class="text-secondary"> Invoice </span> 
						<span> <?php echo($data->invoice) ;  ?></span> 
					</div>
					
					<div class="d-flex align-items-center justify-content-between">
						<span class="text-secondary"> Total Deposit  </span> 
						<span> <?php echo($data->total_rfc) ;  ?> USDT </span> 
					</div>
					
					<div class="d-flex align-items-center justify-content-between">
						<span class="text-secondary"> Paid With  </span> 
						<span> <?php echo strtoupper($data->paid_with) ;  ?> </span> 
					</div>
					
					
					<div class="d-flex align-items-center justify-content-between">
						<span class="text-secondary"> Status  </span> 
						<span class="text-<?php echo($cl) ;  ?>"> <?php echo ($data->status) ;  ?> </span> 
					</div>
					
					<?php if($data->status == "Waiting Payments"){?> 
					<a class="btn btn-dark btn-sm w-100 mt-2 d-block" href="<?php echo($site) ?>?page=payment&inv=<?php echo($data->invoice) ;  ?>"> Pay Now </a>  
					<?php 
					}  ?>
					
				
				</div>
			<?php 
		}
	} 
	 ?>
	
	
</div>



