<?php 
if(!empty($user)){
$id_user = $user->id;
$table = "crypto";
$sql = "`nama`='rfc'";
$row = $this->model->row($table,$sql);
if($row >= 1){
$rfc = $this->model->get_obj($table,$sql)[0];
	


?> 


<div class="tab-pane" role="tabpanel" id="tab-7"> 
<div class="pl-3 pr-3 pt-2">
	<a class="btn btn-dark btn-sm" onclick="show_tab('#tab-3')" > &lt; Back To Account </a> 
	<b class="fs-16 mt-1 d-block"> Buy RFC </b> 
	<p class="mb-2"> Request Deposit RFC With IDR Currency , 1 RFC = Rp. <?php echo uang($rfc->idr,0) ;  ?> </p> 
	<form method="post" action="<?php echo($site) ?>?page=deposit" enctype="multipart/form-data"> 
		<span> Total RFC </span> 
		<input type="number" id="deposit_rfc" step="0.01" min="1" onkeyup="check_total_idr('<?php echo($rfc->idr) ;  ?>')"  required class="form-control mb-1  text-white" name="total" value="" placeholder="Total Deposit RFC"    />
		<span> Bank Transfer Destination </span> 
		<select type="text" required class="form-control mb-1  text-white" name="id_bank" value="" placeholder=""  >
		<?php $table = "bank";
		$sql = "`id`<>-1";
		$row = $this->model->row($table,$sql);
		if($row >= 1){
			$dd = $this->model->get_obj($table,$sql);
			foreach($dd as $data){
				?> 
				<option  value="<?php echo($data->id) ;  ?>"  > <?php echo($data->bank_jenis) ;  ?> </option> 
				<?php 
			}
		} 
		 ?>
		</select>
		
		<span> Total IDR </span> 
		<input type="text" id="deposit_idr"  readonly class="form-control mb-1 text-white" value="" placeholder="1 RFC = <?php echo uang($rfc->idr, 0) ;  ?>"    />
		<br />
		
		<button type="submit" class="btn btn-dark w-100 mb-2" name="deposit" >Request Deposit </button>  
	</form>
</div>

<hr>



<div class="pl-3 pr-3"> 
	<b class="fs-18  d-block"> Deposit History </b> 
	<p> You Can Click Invoice for detail of payments </p> 
	
	<table class="table table-striped table-bordered">
		<thead>
		<tr>
			<th  style="width : 80px" > Invoice </th> 		
			<th  style="width : 80px" > RFC </th> 		
			<th  style="width : 80px" > Status </th> 		
		</tr>
		</thead>
		<tbody>
		<?php $table = "deposit";
		$sql = "`id_user`='$id_user' and type='rfc' ORDER BY id DESC LIMIT 10 ";
		$row = $this->model->row($table,$sql);
		if($row >= 1){
			$dd = $this->model->get_obj($table,$sql);
			foreach($dd as $data){
				?> 
				<tr> 
					<td> <a class="text-success" href="<?php echo($site) ?>?page=deposit&inv=<?php echo($data->invoice) ;  ?>" > <?php echo($data->invoice) ;  ?> </a>  </td>
					<td> <?php echo uang($data->total_rfc, 2) ;  ?> </td>
					<td> <?php echo ($data->status) ;  ?> </td>
				</tr> 
				<?php 
			}
		} else {?> 
		<tr> 
			<td colspan="3"> You Dont Have Deposit History </td>
		</tr> 
		<?php }
		 ?>
		</tbody> 
	</table> 
	<br />
	<br />
	  
</div>
  

</div>


<script>  
function check_total_idr(per_idr){
	var total_rfc = $('#deposit_rfc').val();
	$('#deposit_idr').val('0');
	if(total_rfc != ""){
		if(total_rfc >= 1){
			total = Number(total_rfc) * Number(per_idr);
			total = Number(total).toFixed(0);
			$('#deposit_idr').val(total);
		} 
	} 
}

</script> 
  

 
<?php }  ?>
<?php }  ?>


