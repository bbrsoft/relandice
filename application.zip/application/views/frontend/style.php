<style>
	.mobile_width{
		width: 400px;
		max-width: 100%;
	}
	
	.td1{width : 60px; overflow:hidden;}
	.td2{width : 90px;max-width:90px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; padding-right:5px}
	.td3{width : 40px; overflow:hidden;}
	.td4{
		max-width : calc(100% - 190px)!important;
		width : calc(100% - 190px)!important;
		text-align:right!important; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; padding-right:5px ;}
	
	.box_size{
		width : calc(100% / 5);
		height : 45px;
		display:flex;
		align-items:center;
		justify-content:center;
		font-size : 16px!important;
		font-weight : 700px!important;
		cursor:pointer;
	}
	.border-box{
		border:1px solid rgba(255,255,255,.2);
	}
	.tabel_history th{
		text-align:left; 
		font-size : 14px;
	}
	.tabel_history{
		width : 100%;
	}
	 



/* CSS */
.box_size.active{
	color: lawngreen!important;
	background : lawngreen!important;
}
 

.box_size {
  overflow:hidden;
  appearance: button;
  background-color: #4a5354;
  border: solid transparent;
  border-radius: 7px!important;;
  border-width: 0 0 4px;
  box-sizing: border-box;
  color: #FFFFFF;
  cursor: pointer;
  display: flex; 
  font-weight: 700;
  letter-spacing: .8px;
  align-items:center;
  justify-content:center;
  margin: 0;
  outline: none;
  overflow: visible; 
  text-align: center;
  text-transform: uppercase;
  touch-action: manipulation;
  transform: translateZ(0);
  transition: filter .2s;
  user-select: none;
  -webkit-user-select: none;
  vertical-align: middle;
  white-space: nowrap; 
}

.box_size:after {
  background-clip: padding-box;
  background-color: #3a4143;
  border: solid transparent;
  border-radius: 5px;
  border-width: 0 0 4px;
  bottom: -4px;
  content: "";
  left: 0;
  position: absolute;
  right: 0;
  top: 0;
  z-index: -1;
}

.box_size,
.box_size:focus {
  user-select: auto;
}

.box_size:hover:not(:disabled) {
  filter: brightness(1.1);
  -webkit-filter: brightness(1.1);
}

.box_size:disabled {
  cursor: auto;
}

.box_size:active {
  border-width: 4px 0 0;
  background: none;
}
</style>