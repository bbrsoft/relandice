<div class="tab_manual_content active" id="tab_8_1">
<div class="p-3" id="tab_8_list"> 
	
	
	<div class="border p-3 radius-5"  style="border-color:black!important;" >
	<h5 class="fs-18 mb-3  d-flex align-items-center justify-content-between"> 
	<div class="">
		<i class="fa fa-code mr-2">  </i> 
		<span class="mr-2">   AI Strategy  </span>
	</div>
	<a class="btn btn-danger btn-sm px-3 btn-rounded mr-2" > Short </a>  
	</h5> 
	
	<div class="card" >
		<div class="card_header d-flex align-items-center fs-16"> 
			Bearfish Trend - Moderate <span class="badge bg-secondary text-light mx-2"> 5x </span> 
		</div>
		<div class="card_body">
			<div class="d-flex">
				<div class="text-success " align="">
					<small class="d-block"> 30D Back. Arbitrage ABY </small> 
					<h3  class="d-block mb-0"> +410.96% </h3> 
				</div>
				<div class="px-2"  style="line-height:16px;" >
					<div class="mb-1">
						<small> Upper limit </small> <br /> 
						<b> 0.000016832 </b>
					</div>
					
					<div class="mb-1">
						<small> Lower limit </small> <br /> 
						<b> 0.000004147 </b>
					</div>
					
					
					<div class="">
						<small> Max drawdown </small> <br /> 
						<b> -11.64% </b>
					</div>
				</div>
			</div>
			
		</div>
	</div>  
	
	<a class="btn btn-dark w-100 border-1 mt-3" id="copy_bot" > Copy Bot </a> 
	</div>
	
	
</div>


</div>
