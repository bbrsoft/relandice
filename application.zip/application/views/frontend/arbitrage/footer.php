</div>


<?php if(!empty($user)){?> 
 
<div class="bg_black_3 px-3 d-flex align-items-center justify-content-between"  style="position:absolute; bottom:0px; width : 100%; left:0px; height: 55px; box-shadow:0px 0px 10px 0px rgba(255,255,255,.05)" >	
	<a href="<?php echo($site) ?>/arbitrage" class="menu_item_2 text-light"  style="" align="center" >
		<i class="fa fa-calendar fs-18">  </i>
		<span class="d-block fs-12 text-secondary"> History Data </span> 
	</a>
	
	<a onclick="showcreate()" class="menu_item_2 text-light"  style="line-height:14px;" align="center" >
		<i class="fa fa-plus fs-20">  </i>
		<span class="d-block fs-12 text-secondary"> Create New</span> 
	</a>
	
	<a href="<?php echo($site) ?>/arbitrage/bonus" class="menu_item_2 text-light"  style="" align="center" >
		<i class="fa fa-gift fs-20">  </i>
		<span class="d-block fs-12 text-secondary"> Bonus </span> 
	</a>
	
	
	<a  href="<?php echo($site) ?>/?page=profile"  class="menu_item_2 text-light"  style="" align="center" >
		<i class="fa fa-user-circle fs-18">  </i>
		<span class="d-block fs-12 text-secondary"> Set Profile </span> 
	</a>
</div><?php 
}  ?>
