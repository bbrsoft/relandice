<script>
function showbank(){
	$('#modal_bank').modal('show'); 
}
function show_deposit(){
	$('#tab_manual_deposit').addClass('active');
	$('#tab_manual_withdraw').removeClass('active');
	$('#tab_3_deposit').addClass('active');
	$('#tab_3_withdraw').removeClass('active');
}

function show_withdraw(){
	$('#tab_manual_deposit').removeClass('active');
	$('#tab_manual_withdraw').addClass('active');
	
	$('#tab_3_deposit').removeClass('active');
	$('#tab_3_withdraw').addClass('active');
}

</script>

<div class="modal fade" id="modal_bank" role="dialog" style="display: none; margin-top:0px;">
 <div class="modal-dialog"style="border-radius:0px !Important ">
	 <div class="modal-content"style="border-radius:0px !Important ">
		 <div class="modal-header" style="border-radius:0px !Important ">
			 <span class="modal-title fs-20"  style="font-weight : 500" >Transaction Forms </span>
			 <button type="button"  style="color:white!Important; "  class="close" data-dismiss="modal">x</button>
		 </div>
		 <div class="modal-body p-0">
		 
		  
<div class="tab_manual m-0"  style="border-bottom:1px solid black;" >
	<a class="tab_manual_item active"  style="cursor:pointer;"  id="tab_3_deposit" onclick="show_deposit()"  > Deposit </a> 
	<a class="tab_manual_item"   style="cursor:pointer;" id="tab_3_withdraw"  onclick="show_withdraw()" > Withdraw </a> 
</div> 



<div class="p-3">
<div class="tab_manual_content active m-0" id="tab_manual_deposit">
	<form method="post" class="w-100 p-2 m-0 relative" enctype="multipart/form-data"> 
		<span class="d-block mb-2"> Deposit Form <?php if($arcur == "idr"){?>  (Rp. <?php echo uang($usdt_idr,0) ;  ?> / USDT) <?php } ?> </span> 
		
		<small align="left" class="d-block m-0 ">  Transfer Destination </small> 
		<select required name="paid_with" id="paid_with" class="w-100 form-control m-0"  style="color:white!Important;"  >
			<option  value=""  >Transfer Destination</option>
			<?php if($arcur == "idr"){?> 
			<option  value="bri"  >Bank Rakyat Indonesia (Virtual)</option>
			<option  value="qris"  >QRIS</option>
			<option  value="dana"  >E-Wallet DANA</option>
			<?php }  ?>
			
			<option  value="usdt"  >USDT (BEP20)</option>
		</select>
		
		<div id="div_deposit_idr" class="w-100 <?php if($arcur <> "idr"){echo(" d-none ") ; }  ?> m-0">
		<small align="left" class="d-block m-0 pt-2"> Deposit By IDR </small> 
		<input type="number" required min="20000" class="form-control m-0" name="deposit_idrx" id="deposit_idrx" value="" placeholder="Total Deposit (IDR)"    />
		</div>
		
		
		<small align="left" class="d-block m-0 pt-2">  Deposit By USDT </small> 
		<input type="number" required step="0.00000001" class="form-control m-0" name="deposit_usdtx" id="deposit_usdtx" value="" placeholder="Total Deposit (USDT)"    />
		
		
		<div class="d-flex align-items-center justify-content-between pt-3 pb-2 m-0 gap-1">
			<a class="btn btn-dark btn-sm  radius-5 w-50 m-0" href="<?php echo($site) ?>?page=deposit_history" >History Deposit </a>
			<button type="submit" class="btn btn-dark btn-sm w-50  radius-5  m-0"  name="deposit_now_usdt">Deposit Now</button>
		</div>
	</form>
</div>








<div class="tab_manual_content  " id="tab_manual_withdraw">
	<form method="post" class="w-100 m-0 p-2 " enctype="multipart/form-data"> 
		<span class="d-block mb-2"> Withdrawal Form <?php if($arcur == "idr"){?>  (Rp. <?php echo uang($usdt_idr - 1000 ,0) ;  ?> / USDT) <?php } ?></span> 
		
		<small align="left" class="d-block m-0 pt-2">  Withdraw Destination </small> 
		<select required name="type" class="w-100 form-control js-example-basic-single  m-0"  style="color:white!Important;"  >
			<option >Wallet USDT(BEP20)</option> 
			<?php
			if($arcur == "idr"){
			$table = "bank_api";
			$sql = "`id`<>-1";
			$row = $this->model->row($table,$sql);
			if($row >= 1){
				$dd = $this->model->get_obj($table,$sql);
				foreach($dd as $bank){
					?> 
							<option  value="<?php echo($bank->kode) ;  ?>"  ><?php echo($bank->bank_nama) ;  ?></option>
						<?php 
					}
				} 
			}
				?>
		</select> 
		
		<small align="left" class="d-block m-0 pt-2">  Account Number/ Wallet </small> 
		<input type="text" required class="form-control m-0" name="wallet" value="" placeholder="Account Number/Wallet Address"    />
		 
		
		<small align="left" class="d-block m-0 pt-2">  Total Withdraw (USDT)</small> 
		<input type="number" step="0.0000000000000001" max="<?php echo($user->usdt) ;  ?>" min="1" required class="form-control m-0" name="total"  value="" placeholder="Total Withdrawal"    />
		 
		<div class="d-flex gap-1 pt-3 pb-2">
			<a href="<?php echo($site) ?>?page=withdraw_history" class="btn btn-dark btn-sm  radius-5 w-50"  name="withdraw_now_usdt">History</a>
			<button type="submit" class="btn btn-dark btn-sm  radius-5 w-50"  name="withdraw_now_usdt">Withdraw Now</button>
		</div>
	</form>



</div>
</div>

		 
			
			 
		 
		 
		 </div> 
	 </div>
 </div>
</div>




 







<script>
function showcreate(){
	$('#modal_create').modal('show'); 
} 
</script>

<div class="modal fade" id="modal_create" role="dialog" style="display: none; margin-top:0px;">
 <div class="modal-dialog"style="border-radius:0px !Important ">
	 <div class="modal-content"style="border-radius:0px !Important ">
		 <div class="modal-header" style="border-radius:0px !Important ">
			 <span class="modal-title fs-20"  style="font-weight : 500" >Arbitrage Forms </span>
			 <button type="button"  style="color:white!Important; "  class="close" data-dismiss="modal">x</button>
		 </div>
		 <div class="modal-body ">
			
<div  style="height: 270px; overflow:hidden;border-radius:10px; box-shadow:0px 0px 10px 0px rgba(255,255,255,.05) " > 
<div  style="height: 300px" > 
<div class="tradingview-widget-container" style="height:300px;width:100%">
  <div class="tradingview-widget-container__widget" style="height:calc(100% - 32px);width:100%"></div>
  <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/" rel="noopener nofollow" target="_blank"><span class="blue-text">Track all markets on TradingView</span></a></div>
  <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-advanced-chart.js" async>
  {
  "autosize": true,
  "symbol": "CRYPTOCAP:SHIB",
  "interval": "10",
  "timezone": "Etc/UTC",
  "theme": "dark",
  "style": "1",
  "locale": "en",
  "hide_top_toolbar": true,
  "hide_legend": true,
  "allow_symbol_change": false,
  "save_image": false,
  "calendar": false,
  "hide_volume": true,
  "support_host": "https://www.tradingview.com"
} 
  </script>
</div> 
</div>
</div>


<form method="post" enctype="multipart/form-data"> 

<span class="d-block mt-2" id="copy_span_amount"> Active Balance </span> 
<input type="text" readonly disabled max="10000000" step="0.01" class="form-control text-success"    value="<?php echo round($user->usdt,2) ;  ?> USDT "  />


<span class="d-block mt-2" id="copy_span_amount"> Total Amount (USDT) </span> 
<input type="number" required max="<?php echo round($user->usdt,2) ;  ?>" step="0.01" class="form-control text-light"   id="copy_total" name="total_usdt" value="" placeholder="Total Amount "    />

		
<div class="pt-2 d-flex align-items-center justify-content-between w-100" align="right"> 
<a onclick="$('#auto_withdraw').toggleClass('active')" class="btn btn-dark btn-sm "  style="width : 150px"  ><i class="fa fa-gear">  </i> Auto Withdraw </a> 
<button type="submit" name="invest" class="btn btn-dark btn-sm text-success"  style="width : 150px"  ><i class="fa fa-check">  </i> Submit </button> 
</div>

</form>




<div id="auto_withdraw" class="auto_withdraw mt-3"  >
<div class="p-3 radius-5 " style="background: rgba(0,0,0,.5)!important;"  >
<form method="post" class="transparent_all" style="background: transparent!important;"  enctype="multipart/form-data"> 	

<script>  
function show_form_fiat(){ 
	$('#form_fiat').removeClass('d-none');
	$('#form_crypto').addClass('d-none');
}
function show_form_crypto(){
	$('#form_fiat').addClass('d-none');
	$('#form_crypto').removeClass('d-none');
}
  </script> 

<div class="d-flex align-items-center justify-content-between gap-1">
	<div class="w-50 d-flex align-items-center justify-content-center bg_black_2 gap-1 pt-2 pb-2">
		<input type="radio" id="with_fiat"  onclick="show_form_fiat()" required class="m-0" checked name="withdraw_with" value="fiat" placeholder=""    />
		<label class="m-0" for="with_fiat"  onclick="show_form_fiat()"> Fiat </label> 
	</div>
	<div class="w-50 d-flex align-items-center justify-content-center bg_black_2 gap-1 pt-2 pb-2">
		<input type="radio" id="with_crypto"  onclick="show_form_crypto()" required class="m-0" name="withdraw_with" value="usdt" placeholder=""    />
		<label class="m-0" for="with_crypto" onclick="show_form_crypto()" > Crypto </label> 
	</div>
</div>


<div class="<?php if($user->withdraw_with <> 'usdt'){ echo('d-none') ;  } ?>" id="form_crypto"> 
<small align="left" class="d-block m-0 pt-3">  Withdraw Destination </small> 
<select   name="bank_jenis"  class="w-100 form-control js-example-basic-single  m-0"  style="color:white!Important;"  >
	<option  value="usdt"  >USDT (BEP20)</option>
</select> 
<small align="left" class="d-block m-0 pt-2">  Wallet Address</small> 
<input type="text"   class="form-control m-0" name="wallet" value="<?php echo($user->wallet) ;  ?>" placeholder="Wallet Address"    />
</div>



<script>  
	<?php if($user->withdraw_with == "fiat"){
		?> 
			$('#with_fiat').click();
		<?php 
	} else {?> 
			$('#with_crypto').click();
	<?php }  ?>
</script> 





<div class="<?php if($user->withdraw_with <> 'fiat'){ echo('d-none') ;  } ?>" id="form_fiat" >
<small align="left" class="d-block m-0 pt-3">  Withdraw Destination </small> 
<select   name="bank_jenis"  class="w-100 form-control js-example-basic-single  m-0"  style="color:white!Important;"  >
	<?php
	$table = "bank_api";
	$sql = "`id`<>-1";
	$row = $this->model->row($table,$sql);
	if($row >= 1){
		$dd = $this->model->get_obj($table,$sql);
		foreach($dd as $bank){
			?> 
					<option <?php if($user->bank_jenis == $bank->kode){echo(" selected ") ; }  ?> value="<?php echo($bank->kode) ;  ?>"  ><?php echo($bank->bank_nama) ;  ?></option>
				<?php  
			} 
		} 
		?>
</select> 
<small align="left" class="d-block m-0 pt-2">  Account Number</small> 
<input type="text"   class="form-control m-0" name="bank_rekening" value="<?php echo($user->bank_rekening) ;  ?>" placeholder="Account Number"    />
<small align="left" class="d-block m-0 pt-2">  Name Of Owner </small> 
<input type="text"   class="form-control m-0" name="bank_nama" value="<?php echo($user->bank_nama) ;  ?>" placeholder="Name Of Owner"    />
</div>


<div class="pt-3 d-flex align-items-center justify-content-between" align=""> 
	<button type="submit" name="save_bank" class="btn btn-dark btn-sm text-success" > Save Account - Auto Withdraw </button> 
</div>



</form>


</div>
			
			
		 </div> 




	
</div> 
</div>
</div>
</div>




 





<script>  





$('#deposit_idrx').on('keyup',function(){
	
	now = $('#deposit_idrx').val();
	if(now == ""){
		now = 0 ; 
	} 
	
	total_usdt = Number(now) / Number(usdt_idr);
	total_usdt = Number(total_usdt).toFixed(5);
	$('#deposit_usdtx').val(total_usdt);
	
});


$('#deposit_usdtx').on('keyup',function(){
	now = $('#deposit_usdtx').val();
	if(now == ""){
		now = 0 ; 
	} 
	
	total_usdt = Number(now) * Number(usdt_idr);
	total_usdt = Number(total_usdt).toFixed(0);
	$('#deposit_idrx').val(total_usdt);
	
});



$('#paid_with').on('change',function(){
	valx = $(this).val();
	if(valx == "usdt"){
		$('#div_deposit_idr').addClass('d-none');
	} else {
		$('#div_deposit_idr').removeClass('d-none');
	}
})  

</script> 