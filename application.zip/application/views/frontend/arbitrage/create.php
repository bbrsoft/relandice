<div class="p-3">
<h5 class="mb-0"> Arbitrage Forms </h5> 
<p class=""> Insert Your amount , How much you want to spend in copy trade </p> 
<form method="post" enctype="multipart/form-data"> 

<span class="d-block mt-2" id="copy_span_amount"> Active Balance </span> 
<input type="text" readonly disabled max="10000000" step="0.01" class="form-control text-success"    value="<?php echo round($user->usdt,2) ;  ?> USDT "  />


<span class="d-block mt-2" id="copy_span_amount"> Total Amount (USDT) </span> 
<input type="number" required max="<?php echo round($user->usdt,2) ;  ?>" step="0.01" class="form-control text-light"   id="copy_total" name="total_usdt" value="" placeholder="Total Amount "    />

		
<div class="pt-2 d-flex align-items-center justify-content-between w-100" align="right"> 
<a onclick="$('#auto_withdraw').toggleClass('active')" class="btn btn-dark btn-sm "  style="width : 150px"  ><i class="fa fa-gear">  </i> Auto Withdraw </a> 
<button type="submit" name="invest" class="btn btn-dark btn-sm text-success"  style="width : 150px"  ><i class="fa fa-check">  </i> Submit </button> 
</div>

</form>
</div>




<div id="auto_withdraw" class="auto_withdraw" style="" >
<div class="p-3 radius-5 "  style="background: rgba(0,0,0,.5)!important;" >
<form method="post" enctype="multipart/form-data"> 	

<script>  
function show_form_fiat(){ 
	$('#form_fiat').removeClass('d-none');
	$('#form_crypto').addClass('d-none');
}
function show_form_crypto(){
	$('#form_fiat').addClass('d-none');
	$('#form_crypto').removeClass('d-none');
}
  </script> 

<div class="d-flex align-items-center justify-content-between gap-1">
	<div class="w-50 d-flex align-items-center justify-content-center bg_black_2 gap-1 pt-2 pb-2">
		<input type="radio" id="with_fiat"  onclick="show_form_fiat()" required class="m-0" checked name="withdraw_with" value="fiat" placeholder=""    />
		<label class="m-0" for="with_fiat"  onclick="show_form_fiat()"> Fiat </label> 
	</div>
	<div class="w-50 d-flex align-items-center justify-content-center bg_black_2 gap-1 pt-2 pb-2">
		<input type="radio" id="with_crypto"  onclick="show_form_crypto()" required class="m-0" name="withdraw_with" value="usdt" placeholder=""    />
		<label class="m-0" for="with_crypto" onclick="show_form_crypto()" > Crypto </label> 
	</div>
</div>


<div class="<?php if($user->withdraw_with <> 'usdt'){ echo('d-none') ;  } ?>" id="form_crypto"> 
<small align="left" class="d-block m-0 pt-3">  Withdraw Destination </small> 
<select   name="bank_jenis"  class="w-100 form-control js-example-basic-single  m-0"  style="color:white!Important;"  >
	<option  value="usdt"  >USDT (BEP20)</option>
</select> 
<small align="left" class="d-block m-0 pt-2">  Wallet Address</small> 
<input type="text"   class="form-control m-0" name="wallet" value="<?php echo($user->wallet) ;  ?>" placeholder="Wallet Address"    />
</div>



<script>  
	<?php if($user->withdraw_with == "fiat"){
		?> 
			$('#with_fiat').click();
		<?php 
	} else {?> 
			$('#with_crypto').click();
	<?php }  ?>
</script> 





<div class="<?php if($user->withdraw_with <> 'fiat'){ echo('d-none') ;  } ?>" id="form_fiat" >
<small align="left" class="d-block m-0 pt-3">  Withdraw Destination </small> 
<select   name="bank_jenis"  class="w-100 form-control js-example-basic-single  m-0"  style="color:white!Important;"  >
	<?php
	$table = "bank_api";
	$sql = "`id`<>-1";
	$row = $this->model->row($table,$sql);
	if($row >= 1){
		$dd = $this->model->get_obj($table,$sql);
		foreach($dd as $bank){
			?> 
					<option <?php if($user->bank_jenis == $bank->kode){echo(" selected ") ; }  ?> value="<?php echo($bank->kode) ;  ?>"  ><?php echo($bank->bank_nama) ;  ?></option>
				<?php  
			} 
		} 
		?>
</select> 
<small align="left" class="d-block m-0 pt-2">  Account Number</small> 
<input type="text"   class="form-control m-0" name="bank_rekening" value="<?php echo($user->bank_rekening) ;  ?>" placeholder="Account Number"    />
<small align="left" class="d-block m-0 pt-2">  Name Of Owner </small> 
<input type="text"   class="form-control m-0" name="bank_nama" value="<?php echo($user->bank_nama) ;  ?>" placeholder="Name Of Owner"    />
</div>


<div class="pt-3 d-flex align-items-center justify-content-between" align=""> 
	<button type="submit" name="save_bank" class="btn btn-dark btn-sm text-success" > Save Account - Auto Withdraw </button> 
</div>



</form>


</div>
</div>

