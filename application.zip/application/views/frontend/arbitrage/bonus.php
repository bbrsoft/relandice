<style>
	.card_gift{
		border-radius:5px;  
		display:flex; align-items:center;
		justify-content:space-between;
		padding:1rem;
		margin-bottom: 1rem;
	}
	
	.bg_gift_1{
		background: rgb(60,54,95);
		background: linear-gradient(90deg, rgba(60,54,95,1) 0%, rgba(50,55,56,1) 35%);
	}
	
	.bg_gift_2{
		background: rgb(92,54,54);
		background: linear-gradient(90deg, rgba(92,54,54,1) 0%, rgba(50,55,56,1) 35%);
	}
	
</style>
<div class="overflow_style relative"  style="height: 100%!important; background: #575454" >
	
	<div class="p-3">
			
		
		<div class="card_gift bg_gift_1">
			<div class="d-flex align-items-center justify-content-start"  style="width : 70px; " >
				<img src="<?php echo($site) ?>/image/target.png"  class="w-100" />
			</div>
			<div class="px-3"  style="width : calc(100% - 70px)" >
				<h5 class="mb-1 d-block"  style="margin-top: -5px;"  > Weekly Bonus </h5> 
				<p class="mb-0" style="line-height:16px;" > 
					<span>0.00000000 USDT</span>   
				</p> 			
			</div>
		</div>
			
	
		 
			
	
	</div>
	
	
</div>