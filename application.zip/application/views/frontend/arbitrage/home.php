<?php  
if(!empty($user)){
	
	$date = date('Y-m-d');
	$profit = 0 ;
	
	$sql = "SELECT SUM(total) as total , SUM(total_profit) as total_profit FROM copy_data WHERE id_user='$id_user' and `date_stop` >= '$date'  and  (status='Profit' or status='Lose') ";
	$data = $this->model->sql_fetch($sql)[0];
	$profit = $data->total_profit - $data->total;
	$profit_usdt = $profit / $usdt_idr;
?> 

<?php include("home_start.php"); ?>
  
<div class="px-3 pb-3 pt-3"> 
<div class="p-3 radius-5 relative mb-3"  style="background: rgb(249,217,106);
background: linear-gradient(80deg, rgba(249,217,106,1) 0%, rgba(255,191,65,1) 100%);
 color:black!Important; text-shadow:0px 0px 5px white" >
	
	<div class="d-flex align-items-center justify-content-between  "  >
		<div class="relative" style="width : 55%; border-right:1px solid rgba(249,217,106,1)!important;" >
			<span  onclick="showbank()"  style="cursor:pointer;"  > Balance <a> <i class="fa fa-plus-square fs-16 text-dark">  </i> </a> </span> 
			<h5 class="mb-0 relative w-100"> <?php echo round($user->usdt,2) ;  ?> USDT 
			</h5> 
			
			<small class="fs-12">  
			<?php 
				$x= $user->usdt * $usdt_idr;
				$x = $x * $kali_uang;
				$x = uang($x, $round_uang);
				echo($kode_uang." ".$x) ; 
			?>
			</small> 
		</div>
		
		<div style="width : 45%"  align="right">
			<span> Profit Today </span> 
			<h5 class="mb-0"> <?php echo round($profit_usdt,2) ;  ?> USDT </h5> 
			<small> 
				<?php 
				$x= $profit;
				$x = $x * $kali_uang;
				$x = uang($x, $round_uang);
				echo($kode_uang." ".$x) ; 
				?> 
			</small> 
		</div>
	</div>
	<div class="" align="right "  style="line-height:16px; padding-top:10px;" >
		Data is counted by every time <br />
		Daily statistics based on Netherland time (UTC+2) 
	</div> 
	
</div>
 
<style>
	.dataTables_length{
		display:none!important;
	}
</style>
 
 
<table id="tables" class="table table-striped table-no-padding">
<thead>
<tr>
	<th   style="display:none" > Data </th>
</tr>
</thead>
</table> 



<script>  
var step = [];
var profit = [];
var detik = [];
var modal = [];
var percent = [];

	<?php 
	$table = "copy_data";
	$sql = "`id_user`='$id_user' and status='Running'  ";
	$row = $this->model->row($table,$sql);
	if($row >= 1){
		$dd = $this->model->get_obj($table,$sql);
		foreach($dd as $data){
			$date = date('Y-m-d H:i:s');
			$date_now = strtotime($date);
			$date_start = strtotime($data->date_start);
			$date_stop = strtotime($data->date_stop);
			$sisa_detik = $date_stop - $date_now; 
			
			
			
			$percent = $data->percent - 0.1;
			$total_detik = $date_stop - $date_start; 
			
			$modal = $data->total * $kali_uang;
			$profit_akan_datang = ($modal * $percent)/ 100; 
			$step = $profit_akan_datang / $total_detik ;
			 
			if($sisa_detik <= 0){
				$sisa_detik = 0 ;
			} 
			 
			$detik_sebelumnya = $total_detik - $sisa_detik;
			$total_profit = $modal + $profit_akan_datang  ; 
			 
			$profit_sekarang = $modal + ($step * $detik_sebelumnya); 
			
			
			
			?> 
				step[<?php echo($data->id) ;  ?>] = <?php echo($step) ;  ?>;
				profit[<?php echo($data->id) ;  ?>] = <?php echo($profit_sekarang) ;  ?>;
				detik[<?php echo($data->id) ;  ?>] = <?php echo($sisa_detik) ;  ?>;
				modal[<?php echo($data->id) ;  ?>] = <?php echo($modal) ;  ?>;
				
				
				
				setInterval(function(){ 
					if(Number(detik[<?php echo($data->id) ;  ?>]) >= 1){
						profit[<?php echo($data->id) ;  ?>] = Number(profit[<?php echo($data->id) ;  ?>]) + Number(step[<?php echo($data->id) ;  ?>]);
						detik[<?php echo($data->id) ;  ?>]--;
						
						
						let sementara = (Number(profit[<?php echo($data->id) ;  ?>]).toFixed(0) * 100 ) / Number(<?php echo($modal) ;  ?>) ;
						sementara = Number(Number(sementara) - 100 ).toFixed(2);
						 
						
						if($('.running_usdt_<?php echo($data->id) ;  ?>').length >= 1){	
							$('.running_usdt_<?php echo($data->id) ;  ?>').html(Number(Number(profit[<?php echo($data->id) ;  ?>]) / Number(usdt_idr)).toFixed(8)+" USDT ( "+sementara+"%) " );
							
							
							$('.running_idr_<?php echo($data->id) ;  ?>').html(kode_uang+" "+uang(Number(Number(profit[<?php echo($data->id) ;  ?>]) - <?php echo($modal) ;  ?> ).toFixed(0),0) );	
						}
						
						
					
					} else {
						
						let sementara = (Number(profit[<?php echo($data->id) ;  ?>]).toFixed(0) * 100 ) / Number(<?php echo($modal) ;  ?>) ;
						sementara = Number(Number(sementara) - 100 ).toFixed(2);
						 
						
						if($('.running_usdt_<?php echo($data->id) ;  ?>').length >= 1){	
							$('.running_usdt_<?php echo($data->id) ;  ?>').html(Number(Number(profit[<?php echo($data->id) ;  ?>]) / Number(usdt_idr)).toFixed(8)+" USDT ( "+sementara+"%) " );
							$('.running_idr_<?php echo($data->id) ;  ?>').html(kode_uang+" "+uang(Number(Number(profit[<?php echo($data->id) ;  ?>]) - <?php echo($modal) ;  ?> ).toFixed(0),0) );	
						} 
					
					}
					
				},1000)
			<?php 
		}
	} 
	 ?>

</script> 

<script>  
function show_detail(idx){
 	$('#'+idx).toggleClass('active');
}



var site ="<?php echo($site) ?>";
const months = ["Jan", "Feb", "Mar", "Apr", "May", "June", "July", "Aug", "Sept", "Oct", "Nov", "Dec"];
const usdt_idr = <?php echo($usdt_idr) ;  ?>;

var tablex = $('#tables').dataTable( {
 "bProcessing": true,
 "bServerSide": true,  
 "order" : [[0, 'desc']],
    "ajax" : { 
        url:  site+"server/copy_history.php?id_user=<?php echo($user->id) ;  ?>", 
        type:"POST"
    } ,
	
 "aoColumns": [
  
	{ "mclass":"wall", "mData": "0", "mRender": function ( data, type, full ) {
		
		//$aColumns = array('date_start','date_stop','id_user','total','total_usdt','total_profit','status','percent','invoice','id');
	date_start = full[0];
	date_stop = full[1];
	id_user = full[2];
	total = full[3];
	total_usdt = full[4];
	total_profit = full[5];
	status = full[6];
	percent = full[7];
	invoice = full[8];
	id = full[9];
	
	if((status == "Running") || (status == "Waiting Payments") || (status == "Expired")){
		total_profit_idr = 0;
	}else { 
		total_profit_idr = Number(total_profit) - Number(total);
		total_profit_idr = Number(total_profit_idr) * Number(kali_uang);
		total_profit_idr = Number(total_profit_idr).toFixed(round_uang);		
	} 
	
	total_profit_usdt = Number(total_profit) / Number(usdt_idr); 
	total_profit_usdt = Number(total_profit_usdt).toFixed(4);
	
	
	total = Number(total) * Number(kali_uang);
	total = uang(total,round_uang)
	

	date = new Date(date_start);
	d = date.getDate();
	m = months[date.getMonth()];
	y = date.getFullYear();
	h = date.getHours()   ;
	i = date.getMinutes()   ;
	s = date.getSeconds()   ;

	date2 = new Date(date_stop);
	d2 = date2.getDate();
	m2 = months[date2.getMonth()];
	y2 = date2.getFullYear();
	h2 = date2.getHours()   ;
	i2 = date2.getMinutes()   ;
	s2 = date2.getSeconds()   ;
	
	class_profit = '';
	
	onc = "show_detail('history_detail_"+id+"')";
		
		div = '';
		div += '<div class="history_div bg_black_3 mb-2 radius-5 relative">';
		div += '<div onclick="'+onc+'"   class="history_main p-3 relative">';
		div += '<div class="fs-15"  style="line-height:18px!Important;width : 70px!Important;" >';
		div += '	<span class="bold"> '+d+' '+m+'</span> ';
		div += '	<small class="text-secondary d-block"> '+y+' </small> ';
		div += '</div>';
		
		if(status == "Running"){
			div += '<div class="fs-15"   style="line-height:18px!Important; width : 	calc(100% - 70px)">';
			div += '	<span class="bold text-success running_usdt_'+id+'  " > 0.00000000 USDT </span>  ';
			div += '	<small class="text-secondary d-block running_usdt_'+id+'  "> 0.00000000 USDT </small> ';
			div += '</div>';
			class_profit = "text-light";
		} 
		
		
		if(status == "Expired"){
			div += '<div class="fs-15"   style="line-height:18px!Important; width : 	calc(100% - 70px)">';
			div += '	<span class="bold text-success"> Expired </span>  ';
			div += '	<small class="text-secondary d-block"> Expired </small> ';
			div += '</div>';
			class_profit = "text-light";
		} 
		
		
		if(status == "Waiting Payments"){
			div += '<a class="fs-15 d-block" href="'+site+'?page=payment_invest&inv='+invoice+'"  style="line-height:18px!Important; width : 	calc(100% - 70px)">';
			div += '	<span class="bold text-warning"> Paid Now </span>  ';
			div += '	<small class="text-secondary d-block"> Waiting Payments </small> ';
			div += '</a>';
			class_profit = "text-warning";
		} 
		
		
		if(status == "Lose"){
			div += '<div class="fs-15 d-block"    style="line-height:18px!Important; width : 	calc(100% - 70px)">';
			div += '	<span class="bold text-danger"> '+Number(total_profit_usdt).toFixed(8)+' USDT ('+percent+'%) </span>  ';
			div += '	<small class="text-secondary d-block"> Lose </small> ';
			div += '</div>';
			class_profit = "text-danger";
		} 
				
		
		if(status == "Profit"){
			div += '<div class="fs-15 d-block"   style="line-height:18px!Important; width : 	calc(100% - 70px)">';
			div += '	<span class="bold text-success"> '+Number(total_profit_usdt).toFixed(8)+' USDT (+'+percent+'%) </span>  ';
			div += '	<small class="text-secondary d-block"> Profit </small> ';
			div += '</div>';
			
			class_profit = "text-success";
		} 
		
		
		
		
		div += '<div class="d-flex align-items-center justify-content-end px-3"   align="right"  style="width : 30px;height: 100%!Important; position:absolute; top:0px; height: 100%; right:0px; " >';
		div += '	<i class="fa fa-chevron-right" >  </i>';
		div += '</div>';
		div += '</div>';
		
			
			
		div += '<div class="history_detail" id="history_detail_'+id+'" >';
		div += '<div class="px-3 pb-3 " >';
			
		div += '		<div class="d-flex align-items-center justify-content-between">';
		div += '			<span>Open </span> ';
		div += '			<span>'+d+' '+m+' '+y+' '+h+':'+i+':'+s+' </span>';
		div += '		</div>';
		
		if((status == "Lose") || (status == "Profit")){
		div += '		<div class="d-flex align-items-center justify-content-between">';
		div += '			<span>Close </span> ';
		div += '			<span>'+d2+' '+m2+' '+y2+' '+h2+':'+i2+':'+s2+' </span>';
		div += '		</div>';
		}
		
		
		div += '		<div class="d-flex align-items-center justify-content-between">';
		div += '			<span>Total Amount  USDT</span> ';
		div += '			<span>'+total_usdt+' USDT</span> ';
		div += '		</div>';
		div += '		<div class="d-flex align-items-center justify-content-between">';
		div += '			<span>Total Payment </span> ';
		div += '			<span>'+kode_uang+" "+uang(total,round_uang)+'</span> ';
		div += '		</div>'; 
		div += '		<div class="d-flex align-items-center justify-content-between">';
		div += '			<span>Status </span> ';
		
		
		if(status == "Running"){
		div += '			<span>Trading on Process</span> 	';
		} else {
		div += '			<span>'+status+'</span> 	';		
		}
		
		
		
		div += '		</div>';
		div += '		<div class="d-flex align-items-center justify-content-between">';
		div += '			<span>Profit </span> ';
		
		if(status == "Running"){
		div += '			<span class="'+class_profit+' running_idr_'+id+'  " > '+kode_uang+" "+uang(total_profit_idr,round_uang)+'</span> ';
		} else {
		div += '			<span class="'+class_profit+'" > '+kode_uang+" "+uang(total_profit_idr,round_uang)+'</span> ';
		}
		div += '		</div>';
		
		div += '</div>';
		div += '</div>';
		div += '</div> ';




		return div; 
		
	}}, 
	
 ]
 } );
   
 


</script> 	
</div>

<?php } else {?> 
<div class="p-3" align="center">
	<h4 class="mb-0"> Session Expired </h4> 
	<p> Sorry . Your account has logout , Please login again </p> 
	<a class="btn btn-dark text-success" href="<?php echo($site) ?>/?page=profile" > Login Now </a> 
</div> 
<?php }  ?>

