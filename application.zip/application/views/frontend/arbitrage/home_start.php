<?php if(empty($arcur)){?> 
 

<div class="p-3"  style="position:fixed;z-index:999; width : 100%; height: 100%;top:0px; left:0px; background: rgba(0,0,0,0.9)!important; " >
	
	<div class="bg-header"  style="border-radius:5px; margin:auto;width : calc(400px - 2rem)!important; max-width:calc(100% - 2rem)!important;" >
	<div class="d-flex  w-100 p-3 align-items-center justify-content-center">
		
		<div class="w-100">
			<h5 class="mb-0"> Select Currency </h5> 
			<p> Please select the currency you wish to use. </p> 
			
			<form method="post" enctype="multipart/form-data"> 
			<div class="d-flex gap-1 mb-2 align-items-center justify-content-between">
				<a href="<?php echo($site) ?>/arbitrage/?arcur=usd" class="btn btn-dark w-50" > USD  </a> 			
				<a href="<?php echo($site) ?>/arbitrage/?arcur=myr" class="btn btn-dark w-50" > MYR  </a> 			
			</div>
			
			<div class="d-flex gap-1 mb-2 align-items-center justify-content-between">
				<a href="<?php echo($site) ?>/arbitrage/?arcur=idr" class="btn btn-dark w-50" > IDR  </a> 			
				<a href="<?php echo($site) ?>/arbitrage/?arcur=rupee" class="btn btn-dark w-50" > RUPEE  </a> 			
			</div>
			</form>
			
		
		</div>
		
	
	</div>
	</div>
	
</div> 
<?php }  ?>

