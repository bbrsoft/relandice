<?php 

if($_SESSION['broker'] == "wolf"){
	echo("<script>  document.location.href='".$site."/';   </script> ") ; 
	exit();
} 

include("modal.php"); ?> 
<div class="bg_black_4 d-flex align-items-center px-3 text-light justify-content-between"  style="position:absolute; left:0px; top:0px; width : 100%!important; background: red; height: 55px;" >
	<a href="<?php echo($site) ?>/page/logout" class="fs-20" > <i class="fa text-light fa-sign-out">  </i> </a> 	
	<div class=""  >
		<h5 class="m-0 fs-18"> Market Overview > USDT </h5> 
	</div>
	<a href="<?php echo($site) ?>?page=profile" class="fs-20"  > <i class="fa fa-user-circle text-light">  </i> </a> 
</div>

<div class="overflow-style"  style="width : 100%!important; position:absolute; top: 55px; height: calc(100% - 110px); overflow:auto;" >
 