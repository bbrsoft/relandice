<?php 
if(!empty($_SESSION['broker'])){
if($_SESSION['broker'] == "wolf"){

if(!empty($user)){
if(empty($user->token)){ 
?>

<style>
.la-circle-o-notch{
	-webkit-animation:spin 4s linear infinite;
	-moz-animation:spin 4s linear infinite;
	animation:spin 1s linear infinite;
}
@-moz-keyframes spin { 
    100% { -moz-transform: rotate(360deg); } 
}
@-webkit-keyframes spin { 
    100% { -webkit-transform: rotate(360deg); } 
}
@keyframes spin { 
    100% { 
        -webkit-transform: rotate(360deg); 
        transform:rotate(360deg); 
    } 
}
</style>


<div class="pt-2 pb-2"  style="position:absolute;z-index:99!important; left:0px; top:0px;background: #2f2f2f!important; width : 100%; height: 100%; overflow:auto;" >
	<h3 align="center" class="m-0"> Setup Bot Account </h3> 
	<p align="center"> Or Logout Your Account Secret - <a  href="<?php echo($site) ?>page/logout" > Logout </a> </p> 
	<?php 
if(!empty($alert)){?> 
	<p align="center" class="text-success"><?php echo($respon) ;  ?> </p> 
<?php } 	?>
	
	<div class="flex-center flex-border pl-3 pr-3 pt-0">
	<div class="w-100 d-block" align="left" style="height: auto!important; white-space: normal!important;"  >
	<form method="post" enctype="multipart/form-data"> 
		<h6 align="left" class="d-block">Using Token Wolf.bet </h6> 
		<span> API KEY / TOKEN </span> 
		<input type="text" class="w-100 text-center" name="token" id="token_wolf" required value="" placeholder="Your Token" />
		<button class="btn w-100 btn-dark btn-sm btn-rounded pl-3 pr-3" name="login_token" id="login_token" type="submit">Login Token <i class="fa fa-sign-in">  </i></button>
	</form>
	</div>
	</div>
	
	
	<div class="flex-center flex-border pl-3 pr-3 pt-0">
	<div class="w-100 d-block" align="left" style="height: auto!important; white-space: normal!important;"  >	
		<h6 class="d-block">Or Login Wolf.bet </h6>  
		<span> Username  </span> 
		<input type="text" class="w-100 text-center" name="username" id="wolf_username"  required value="" placeholder="Username" />
		<span> Password </span> 
		<input type="password" class="w-100 text-center" name="password" id="wolf_password"  required value="" placeholder="Password" />
		<span> Two Factor Authenticator (2fa)  </span> 
		<input type="text" class="w-100 text-center" name="code" id="wolf_code"  required value="" placeholder="2fa" />
		
		<span id="respon_login" class="d-block text-danger fs-12"></span> 
		<button class="btn btn-dark w-100 btn-sm btn-rounded pl-3 pr-3" name="login_wolf" id="login_wolf" >Login With Wolf Account </button>
	</div>
	</div>
	
	 
	
	<div class="flex-center flex-border pl-3 pr-3 pt-0">
	<div class="w-100 d-block" align="left" style="height: auto!important; white-space: normal!important;"  >
		
			<h6 class="d-block">Or Register Wolf.bet </h6>  
			<span> Username  </span> 
			<input type="text" class="w-100 text-center" name="username" id="wolf2_username"  required value="" placeholder="Username" />
			
			<span> Email  </span> 
			<input type="email" class="w-100 text-center" name="email" id="wolf2_email"  required value="" placeholder="Email" />
			 
			<span> Password </span> 
			<input type="password" class="w-100 text-center" name="password" id="wolf2_password"  required value="" placeholder="Password" />
			<span id="respon_register" class="d-block text-danger fs-12"></span> 
		
			<button class="btn btn-dark w-100 btn-sm btn-rounded pl-3 pr-3" id="register_wolf" >Register To Wolf </button>
	</div>
	</div>	
</div>




<script type="module"> 
import { io } from "https://cdn.socket.io/4.7.5/socket.io.esm.min.js";
const socket = io('wss://77.37.47.67:3001');

var wait = false ;
 

function login_now(username, password, code){ 
	socket.emit('login_get_token','{"username":"'+username+'", "password":"'+password+'" , "code":"'+code+'"  } ', function (msg) {
		if(msg){
			
			if(msg != "error"){
				var token = msg;
				$('#token_wolf').val(token);
				$('#login_token').click();
				wait = false; 
				$('#login_wolf').html('SUCCESS . REDIRECT');			
			}else {
				$('#respon_login').html('Sorry, Your Username or password is wrong');
				$('#login_wolf').removeClass('text-success');
				$('#login_wolf').html('Login With Wolf Account');			
			} 
		}  
	}); 
} 






$('#login_wolf').click(function(){
	if(wait == false){
		var code = $('#wolf_code').val();
		var username = $('#wolf_username').val();
		var password = $('#wolf_password').val();
		$('#respon_login').html('');
		if((username != '') && (password != '')){
			wait = true;  
			$('#login_wolf').addClass('text-success');
			$('#login_wolf').html('<i class="la la-circle-o-notch">  </i> LOADING . CHECK YOUR ACCOUNT - 10`s '); 
			login_now(username, password, code);  
		}
	}
	 
});











/*
 * REGISTER FORMS 
 * --------------
 */

function register_now(username, password,email){ 
	socket.emit('register_get_token','{"username":"'+username+'", "password":"'+password+'"  , "email":"'+email+'"  } ', function (msg) {
		if(msg){
			
			if(msg != "error"){
				var token = msg;
				$('#token_wolf').val(token);
				$('#login_token').click();
				wait = false; 
				$('#register_wolf').html('SUCCESS . REDIRECT');			
			}else { 
				$('#respon_register').html('Sorry, Multiple Account Detected . ');
				$('#register_wolf').removeClass('text-success');
				$('#register_wolf').html('Register To Wolf ');			
			}  
		}  
	}); 
} 




 

$('#register_wolf').click(function(){
	if(wait == false){
		var username = $('#wolf2_username').val();
		var password = $('#wolf2_password').val();
		var email = $('#wolf2_email').val();
		$('#respon_register').html('');
		if((username != '') && (password != '') && (email != '')){
			wait = true;   
			$('#register_wolf').addClass('text-success');
			$('#register_wolf').html('<i class="la la-circle-o-notch">  </i> LOADING . REGISTER - 10`s '); 
			register_now(username, password,email);   
		}
	}
	 
});




</script>
</html>




<?php 
}
}  
}  
}  
?>



