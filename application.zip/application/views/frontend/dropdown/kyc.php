<?php if($user->kyc_status <> "Approve"){?> 
 
<div id="kyc_form" class="bg_black_5"  >
	
	<div class="p-3">
		<div class="bg-header p-3 radius-5" >
			
			<?php if(($user->kyc_status == "Rejected") or ($user->kyc_status == "No Data")){?> 
			<h5 class="mb-0"> KYC Forms Verification </h5>  
			<?php if($user->kyc_status == "Rejected"){?> 
			<p> Your Request Has Rejected , Please enter your personal data correctly</p> 			
			<?php } else {?> 
			<p> Please enter your personal data correctly </p>  
			<?php }?>
			

			<form method="post" enctype="multipart/form-data"> 
			
				<span> Full Name </span> 
				<input type="text" required class="form-control" name="nama" value="" placeholder="Full Name"    />
				<br />
				<span> Full Address </span> 
				<textarea type="text" required class="form-control" name="alamat" value="" placeholder="Full Address (Country, Region, City & Address)"   ></textarea>
				<br />
				<span> Regional Identification Card (ID Card)</span> 
				<input type="file" required class="form-control" name="image" value="" placeholder=""    />
				<br />
				<span> Selfie With ID Card </span> 
				<input type="file" required class="form-control" name="image2" value="" placeholder=""    />
				<br />
				 
				<button type="submit" name="kyc_upload" class="btn btn-dark" >Request Verification</button>
			</form>
			
			<?php } else{?> 
				
				

				<?php if($user->kyc_status == "Waiting"){?> 
				<div class="d-flex align-items-center justify-content-center h-100 w-100">
					<div class="">
						<h5 class=""> KYC - Verification Process </h5> 
					<p> Your data is being verified. Please wait for approval within 1-3 business days. </p> 
					
					
					</div>
				</div>
				
				<?php 
				}  ?>
				
			<?php }  ?>
			
			
		
		</div>
	
	</div>

</div><?php }  ?>
