<?php 
	
	$total_deposit = $settings->earn_deposit; 
	$total_profit = 0;
	$profit = array();
	 
	
	
	
	$row = $this->model->row("earn_history","id_user='$id_user' and `sudah_reset`='No' ");
	if($row >= 25){
		$this->db->query("UPDATE earn_history SET `sudah_reset`='Yes' WHERE id_user='$id_user' and sudah_reset='No' ORDER BY id ASC LIMIT 25 ");	
	}
	 
	
	
	$table = "earn_history";
	$sql = "`id_user`='$id_user' and sudah_reset='No' ";
	$row = $this->model->row($table,$sql);
	$total_active = $row;
	
	if($row >= 1){
		$dd = $this->model->get_obj($table,$sql);
		foreach($dd as $data){
			$selected[] = $data->target; 
			$profit[$data->target] = "$".round($data->profit,4) ; 
		}
	} 
	
	
	
	
?>


<style>
	.fa-spinner{
		animation: mymove 3s infinite;
	}
	
	.box_size.disable:not(.active),
	.box_size.disabled:not(.active){
		opacity:0.6!important;
		cursor:no-drop!important;
	}
	@keyframes mymove {
	  100% {transform: rotate(360deg);}
	}

</style>

<div class="tab-pane " role="tabpanel" id="tab-8"> 
<?php 
if(!empty($user)){
?> 
<div class=""  style=" " > 
	<div class="px-3 pb-3">
		
		<div class="py-2 px-3 bg_black_3 relative"  style="border-bottom-left-radius:15px;border-bottom-right-radius:15px;
			border:1px solid rgba(255,255,255,.2)!important; border-top:0px!IMportant;" >
			
			<div class="d-flex align-items-center"> <span  style="width : 80px" > Bets </span> : &nbsp; <span id="earn_total_select"> <?php echo($user->earn_total_select) ;  ?>x  </span>  </div>
			<div class="d-flex align-items-center"> <span  style="width : 80px" > Balance </span> : &nbsp; <span id="usdt_earn_all"> <?php echo($user->usdt_earn_all) ;  ?> </span>  </div>
			<div class="d-flex align-items-center"> <span  style="width : 80px" > Total Profit </span> : &nbsp; <span id="earn_total_profit"> <?php echo($user->earn_total_profit) ;  ?> </span>  </div>
			<div class="d-flex align-items-center"> <span  style="width : 80px" > Max Profit </span> : &nbsp; <span id="usdt_earn_max"> <?php echo($user->usdt_earn_max) ;  ?> </span>  </div>
		
			<a class="btn btn-sm btn-dark px-3 fs-13" onclick="showbank()" style="position:absolute ; right:10px; bottom:10px; border:1px solid rgba(255,255,255,.2)!important;"  > Wallet </a> 
		</div>
		
		
		<div class="d-flex align-items-center justify-content-center">
			<div id="earn_total_deposit" class="p-1 fs-15 px-3 bg_black_3" align="center" style="border-bottom-left-radius:15px;border-bottom-right-radius:15px; border:1px solid rgba(255,255,255,.2); border-top:0px!Important;width : calc(100% - 50px)" >
				<?php echo ($total_deposit) ;  ?> USDT		
			</div>
		</div>
		
		
		<div class="px-2 pt-3 pb-3 bg_black_3 mt-3 radius-10 ">
		<div class="" align="center">
			<span class="bg_black_3 p-2 px-3 radius-10 d-inline-block"> <span id="earn_status"> Starting In </span> <span id="earn_time"> 01:21 Seconds </span>  </span> 
		</div>
		
		
		
		
		<div class="pt-2">
			
		<div class="d-flex align-items-center py-1   gap-1 justify-content-center">
		<?php for ($i = 1; $i <= 5; $i++) {?> 
			<div valx="<?php echo($i) ;  ?>" class=" box_size radius-5 <?php if(in_array($i, $selected)){echo(" active ") ; }  ?> "  id="box_<?php echo($i) ;  ?>" >
				<?php  if(in_array($i, $selected)){echo(" <small class='text-success fs-10'> ".$profit[$i]."</small>  ") ; }  else {echo($i) ; } ?>
			</div> 
		<?php }  ?>
		</div>
		
		<div class="d-flex align-items-center py-1  gap-1 justify-content-center">
		<?php for ($i = 6; $i <= 10; $i++) {?> 
			<div valx="<?php echo($i) ;  ?>"  class=" box_size radius-5 <?php if(in_array($i, $selected)){echo(" active ") ; }  ?> " id="box_<?php echo($i) ;  ?>" >
				<?php  if(in_array($i, $selected)){echo(" <small class='text-success fs-10'> ".$profit[$i]."</small>  ") ; }  else {echo($i) ; } ?>
			</div> 
		<?php }  ?>
		</div>
		
		<div class="d-flex align-items-center py-1   gap-1 justify-content-center">
		<?php for ($i = 11; $i <= 15; $i++) {?> 
			<div valx="<?php echo($i) ;  ?>"  class=" box_size radius-5 <?php if(in_array($i, $selected)){echo(" active ") ; }  ?> " id="box_<?php echo($i) ;  ?>" >
				<?php  if(in_array($i, $selected)){echo(" <small class='text-success fs-10'> ".$profit[$i]."</small>  ") ; }  else {echo($i) ; } ?>
			</div> 
		<?php }  ?>
		</div>
		
		<div class="d-flex align-items-center py-1 gap-1 justify-content-center">
		<?php for ($i = 16; $i <= 20; $i++) {?> 
			<div valx="<?php echo($i) ;  ?>"  class=" box_size radius-5 <?php if(in_array($i, $selected)){echo(" active ") ; }  ?> " id="box_<?php echo($i) ;  ?>" >
				<?php  if(in_array($i, $selected)){echo(" <small class='text-success fs-10'> ".$profit[$i]."</small>  ") ; }  else {echo($i) ; } ?>
			</div> 
		<?php }  ?>
		</div>
		
		<div class="d-flex align-items-center py-1  gap-1 justify-content-center">
		<?php for ($i = 21; $i <= 25; $i++) {?> 
			<div valx="<?php echo($i) ;  ?>"  class=" box_size radius-5  <?php if(in_array($i, $selected)){echo(" active ") ; }  ?> " id="box_<?php echo($i) ;  ?>" >
				<?php  if(in_array($i, $selected)){echo(" <small class='text-success fs-10'> ".$profit[$i]."</small>  ") ; }  else {echo($i) ; } ?>
			</div> 
		<?php }  ?>
		</div>
		</div>
		
		
		
		
		
		
		 
		 
		
		<div class=" p-3"  style=""  align="center">
			<span class="fs-16 d-block"> Win Profit  </span> 
			<span class="fs-22 text-success" style="font-weight : 700" id="usdt_profit_now"> 0 </span> <span class="fs-14"> USDT </span> 
		</div>
		
	
		
		<div class="d-flexx d-none py-2 radius-5 fs-15 mt-2 px-2 bg_black_3 gap-1  align-items-center justify-content-between"  style="border:1px solid rgba(255,255,255,.2);  " >
			<a class="btn btn-dark btn-sm"  style="font-size : 13px; width : 70px"  > Deposit </a>
			<span class="d-inline-block fs-14" style="width : calc(100% - 140px; ); overflow:hidden; text-overflow:ellipsis; white-space:nowrap;" > Earn : <b  style="color:#eded03; font-weight : 700" > 32.22993288 </b>  USDT </span> 
			<a class="btn btn-dark btn-sm"  style="font-size : 13px; width : 70px"  > Withdraw </a>
		</div>
		
		<div class="d-flex align-items-center justify-content-center">
			<div class=""  style="width : 80%;border-top:1px solid rgba(255,255,255,.1)" >
			</div>
		</div>
		 
		<div class="pt-3 fs-14">
			<div class="d-flex align-items-center justify-content-between w-100">
					<div class="td1" > Time </div>
					<div class="td2" > User </div>
					<div class="td3"  align="center"> Target </div>
					<div class="td4" align="right" > Profit </div>
			</div>
			<div class="" id="earn_history" >
			<?php 
			$table = "earn_history_view";
			$sql = "`id`<>-1 ORDER BY id DESC LIMIT 20 ";
			$row = $this->model->row($table,$sql);
			if($row >= 1){
				$dd = $this->model->get_obj($table,$sql);
				foreach($dd as $data){
					?> 
					
					<div class="d-flex align-items-center justify-content-between w-100">
						<div class="td1"> <?php echo($data->time) ;  ?> </div>
						<div class="td2" > <?php echo($data->secret) ;  ?> </div>
						<div class="td3" align="center"> <?php echo($data->target) ;  ?></div>
						<div class="td4 text-success"> +<?php echo($data->profit) ;  ?> </div>
					</div>
					 
					<?php 
				}
			} 
			 ?>
			</div>
			
		</div> 
		</div> 
		
	</div>
</div>



<?php include("earning_modal.php"); ?>

<script>  
usdt_idr = <?php echo($usdt_idr) ;  ?>;


$('#deposit_idrx').on('keyup',function(){
	
	now = $('#deposit_idrx').val();
	if(now == ""){
		now = 0 ; 
	} 
	
	total_usdt = Number(now) / Number(usdt_idr);
	total_usdt = Number(total_usdt).toFixed(5);
	$('#deposit_usdtx').val(total_usdt);
	
});


$('#deposit_usdtx').on('keyup',function(){
	now = $('#deposit_usdtx').val();
	if(now == ""){
		now = 0 ; 
	} 
	
	total_usdt = Number(now) * Number(usdt_idr);
	total_usdt = Number(total_usdt).toFixed(0);
	$('#deposit_idrx').val(total_usdt);
	
});



$('#paid_with').on('change',function(){
	valx = $(this).val();
	if(valx == "usdt"){
		$('#div_deposit_idr').addClass('d-none');
	} else {
		$('#div_deposit_idr').removeClass('d-none');
	}
})  

</script> 

 






















<?php } else {?> 
<div class="p-3">
	
	<h4 class="mb-0"> Session Expired </h4> 
	<p> Sorry . Your account has logout , Please login again </p> 
	<a class="btn btn-dark text-success" href="<?php echo($site) ?>/?page=profile" > Login Now </a> 

</div> 
<?php } ?>
</div>



