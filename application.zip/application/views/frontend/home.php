<?php 
	$page = "";
	if(!empty($_GET['page'])){ 
	$page = in($_GET['page']); 
		include("header.php");
		include($page.".php");

	}else {
		
if(!empty($_SESSION['broker'])){
	if($_SESSION['broker'] == "copytrade"){
		echo("<script>  document.location.href='".$site."/arbitrage';   </script> ") ; 
		exit();
		
	} 
}  

?> 
 
 <div class="header_style">
	<img onclick="show_tab('#tab-1')" src="<?php echo($site) ?>image/<?php echo($settings->favicon) ;  ?>"  style="height: 35px"  class="" />
	<div onclick="show_tab('#tab-1')" class=""  style="line-height:11px" >
	<h5 class="mb-0"  style="margin-top: -5px;" > <?php echo($settings->nama) ;  ?></h5> 
	<small  style="font-size : 10px" > Play with bot and get profit every time </small> 
	</div>
	
	<a  onclick="toggle_developer()"  style="
	background: rgba(0,0,0,.5)!important;border-radius:5px; height: 38px; width : 50px; 
	position:absolute; right:3.7rem; text-decoration:none!important; top:8px;color:white; line-height:11px" 
	class="d-flex align-items-center justify-content-center" align="center"  > 
		<small class="d-block fs-10 text-warning"> Mode <br />
		Dev  </small>   
	</a> 
	
	<a class=""  href="<?php echo($site) ?>?page=profile"  style="position:absolute; right:1rem; top:12px;color:white; line-height:11px" align="center"  > 
		<i class="fa fa-user-circle" style="font-size : 20px"  >  </i> 
		<small class="d-block fs-10"  style=" <?php if(empty($user)){echo('color:red!Important;') ; }  ?>" > Account </small>  
	</a> 
	
 </div>

<div class="tab-content pt-2 overflow-style">
<?php include("tab_1_play.php"); ?>
<?php include("tab_2_bet.php"); ?>
<?php include("tab_3_account.php"); ?>
<?php include("tab_4_stat.php"); ?>
<?php include("tab_5_info.php"); ?>
<?php include("tab_6_bonus.php"); ?>
<?php include("tab_7_deposit.php"); ?>
<?php include("tab_8_earn.php"); ?>
</div>  

<ul class="nav nav-tabs nav-justified"  style="border-top:1px solid black"  role="tablist">
	<li class="nav-item" role="presentation"><a class="nav-link active" role="tab" data-toggle="tab" href="#tab-1"><i class="fa fa-play">  </i> <small> Play Bot</small> </a></li>
	<li class="nav-item" role="presentation"><a class="nav-link" role="tab" data-toggle="tab" href="#tab-2"><i class="fa fa-gear">  </i> <small> Setup Bot </small> </a></li>
	<li class="nav-item" role="presentation"><a class="nav-link" role="tab" data-toggle="tab" href="#tab-4"><i class="fa fa-history">  </i> <small> Status </small> </a></li>
	<li class="nav-item" role="presentation" ><a class="nav-link" role="tab" data-toggle="tab" href="#tab-5"><i class="fa fa-info-circle">  </i> <small> Info Apps</small> </a></li>
	<li class="nav-item" role="presentation" ><a class="nav-link"   href="<?php echo($site) ?>/?page=earning"><img src="<?php echo($site) ?>/image/dollar.png"  style="height: 17px;width : 17px"  class="" />
	<small>Earn</small> </a></li>
</ul>

<?php } ?>

