<script>
function showdel(id,nama){
 $('#del_id').val(id);
 $('#del_name').val(nama);
 
 $('#modal_delete').modal('show'); 
}
function cancel_delete(){ $('#modal_delete').modal('hide'); }
</script>

<div class="modal fade" id="modal_delete" role="dialog" style="display: none; margin-top:0px;">
 <div class="modal-dialog"style="border-radius:0px !Important ">
	 <div class="modal-content"style="border-radius:0px !Important ">
		 <div class="modal-header" style="border-radius:0px !Important ">
			 <span class="modal-title">Apakah Anda Yakin Ingin Menghapus Data Ini</span>
			 <button type="button" class="close" data-dismiss="modal">x</button>
		 </div>
		 <div class="modal-body">
		 <form method="post" enctype="multipart/form-data"> 
			<span> Your Data </span> 
			<input type="hidden" required class="form-control" id="del_id" name="id" value="" placeholder=""    />
			<input type="text" required disabled class="form-control" id="del_name" name="data" value="" placeholder="Your Data "    />
			<br />
			<button type="submit" name="delete" class="btn btn-primary" >Hapus Data</button> 
		 </form>
		 </div> 
	 </div>
 </div>
</div>


<script>
function showrej(id,nama){
 $('#rej_id').val(id);
 $('#rej_name').val(nama);
 
 $('#modal_reject').modal('show'); 
}
function cancel_reject(){ $('#modal_reject').modal('hide'); }
</script>

<div class="modal fade" id="modal_reject" role="dialog" style="display: none; margin-top:0px;">
 <div class="modal-dialog"style="border-radius:0px !Important ">
	 <div class="modal-content"style="border-radius:0px !Important ">
		 <div class="modal-header" style="border-radius:0px !Important ">
			 <span class="modal-title">Apakah Anda Yakin Ingin Menolak Data Ini</span>
			 <button type="button" class="close" data-dismiss="modal">x</button>
		 </div>
		 <div class="modal-body">
		 <form method="post" enctype="multipart/form-data"> 
			<span> Your Data </span> 
			<input type="hidden" required class="form-control" id="rej_id" name="id" value="" placeholder=""    />
			<input type="text" required disabled class="form-control" id="rej_name" name="data" value="" placeholder="Your Data "    />
			<br />
			<button type="submit" name="reject" class="btn btn-primary" >Tolak Data</button> 
		 </form>
		 </div> 
	 </div> 
 </div>
</div>




<script>
function showconf(id,nama){
 $('#conf_id').val(id);
 $('#conf_name').val(nama);
 
 $('#modal_conf').modal('show'); 
}
function cancel_conf(){ $('#modal_conf').modal('hide'); }
</script>

<div class="modal fade" id="modal_conf" role="dialog" style="display: none; margin-top:0px;">
 <div class="modal-dialog"style="border-radius:0px !Important ">
	 <div class="modal-content"style="border-radius:0px !Important ">
		 <div class="modal-header" style="border-radius:0px !Important ">
			 <span class="modal-title">Anda Yakin Ingin Konfirmasi Data Ini</span>
			 <button type="button" class="close" data-dismiss="modal">x</button>
		 </div>
		 <div class="modal-body">
		 <form method="post" enctype="multipart/form-data"> 
			<span> Your Data </span> 
			<input type="hidden" required class="form-control" id="conf_id" name="id" value="" placeholder=""    />
			<input type="text" required disabled class="form-control" id="conf_name" name="data" value="" placeholder="Your Data "    />
			<br />
			<button type="submit" name="konfirmasi" class="btn btn-primary" >Konfirmasi</button> 
		 </form>
		 </div> 
	 </div>
 </div>
</div>




<script>
function showimg(src){
 $('#imgs').attr('src',src);
 $('#hr').attr('href',src);
 $('#modal_img').modal('show'); 
 
}
</script>

<div class="modal fade" id="modal_img" role="dialog" style="display: none; margin-top:0px;">
 <div class="modal-dialog">
	 <div class="modal-content">
		 <div class="modal-header">
			 <span class="modal-title">Image Preview </span>
			 <button type="button" class="close" data-dismiss="modal">x</button>
		 </div>
		 <div class="modal-body" id="isi_img">
			<img src="" id="imgs" class="img-thumbnail" style="width : 100%;" />
		</div>
	 </div>
 </div>
</div>


<script>  

	
function uang(nums) {
var vals = String(nums);

if (vals == null){
	vals = "0";
}
    vals = vals.replace(/,/g, "");
    vals += '';
    x = vals.split('.');
    x1 = x[0];
    x2 = x.length > 1 ? '.' + x[1] : '';

    var rgx = /(\d+)(\d{3})/;

    while (rgx.test(x1)) {
        x1 = x1.replace(rgx, '$1' + ',' + '$2');
    }

	xx = x1 + x2;
	
if (xx == "0"){
	xx = "0";
}
	
    return xx;


}


 

function setCookie(cname, cvalue, exdays) {
    var d = new Date();
    d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
    var expires = "expires="+d.toUTCString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}


function getCookie(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for(var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}



function numbers(inputString){
    var regex=/\d+\.\,\d+|\.\d+|\d+/g, 
        results = "",
        n;
    while(n = regex.exec(inputString)) {
        results += n[0];
    }
    return results;
}


$('.currency').keyup(function(event){
	v = $(this).val();
	v = numbers(v);
	u = uang(v+'');
	$(this).val(u);
})


</script> 






<script>
function showbayar(id,nama){
 $('#bayar_id').val(id);
 $('#bayar_name').val(nama);
 
 $('#modal_bayar').modal('show'); 
}
</script>

<div class="modal fade" id="modal_bayar" role="dialog" style="display: none; margin-top:0px;">
 <div class="modal-dialog"style="border-radius:0px !Important ">
	 <div class="modal-content"style="border-radius:0px !Important ">
		 <div class="modal-header" style="border-radius:0px !Important ">
			 <span class="modal-title">Bayar Investasi Ini</span>
			 <button type="button" class="close" data-dismiss="modal">x</button>
		 </div>
		 <div class="modal-body">
		 <form method="post" enctype="multipart/form-data"> 
			<span> Your Data </span> 
			<input type="hidden" required class="form-control" id="bayar_id" name="id" value="" placeholder=""    />
			<input type="text" required disabled class="form-control" id="bayar_name" name="data" value="" placeholder="Your Data "    />
			<br />
			<button type="submit" name="bayar" class="btn btn-primary" >Bayar</button> 
		 </form>
		 </div> 
	 </div>
 </div>
</div>



<script>
function showlose(id,nama){
 $('#lose_id').val(id);
 $('#lose_name').val(nama);
 
 $('#modal_lose').modal('show'); 
} 
</script>

<div class="modal fade" id="modal_lose" role="dialog" style="display: none; margin-top:0px;">
 <div class="modal-dialog"style="border-radius:0px !Important ">
	 <div class="modal-content"style="border-radius:0px !Important ">
		 <div class="modal-header" style="border-radius:0px !Important ">
			 <span class="modal-title">Lose Investasi Ini</span>
			 <button type="button" class="close" data-dismiss="modal">x</button>
		 </div>
		 <div class="modal-body">
		 <form method="post" enctype="multipart/form-data"> 
			<span> Your Data </span> 
			<input type="hidden" required class="form-control" id="lose_id" name="id" value="" placeholder=""    />
			<input type="text" required disabled class="form-control" id="lose_name" name="data" value="" placeholder="Your Data "    />
			<br />
			<button type="submit" name="lose" class="btn btn-primary" >Lose</button> 
		 </form>
		 </div> 
	 </div>
 </div>
</div>




<script>
function showpotong(id,nama){
 $('#potong_id').val(id);
 $('#potong_name').val(nama);
 
 $('#modal_potong').modal('show'); 
} 
</script>

<div class="modal fade" id="modal_potong" role="dialog" style="display: none; margin-top:0px;">
 <div class="modal-dialog"style="border-radius:0px !Important ">
	 <div class="modal-content"style="border-radius:0px !Important ">
		 <div class="modal-header" style="border-radius:0px !Important ">
			 <span class="modal-title">Potong Investasi</span>
			 <button type="button" class="close" data-dismiss="modal">x</button>
		 </div>
		 <div class="modal-body">
		 <form method="post" enctype="multipart/form-data"> 
			<span> Your Data </span> 
			<input type="hidden" required class="form-control" id="potong_id" name="id" value="" placeholder=""    />
			<input type="text" required disabled class="form-control" id="potong_name" name="data" value="" placeholder="Your Data "    />
			<br />
			<span> Potong (%)</span> 
			<input type="number" max="99" step="0.001" min="1" required class="form-control" name="percent" value="" placeholder=""    />
			<br />
			 
			
			<button type="submit" name="potong" class="btn btn-primary" >Potong</button> 
		 </form>
		 </div> 
	 </div>
 </div>
</div>






<script>
function showtentukan(id,nama){
 $('#tentukan_id').val(id);
 $('#tentukan_name').val(nama);
 
 $('#modal_tentukan').modal('show'); 
} 
</script>

<div class="modal fade" id="modal_tentukan" role="dialog" style="display: none; margin-top:0px;">
 <div class="modal-dialog"style="border-radius:0px !Important ">
	 <div class="modal-content"style="border-radius:0px !Important ">
		 <div class="modal-header" style="border-radius:0px !Important ">
			 <span class="modal-title">Tentukan Profit</span>
			 <button type="button" class="close" data-dismiss="modal">x</button>
		 </div>
		 <div class="modal-body">
		 <form method="post" enctype="multipart/form-data"> 
			<span> Your Data </span> 
			<input type="hidden" required class="form-control" id="tentukan_id" name="id" value="" placeholder=""    />
			<input type="text" required disabled class="form-control" id="tentukan_name" name="data" value="" placeholder="Your Data "    />
			<br />
			<span> Tentukan Profit (USDT)</span> 
			<input type="number" max="99" step="0.001" min="1" required class="form-control" name="profit_admin" value="" placeholder=""    />
			<br />
			 
			
			<button type="submit" name="tentukan" class="btn btn-primary" >Tentukan</button> 
		 </form>
		 </div> 
	 </div>
 </div>
</div>
