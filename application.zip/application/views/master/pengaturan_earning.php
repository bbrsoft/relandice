<?php  
$row = $this->model->row('settings'," id<>-1 ");
if($row >= 1){
	$settings = $this->model->get_obj('settings'," id<>-1 ")[0];
} else {
	echo("Terjadi Kesalahan Website ") ; 
	exit();
}

if(isset($_POST['edit'])){ 

	
	$earn_second = in($_POST['earn_second']);
	$earn_potongan = in($_POST['earn_potongan']);
	$earn_pembagi = in($_POST['earn_pembagi']);
	 $earn_deposit = in($_POST['earn_deposit']);

	
	$this->db->query("UPDATE settings SET `earn_pembagi`='$earn_pembagi' ,`earn_potongan`='$earn_potongan' ,`earn_second`='$earn_second'   ,`earn_deposit`='$earn_deposit'  ");
	
	

	$alert = "success";
	$respon = "Berhasil Memperbaharui Website ";
	
	$table = "settings";
	$sql = "`id`<>-1";
	$row = $this->model->row($table,$sql);
	if($row >= 1){
		$settings = $this->model->get_obj($table,$sql)[0];
	} 
} 

?>

<div class="container-fluid">
<div class="row">
	<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 col-12 ">
		
		<div class="card">
			<div class="card-header">
				<div class="">
				<h4>Pengtaturan Aplikasi Earning </h4>
					 
				</div>	
			</div>
			<div class="card-body">
				<form method="post"  enctype="multipart/form-data"> 
					 <?php include("alert_form.php"); ?>
					 
					
					<span> Earning Time (seconds) </span> 
					<input type="number" required class="form-control" step="1" name="earn_second" value="<?php echo($settings->earn_second) ;  ?>" placeholder=""    />
					<br />
					<span> Earning Admin Fee (%) </span> 
					<input type="number" required class="form-control" step="1" name="earn_potongan" value="<?php echo($settings->earn_potongan) ;  ?>" placeholder=""    />
					<br />
					
					<span> Earning Pembagi </span> 
					<input type="number" required class="form-control" step="1" name="earn_pembagi" value="<?php echo($settings->earn_pembagi) ;  ?>" placeholder=""    />
					<br />
					<span> All Balance </span> 
					<input type="number" step="0.00000001" required class="form-control"  name="earn_deposit" value="<?php echo($settings->earn_deposit) ;  ?>" placeholder=""    />
					<br />
					
					
					<button name="edit" type="submit" class="btn btn-primary" >Edit Website</button>  
				</form>
			</div>
		</div>
	</div> 
	
	
	 
	
	
	
	
</div> 
</div> 


 
			 
 