<?php 
	if(isset($_POST['reject'])){
		$id = in($_POST['id']);
		$row = $this->model->row("user","kyc_status='Waiting' and id='$id'  ");
		if($row >= 1){
			$this->db->query("UPDATE user SET `kyc_status`='Rejected' WHERE id='$id'  ");
			$alert = "success";
			$respon = "Success Rejected KYC User ";
		} 
	} 

	if(isset($_POST['konfirmasi'])){
		$id = in($_POST['id']);
		$row = $this->model->row("user","kyc_status='Waiting' and id='$id'  ");
		if($row >= 1){
			$this->db->query("UPDATE user SET `kyc_status`='Approve' WHERE id='$id'  ");
			$alert = "success";
			$respon = "Success Approve KYC User ";
		} 
	} 



?>


<div class="container-fluid bg-light min-vh-100">  
<div class="row">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 col-12 "> 
 
<div class="card ">
<div class="card-header bg-primary">
	<h5 class="m-0  text-light"> Request Verified Identity - KYC </h5>  
</div>
<div class="card-body shadow-sm">

	<?php include("alert_form.php"); ?>
	<div class="table-responsive">
	<table id="tables" class="table table-striped table-bordered">
		<thead>
		<tr> 
			<th   > Secret Login </th>
			<th   > Name </th>
			<th   > ID Card </th>
			<th   > Selfie  </th>
			<th   > Address</th>
			<th> Action </th>  
			
		</tr>
		</thead>
	</table> 
	</div>
	</div>
</div>


</div>
</div>
</div>




<script>  
site ="<?php echo($site) ?>";

var tablex = $('#tables').dataTable( {
 "bProcessing": true,
 "bServerSide": true,  
 "order" : [[0, 'desc']],
    "ajax" : { 
        url:  site+"server_master/kyc_new.php", 
        type:"POST"
    } ,
	
 "aoColumns": [
	null,
	null,
	
	{ "mclass":"wall", "mData": "2", "mRender": function ( data, type, full ) {
	if(data){
		var url_img = site; 
		imgx = "showimg('"+url_img+"/image/"+data+"')";
		img = '<img src="'+url_img+'/image/'+data+'" onclick="'+imgx+'"  style="height: 30px;"  />';
		return img; 
	} else {
		return "Tidak Ada";
	}
	}},
	{ "mclass":"wall", "mData": "3", "mRender": function ( data, type, full ) {
	if(data){
		var url_img = site; 
		imgx = "showimg('"+url_img+"/image/"+data+"')";
		img = '<img src="'+url_img+'/image/'+data+'" onclick="'+imgx+'"  style="height: 30px;"  />';
		return img; 
	} else {
		return "Tidak Ada";
	}
	}},
	
	{ "mclass":"wall", "mData": "4", "mRender": function ( data, type, full ) {
		return '<div class=""  style="width : 300px;" >'+data+'</div>';
	}},
	
	{ "mclass":"wall", "mData": "5", "mRender": function ( data, type, full ) {
		conf="showconf('"+data+"','Konfirmasi Data "+full[0]+"')";  
		rej="showrej('"+data+"','Hapus Data "+full[0]+"')";  
		div = ''; 
		div += '<div class="dropdown" > <button onclick="$(\'#dropdown_menu_'+data+'\').slideToggle()" class="btn btn-sm btn-primary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Option </button>';
		div += '<div class="dropdown-menu" style="right:0px!Important; left:auto"   id="dropdown_menu_'+data+'" aria-labelledby="dropdownMenuButton">';
		div += '<a class="dropdown-item"  style="cursor:pointer !important;"  onclick="'+conf+'">Verifikasi</a>';  
		div += '<a class="dropdown-item"  style="cursor:pointer !important;"  onclick="'+rej+'">Rejected</a>';  
		
		div += '</div>';
		div += '</div>';
		return div;
		
	}},
	
	
	
	
 ]
 } );
   
 


</script> 
