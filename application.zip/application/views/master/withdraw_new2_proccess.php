<?php 
$bank_rekening = $data->bank_rekening;
$bank_jenis = $data->bank_jenis;
$total = $data->total_idr; 
$secret_user = $data->secret;
$id_data = $data->id;
$id_userx = $data->id_user;
$ticket = "TICKET".date('ymdhis').$data->id_user;							



$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url_api.'/v2/payments/auth/token');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');

curl_setopt($ch, CURLOPT_USERPWD, $client . ':' . $secret);

$result = curl_exec($ch); 
curl_close($ch);   



if(!empty($result)){
$obj = json_decode($result);
$token = $obj->data->accessToken;


if(!empty($token)){

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url_api.'/v2/payments/gs/bank-account-validation?accountNumber='.$bank_rekening.'&bankShortCode='.$bank_jenis);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);  
$headers = array();
$headers[] = 'Publicaccesstoken: Bearer '.$token;
$headers[] = 'Content-Type: application/json';
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
$result = curl_exec($ch);
curl_close($ch);


if(!empty($result)){


$obj = json_decode($result);
if($obj->status == "200"){


		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url_api.'/v2/payments/auth/token');
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');

		curl_setopt($ch, CURLOPT_USERPWD, $client . ':' . $secret);

		$result = curl_exec($ch); 
		curl_close($ch);   
		 
		 
		if(!empty($result)){
			$obj = json_decode($result);
			$token2 = $obj->data->accessToken;
			
			
				
				$ch = curl_init();
				curl_setopt($ch, CURLOPT_URL, $url_api.'/v2/payments/gs/disbursements');
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
				curl_setopt($ch, CURLOPT_POST, 1);
				curl_setopt($ch, CURLOPT_POSTFIELDS, "\n{\n     \"referenceId\": \"$ticket\",\n     \"description\": \"Withdrawal\",\n     \"amount\": $total,\n     \"disbursementMethod\": {\n          \"type\": \"bank_transfer\",\n          \"bankShortCode\": \"$bank_jenis\",\n          \"bankAccountNo\": \"$bank_rekening\",\n          \"bankAccountHolderName\": \"$secret_user\"\n     }\n}\n");

				$headers = array();
				$headers[] = 'Accept: application/json';
				$headers[] = 'Content-Type: application/json';
				$headers[] = 'Publicaccesstoken: Bearer '.$token2;
				curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

				$result = curl_exec($ch); 
				curl_close($ch);  
				if(!empty($result)){
					$obj = json_decode($result);
					$status_pg = $obj->status;
					
					$this->db->query("UPDATE `withdraw2` SET `status_pg`='$status_pg' , `respon_pg`='$result' 
					WHERE id='$id_data'  ");
					 
												 
					if($obj->status == "200"){
									
						$data_respon = $obj->data;
						$status = $data_respon->attributes->status;
						$id_respon = $data_respon->id; 
						
						$this->db->query("UPDATE `withdraw2` SET `with_pg`='Yes' , `id_wd`='$id_respon',`status`='Finish'  WHERE id='$id_data'  ");
						$this->db->query("UPDATE `withdraw2` SET `with_pg`='Yes' , `id_wd`='$id_respon',`status`='Finish'  WHERE id='$id_data'  ");
						$this->db->query("UPDATE `investor_history` SET `status`='Sucesfully'  WHERE id_user='$id_userx' and type='Sell' and status='Processed' ");
						
						
					} 
				} 
		}
}
} 
}
} 



?>