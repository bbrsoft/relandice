<?php 
	if(isset($_POST['new'])){
		require_once("isset_image.php");
		if(!empty($image)){
			
			$this->db->query("INSERT INTO data_kotak (`image`) VALUES ('$image')  ");
			$alert = "success";
			$respon = "Berhasil Menambah Kotak Baru ";
		} else {
			$alert = "danger";
			$respon = "Gambar yang anda masukkan tidak valid ";
		}
	} 
	
	if(isset($_POST['delete'])){
		$id = in($_POST['id']);
		$this->db->query("DELETE FROM data_kotak WHERE id='$id' ");
		 
	} 

?>


<div class="container-fluid bg-light min-vh-100">
<?php include("alert_form.php"); ?>

<div class="row">
<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 col-12 ">
	
<div class="card ">
<div class="card-header bg-primary">
	<h5 class="m-0  text-light"> Kotak Baru </h5>  
</div>
<div class="card-body shadow-sm">
	<form method="post" enctype="multipart/form-data"> 
		
		<span> Kotak Baru <br />
		<small>  (Gambar Persegi 100x100 PX )</small> </span> 
		<input type="file" required class="form-control" name="image" value="" placeholder="Nama Kategori"    />
		<br />
		<button type="submit" name="new" class="btn btn-primary" >Masukkan Data</button> 
		
	
	</form>
</div>
</div>
</div>






<div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 col-12 ">
 
<div class="card ">
<div class="card-header bg-primary">
	<h5 class="m-0  text-light"> Data Kotak </h5>  
</div>
<div class="card-body shadow-sm">

	
	<table class="table table-striped table-bordered">
		<thead>
		<tr>
			<th> Image </th> 
			<th> # </th>
		</tr>
		</thead>
		<tbody>
			<?php $table = "data_kotak";
			$sql = "`id`<>-1";
			$row = $this->model->row($table,$sql);
			if($row >= 1){
				$dd = $this->model->get_obj($table,$sql);
				foreach($dd as $data){
					?> 
					<tr> 
						<td> <img src="<?php echo($site) ?>image/<?php echo($data->image) ;  ?>"  style="width : 40px;"  class="none" /> </td>
						<td> 
						<a class="btn btn-danger btn-sm" onclick="showdel('<?php echo($data->id) ;  ?>','<?php 	echo($data->image) ;  ?>')" > Delete </a> 
						</td>
					</tr> 
					<?php 
				}
			} 
			 ?>		
		</tbody>
	</table> 
	
	


</div>
</div>


</div>
</div>
</div>
