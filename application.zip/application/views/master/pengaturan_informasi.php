<?php  
$row = $this->model->row('settings'," id<>-1 ");
if($row >= 1){
	$settings = $this->model->get_obj('settings'," id<>-1 ")[0];
} else {
	echo("Terjadi Kesalahan Website ") ; 
	exit();
}

if(isset($_POST['edit'])){ 

	$informasi_referral = in($_POST['informasi_referral']);
	 
 
	$this->db->query("UPDATE settings SET `informasi_referral`='$informasi_referral' 
	");
	
	 

	$alert = "success";
	$respon = "Berhasil Memperbaharui Website ";
	
	$table = "settings";
	$sql = "`id`<>-1";
	$row = $this->model->row($table,$sql);
	if($row >= 1){
		$settings = $this->model->get_obj($table,$sql)[0];
	} 
} 


?>

<div class="container-fluid">
<div class="row">
	<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 col-12 ">
		
		<div class="card">
			<div class="card-header">
				<div class="">
				<h4>Pengtaturan Informasi  </h4>
					
				<form method="post" enctype="multipart/form-data"> 
				<button class="btn btn-danger btn-sm" name="clear_profit" onSubmit="return confirm('Anda yakin ingin membersihkan profit bot ?');" > Clear Profit Bot </button> </h4> 
				</form>
				
			
				</div>	
			</div>
			<div class="card-body">
				<form method="post"  enctype="multipart/form-data"> 
					 <?php include("alert_form.php"); ?>
					<span> Informasi Referral  </span> 
					<textarea type="text" required class="form-control" name="informasi_referral"  placeholder=""    ><?php echo($settings->informasi_referral) ;  ?></textarea>
					<br />
					 
					 
					
					<button name="edit" type="submit" class="btn btn-primary" >Edit Website</button>  
				</form>
			</div>
		</div>
</div> 
</div> 


 
			 