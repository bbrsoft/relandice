<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Admin - <?php echo($settings->nama) ;  ?></title>
  <link rel="shortcut icon" type="image/png" href="<?php echo($site) ?>image/<?php echo($settings->favicon) ;  ?>" />
  <link rel="stylesheet" href="<?php echo($site) ?>assets/css/styles.min.css" />
  <script src="<?php echo($site) ?>assets/libs/jquery/dist/jquery.min.js"></script>
	<?php include("style.php"); ?>
	
	<link rel="stylesheet" href="<?php echo($site) ?>assets/modules/datatables/datatables.min.css">
	<link rel="stylesheet" href="<?php echo($site) ?>assets/modules/datatables/DataTables-1.10.16/css/dataTables.bootstrap4.min.css">
	<link rel="stylesheet" href="<?php echo($site) ?>assets/modules/datatables/Select-1.2.4/css/select.bootstrap4.min.css">  

	<script src="<?php echo($site) ?>assets/modules/datatables/datatables.min.js?id=1"></script>
	<script src="<?php echo($site) ?>assets/modules/datatables/DataTables-1.10.16/js/dataTables.bootstrap4.min.js"></script>
	<script src="<?php echo($site) ?>assets/modules/datatables/Select-1.2.4/js/dataTables.select.min.js"></script>

<style>
	.text-success {  color: green!important;font-weight : 600!Important}
	.text-danger {  color: red!important;font-weight : 600!Important}

input[type="checkbox"]{margin-right: 5px}
.flex-center{
	display:flex;
	align-items:center;
	justify-content:center;
	gap : 10px;
	padding-top:7px;
	padding-bottom:7px
}

.width-60{
	width : 60px
}
.width-40{
	width : 40px!important;
}
.width-130{
	width : 130px!important;
}
.flex-center select,
.flex-center input{
	border-radius:3px;
	border:1px solid gainsboro;
}
</style> 



</head>

<body>


<div class="page-wrapper" id="main-wrapper" data-layout="vertical" data-navbarbg="skin6" data-sidebartype="full"
data-sidebar-position="fixed" data-header-position="fixed">
<?php include("aside.php"); ?>
<?php include("modal.php"); ?>



<div class="body-wrapper">
<?php include("header.php"); ?>



