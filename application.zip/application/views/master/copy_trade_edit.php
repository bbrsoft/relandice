<?php 
$table = "copy_trade";
$sql = "`id`='$id'";
$row = $this->model->row($table,$sql);
if($row >= 1){
	$data = $this->model->get_obj($table,$sql)[0];
	
	


if(isset($_POST['new'])){
	$nama = in($_POST['nama']);
	$secret = in($_POST['secret']);
	  
	
	$table = "copy_trade";
	$sql = "nama='$nama' and secret='$secret' and id<>'$id'  ";
	$row = $this->model->row($table,$sql);
	if($row >= 1){
		$alert = "danger";
		$respon = "Maaf. Data ini sudah ada sebelumnya ";
	} else {
		 
		$datax = array();
		$datax['nama'] = $nama;
		$datax['secret'] = $secret;
		 $this->db->where('id',$id);
		 $this->db->update('copy_trade',$datax);

		$alert = "success";
		$respon = "Berhasil Memperbaharui Data ";
		?> 
		<script>  document.location.href="<?php echo($site) ?>baim/copy_trade";   </script>  
		<?php 
	}
} 
 

?>

<?php include("alert_form.php"); ?>

 <div class="container-fluid">
<div class="row"> 
	<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 col-12 ">
		
		<div class="card">
			<div class="card-header">
				<h4>Tambah Data </h4>
			</div>
			<div class="card-body">
				<form method="post" enctype="multipart/form-data"> 
				 
					<span> Nama </span> 
					<input type="text" required class="form-control" name="nama" value="<?php echo($data->nama) ;  ?>" placeholder="Nama"    />
					<br />
					
					<span> Secret </span> 
					<input type="text" required class="form-control" name="secret" value="<?php echo($data->secret) ;  ?>" placeholder="Secret"    />
					<br />
					 
					
					
					<button name="new" type="submit" class="btn btn-primary" > <i class="la la-ticket">  </i> Masukkan Data</button>
				</form>
			</div>
		</div>
	</div>
	</div>
	</div>
	

<?php } ?>

