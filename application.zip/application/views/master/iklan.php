<?php 
	if(isset($_POST['new'])){
		$url = in($_POST['url']);
		require_once("isset_image.php");
		
		
		if(!empty($image)){	
			$this->db->query("INSERT INTO iklan (`image`,`url`) VALUES ('$image','$url')  ");
			$alert = "success";
			$respon = "Berhasil Menambah Iklan Baru ";
		} else {
			$alert = "danger";
			$respon = "Gambar yang anda masukkan tidak valid ";
		}
	} 
	
	if(isset($_POST['delete'])){ 
		$id = in($_POST['id']);
		$this->db->query("DELETE FROM iklan WHERE id='$id' ");
		$alert = "success";
		$respon = "Berhasil Menghapus Iklan";
		
	} 

?>


<div class="container-fluid bg-light min-vh-100">
<?php include("alert_form.php"); ?>

<div class="row">
<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 col-12 ">
	
<div class="card ">
<div class="card-header bg-primary">
	<h5 class="m-0  text-light"> Iklan Baru </h5>  
</div>
<div class="card-body shadow-sm">
	<form method="post" enctype="multipart/form-data"> 
		
		<span> Gambar Iklan  </span> 
		<input type="file" required class="form-control" name="image" value="" placeholder="Nama Kategori"    />
		<br />
		<span> URL Iklan </span> 
		<input type="url" required class="form-control" name="url" value="" placeholder="URL Iklan"    />
		<br />
		 
		<button type="submit" name="new" class="btn btn-primary" >Masukkan Data</button> 
		
	
	</form>
</div>
</div>
</div>






<div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 col-12 ">
 
<div class="card ">
<div class="card-header bg-primary">
	<h5 class="m-0  text-light"> Data Iklan </h5>  
</div>
<div class="card-body shadow-sm">

	
	<table class="table table-striped table-bordered">
		<thead>
		<tr>
			<th> Image </th> 
			<th> URL </th> 
			<th> Total Klik </th> 
			<th> # </th>
		</tr>
		</thead>
		<tbody>
			<?php $table = "iklan";
			$sql = "`id`<>-1";
			$row = $this->model->row($table,$sql);
			if($row >= 1){
				$dd = $this->model->get_obj($table,$sql);
				foreach($dd as $data){
					?> 
					<tr> 
						<td> <img onclick="showimg('<?php echo($site) ?>image/<?php echo($data->image) ;  ?>')" src="<?php echo($site) ?>image/<?php echo($data->image) ;  ?>"  style="width : 40px;"  class="none" /> </td>
						<td><a target="_blank" class="" href="<?php echo($data->url) ;  ?>" > Lihat URL  </a> </td>
						<td> <?php echo(uang($data->total_klik,0)) ;  ?>x </td>
						<td> 
						<a class="btn btn-danger btn-sm" onclick="showdel('<?php echo($data->id) ;  ?>','<?php 	echo($data->image) ;  ?>')" > Delete </a> 
						</td>
					</tr> 
					<?php 
				}
			} 
			 ?>		
		</tbody>
	</table> 
	
	


</div>
</div>


</div>
</div>
</div>
