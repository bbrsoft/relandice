<?php
if(isset($_POST['delete'])){
	$id = in($_POST['id']);
	$row = $this->model->row("copy_plan","id='$id'");
	if($row >= 1){
			
		$this->db->query("DELETE FROM copy_plan WHERE id='$id' ");
		$alert = "success";
		$respon = "Berhasil Menghapus Data Plan ";
	} 
}  


if(isset($_POST['new'])){
	 
	 $total = in($_POST['total']);
	 $jam = in($_POST['jam']);
	 $min = in($_POST['min']);
	 $max = in($_POST['max']);
	  
	$table = "copy_plan";
	$sql = "total='$total'   ";
	$row = $this->model->row($table,$sql);
	if($row >= 1){
		$alert = "danger";
		$respon = "Maaf. Data ini sudah ada sebelumnya ";
	} else {
		 
		$datax = array();
		$datax['total'] = $total ;
		$datax['jam'] = $jam ;
		$datax['min'] = $min ; 
		$datax['max'] = $max ; 
 		$this->db->insert('copy_plan',$datax);
 
		$alert = "success";
		$respon = "Berhasil Menambah Data Plan ";
	}
} 
 

?>

<?php include("alert.php"); ?>

<link rel="stylesheet" href="<?php echo($site) ?>assets/modules/datatables/datatables.min.css">
<link rel="stylesheet" href="<?php echo($site) ?>assets/modules/datatables/DataTables-1.10.16/css/dataTables.bootstrap4.min.css">
<link rel="stylesheet" href="<?php echo($site) ?>assets/modules/datatables/Select-1.2.4/css/select.bootstrap4.min.css">  


 <div class="container-fluid">
<div class="row"> 
	<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 col-12  ">
		
		<div class="card">
			<div class="card-header">
				<h4>Tambah Data Plan</h4>
			</div>
			<div class="card-body">
				<form method="post" enctype="multipart/form-data"> 
				 
					<span> Minimal Deposit </span> 
					<input type="text" required class="form-control" name="total" value="" placeholder="Min Deposit"    />
					<br />
					
					<span> Detik </span> 
					<input type="text" required class="form-control" name="jam" value="" placeholder="Jam "    />
					<br />
					<span> Min Profit (%) </span> 
					<input type="number" step="0.01" required  class="form-control" name="min" value="" placeholder="Min Profit"    />
					<br />
					
					<span> Max Profit (%) </span> 
					<input type="number" step="0.01" required class="form-control" name="max" value="" placeholder="Max Profit"    />
					<br />
					
					<button name="new" type="submit" class="btn btn-primary" > <i class="la la-ticket">  </i> Masukkan Data</button>
				</form>
			</div>
		</div>
	</div>
	
	
	
	<div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 col-12 ">
		<div class="card">
			<div class="card-header">
				<h4>Data Plan  </h4>
			</div>
			<div class="card-body">
				<div class="table-responsive">
					<table id="tables" class="table table-striped">
						<thead>
						<tr>  			
							<th>Min Deposit</th>					
							<th>Detik </th>					
							<th>Min </th>				
							<th>Max </th>				
							<th>#</th>
						</tr>
						</thead>
						<tbody>
						
						<?php $table = "copy_plan";
						$sql = "`id`<>-1";
						$row = $this->model->row($table,$sql);
						if($row >= 1){
							$dd = $this->model->get_obj($table,$sql);
							foreach($dd as $data){
								?> 
								<tr> 
									<td> <?php echo uang($data->total,0) ;  ?> </td>
									<td> <?php echo($data->jam) ;  ?> Detik </td>
									<td> <?php echo uang($data->min,2) ;  ?>% </td>
									<td> <?php echo uang($data->max,2) ;  ?>% </td>
									<td> 
										<a href="<?php echo($site) ?>baim/copy_plan_edit/<?php echo($data->id) ;  ?>" class="btn btn-primary btn-sm " > Edit </a>    
										<a onclick="showdel('<?php echo($data->id) ;  ?>','Hapus Plan <?php echo($data->total) ;  ?>')" class="btn btn-danger btn-sm " > Hapus </a>  
									</td>
								</tr> 
								<?php 
							}
						} 
						 ?>
						</tbody> 
					</table> 
				</div>
					
			</div>
		</div>	
	</div>
</div>
</div>


 

<script>  
site ="<?php echo($site) ?>";
$( document ).ready(function() {
    
var tablex = $('#tables').dataTable( {
 "bProcessing": true, 
 } );
   
});

 

</script> 

	

	


