<?php 
$id_data = $data->id;
$id_wd = $data->id_wd; 

	
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url_api.'/v2/payments/auth/token');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');

curl_setopt($ch, CURLOPT_USERPWD, $client . ':' . $secret);

$result = curl_exec($ch); 
curl_close($ch);   
  
if(!empty($result)){
	$obj = json_decode($result);
	$token2 = $obj->data->accessToken;
	
	

		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url_api.'/v2/payments/gs/disbursements/'.$id_wd);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		$headers = array();
		$headers[] = 'Accept: application/json';
		$headers[] = 'Content-Type: application/json';
		$headers[] = 'Publicaccesstoken: Bearer '.$token2;
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

		$result = curl_exec($ch);
		curl_close($ch); 
			 
				
		if(!empty($result)){
			$obj = json_decode($result); 
			if($obj->status == "200"){
				
				$data_respon = $obj->data;
				$status = $data_respon->attributes->status; 
				if(strtolower($status) == "completed"){
					$id_userx = $data->id_user;
					$this->db->query("UPDATE withdraw2 SET `status`='Finish' WHERE id='$id_data'");
					$this->db->query("UPDATE `investor_history` SET `status`='Sucesfully' WHERE id_user='$id_userx' and type='Sell'");
									
				} 
			}
		}  
} 
 
 
?>