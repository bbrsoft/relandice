	
	
	</div>
	</div>
	
  <script src="<?php echo($site) ?>assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <script src="<?php echo($site) ?>assets/js/sidebarmenu.js"></script>
  <script src="<?php echo($site) ?>assets/js/app.min.js"></script>
  <script src="<?php echo($site) ?>assets/libs/simplebar/dist/simplebar.js"></script>
</body>

</html>