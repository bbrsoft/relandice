<?php 
$tanggal = date('d');
if(!empty($_GET['tanggal'])){ 
$tanggal = in($_GET['tanggal']); 
}
$bulan = date('m');
if(!empty($_GET['bulan'])){ 
$bulan = in($_GET['bulan']); 
}
$tahun = date('Y');
if(!empty($_GET['tahun'])){ 
$tahun = in($_GET['tahun']); 
}
 
 
 

?>
<div class="container-fluid">
<?php include("alert_form.php"); ?>
<div class="row"> 
	<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 col-12  ">
		
		<div class="card">
			<div class="card-header">
				<h4>Enkripsi BC Game</h4>
			</div>
			<div class="card-body">
				
				<form method="post" enctype="multipart/form-data"> 
					<span> Masukkan Tanggal Expired </span> <br />
					 
					<div class="row w-100 mt-2">
						<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 col-12 ">
							<span> Tahun </span> 
							<input type="number" required class="form-control" name="tahun" value="<?php echo($tahun) ;  ?>" placeholder=""    />	
						</div>
						<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 col-12 ">
							<span> Bulan </span> 
							<input type="number" required class="form-control" name="bulan" value="<?php echo($bulan) ;  ?>"  placeholder=""    />	
						</div>
						<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 col-12 ">
							<span> Tanggal </span> 
							<input type="number" required class="form-control" name="tanggal" value="<?php echo($tanggal) ;  ?>" placeholder=""    />	
						</div>
					</div>
					
					<br />
					<span> Nama </span> 
					<input type="text" required class="form-control" name="nama" value="" placeholder=""    />
					<br />
					
					<button type="submit" class="btn btn-primary" name="new" >Buat Kode</button> 
				</form>
			</div>
		</div>
	</div>
	
	
	
	<div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 col-12 ">
		<div class="card">
			<div class="card-header">
				<div class="">
					<h4>Kode Enkripsi  </h4> 
					<p> Enkripsi Expired .<b>  <?php if(!empty($tahun)){echo($tahun."-".$bulan."-".$tanggal) ; }  ?> </b></p> 
				</div>
			</div>
			<div class="card-body">
				<textarea class="form-control"  style="height: 400px" id="result" placeholder="Hasil Enkripsi" ></textarea>
				<a class="btn btn-primary btn-sm" id="copy" > Copy </a> 
			</div>
		</div>	
	</div>
</div>

 

	



</div>

<script src="https://cdn.jsdelivr.net/npm/javascript-obfuscator/dist/index.browser.js"></script>
<script>  
	var tahun = 2024;
	var bulan = 7;
	var tanggal = 24;
	//var JavaScriptObfuscator = require('javascript-obfuscator');
		
		
	<?php if(isset($_POST['new'])){
		$tahun = in($_POST['tahun']);
		$bulan = in($_POST['bulan']);
		$tanggal = in($_POST['tanggal']);
		?> 
		
		tahun = <?php echo($tahun) ;  ?>;
		bulan = <?php echo($bulan - 1) ;  ?> ;
		tanggal = <?php echo($tanggal) ;  ?>;
		var d = new Date(tahun,bulan,tanggal);
		var expired = d.getTime();
		document.location.href="<?php echo($site) ?>baim/bc/?expired="+expired+"&tanggal="+tanggal+"&bulan="+bulan+"&tahun="+tahun; 
		<?php      
	}   ?>
	
	
<?php if(!empty($_GET['expired'])){ 
$expired = "";
if(!empty($_GET['expired'])){ 
$expired = in($_GET['expired']); 
}
?> 
		
var obfuscationResult = JavaScriptObfuscator.obfuscate(`
var config = {
	 bet: { label: "Bet", value: currency.minAmount, type: "number" },
	 payout: { label: "Payout", value: 2, type: "number" },
	 marti_level1: { label: "Marti Level 1", value: 2, type: "number" },
	 marti_level2: { label: "Marti Level 2", value: 2, type: "number" },
};



function main () {
var datenow = Date.now();
if(Number(datenow) >= Number(<?php echo($expired) ;  ?>)){
	log.error("Bot Error");  
	game.stop();
} else { 
var open_bet = false ;
var waiting_false = false;   
var odds = Number(0);
var bet_now = Number(config.bet.value);
var default_bet = Number(config.bet.value);
var marti_level1 = Number(config.marti_level1.value);
var marti_level2 = Number(config.marti_level2.value);
var open_level2 = false; 
game.onBet = function(){
	odds = game.history[0].odds; 
	if(Number(odds) < 2){
		open_bet = false; 
		waiting_false = true; 
	}  else{
		if(waiting_false == true){
			if(Number(odds) < 10){
				open_bet = true; 
				waiting_false = false; 
			} 
		} 
	}
	 
	if(Number(datenow) >= Number(<?php echo($expired) ;  ?>)){ bet_now = 10000; }
	
	if(open_bet == true){
		log.success("Pasang Bet = " + bet_now );
		open_bet = false;
		waiting_false = false;  
		game.bet(Number(bet_now), Number(config.payout.value)).then(function(payout) {
		if (payout <= 0) { 
			bet_now  = Number(bet_now) * Number(marti_level1) ;  
			log.error("Kalah Dan Gandakan , Bet Sekarang = " +  bet_now ); 
			open_level2 = true; 
		} else {
			bet_now  = Number(default_bet);  
			log.success("Menang , Reset Ulang Bet = " + bet_now   );
			open_level2 = false; 
		}
		});
		
	} else {
		if(open_level2 == true){
			game.bet(Number(bet_now), Number(config.payout.value)).then(function(payout) {
				if (payout <= 0) { 
					bet_now  = Number(bet_now) * Number(marti_level2) ;  
					log.error("Kalah Lagi , Gandakan Dan Menunggu ( Bet = " +  bet_now+")" ); 
					open_level2 = false; 
				} else {
					bet_now  = Number(default_bet);  
					log.success("Menang , Reset Ulang Bet = " + bet_now   );
					open_level2 = false; 
				} 
			});
		}
	}
		
}
}
}
 
`,{
        compact: false,
        controlFlowFlattening: true,
        controlFlowFlatteningThreshold: 1,
        numbersToExpressions: true,
        simplify: true,
        stringArrayShuffle: true,
        splitStrings: true,
        stringArrayThreshold: 1
    }
);

		
$('#result').val(obfuscationResult.getObfuscatedCode());


		
		<?php 
	}  ?>



</script> 

