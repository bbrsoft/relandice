<?php 
$client = $settings->client;
$secret = $settings->secret;
$status = "";
$url_api = "https://api.onebrick.io";

 
 
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url_api.'/v2/payments/auth/token');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');

curl_setopt($ch, CURLOPT_USERPWD, $client . ':' . $secret);

$result = curl_exec($ch); 
curl_close($ch);   
 
 
if(!empty($result)){
	$obj = json_decode($result);
	$token = $obj->data->accessToken;
	
	
	if(!empty($token)){
		 
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url_api.'/v2/payments/gs/bank-account-validation?accountNumber='.$bank_rekening.'&bankShortCode='.$bank_jenis);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);  
		
		$headers = array();
		$headers[] = 'Publicaccesstoken: Bearer '.$token;
		$headers[] = 'Content-Type: application/json';
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		$result = curl_exec($ch);
		curl_close($ch);
		
		
		if(!empty($result)){

			
			$obj = json_decode($result);
			if($obj->status == "200"){
			 
								$ch = curl_init();
								curl_setopt($ch, CURLOPT_URL, $url_api.'/v2/payments/auth/token');
								curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
								curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');

								curl_setopt($ch, CURLOPT_USERPWD, $client . ':' . $secret);

								$result = curl_exec($ch); 
								curl_close($ch);   
								  
								 
								if(!empty($result)){
									$obj = json_decode($result);
									$token2 = $obj->data->accessToken;
									 
									 
										$ticket = "TICKET".date('ymdhis').$id_user;
										$total = $total_profit; 
										$ch = curl_init();
										curl_setopt($ch, CURLOPT_URL, $url_api.'/v2/payments/gs/disbursements');
										curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
										curl_setopt($ch, CURLOPT_POST, 1);
										curl_setopt($ch, CURLOPT_POSTFIELDS, "\n{\n     \"referenceId\": \"$ticket\",\n     \"description\": \"Withdrawal\",\n     \"amount\": $total,\n     \"disbursementMethod\": {\n          \"type\": \"bank_transfer\",\n          \"bankShortCode\": \"$bank_jenis\",\n          \"bankAccountNo\": \"$bank_rekening\",\n          \"bankAccountHolderName\": \"$secret_user\"\n     }\n}\n");
 
										$headers = array();
										$headers[] = 'Accept: application/json';
										$headers[] = 'Content-Type: application/json';
										$headers[] = 'Publicaccesstoken: Bearer '.$token2;
										curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

										$result = curl_exec($ch); 
										curl_close($ch);  
										 
										if(!empty($result)){
											$obj = json_decode($result);
											$status_pg = $obj->status;
											
											$this->db->query("UPDATE `withdraw` SET `status_pg`='$status_pg' , `respon_pg`='$result' 
											WHERE invoice='$invoice'  "); 
																						
													
											if($obj->status == "200"){
													 
												$data_respon = $obj->data;
												$status = $data_respon->attributes->status;
												$id_respon = $data_respon->id; 												 
												
												
												$this->db->query("UPDATE `withdraw` SET `status`='Waiting' , `with_pg`='Yes' , `id_wd`='$id_respon' 
												WHERE invoice='$invoice'");
												
												
												$alert = "success";
												$respon = "Success Insert Your Withdrawal Request (Auto Transfer)";
												
																					 
											} 
										} 
								}
			}
		} 
	}
} 


 
	
?>


