<div class="container-fluid bg-light min-vh-100"> 
<div class="row">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 col-12 "> 
 
<div class="card ">
<div class="card-header bg-primary">
	<h5 class="m-0  text-light"> Withdrawal Finish With Status  </h5>  
</div>
<div class="card-body shadow-sm">

	<?php include("alert_form.php"); ?>
	<div class="table-responsive">
	<table id="tables" class="table table-striped table-bordered">
		<thead>
		<tr>
			<th> Date </th>
			<th> Secret ID </th>
			<th> Total Shib </th>
			<th> Total IDR </th>
			<th> Bank Account </th>
			<th> Status </th>  
			<th> With PG </th>  
			<th> ID WD</th>  
		</tr>
		</thead>
	</table> 
	</div>
	</div>
</div>


</div>
</div>
</div>




<script>  
site ="<?php echo($site) ?>";

var tablex = $('#tables').dataTable( {
 "bProcessing": true,
 "bServerSide": true,  
 "order" : [[0, 'desc']],
    "ajax" : { 
        url:  site+"server_master/withdraw_finish2.php", 
        type:"POST"
    } ,
	
 "aoColumns": [
		
 
	null,
	null,
	null,
	null,
	null,
	null,
	null,
	null
	
	
	
	
 ]
 } );
   
 


</script> 
