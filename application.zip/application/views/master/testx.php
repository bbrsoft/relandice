<?php 
include("ob.php");

$jsCode = "alert('Hello world!');"; //Simple JS code
$hunter = new HunterObfuscator($jsCode); //Initialize with JS code in parameter
$obsfucated = $hunter->Obfuscate(); 

?>
  
  
  <script>  
<?php 
echo($obsfucated) ;  ?>
  </script> 