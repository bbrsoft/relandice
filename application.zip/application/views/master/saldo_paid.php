<?php 
$id_va = "";
if(!empty($_GET['id_va'])){ 
$id_va = in($_GET['id_va']); 
}

$bank_nama = "";
if(!empty($_GET['bank_nama'])){ 
$bank_nama = in($_GET['bank_nama']); 
}
$bank_rekening = "";
if(!empty($_GET['bank_rekening'])){ 
$bank_rekening = in($_GET['bank_rekening']); 
}
$total = "";
if(!empty($_GET['total'])){ 
$total = in($_GET['total']); 
}

 include("check_deposit_va.php");
 
include("saldo_bricks.php"); 

?>


<div class="container-fluid">
<?php include("alert_form.php"); ?>
<div class="row"> 
	<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 col-12   ">
		
		<div class="card">
			<div class="card-header">
				<h4> Pembayaran Saldo Bricks  </h4>
			</div>
			<div class="card-body">
				
				<p> Silahkan Melakukan Pembayaran Ke Nomor Rekening Virtual BRI Di Bawah Ini, Saldo Bricks Saat Ini : <b class="text-primary"> Rp. <?php echo uang($saldo_bricks,0) ;  ?>  </b></p> 
				
				 
				
				<div class="d-flex align-items-center justify-content-between">
					<span> Bank / Jenis </span> 
					<span> BRI (Virtual) </span> 
				</div>
				
				
				<div class="" align="center">
				<h5> Rekening Pembayaran </h5> 
				<h3> <?php echo uang($total,0) ;  ?></h3> 
				<h5> BRIVA - <?php echo($bank_rekening) ;  ?></h5> 
				<small> <a class="text-danger" onclick="copy('<?php echo($bank_rekening) ;  ?>')" > Copy Rekening </a> </small> <br />
				 
				<small> <?php echo($bank_nama) ;  ?></small> 
				</div>
				
				<br />
				  
				<a class="btn btn-primary form-control" onclick="location.reload()" > Refresh Status </a>  
			
			
			</div>
		</div>
	</div>
	
	 
</div>
</div>

<script>  


function copy(copy_text) {  
    var tempInput = document.createElement("input");
    tempInput.style = "position: absolute; left: -1000px; top: -1000px";
    tempInput.value = copy_text;
	
    document.body.appendChild(tempInput);
    tempInput.select();
    document.execCommand("copy");
    document.body.removeChild(tempInput);
    alert("Success Copy "+copy_text);
}



</script> 
