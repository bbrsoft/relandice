<?php  

$alert = "danger";
$respon = "Sorry - Deposit / Payment With VA BRI Is Maintennace . Please change your transfer destination ";

 

$client = $settings->client;
$secret = $settings->secret;
$url_api = "https://api.onebrick.io";
 

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url_api.'/v2/payments/auth/token');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');

curl_setopt($ch, CURLOPT_USERPWD, $client . ':' . $secret);

$result = curl_exec($ch);
if (curl_errno($ch)) {
	$alert = "danger";
	$respon = "Sorry - An error occurred while creating the Virtual Account ";
}
curl_close($ch); 

if(!empty($result)){
	$obj = json_decode($result);
	$token = $obj->data->accessToken;
	
	
	if(!empty($token)){
		
		
		$ch = curl_init();

		curl_setopt($ch, CURLOPT_URL, $url_api.'/v2/payments/gs/va/close');
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
		curl_setopt($ch, CURLOPT_POST, 1);
		
		
		
		
		$invoice = date('ymdhis').rand(0,9999);
		$nama = "MasterReland"; 
		$secret_user = "MasterReland";
		
		curl_setopt($ch, CURLOPT_POSTFIELDS, "{\n    \"amount\": $total_idr,\n    \"referenceId\": \"$invoice\",\n    \"expiredAt\": \"60\",\n    \"description\": \"Topup Balance\",\n    \"bankShortCode\": \"BRI\",\n    \"displayName\": \"$secret_user\"\n}");

		$headers = array();
		$headers[] = 'Publicaccesstoken: Bearer '.$token;
		$headers[] = 'Content-Type: application/json';
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

		$result = curl_exec($ch);
		  
		if (curl_errno($ch)) {
			$alert = "danger";
			$respon = "Sorry - An error occurred while creating the Virtual Account . Please Change Bank Destination ";
		}
		
		if(!empty($result)){
			
			$obj = json_decode($result);
			if($obj->status == "200"){
				
				$data_respon = $obj->data;
				
				$id_va = $data_respon->id;
				$bank_nama = $data_respon->displayName;
				$bank_rekening = $data_respon->accountNo;
				
				$url = $site."baim/saldo_paid/?id_va=".$id_va ;
				$url .= "&bank_nama=".$bank_nama;
				$url .= "&bank_rekening=".$bank_rekening;
				$url .= "&total=".$total;
				
				echo("<script>  document.location.href='".$url."';   </script> ") ; 
				exit();
 
 
			} 
		} 
		
		curl_close($ch);
		
		
	}
} 


 


 
?>
