<div class="container-fluid bg-light min-vh-100"> 
<?php include("alert_form.php"); ?>
<div class="row">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 col-12 "> 
 
<div class="card ">
<div class="card-header bg-primary">
	<h5 class="m-0  text-light"> Deposit Finish  </h5>  
</div>
<div class="card-body shadow-sm">
<div class="table-responsive">
 
	<table id="tables" class="table table-striped table-bordered">
		<thead>
		<tr>
			<th> Secret ID </th>
			<th> Subscribe </th>
			<th> Total Payment </th>
			<th> Evidence </th> 
		</tr>
		</thead>
	</table> 
	</div>
</div>
</div>


</div>
</div>
</div>




<script>  
site ="<?php echo($site) ?>";

var tablex = $('#tables').dataTable( {
 "bProcessing": true,
 "bServerSide": true,  
 "order" : [[0, 'desc']],
    "ajax" : { 
        url:  site+"server_master/deposit2_finish.php", 
        type:"POST"
    } ,
	
	"aoColumns": [
	
	null,
	{ "mclass":"wall", "mData": "1", "mRender": function ( data, type, full ) {
		return data+" Month ";
	}},
	{ "mclass":"wall", "mData": "2", "mRender": function ( data, type, full ) {
		return uang(data , 0);
	}},
	 
{ "mclass":"wall", "mData": "3", "mRender": function ( data, type, full ) {
		if(data){
			
			url_img = "https://relandice.site/1x/";
			  
			imgx = "showimg('"+url_img+"/image/"+data+"')";
			img = '<img src="'+url_img+'/image/'+data+'" onclick="'+imgx+'"  style="height: 30px;"  />';
			return img; 
		} else {
			return "Tidak Ada";
		}
	}},
	
	
	
 ]
 } );
   
 


</script> 
