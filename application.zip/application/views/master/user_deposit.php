<?php 
$table = "user";
$sql = "`id`='$id'";
$row = $this->model->row($table,$sql);
if($row >= 1){
$data = $this->model->get_obj($table,$sql)[0];



?>
<div class="container-fluid bg-light min-vh-100"> 
<?php include("alert_form.php"); ?>
<div class="row">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 col-12 "> 
 
<div class="card ">
<div class="card-header bg-primary">
	<h5 class="m-0  text-light"> Deposit User - <?php echo($data->secret) ;  ?>  </h5>  
</div>
<div class="card-body shadow-sm"> 
	<table id="tables" class="table table-striped table-bordered">
		<thead>
		<tr>
			<th> Date</th> 
			<th> Total Crypto </th>
			<th> Total </th>
			<th> Bank / Wallet</th>
			<th> Evidence </th> 
			<th> Status </th> 
		</tr>
		</thead>
	</table> 
	</div>
</div>


</div>
</div>
</div>




<script>  
site ="<?php echo($site) ?>";

var tablex = $('#tables').dataTable( {
 "bProcessing": true,
 "bServerSide": true,  
 "order" : [[4 , 'desc']],
    "ajax" : { 
        url:  site+"server_master/user_deposit.php?id_user=<?php echo($data->id) ;  ?>", 
        type:"POST"
    } ,
	
	"aoColumns": [
	null,
	{ "mclass":"wall", "mData": "1", "mRender": function ( data, type, full ) {
		return uang(data , 0)+ " "+full[7];
	}},
	{ "mclass":"wall", "mData": "2", "mRender": function ( data, type, full ) {
		return full[8]+" "+uang(data , 0); 
	}},
	{ "mclass":"wall", "mData": "3", "mRender": function ( data, type, full ) {
		//$aColumns = array('date','total_rfc','total','tujuan','bukti','status','id','type','type_money','pg','pg_rekening','pg_bank','pg_nama');
		
		if(full[9] == "Yes"){
			return "Virtual "+full[11]+"<br>"+full[10]+"<br />"+full[12];
		} else {
			return data; 
		}

	}},
	{ "mclass":"wall", "mData": "4", "mRender": function ( data, type, full ) {
		if(data){
			
	
		var url_img = site;
		if(full[7] == "shiba"){
			url_img = "https://relandice.site/desain/";
		}  
		imgx = "showimg('"+url_img+"/image/"+data+"')";
		img = '<img src="'+url_img+'/image/'+data+'" onclick="'+imgx+'"  style="height: 30px;"  />';
		return img; 
		} else {
			return "Tidak Ada";
		}
	}}, 
	null
	
	
	
 ]
 } );
   
 


</script> 

<?php } ?>

