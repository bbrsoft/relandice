<?php 

if(isset($_POST['new'])){
	
	
	
	
	$total = in($_POST['total']);
	$len = strlen($total);
	$last = $len - 3; 
	$tt = "";
	for ($i = 0; $i <= $len -1; $i++) {
	if($i >= $last){
	$tt .= 0;
	} else {
	$tt .= $total[$i];
	}
	} 
	$total_idr = $tt;
	
	if($total_idr >= 10000){
		include("deposit_isset_va.php");
	} 
	
	
	
} 


include("saldo_bricks.php"); 
?>



 <div class="container-fluid">
 <?php include("alert_form.php"); ?>
<div class="row"> 
	<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 col-12  ">
		
		<div class="card">
			<div class="card-header">
				<h4>Tambah Saldo Bricks </h4>
			</div>
			<div class="card-body">
				<form method="post" enctype="multipart/form-data"> 
				 
					<span> Sisa Saldo Bricks </span> 
					<input type="text" disabled class="form-control"  value="<?php echo uang($saldo_bricks,0) ;  ?>" placeholder="Nominal Saldo"    />
					<br />
					
					<span> Nominal Topup Saldo </span> 
					<input type="text" required class="form-control" name="total" value="" placeholder="Nominal Saldo"    />
					<br />
					
					
					<button name="new" type="submit" class="btn btn-primary" > <i class="la la-ticket">  </i> Topup Saldo </button>
				</form>
			</div>
		</div>
	</div>
	
	 
</div>
</div>
