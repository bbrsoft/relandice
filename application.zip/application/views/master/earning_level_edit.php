<?php  
$table = "earn_level";
$sql = "`id`='$id'";
$row = $this->model->row($table,$sql);
if($row >= 1){
	$data = $this->model->get_obj($table,$sql)[0];
	




if(isset($_POST['new'])){
	$min_deposit = in($_POST['min_deposit']);
	$time = in($_POST['time']);
	$profit = in($_POST['profit']);
	
	$row = $this->model->row("earn_level","min_deposit = $min_deposit and id<>'$id'  ");
	if($row >= 1){
		$alert = "danger";
		$respon = "Sorry - This Data has already exists ";
	}else {
		$data = array();
		$data['min_deposit'] = $min_deposit ;
		$data['time'] = $time ;
		$data['profit'] = $profit ;  
		$this->db->where('id',$id);
		$this->db->update('earn_level',$data);
		
		$alert = "success";
		$respon = "Berhasil Memperbaharui Data Baru ";
		
		?> 
		<script>  document.location.href="<?php echo($site) ?>/baim/earning_level/";   </script>  
		<?php 
		exit();
		
	}
		 
} 

?>

<div class="container-fluid">

	<?php include("alert_form.php"); ?>
<div class="row"> 
	
	<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 col-12 ">
		
		<div class="card">
			<div class="card-header">
				<div class="">
				<h4>Level Deposit </h4>
					 
				</div>	
			</div>
			<div class="card-body">
				<form method="post"  enctype="multipart/form-data"> 
					 <?php include("alert_form.php"); ?>
					 
					
					<span> Minimal Deposit </span> 
					<input type="number" required class="form-control" step="0.00000001"  value="<?php echo($data->min_deposit) ;  ?>"   name="min_deposit"   placeholder="Minimal Deposit"    />
					<br />
					<span> Time (second) </span> 
					<input type="number" required class="form-control" step="1" name="time"  value="<?php echo($data->time) ;  ?>"   placeholder="Waktu Pembagian"    />
					<br />
					<span> Profit </span> 
					<input type="number" required class="form-control" step="0.001" name="profit" value="<?php echo($data->profit) ;  ?>"     placeholder="Profit"    />
					<br /> 
					
					<button name="new" type="submit" class="btn btn-primary" >Edit Level</button>  
				</form>
				
				
				
					
				
				
				
				
			</div>
		</div>
	</div> 
	
	 
	
	
	
</div> 
</div> 
 
<?php } ?>