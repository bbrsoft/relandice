<?php  
if(isset($_POST['new'])){
		
	$secret = in($_POST['secret']);
	$token = in($_POST['token']); 
	$bet = in($_POST['bet']);
		
	$row = $this->model->row("user","secret='$secret' ");
	if($row >= 1){
		$alert = "danger";
		$respon = "Maaf. Secret Ini sudah ada sebelumnya ";
	}else {
		
		$data = array();
		$data['secret'] = $secret ;
		$data['token'] = $token ;
		$data['bet'] = $bet;
		
		$this->db->insert('user',$data);
		$return  = $this->db->insert_id(); 
		
		$alert = "success";
		$respon = "Berhasil Memasukkan User Secret Baru ";
	}
} 


?>

<div class="container-fluid">
<div class="row">
	<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 col-12 ">
		
		<div class="card">
			<div class="card-header">
				<h4>Tambah User Secret </h4>
			</div>
			<div class="card-body">
				<form method="post"  enctype="multipart/form-data"> 
					 <?php include("alert_form.php"); ?>
					<span> Secret * </span> 
					<input type="text" required class="form-control" name="secret"  placeholder="Secret Login"    />
					<br />
					
					<span> Token  </span> 
					<textarea type="text" class="form-control" name="token"  placeholder="Token Bermain"   ></textarea>
					<br />
					
					<span> Saldo Bermain *</span> 
					<input type="number" required class="form-control" name="bet" value="" placeholder="Total Jumlah Permainan"    />
					<br />
					
					
					<button name="new" type="submit" class="btn btn-primary" >Tambah User</button> 
				</form>
			</div>
		</div>
</div> 
</div> 
</div> 


 
			
			
			