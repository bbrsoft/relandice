<?php 
if(isset($_POST['delete'])){
	$id = in($_POST['id']);
	$this->db->query("UPDATE deposit SET `status`='Bukti Ditolak' WHERE id='$id'  ");
	$alert = "success"; 
	$respon = "Berhasil Menolak Bukti Pembayaran";
}  

if(isset($_POST['konfirmasi'])){
	$id = in($_POST['id']);
	
	$table = "deposit";
	$sql = "`id`='$id' and status='Pengecekan Bukti' ";
	$row = $this->model->row($table,$sql);
	if($row >= 1){
		$data = $this->model->get_obj($table,$sql)[0];
		$qty = $data->qty;
		$id_user = $data->id_user;
		$total = $data->total;
		$percent = $settings->referral;
		
		$total_bonus = ($total * $percent ) / 100;
		
		$table = "user";
		$sql = "`id`='$id_user'";
		$row = $this->model->row($table,$sql);
		if($row >= 1){
			$u = $this->model->get_obj($table,$sql)[0];
			$id_referral = $u->id_referral;
			
			$data = array();
			$data['id_user'] = $id_referral ; 
			$data['total'] = $total_bonus ;
			$data['keterangan'] = "Bonus Referral Dari Deposit ".$u->nama." Sebesar Rp. ".uang($total,0)." x ".$percent."% = ".uang($total_bonus,0);
			$this->db->insert('bonus',$data);
			$return  = $this->db->insert_id(); 
			
			$alert = "success";
			$respon = "Berhasil Memasukkan Data Baru ";
			
			$this->db->query("UPDATE user SET `saldo`=`saldo`+$total_bonus WHERE id='$id_referral'  ");
		} 
		
		
		
		$this->db->query("UPDATE deposit SET `status`='Selesai' WHERE id='$id'  ");
		$this->db->query("UPDATE user SET `tiket`=`tiket`+$qty WHERE id='$id_user'  ");
		
		$alert = "success";
		$respon = "Berhasil Menerima Bukti Pembayaran";
		
		
	} 
} 


?>


<div class="container-fluid bg-light min-vh-100">
<?php include("alert_form.php"); ?>
<!--  Row 1 -->
<div class="row">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 col-12 ">
 
<div class="card ">
<div class="card-header bg-primary">
	<h5 class="m-0  text-light"> Bukti Pembayaran Masuk </h5>  
</div>
<div class="card-body shadow-sm">
 
	<table id="tables" class="table table-striped table-bordered">
		<thead>
		<tr>
			<th> Tanggal </th>
			<th> User ID  </th> 
			<th> Invoice </th> 
			<th> Total Ticket </th>
			<th> Harga </th>
			<th> Total Pembayaran </th>
			<th> Bukti Transfer </th>
			<th> # </th>
		</tr>
		</thead>
		<tbody>
			<?php $table = "deposit";
			$sql = "status='Pengecekan Bukti' and bukti <> '' ORDER BY id DESC LIMIT 200 ";
			$row = $this->model->row($table,$sql);
			if($row >= 1){
				$dd = $this->model->get_obj($table,$sql);
				foreach($dd as $data){
					$id_user = $data->id_user;
					$table = "user";
					$user_id= "";
					$sql = "`id`='$id_user'";
					$row = $this->model->row($table,$sql);
					if($row >= 1){
						$user = $this->model->get_obj($table,$sql)[0];
						$user_id = $user->user_id;
					} 
					?> 
					<tr> 
						<td> <?php echo($data->tanggal) ;  ?> </td>
						<td> <?php echo($user_id) ;  ?> </td> 
						<td> #<?php echo($data->invoice) ;  ?> </td> 
						<td> <?php echo($data->qty) ;  ?> </td>
						<td> <?php echo uang($data->harga,0) ;  ?> </td>
						<td> Rp. <?php echo uang($data->total,0) ;  ?> </td>
						<td> 
							<img onclick="showimg('<?php echo($site) ;  ?>/image/<?php echo($data->bukti) ;  ?>')" src="<?php echo($site) ?>image/<?php echo($data->bukti) ;  ?>"  style="height: 30px;"  class="" />
						</td>
						
						<td> 
							<div class="dropdown dropdown-right">
							  <button class="btn btn-primary btn-sm dropdown-toggle" onclick="$('#d_<?php echo($data->id) ;  ?>').slideToggle()" 
							  type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
								 Action 
							  </button>
							  <div  style="right:0px!Important; left:auto"  class="dropdown-menu" id="d_<?php echo($data->id) ;  ?>" aria-labelledby="dropdownMenuButton">
								<a class="dropdown-item" onclick="showdel('<?php echo($data->id) ;  ?>','<?php 	echo($data->invoice) ;  ?>')">Tolak Bukti</a>
								<a class="dropdown-item" onclick="showconf('<?php echo($data->id) ;  ?>','<?php 	echo($data->invoice) ;  ?>')">Terima Bukti</a> 
							  </div>
							</div>
						</td>
						
						
					</tr> 
					<?php 
				}
			} 
			 ?>		
		</tbody>
	</table> 
	
	


</div>
</div>


</div>
</div>
</div>




<script>   

var tablex = $('#tables').dataTable( {
 "bProcessing": true,
});

 
 
</script>