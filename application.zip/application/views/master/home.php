<?php 
$date = date('Y-m-d');


$data_rp_va = $this->model->sql_fetch("SELECT SUM(total) as total FROM deposit WHERE status='Accept' and type_money='Rp' and pg='Yes' and date>='$date'  ")[0];
$data_rp_manual = $this->model->sql_fetch("SELECT SUM(total) as total FROM deposit WHERE status='Accept' and type_money='Rp' and pg='No' and date>='$date'  ")[0];
$rp_va = $data_rp_va->total;
$rp_manual = $data_rp_manual->total;
$rp_total = $rp_va + $rp_va_manual;


$data_wd_va = $this->model->sql_fetch("SELECT SUM(total_idr) as total FROM withdraw2 WHERE status='Finish' and type_money='Rp' and with_pg='Yes' and date>='$date'  ")[0];
$data_wd_manual = $this->model->sql_fetch("SELECT SUM(total_idr) as total FROM withdraw2 WHERE status='Finish' and type_money='Rp' and with_pg='No' and date>='$date'  ")[0];
$wd_va = $data_wd_va->total;
$wd_manual = $data_wd_manual->total;
$wd_total = $wd_va + $wd_manual;



$row_user = $this->model->row("user","id<>-1 and ( secret='' or secret IS NULL )	");
$row_user_secret = $this->model->row("user","id<>-1 and secret <> '' ");

if(isset($_POST['reset_x'])){
	$x = in($_POST['x']);
	$this->db->query("UPDATE settings SET `x`='$x'   ");
	 $alert = "success";
	 $respon = "Berhasil Mereset Perkalian ";
} 

if(isset($_POST['reset_balance'])){
	$default_balance = in($_POST['default_balance']);
	$this->db->query("UPDATE settings SET `default_balance`='$default_balance'  ");
	 $alert = "success";
	 $respon = "Berhasil Mereset Default Saldo ";
} 

if(isset($_POST['reset_all'])){
	$default_balance = in($_POST['default_balance']);
	$x = in($_POST['x']);
	$this->db->query("UPDATE settings SET `default_balance`='$default_balance',`target`='$default_balance', `x`='$x' , `total_win`=0, total_lose=0 , total_balance='$default_balance' , `status_game`='normal'   ");
	$alert = "success";
	$respon = "Berhasil Mereset Semua "; 
} 


$table = "settings";
$sql = "`id` <> -1";
$row = $this->model->row($table,$sql);
if($row >= 1){
	$settings = $this->model->get_obj($table,$sql)[0];
 
} 
include("saldo_bricks.php");

?> 

<div class="container-fluid">
<div class="">
<?php include("alert_form.php"); ?>
<div class="p-3 bg-light shadow"  style="border-radius:10px " >
	<h5  style="font-weight : bold;margin:0px !important; " > Selamat Datang </h5> 
	<p> Selamat Datang Di Dashboard Administrator <?php echo($settings->nama) ;  ?>, Berikut Rincian Singkat </p> 
</div> 

<div class="row mt-3">
	<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 col-12 ">
	<a class="card overflow-hidden shadow"  >
	  <div class="card-body p-4">
		<h5 class="card-title">Deposit Total</h5>
		<div class="row align-items-center">
		  <div class="col-8">
			<h4 class="fw-semibold mb-1">Rp. <?php echo uang($rp_total,0) ;  ?></h4>
			<div class="d-flex align-items-center mb-3">
			  <span class="me-1 rounded-circle bg-light-success round-20 d-flex align-items-center justify-content-center">
				<i class="ti ti-arrow-up-left text-success"></i>
			  </span>
			  <p class="text-dark me-1 fs-3 mb-0">Total Deposit  Hari ini </p> 
			</div>  
		  </div>
		  <div class="col-4">
			<h1> <i class="ti ti-wallet">  </i></h1> 
		  </div>
		</div>
	  </div>
	</a>
	</div>
	<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 col-12 ">
	<a class="card overflow-hidden shadow"  >
	  <div class="card-body p-4">
		<h5 class="card-title">Deposit VA </h5>
		<div class="row align-items-center">
		  <div class="col-8">
			<h4 class="fw-semibold mb-1">Rp. <?php echo uang($rp_va,0) ;  ?></h4>
			<div class="d-flex align-items-center mb-3">
			  <span class="me-1 rounded-circle bg-light-success round-20 d-flex align-items-center justify-content-center">
				<i class="ti ti-arrow-up-left text-success"></i>
			  </span>
			  <p class="text-dark me-1 fs-3 mb-0">Deposit VA Hari ini </p> 
			</div>  
		  </div>
		  <div class="col-4">
			<h1> <i class="ti ti-wallet">  </i></h1> 
		  </div>
		</div>
	  </div>
	</a>
	</div>
	
	<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 col-12 ">
	<a class="card overflow-hidden shadow"  >
	  <div class="card-body p-4">
		<h5 class="card-title">Deposit Manual </h5>
		<div class="row align-items-center">
		  <div class="col-8">
			<h4 class="fw-semibold mb-1">Rp. <?php echo uang($rp_manual,0) ;  ?></h4>
			<div class="d-flex align-items-center mb-3">
			  <span class="me-1 rounded-circle bg-light-success round-20 d-flex align-items-center justify-content-center">
				<i class="ti ti-arrow-up-left text-success"></i>
			  </span>
			  <p class="text-dark me-1 fs-3 mb-0">Deposit Manual Hari ini </p> 
			</div>  
		  </div>
		  <div class="col-4">
			<h1> <i class="ti ti-wallet">  </i></h1> 
		  </div>
		</div>
	  </div>
	</a>
	</div>
	
	
	<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 col-12 ">
	<a class="card overflow-hidden shadow"  >
	  <div class="card-body p-4">
		<h5 class="card-title">Total Withdraw</h5>
		<div class="row align-items-center">
		  <div class="col-8">
			<h4 class="fw-semibold mb-1">Rp. <?php echo uang($wd_total,0) ;  ?></h4>
			<div class="d-flex align-items-center mb-3">
			  <span class="me-1 rounded-circle bg-light-success round-20 d-flex align-items-center justify-content-center">
				<i class="ti ti-arrow-up-left text-danger"></i>
			  </span>
			  <p class="text-dark me-1 fs-3 mb-0">Total Withdraw  Hari ini </p> 
			</div>  
		  </div>
		  <div class="col-4">
			<h1> <i class="ti ti-wallet text-danger">  </i></h1> 
		  </div>
		</div>
	  </div>
	</a>
	</div>
	
	<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 col-12 ">
	<a class="card overflow-hidden shadow"  >
	  <div class="card-body p-4">
		<h5 class="card-title">Withdraw PG </h5>
		<div class="row align-items-center">
		  <div class="col-8">
			<h4 class="fw-semibold mb-1">Rp. <?php echo uang($wd_va,0) ;  ?></h4>
			<div class="d-flex align-items-center mb-3">
			  <span class="me-1 rounded-circle bg-light-success round-20 d-flex align-items-center justify-content-center">
				<i class="ti ti-arrow-up-left text-danger"></i>
			  </span>
			  <p class="text-dark me-1 fs-3 mb-0">Withdraw PG Hari ini </p> 
			</div>  
		  </div>
		  <div class="col-4">
			<h1> <i class="ti ti-wallet text-danger">  </i></h1> 
		  </div>
		</div>
	  </div>
	</a>
	</div>
	
	<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 col-12 ">
	<a class="card overflow-hidden shadow"  >
	  <div class="card-body p-4">
		<h5 class="card-title">Withdraw Manual </h5>
		<div class="row align-items-center">
		  <div class="col-8">
			<h4 class="fw-semibold mb-1">Rp. <?php echo uang($wd_manual,0) ;  ?></h4>
			<div class="d-flex align-items-center mb-3">
			  <span class="me-1 rounded-circle bg-light-success round-20 d-flex align-items-center justify-content-center">
				<i class="ti ti-arrow-up-left text-danger"></i>
			  </span>
			  <p class="text-dark me-1 fs-3 mb-0">Withdraw Manual Hari ini </p> 
			</div>  
		  </div>
		  <div class="col-4">
			<h1> <i class="ti ti-wallet text-danger">  </i></h1> 
		  </div>
		</div>
	  </div>
	</a>
	</div>
	
	
	
	
	
	<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 col-12 ">
	<a class="card overflow-hidden shadow"  >
	  <div class="card-body p-4">
		<h5 class="card-title">User Secret </h5>
		<div class="row align-items-center">
		  <div class="col-8">
			<h4 class="fw-semibold mb-1"><?php echo($row_user_secret) ;  ?> Secret</h4>
			<div class="d-flex align-items-center mb-3">
			  <span class="me-1 rounded-circle bg-light-success round-20 d-flex align-items-center justify-content-center">
				<i class="ti ti-arrow-up-left text-success"></i>
			  </span>
			  <p class="text-dark me-1 fs-3 mb-0">Total Pengguna Secret </p> 
			</div>  
		  </div>
		  <div class="col-4">
			<h1> <i class="ti ti-users">  </i></h1> 
		  </div>
		</div>
	  </div>
	</a>
	</div> 
	
	
	<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 col-12 ">
	<a class="card overflow-hidden shadow"  >
	  <div class="card-body p-4">
		<h5 class="card-title">Price / Lot </h5>
		<div class="row align-items-center">
		  <div class="col-8">
			<h4 class="fw-semibold mb-1">Rp. <?php echo($settings->price_lot) ;  ?> / Lot</h4>
			<div class="d-flex align-items-center mb-3">
			  <span class="me-1 rounded-circle bg-light-success round-20 d-flex align-items-center justify-content-center">
				<i class="ti ti-arrow-up-left text-success"></i>
			  </span>
			  <p class="text-dark me-1 fs-3 mb-0">Price / Lot </p> 
			</div>  
		  </div>
		  <div class="col-4">
			<h1> <i class="ti ti-users">  </i></h1> 
		  </div>
		</div>
	  </div>
	</a>
	</div> 
	<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 col-12 ">
	<div class="card overflow-hidden shadow"  >
	  <div class="card-body p-4">
		<h5 class="card-title">Saldo Bricks - <a class="btn btn-primary btn-sm" href="<?php echo($site) ?>baim/saldo" > + Saldo </a> </h5>
		<div class="row align-items-center">
		  <div class="col-8">
			<h4 class="fw-semibold mb-1">Rp. <?php echo($saldo_bricks) ;  ?> </h4>
			<div class="d-flex align-items-center mb-3">
			  <span class="me-1 rounded-circle bg-light-success round-20 d-flex align-items-center justify-content-center">
				<i class="ti ti-arrow-up-left text-success"></i>
			  </span>
			  <p class="text-dark me-1 fs-3 mb-0">Saldo Bricks </p> 
			</div>  
		  </div>
		  <div class="col-4">
			<h1> <i class="ti ti-users">  </i></h1> 
		  </div>
		</div>
	  </div>
	</div>
	</div> 
</div>




<div class="row mt-3">
	<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 col-12 ">
	<div class="card overflow-hidden shadow"  >
	  <div class="card-body p-4">
		<h5 class="card-title">Admin Lose</h5> 
			<h4 class="fw-semibold mb-1"><?php echo uang($settings->total_lose , 0) ;  ?>  TKN </h4>
	  </div>
	</div>
	</div> 

	<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 col-12  ">
	<div class="card overflow-hidden shadow"  >
	  <div class="card-body p-4">
		<h5 class="card-title">Admin Win</h5>
		 <h4 class="fw-semibold mb-1"><?php echo(uang($settings->total_win, 0)) ;  ?> TKN </h4>
	  </div>
	</div>
	</div> 

	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 col-12  ">
	<div class="card overflow-hidden shadow"  >
	  <div class="card-body p-4">
		<h5 class="card-title">Target Saldo</h5>
		 <h4 class="fw-semibold mb-1"><?php echo(uang($settings->target, 0)) ;  ?> TKN </h4>
		<p> Status Game : <b> <?php echo($settings->status_game) ;  ?> </b> 
		</p> 
		
		
<div class="">
<form method="post" enctype="multipart/form-data"> 
	<span class="d-block"> Saldo </span> 
	<div class="d-flex w-100">
	<input type="text"   class="form-control" name="default_balance" value="<?php echo($settings->default_balance) ;  ?>" placeholder=""    /> 
	<button type="submit"  style="width : 200px!important"  name="reset_balance" class="btn btn-primary" >Atur Ulang Saldo</button>
	</div> 
	
	<span  class="d-block mt-2"> Perkalian </span> 
	<div class="d-flex w-100">
	<input type="text"   class="form-control" name="x" value="<?php echo($settings->x) ;  ?>" placeholder=""    /> 
	<button type="submit"  style="width : 200px!important"  name="reset_x" class="btn btn-primary" >Atur Ulang X</button>
	</div>
	<p> <small> #info, refresh untuk melihat perubahan terbaru . sistem tidak berjalan secara realtime </small> </p> 
	
	<br />
	
	<button type="submit" class="btn btn-primary"  name="reset_all">Atur Ulang Semua</button>
	  
</form>	
</div>

</div>
	</div>
	</div> 




</div>












</div>
</div>



