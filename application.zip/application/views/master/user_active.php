<style>
	.text-success{
		color:green!important;
	}
	.text-danger{
		color:red!Important;
	}
</style>

<div class="container-fluid bg-light min-vh-100">  
<div class="row">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 col-12 "> 
 
<div class="card ">
<div class="card-header bg-primary">
	<h5 class="m-0  text-light"> Data Pengguna - Notibot </h5>  
</div>
<div class="card-body shadow-sm">

	<div class="">
		
<div class="row ">
	<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 col-12 ">
	<a class="card overflow-hidden shadow"  >
	  <div class="card-body p-4">
		<h5 class="card-title">Start Modal</h5>
		<div class="">
		<h4 class="fw-semibold mb-1" id="data_modal">Rp. 0 </h4>
		</div>
		</div>
	</a>
	</div>
	<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 col-12 ">
	<a class="card overflow-hidden shadow"  >
	  <div class="card-body p-4">
		<h5 class="card-title">Total Profit</h5>
		<div class="">
		<h4 class="fw-semibold mb-1" id="data_profit">Rp. 0 </h4>
		</div>
		</div>
	</a>
	</div>
	<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 col-12 ">
	<a class="card overflow-hidden shadow"  >
	  <div class="card-body p-4">
		<h5 class="card-title">Last Balance</h5>
		<div class="">
		<h4 class="fw-semibold mb-1" id="data_close">Rp. 0 </h4>
		</div>
		</div>
	</a>
	</div>

</div>
		
	</div>

	<?php include("alert_form.php"); ?>
	<div class="table-responsive">
	<table id="tables" class="table table-striped table-bordered">
		<thead>
		<tr> 
			<th   > Secret Login </th> 
			<th   > T/P</th>
			<th   > S/L</th>
			<th   > Buy </th>
			<th   > LOT </th>
			<th   > Profit Active </th>
			<th   > Balance Now </th>
			<th   > Percentage </th>  
		</tr>
		</thead> 
	<tbody>
	<?php $table = "investor_history_view";
	$sql = "`status`='Order' ";
	$row = $this->model->row($table,$sql);
	if($row >= 1){
		$dd = $this->model->get_obj($table,$sql);
		foreach($dd as $data){
			?> 
			<tr> 
				<td class="secret_<?php echo($data->id_user) ;  ?>" > <?php echo($data->secret) ;  ?> </td>
				<td class="percent_<?php echo($data->id_user) ;  ?>" > <?php echo($data->percent) ;  ?>% </td>
				<td class="percent_lose_<?php echo($data->id_user) ;  ?>" > <?php echo($data->percent_lose) ;  ?>% </td>
				<td class="total_shiba_<?php echo($data->id_user) ;  ?>" > <?php echo round($data->total_shiba,4) ;  ?> </td>
				<td class="total_lot_<?php echo($data->id_user) ;  ?>" > <?php echo round($data->total_lot,2) ;  ?> LOT </td>
				<td class="total_profit_<?php echo($data->id_user) ;  ?> <?php if($data->percent_profit > 0){echo("text-success") ; } else {echo("text-danger") ; }  ?> "> <?php echo round($data->total_profit,4) ;  ?></td>
				<td class="last_shiba_<?php echo($data->id_user) ;  ?>" > <?php echo round($data->last_shiba,4) ;  ?></td>
				<td class="percent_profit_<?php echo($data->id_user) ;  ?> <?php if($data->percent_profit > 0){echo("text-success") ; } else {echo("text-danger") ; }  ?> " > <?php echo round($data->percent_profit,2) ;  ?>%</td>
			</tr> 
			<?php 
		}
	} 
	?>
	</tbody> 
	</table> 
	</div>
	</div>
</div>


</div>
</div>
</div> 


<?php 	

$idr = 0.31851;
$usd = 0.00002;
$table = "crypto";
$sql = "`nama`='shib'";
$row = $this->model->row($table,$sql);
if($row >= 1){
	$dd = $this->model->get_obj($table,$sql)[0];
	$idr = $dd->idr;
	$usd = $dd->usd;
	$usdt = $dd->usd;
	
} 
?>




<script type="module"> 
import { io } from "https://cdn.socket.io/4.7.5/socket.io.esm.min.js";
const socket = io('wss://77.37.47.67:3005');
var wait = false ; 


var idr = <?php echo($idr) ;  ?>;
var usdt = <?php echo($usd) ;  ?>;



setInterval(function () {
if(wait == false){
wait = true; 
	socket.emit('get_history_all','{"status":"Order" } ', function (msg) {
	if(msg){
		
		let data_modal = 0 ;
		let data_profit = 0 ;
		let data_close = 0 ;
		let shib_profit = 0 ;
		let shib_close = 0 ;
		
		
		
		wait = false; 
		if(Array.isArray(msg)){
			msg.forEach(function(item, index){
				 
				
				let id_user = item.id_user;
				let secret = item.secret; 
				let percent = item.percent; 
				let total_idr = item.total_idr; 
				let percent_lose = item.percent_lose; 
				let total_shiba = item.total_shiba;  
				let total_lot = item.total_lot; 
				let total_profit = item.total_profit; 
				let last_shiba = item.last_shiba; 
				let percent_profit = item.percent_profit; 
					
					
					
					
				data_modal = Number(data_modal) + Number(total_idr);	
				$('#data_modal').html("Rp. "+uang(data_modal));
				
				
				shib_profit = Number(shib_profit) + Number(total_profit);
				data_profit = Number(shib_profit) * Number(idr);
				data_profit = Number(data_profit).toFixed(0);
				$('#data_profit').html("Rp. "+uang(data_profit));
				
				shib_close = Number(shib_close) + Number(last_shiba);
				data_close = Number(shib_close) * Number(idr);
				data_close = Number(data_close).toFixed(0);
				$('#data_close').html("Rp. "+uang(data_close));
				
 
				$('.secret_'+id_user).html((secret));
				$('.percent_'+id_user).html((percent)+"%");
				$('.percent_lose_'+id_user).html((percent_lose)+"%");
				$('.total_shiba_'+id_user).html(Number(total_shiba).toFixed(4));
				$('.total_lot_'+id_user).html(Number(total_lot).toFixed(2)+" LOT");
				
				$('.total_profit_'+id_user).html(Number(total_profit).toFixed(4) );
				$('.total_profit_'+id_user).append("<br>Rp. "+(Number(total_profit) * Number(idr)).toFixed(0) );
				
				$('.last_shiba_'+id_user).html(Number(last_shiba).toFixed(4));
				$('.percent_profit_'+id_user).html(Number(percent_profit).toFixed(2)+"%");
				
				if(Number(percent_profit) > 0){
					$('.percent_profit_'+id_user).removeClass('text-danger');
					$('.percent_profit_'+id_user).addClass('text-success');
					
					$('.total_profit_'+id_user).removeClass('text-danger');
					$('.total_profit_'+id_user).addClass('text-success');
					
					
				} else {
					$('.percent_profit_'+id_user).addClass('text-danger');
					$('.percent_profit_'+id_user).removeClass('text-success');
				
					$('.total_profit_'+id_user).addClass('text-danger');
					$('.total_profit_'+id_user).removeClass('text-success');
				}
				
			});
		}
		
		wait = false;
	} else {
		console.log('empty data');
		wait = false;
	}
	});
}

	
		
}, 1000);




</script>