<?php 
if(isset($_POST['konfirmasi'])){
	$id = in($_POST['id']);	
	
	$table = "deposit";
	$sql = "id='$id' and status ='Waiting Payments' and status_bukti='Checked'  ";
	$row = $this->model->row($table,$sql);
	if($row >= 1){
		$dd = $this->model->get_obj($table,$sql)[0];
		$total_rfc = $dd->total_rfc; 
		$id_user = $dd->id_user;
		$id_copy = $dd->id_copy;
		$earn = $dd->earn; 
		
		$alert = "success";
		$respon = "Success Confirm Deposit ";
		$this->db->query("UPDATE deposit SET `status`='Accept',`status_bukti`='Accept' where id='$id'  ");
		 
		if($dd->type == "rfc"){
			$this->db->query("UPDATE user SET `bet`=`bet`+ $total_rfc    where id='$id_user'  ");
		}
		
		if($dd->type == "usdt"){
			if($id_copy >= 1){
				$this->db->query("UPDATE copy_data SET `status`='Running' WHERE id='$id_copy'  ");
			} else { 
				if($earn == "No"){
					$this->db->query("UPDATE user SET `usdt`=`usdt`+ $total_rfc    where id='$id_user'  ");
				} else {
					$total_max = $total_rfc * 3; 
					$potongan = ($total_rfc * $settings->earn_potongan) / 100; 
					$usdt_earn_deposit = $total_rfc - $potongan; 											
					
					$this->db->query("UPDATE user SET `earn_total_profit`=0, `usdt_earn_deposit`=`usdt_earn_deposit`+ $total_rfc ,`earn_withdraw`='0',`earn_last_deposit`='$total_rfc'  where id='$id_user'  ");
					$this->db->query("UPDATE settings SET `earn_deposit`=`earn_deposit` + $usdt_earn_deposit ");
					$this->db->query("UPDATE user SET `usdt_earn_max`='$total_max' WHERE $total_max >= `usdt_earn_max` and id='$id_user'    ");
		
					$table = "earn_level";
					$sql = " min_deposit <= $total_rfc ORDER BY profit DESC LIMIT 1; ";
					$row = $this->model->row($table,$sql);
					if($row >= 1){
						$dd = $this->model->get_obj($table,$sql)[0];
						$detik = $dd->time;
						$profit = $dd->profit; 
						$this->db->query("UPDATE user SET `earn_sisa_waktu`=$detik  , `earn_waktu_profit`='$profit',`earn_waktu_dasar`='$detik'  WHERE id='$id_user'   ");

					} 
					
					
					

				} 
			}
		}
		
		
		
		if($dd->type == "shiba"){
			 
			$order_shiba = $dd->total_rfc;
			$order_idr = $dd->total; 
			$order_type = $dd->order_type;
			$order_percent = $dd->order_percent;
			$order_code= $dd->order_code;
			
			
			$this->db->query("update investor_history SET `status`='Order' WHERE code='$order_code'  ");
			
			 
		}
		
		
		
	} 
} 



if(isset($_POST['reject'])){
	$id = in($_POST['id']);
	$row = $this->model->row("deposit","id='$id' and status='Waiting Payments' and status_bukti='Checked' ");
	if($row >= 1){
		$alert = "danger";
		$respon = "Success Rejected Withdrawal ";
		$this->db->query("UPDATE deposit SET `status_bukti`='Reject' where id='$id'  ");
	} 
} 

?>


<div class="container-fluid bg-light min-vh-100"> 

	<?php include("alert_form.php"); ?>
<div class="row">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 col-12 "> 
 
<div class="card ">
<div class="card-header bg-primary">
	<h5 class="m-0  text-light"> Deposit Request  </h5>  
</div>
<div class="card-body shadow-sm"> 
<div class="table-responsive">

	<table id="tables" class="table table-striped table-bordered">
		<thead>
		<tr>
			<th> Date</th>
			<th> Secret ID </th>
			<th> Total Crypto </th>
			<th> Total </th>
			
			<th> Bank /Wallet </th>
			<th> Evidence </th>
			<th> Action </th>  
		</tr>
		</thead>
	</table> 
	</div>
	</div>
</div>


</div>
</div>
</div>




<script>  
site ="<?php echo($site) ?>";

var tablex = $('#tables').dataTable( {
 "bProcessing": true,
 "bServerSide": true,  
 "order" : [[0, 'desc']],
    "ajax" : { 
        url:  site+"server_master/deposit_new.php", 
        type:"POST"
    } ,
	
 "aoColumns": [
		
	null,
	null,
	{ "mclass":"wall", "mData": "2", "mRender": function ( data, type, full ) {
		return uang(data , 0)+ " "+full[7];
	}},
	{ "mclass":"wall", "mData": "3", "mRender": function ( data, type, full ) {
		return full[8]+" "+uang(data , 0);
	}},
	null,
{ "mclass":"wall", "mData": "5", "mRender": function ( data, type, full ) {
		if(data){
			
			var url_img = site;
			if(full[7] == "shiba"){
				url_img = "https://relandice.site/desain/";
			} 
			  
			imgx = "showimg('"+url_img+"/image/"+data+"')";
			img = '<img src="'+url_img+'/image/'+data+'" onclick="'+imgx+'"  style="height: 30px;"  />';
			return img; 
		} else {
			return "Tidak Ada";
		}
	}},
	{ "mclass":"wall", "mData": "6", "mRender": function ( data, type, full ) {
		del="showrej('"+data+"','Hapus Data "+full[0]+"')"; 
		conf="showconf('"+data+"','Konfirmasi Deposit Ini "+(full[0])+"')";  
		div = '';
		div += '<div class="dropdown" > <button onclick="$(\'#dropdown_menu_'+data+'\').slideToggle()" class="btn btn-sm btn-primary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Option </button>';
		div += '<div class="dropdown-menu" style="right:0px!Important; left:auto"   id="dropdown_menu_'+data+'" aria-labelledby="dropdownMenuButton">';
		div += '<a class="dropdown-item"  style="cursor:pointer !important;"  onclick="'+del+'">Tolak Permintaan</a>'; 
		div += '<a class="dropdown-item"  style="cursor:pointer !important;"  onclick="'+conf+'">Selesai</a>';    
		div += '</div>';
		div += '</div>';
		return div;
		
	}},
	
	
	
	
 ]
 } );
   
 


</script> 
