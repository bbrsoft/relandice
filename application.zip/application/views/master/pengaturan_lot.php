<?php 
 
$this->db->query("UPDATE investor_history SET `total_lot`=`total_shiba`/$price_lot WHERE type <>'Sell' and (`status`='Order' or `status`='Processing' ) ");



?>