<?php  
$row = $this->model->row('settings'," id<>-1 ");
if($row >= 1){
	$settings = $this->model->get_obj('settings'," id<>-1 ")[0];
} else {
	echo("Terjadi Kesalahan Website ") ; 
	exit();
}

if(isset($_POST['edit'])){ 

	$client = in($_POST['client']);
	$secret = in($_POST['secret']);

	$client_qris = in($_POST['client_qris']);
	$secret_qris = in($_POST['secret_qris']);
	 
	
	$this->db->query("UPDATE settings SET 
	`secret`='$secret' , `client`='$client'  
	,`secret_qris`='$secret_qris' , `client_qris`='$client_qris'  
	
	");
	
	

	$alert = "success";
	$respon = "Berhasil Memperbaharui API ";
	
	$table = "settings";
	$sql = "`id`<>-1";
	$row = $this->model->row($table,$sql);
	if($row >= 1){
		$settings = $this->model->get_obj($table,$sql)[0];
	} 
} 





?>

<div class="container-fluid">
<div class="row">
	<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 col-12 ">
		
		<div class="card">
			<div class="card-header">
				<div class="">
				<h4>Pengtaturan API </h4>
					
				<form method="post" enctype="multipart/form-data"> 
				<button class="btn btn-danger btn-sm" name="clear_profit" onSubmit="return confirm('Anda yakin ingin membersihkan profit bot ?');" > Clear Profit Bot </button> </h4> 
				</form>
				
			
				</div>	
			</div>
			<div class="card-body">
				<form method="post"  enctype="multipart/form-data"> 
					<?php include("alert_form.php"); ?>
					 
					<span>API Secret (VA & DANA) </span> 
					<input type="text" required class="form-control" step="" name="secret" value="<?php echo($settings->secret) ;  ?>" placeholder=""    />
					<br />
									
					<span>API Client (VA & DANA) </span> 
					<input type="text" required class="form-control" step="" name="client" value="<?php echo($settings->client) ;  ?>" placeholder=""    />
					<br />
					<hr>
					
					<span>API Secret (QRIS) </span> 
					<input type="text" required class="form-control" step="" name="secret_qris" value="<?php echo($settings->secret_qris) ;  ?>" placeholder=""    />
					<br />
									
					<span>API Client (QRIS) </span> 
					<input type="text" required class="form-control" step="" name="client_qris" value="<?php echo($settings->client_qris) ;  ?>" placeholder=""    />
					<br />
					
					
					<button name="edit" type="submit" class="btn btn-primary" >Edit Website</button>  
				</form>
			</div>
		</div>
</div> 
</div> 


 
			 