<?php  
$row = $this->model->row('settings'," id<>-1 ");
if($row >= 1){
	$settings = $this->model->get_obj('settings'," id<>-1 ")[0];
} else {
	echo("Terjadi Kesalahan Website ") ; 
	exit();
}

if(isset($_POST['edit'])){ 
	$nama = in($_POST['nama']);
	$deskripsi = in($_POST['deskripsi']); 
	$facebook = in($_POST['facebook']);
	$telegram = in($_POST['telegram']);
	$email = in($_POST['email']);
	$win_percent = in($_POST['win_percent']);
	$lose_percent = in($_POST['lose_percent']);
	$ref_bonus = in($_POST['ref_bonus']);
	//$ref_second = in($_POST['ref_second']);
	$price_lot = in($_POST['price_lot']);
	$fee_buy = in($_POST['fee_buy']);
	$fee_sell= in($_POST['fee_sell']);
	$wallet_usdt = in($_POST['wallet_usdt']);
	 
	$bagi_win = in($_POST['bagi_win']);
	$bagi_lose = in($_POST['bagi_lose']);
	$max_profit = in($_POST['max_profit']);
	$price_autobot = in($_POST['price_autobot']);

	  
	$idr = in($_POST['idr']);
	$usd = in($_POST['usd']);
	  
	  
	require_once("isset_image.php");
	
	$this->db->query("UPDATE settings SET `price_autobot`='$price_autobot' ,`max_profit`='$max_profit' , `bagi_lose`='$bagi_lose' 
	,`bagi_win`='$bagi_win' , `wallet_usdt`='$wallet_usdt' ,  `nama`='$nama' 
	, `deskripsi`='$deskripsi', `facebook`='$facebook',
	`telegram`='$telegram', `email`='$email' , `lose_percent`='$lose_percent', `fee_buy`='$fee_buy', `fee_sell`='$fee_sell',
	`win_percent`='$win_percent'  , `ref_bonus`='$ref_bonus' ,   `price_lot`='$price_lot' 
	");
	
	
	$this->db->query("UPDATE crypto SET `idr`='$idr', `usd`='$usd' where nama='rfc' ");
	if(!empty($image2)){ $this->db->query("UPDATE settings SET `favicon`='$image2' "); } 
	
		 
	
	
	$this->db->query("UPDATE investor_history SET `total_lot`=`total_shiba` / $price_lot  WHERE type <>'Sell' and (`status`='Order' or `status`='Processing' ) ");
	$this->db->query("UPDATE investor_history SET `percent`='$max_profit',`target`= (`total_shiba` * $max_profit) / 100   WHERE type <>'Sell' and (`status`='Order' or `status`='Processing' ) and `percent` > '$max_profit' ");

	

	$alert = "success";
	$respon = "Berhasil Memperbaharui Website ";
	
	$table = "settings";
	$sql = "`id`<>-1";
	$row = $this->model->row($table,$sql);
	if($row >= 1){
		$settings = $this->model->get_obj($table,$sql)[0];
	} 
} 

$table = "crypto";
$sql = "`nama`='rfc'";
$row = $this->model->row($table,$sql);
if($row >= 1){
	$crypto = $this->model->get_obj($table,$sql)[0];	
} 

if(isset($_POST['clear_profit'])){

	$this->db->query("DELETE FROM profit_user ");
$alert = "success";
$respon = "Success Clear Profit Bot ";

} 


?>

<div class="container-fluid">
<div class="row">
	<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 col-12 ">
		
		<div class="card">
			<div class="card-header">
				<div class="">
				<h4>Pengtaturan Aplikasi/ Website </h4>
					
				<form method="post" enctype="multipart/form-data"> 
				<button class="btn btn-danger btn-sm" name="clear_profit" onSubmit="return confirm('Anda yakin ingin membersihkan profit bot ?');" > Clear Profit Bot </button> </h4> 
				</form>
				
			
				</div>	
			</div>
			<div class="card-body">
				<form method="post"  enctype="multipart/form-data"> 
					 <?php include("alert_form.php"); ?>
					<span> Nama Website </span> 
					<input type="text" required class="form-control" name="nama" value="<?php echo($settings->nama) ;  ?>" placeholder=""    />
					<br />
					<span> Description </span> 
					<textarea type="text" required class="form-control" name="deskripsi"  placeholder=""    /><?php echo html_entity_decode(htmlspecialchars_decode($settings->deskripsi)) ;  ?></textarea>
					<br /> 
					<span> Ubah Favicon</span> 
					<input type="file"  class="form-control" name="image2" placeholder=""    />
					<br />
					
					 
					
					<span> Facebook </span> 
					<input type="text" required class="form-control" name="facebook" value="<?php echo($settings->facebook) ;  ?>" placeholder=""    />
					<br />
					
					<span> Telegram </span> 
					<input type="text" required class="form-control" name="telegram" value="<?php echo($settings->telegram) ;  ?>" placeholder=""    />
					<br />
					 
					<span> Email </span> 
					<input type="text" required class="form-control" name="email" value="<?php echo($settings->email) ;  ?>" placeholder=""    />
					<br />
					
					<span> Percent Win </span> 
					<input type="number" required class="form-control" name="win_percent" value="<?php echo($settings->win_percent) ;  ?>" placeholder=""    />
					<br />
					<span> Percent Lose </span> 
					<input type="number" required class="form-control" name="lose_percent" value="<?php echo($settings->lose_percent) ;  ?>" placeholder=""    />
					<br />
					<span> RFC to RP </span> 
					<input type="number" required class="form-control"  step="0.000000000001"  name="idr" value="<?php echo($crypto->idr) ;  ?>"    />
					<br />
					<span> RFC to USD </span> 
					<input type="number" required class="form-control" step="0.000000000001" name="usd" value="<?php echo($crypto->usd) ;  ?>" placeholder=""    />
					<br />
					 
					<span> Bonus Referral  </span> 
					<input type="number" required class="form-control" step="0.000000000001" name="ref_bonus" value="<?php echo($settings->ref_bonus) ;  ?>" placeholder=""    />
					<br />
									
					<span> Price Per Lot  </span> 
					<input type="number" required class="form-control" step="" name="price_lot" value="<?php echo($settings->price_lot) ;  ?>" placeholder=""    />
					<br />
					<span> Fee Buy (%)  </span> 
					<input type="number" required class="form-control" step="" name="fee_buy" value="<?php echo($settings->fee_buy) ;  ?>" placeholder=""    />
					<br />
					<span> Fee Sell (%)  </span> 
					<input type="number" required class="form-control" step="" name="fee_sell" value="<?php echo($settings->fee_sell) ;  ?>" placeholder=""    />
					<br />
					<span> Wallet Deposit </span> 
					<input type="text" required class="form-control" step="" name="wallet_usdt" value="<?php echo($settings->wallet_usdt) ;  ?>" placeholder=""    />
					<br />
									 
					
					<span> Max Take Profit (%)  </span> 
					<input type="number" required class="form-control" step="" name="max_profit" value="<?php echo($settings->max_profit) ;  ?>" placeholder=""    />
					<br />
					
					<span> Dibagikan Ketika Win (%)  </span> 
					<input type="number" required class="form-control" step="" name="bagi_win" value="<?php echo($settings->bagi_win) ;  ?>" placeholder=""    />
					<br />
					<span> Dibagikan Ketika Lose (%)  </span> 
					<input type="number" required class="form-control" step="" name="bagi_lose" value="<?php echo($settings->bagi_lose) ;  ?>" placeholder=""    />
					<br />
										 
					<span> Price Autobot 1x / Month </span> 
					<input type="number" required class="form-control" step="" name="price_autobot" value="<?php echo($settings->price_autobot) ;  ?>" placeholder=""    />
					<br />
					 
					<button name="edit" type="submit" class="btn btn-primary" >Edit Website</button>  
				</form>
			</div>
		</div>
</div> 
</div> 


 
			 