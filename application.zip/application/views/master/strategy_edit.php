<?php 
$table = "strategy";
$sql = "`id`='$id'";
$row = $this->model->row($table,$sql);
if($row >= 1){
	$data = $this->model->get_obj($table,$sql)[0];
	




if(isset($_POST['new'])){
	$nama = in($_POST['nama']);
	$row = $this->model->row("strategy","nama='$nama' and id<>'$id'");
	if($row >= 1){
		$alert = "danger";
		$respon = "Maaf. Data ini sudah ada sebelumnya ";
	} else {
		
		$this->db->query("UPDATE strategy SET `nama`='$nama' WHERE id='$id'  ");
		
		?> 
		<script>  document.location.href="<?php echo($site) ?>baim/strategy";   </script>  
		<?php
		
	}
} 
?>
<div class="container-fluid bg-light min-vh-100"> 
<?php include("alert_form.php"); ?>
<div class="row">
<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 col-12  ">
	<div class="card ">
<div class="card-header bg-primary">
	<h5 class="m-0  text-light">Edit Strategy </h5>  
</div>
<div class="card-body shadow-sm">
<form method="post" enctype="multipart/form-data"> 
		
		<span> Strategy </span> 
		<input type="text" required class="form-control" name="nama" value="<?php echo($data->nama) ;  ?>" placeholder=""    />
		<br />
		
		 
				<div class="flex-center flex-border">
					<select id="rule" class="width-100">
						<option value="Random">Random</option>
						<option value="over" selected>Hi</option>
						<option value="under">Low</option>
					</select><span>&nbsp;Hi / Low after</span>
					<input type="number" class="width-60"  value="0"   onkeyup="check_low_after(this.value)"  id="rule_change_at" ><span>bets</span>
				</div>
				
				<script>  
					function check_low_after(val){
						$('#rule_change_at').val(val);
						$('#high_low_after_bet').val(val); 
					} 
					
					$('#rule').on('change',function(){
						rule_now = $(this).val();
						if(rule_now == "Random"){ 
							$('#rule_change_at').val('0');
							$('#high_low_after_bet').val('0');
							$('#high_low_after_win').val('0');
							$('#rule_change_at').attr('disabled','true');
							$('#high_low_after_bet').attr('disabled','true');
							$('#high_low_after_win').attr('disabled','true');							
						} else{
							$('#rule_change_at').removeAttr('disabled');
							$('#high_low_after_bet').removeAttr('disabled');
							$('#high_low_after_win').removeAttr('disabled');
						}
					})
				</script> 
				
				<div class="flex-center flex-border">
					<span>&nbsp;Hi / Low after</span> 
					<input type="number" id="high_low_after_bet"  onkeyup="check_low_after(this.value)"  class="width-60" value="0">
					<span>bets</span>
					
					<input type="number" id="high_low_after_win"     class="width-60" value="0">
					<span>win</span>
				</div>
				
				
				<div class="flex-center">
					<div class="d-flex align-items-center">
						<input type="checkbox" id="ganda_check"  value="ganda_check"   class="mb-0 mt-0">
						<label class="mb-0 mt-0" for="ganda_check">Constant Divider</label>
					</div>
					<input type="number" class="width-40 text-center" value="1"><span>from balance&nbsp;</span>
				</div>
				
				
				
				<div class="flex-center flex-border pt-0 d-none"><span>Bet ammount 0.00000001 Doge</span></div>
				
				<div class="flex-center">
					<span>If win</span>
					<input type="number" id="ganda_win"    class="width-40 text-center" value="1">
					
					<span>If lose</span>
					<input type="number" id="ganda_lose"   class="width-40 text-center" value="2">
				</div>
				
				<div class="flex-center">
					<div class="d-flex align-items-center">
						<input type="checkbox"  id="check_win_streak" class="mb-0 mt-0" >
						<label class="mb-0 mt-0" for="check_win_streak">Reset if win</label>
					</div>
					<input type="number" id="reset_win_streak"    class="width-40 text-center" value="1">
					<span>bets</span>
				</div>
				
				
				
				<div class="flex-center flex-border pt-0">
					<div class="d-flex align-items-center">
						<input type="checkbox" id="check_lose_streak" class="mb-0 mt-0">
						<label class="mb-0 mt-0" for="check_lose_streak">Reset if lose</label>
					</div>
					<input type="number" id="reset_lose_streak"   class="width-40 text-center" value="1">
					<span>bets</span>
				</div>
				
				 
				
				<div class="">
				<div class="flex-center">
					<div class="d-flex align-items-center">
						<input type="checkbox"  id="check_max_win_streak" class="mb-0 mt-0" >
						<label class="mb-0 mt-0" for="check_max_win_streak">Reset if winstreak</label>
					</div>
					<input type="number" id="max_win_streak"    class="width-40 text-center" value="1">
					<span>bets</span>
				</div>
				<div class="flex-center flex-border pt-0">
					<div class="d-flex align-items-center">
						<input type="checkbox" id="check_max_lose_streak" class="mb-0 mt-0">
						<label class="mb-0 mt-0" for="check_max_lose_streak">Reset if losestreak</label>
					</div>
					<input type="number" id="max_lose_streak"   class="width-40 text-center" value="1">
					<span>bets</span>
				</div>
				</div>
				
				
				
				
				
				
				
				
				
				<div class="flex-center flex-border">
					<span>Reset Bet At Up</span>
					<input type="number" id="balance_up"   class="width-130 text-center" value="0">
						<div class="d-flex align-items-center">
						<input type="checkbox" id="balance_up_check"  value="balance_up_check"   class="mb-0 mt-0">
						<label class="mb-0 mt-0" for="balance_up_check">active</label>
					</div>
				</div>
				
				<div class="flex-center flex-border">
					<span>Max Bet</span>
					<input type="number" id="max_bet"   class="width-130 text-center" value="0">
						<div class="d-flex align-items-center">
						<input type="checkbox" id="max_bet_check"  value="max_bet_check"   class="mb-0 mt-0">
						<label class="mb-0 mt-0" for="max_bet_check">stop</label>
					</div>
				</div>
				
				
				<div class="flex-center flex-border">
					<span>If Balance</span>
					<input type="number" id="max_balance"    class="width-130 text-center" value="0">
					<div class="d-flex align-items-center">
						<input type="checkbox" id="max_balance_check"  value="max_balance_check"   class="mb-0 mt-0">
						<label class="mb-0 mt-0" for="max_balance_check" >stop</label>
					</div>
				</div>
				
				
				
				
				<div class="flex-center flex-border">
					<span>If Profit</span>
					<input type="number" id="max_profit"    class="width-130 text-center" value="0">
					<div class="d-flex align-items-center">
						<input type="checkbox" id="max_profit_check"  value="max_profit_check"   class="mb-0 mt-0">
						<label class="mb-0 mt-0" for="max_profit_check">stop</label>
					</div>
				</div>
				
				<div class="flex-center flex-border">
					<span>If Show Number</span>
					<input type="number" id="show_number"    style="width : 80px!important;"  class="width-130 text-center" value="0">
					<div class="">
					
					
					<div class="d-flex align-items-center">
						<input type="checkbox" id="show_number_check"  class="mb-0 mt-0">
						<label class="mb-0 mt-0" for="show_number_check">active stop on win </label>
					</div>
					
					<div class="d-flex align-items-center">
						<input type="checkbox" id="show_number_check_reset"  class="mb-0 mt-0">
						<label class="mb-0 mt-0" for="show_number_check_reset">active reset bet</label>
					</div>
					
					</div>
					
				</div>
				 
				
				<div class="flex-center flex-border">
					<input type="number" class="width-130 text-center" value="0" id="profit_target">
					<div class="d-flex align-items-center">
						<input type="checkbox" id="check_reset_target" class="mb-0 mt-0">
						<label class="mb-0 mt-0" for="check_reset_target">reset to base bet if profit</label>
					</div>
				</div> 
					
				 
				<div class="flex-center  ">
					<div class="d-flex align-items-center"> 
						<input type="checkbox" id="losetreak_max_check" class="mb-0 mt-0">
						<label class="mb-0 mt-0" for="losetreak_max_check">x<input type="number" id="losetreak_x" class="width-40 text-center" value="4" > total losses at lose </label>
					</div>	
					<input type="number" id="losetreak_max" class="width-40 text-center" value="0" > <span> times</span> 
				</div>
				
				<div class="flex-center flex-border">
					<div class="d-flex align-items-center">
						<label class="mb-0 mt-0" >Using Chance</label>
					</div>
					<input type="number" class="width-130 text-center" value="0" id="losetreak_chance">
				</div>
				  
				 
				<div class="flex-center flex-border">
					<div class="d-flex align-items-center">
						<input type="checkbox" id="auto_reset"   class="mb-0 mt-0">
						<label class="mb-0 mt-0" for="auto_reset">Auto Restart After Error/Disconnect </label>
					</div> 
				</div> 
					
				  	
				
		<button type="submit" name="new" class="btn btn-primary" >Edit Data</button> 
		
</form>
</div>
</div>
	
	
</div>
</div>
</div>



<?php } ?>
 