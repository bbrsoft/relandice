<div class="container-fluid bg-light min-vh-100">
<?php include("alert_form.php"); ?>
<!--  Row 1 -->
<div class="row">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 col-12 ">
 
<div class="card ">
<div class="card-header bg-primary">
	<h5 class="m-0  text-light"> Copy Trade - History</h5>  
</div>
<div class="card-body shadow-sm">
 
	<div class="table-responsive">
	<table id="tables" class="table table-striped table-bordered">
		<thead>
		<tr>
			<th> Tanggal </th>
			<th> User ID  </th> 
			<th> Total </th> 
			<th> Status </th>
			<th> Percent </th>
			<th> Profit </th>
		</tr>
		</thead>
		</table> 
	
	</div>
	

</div>
</div>


</div>
</div>
</div>





<script>  
site ="<?php echo($site) ?>";

var tablex = $('#tables').dataTable( {
 "bProcessing": true,
 "bServerSide": true,  
 "order" : [[0, 'desc']],
    "ajax" : { 
        url:  site+"server_master/copy_trade_history.php", 
        type:"POST"
    } ,
	
 "aoColumns": [
		// date_start','secret','total','percent','status','total_profit','id');

	null,
	null,
	{ "mclass":"wall", "mData": "2", "mRender": function ( data, type, full ) {
		data = Number(data).toFixed(0);
		
		return uang(data , 0) ;
	}},
	{ "mclass":"wall", "mData": "3", "mRender": function ( data, type, full ) {
		if(data >= 0){
			return '<span class="text-success"> '+data+'%</span> ';
		} else {
			return '<span class="text-danger"> '+data+'%</span> ';
		}
	}},
	null,
	{ "mclass":"wall", "mData": "5", "mRender": function ( data, type, full ) {
		if(full[3] >= 0){
			return '<span class="text-success"> '+uang(data,0)+'</span> ';
		} else {
			return '<span class="text-danger"> '+uang(data,0)+'</span> ';
		}
	}},
 
	
	
	
 ]
 } );
   
 


</script> 
