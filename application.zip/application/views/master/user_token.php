<?php 
if(isset($_POST['delete'])){
	$id = in($_POST['id']);
	$this->db->query("DELETE FROM user WHERE id='$id' ");
	$alert = "success";
	$respon = "Berhasil Menghapus User "; 
}  
?>

<div class="container-fluid bg-light min-vh-100"> 
<div class="row">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 col-12 ">
 
<div class="card ">
<div class="card-header bg-primary">
	<h5 class="m-0  text-light"> Data Pengguna Menggunakan Token </h5>  
</div>
<div class="card-body shadow-sm">

	<?php include("alert_form.php"); ?>
	<table id="tables" class="table table-striped table-bordered">
		<thead>
		<tr>
			<th  style="min-width : 100px" > Datetime </th>
			<th> Token </th>  
		</tr>
		</thead>
	</table> 
	</div>
</div>


</div>
</div>
</div>




<script>  
site ="<?php echo($site) ?>";

var tablex = $('#tables').dataTable( {
 "bProcessing": true,
 "bServerSide": true,  
 "order" : [[0, 'desc']],
    "ajax" : { 
        url:  site+"server_master/user_token.php", 
        type:"POST"
    } ,
	
 "aoColumns": [
 
 
	null,
		{ "mclass":"wall", "mData": "1", "mRender": function ( data, type, full ) {
			return '<div class=""  style="white-space: normal;word-break: break-word;" > '+data+ '</div>';
		}},
	
	
 ]
 } );
   
 


</script> 
