<style>
	.modal .close{
		color:black!important;
		border:0px!important;
		background: transparent!important;
	}

	.alert{
		position:relative;
	}
	.close{
		position:absolute; right:10px; top:0px;
		font-size : 22px; font-weight : bold; color:white!Important;
	}
	
	
	.dataTables_wrapper,
	.dataTables_wrapper
	table{
		width : 100%!important;
		padding:0px!Important;
	}

	.card-body{
		padding:1rem!important;
	}
	
	.card-header{
		padding-left:1rem!important;
		padding-right:1rem!important;
	}
	
	
</style>

