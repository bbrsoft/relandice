<?php 
if(isset($_POST['delete'])){
	$id = in($_POST['id']);
	$this->db->query("DELETE FROM user WHERE id='$id' ");
	$alert = "success";
	$respon = "Berhasil Menghapus User "; 
}  
?>


<div class="container-fluid bg-light min-vh-100">  
<div class="row">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 col-12 "> 
 
<div class="card ">
<div class="card-header bg-primary">
	<h5 class="m-0  text-light"> Data Pengguna Menggunakan Secret </h5>  
</div>
<div class="card-body shadow-sm">

	<?php include("alert_form.php"); ?>
	<div class="table-responsive">
	<table id="tables" class="table table-striped table-bordered">
		<thead>
		<tr>
			<th  style="min-width : 100px" > Secret </th>
			<th  style="min-width : 100px" > Bet </th>
			<th  style="min-width : 100px" > Saldo Profit </th>
			
			<th  style="min-width : 100px" > Total Deposit </th>
			<th  style="min-width : 100px" > Total Withdraw </th>
			<th  style="min-width : 100px" > Max Profit </th> 
			
		</tr>
		</thead>
	</table> 
	</div>
	</div>
</div>


</div>
</div>
</div>




<script>  
site ="<?php echo($site) ?>";

var tablex = $('#tables').dataTable( {
 "bProcessing": true,
 "bServerSide": true,  
 "order" : [[0, 'desc']],
    "ajax" : { 
         url:  site+"server_master/user_earn.php", 
        type:"POST"
    } ,
	
 "aoColumns": [
 
	{ "mclass":"wall", "mData": "0", "mRender": function ( data, type, full ) { return  data; }},
	{ "mclass":"wall", "mData": "1", "mRender": function ( data, type, full ) { return  data; }},
	{ "mclass":"wall", "mData": "2", "mRender": function ( data, type, full ) { return  data; }},
	{ "mclass":"wall", "mData": "3", "mRender": function ( data, type, full ) { return  data; }},
	{ "mclass":"wall", "mData": "4", "mRender": function ( data, type, full ) { return  data; }},
	{ "mclass":"wall", "mData": "5", "mRender": function ( data, type, full ) { return  data; }},
	
	
 ]
 } );
   
 


</script> 
