<?php 
$client = $settings->client;
$secret = $settings->secret;
$status = "";
$url_api = "https://api.onebrick.io";


$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url_api.'/v2/payments/auth/token');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');

curl_setopt($ch, CURLOPT_USERPWD, $client . ':' . $secret);

$result = curl_exec($ch); 
curl_close($ch);   


 
if(!empty($result)){
	$obj = json_decode($result);
	$token = $obj->data->accessToken;
	
	
	if(!empty($token)){
		 
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url_api.'/v2/payments/gs/ledger?page=1&size=100&startDate=2024-08-20&endDate=2024-08-20&status=completed');
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);  
		$headers = array();
		$headers[] = 'Publicaccesstoken: Bearer '.$token;
		$headers[] = 'Content-Type: application/json';
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		$result = curl_exec($ch);
		curl_close($ch);
		
		
		if(!empty($result)){

			
			$obj = json_decode($result);
			if($obj->status == "200"){
				
				print_r($obj);
			
			 
			 
			}
			 
		} 
	}
} 


 
	
?>

