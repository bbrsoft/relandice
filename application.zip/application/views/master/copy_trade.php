<?php if(isset($_POST['delete'])){
	$id = in($_POST['id']);
	$row = $this->model->row("copy_trade","id='$id'");
	if($row >= 1){
			
		$this->db->query("DELETE FROM copy_trade WHERE id='$id' ");
		$alert = "success";
		$respon = "Berhasil Menghapus Copy Trade ";
	} 
}  


if(isset($_POST['new'])){
	$nama = in($_POST['nama']);
	$secret = in($_POST['secret']);
	  
	
	$table = "copy_trade";
	$sql = "nama='$nama' and secret='$secret'   ";
	$row = $this->model->row($table,$sql);
	if($row >= 1){
		$alert = "danger";
		$respon = "Maaf. Data ini sudah ada sebelumnya ";
	} else {
		 
		$datax = array();
		$datax['nama'] = $nama;
		$datax['secret'] = $secret;
		$this->db->insert('copy_trade',$datax);
 
		$alert = "success";
		$respon = "Berhasil Memasukkan Data ";
	}
} 
 

?>

<?php include("alert.php"); ?>

<link rel="stylesheet" href="<?php echo($site) ?>assets/modules/datatables/datatables.min.css">
<link rel="stylesheet" href="<?php echo($site) ?>assets/modules/datatables/DataTables-1.10.16/css/dataTables.bootstrap4.min.css">
<link rel="stylesheet" href="<?php echo($site) ?>assets/modules/datatables/Select-1.2.4/css/select.bootstrap4.min.css">  


 <div class="container-fluid">
<div class="row"> 
	<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 col-12  ">
		
		<div class="card">
			<div class="card-header">
				<h4>Tambah Data </h4>
			</div>
			<div class="card-body">
				<form method="post" enctype="multipart/form-data"> 
				 
					<span> Nama </span> 
					<input type="text" required class="form-control" name="nama" value="" placeholder="Nama"    />
					<br />
					
					<span> Secret / Username </span> 
					<input type="text" required class="form-control" name="secret" value="" placeholder="Secret"    />
					<br />
					
					<button name="new" type="submit" class="btn btn-primary" > <i class="la la-ticket">  </i> Masukkan Data</button>
				</form>
			</div>
		</div>
	</div>
	
	
	
	<div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 col-12 ">
		<div class="card">
			<div class="card-header">
				<h4>Data Copy Trade  </h4>
			</div>
			<div class="card-body">
				<div class="table-responsive">
					<table id="tables" class="table table-striped">
						<thead>
						<tr>  			
							<th>Nama</th>					
							<th>Secret / Username </th>					
							<th>#</th>
						</tr>
						</thead>
					</table> 
				</div>
					
			</div>
		</div>	
	</div>
</div>
</div>

 
<script>  
site ="<?php echo($site) ?>";

var tablex = $('#tables').dataTable( {
 "bProcessing": true,
 "bServerSide": true,   
  
    "ajax" : { 
        url:  site+"server_master/copy_trade.php", 
        type:"POST"
    } ,
	
 "aoColumns": [ 
	null,  
	{ "mclass":"wall", "mData": "1", "mRender": function ( data, type, full ) {
		return '<div class=""  style="display:block;width : 350px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis" >'+data+'</div>'
	}},
	{ "mclass":"wall", "mData": "2", "mRender": function ( data, type, full ) {
		del="showdel('"+data+"','"+full[0]+"')";
		div = '';
		div += '<a class="btn btn-sm btn-danger"  style="cursor:pointer !important;"  onclick="'+del+'">Hapus</a>';
		div += '<a class="btn btn-sm btn-info"  style="cursor:pointer !important;"  href="'+site+'baim/copy_trade_edit/'+data+'" >Edit</a>';
		 
		return div;
		
	}},
	
	
 ]
 } );
 
 
 
function table_reload(){
	$('#tables').DataTable().ajax.reload(null, false);
}

 

</script> 

	

	


