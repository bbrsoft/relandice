<?php 
$table = "user";
$sql = "`id`='$id'";
$row = $this->model->row($table,$sql);
if($row >= 1){
$data = $this->model->get_obj($table,$sql)[0];



?><div class="container-fluid bg-light min-vh-100"> 
<div class="row">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 col-12 "> 
 
<div class="card ">
<div class="card-header bg-primary">
	<h5 class="m-0  text-light"> Withdrawal Finish - <?php echo($data->secret) ;  ?>  </h5>  
</div>
<div class="card-body shadow-sm">

	<?php include("alert_form.php"); ?>
	<table id="tables" class="table table-striped table-bordered">
		<thead>
		<tr>
			<th> Date</th>
			<th> Secret ID </th>
			<th> Total Shib </th>
			<th> Total </th>
			
			<th> Bank / Wallet </th>
			<th> With PG </th> 
		</tr>
		</thead>
	</table> 
	</div>
</div>


</div>
</div>
</div>




<script>  
site ="<?php echo($site) ?>";

var tablex = $('#tables').dataTable( {
 "bProcessing": true,
 "bServerSide": true,  
 "order" : [[0, 'desc']],
    "ajax" : { 
        url:  site+"server_master/user_withdraw.php?id_user=<?php echo($data->id) ;  ?>", 
        type:"POST"
    } ,
	
 "aoColumns": [
		//$aColumns = array('secret','total_shib','total_idr','bank','status','id','type_money','with_pg');
	null,
	null,
	null,
	
	{ "mclass":"wall", "mData": "3", "mRender": function ( data, type, full ) {
		return full[7]+" "+ data ;
	}},
	null,
	
	{ "mclass":"wall", "mData": "8", "mRender": function ( data, type, full ) {
		return data ;
	}},
	
	
 ]
 } );
   
 


</script> 


<?php } ?>