<?php 
if(isset($_POST['delete'])){
	$id = in($_POST['id']);
	$this->db->query("DELETE FROM user WHERE id='$id' ");
	$alert = "success";
	$respon = "Berhasil Menghapus User "; 
}  
?>


<div class="container-fluid bg-light min-vh-100">  
<div class="row">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 col-12 "> 
 
<div class="card ">
<div class="card-header bg-primary">
	<h5 class="m-0  text-light"> Data Pengguna Menggunakan Secret </h5>  
</div>
<div class="card-body shadow-sm">

	<?php include("alert_form.php"); ?>
	<table id="tables" class="table table-striped table-bordered">
		<thead>
		<tr>
			<th  style="min-width : 100px" > Datetime </th>
			<th  style="min-width : 100px" > Secret Login </th>
			<th  style="min-width : 100px" > Saldo </th>
			<th> Action </th>  
			
		</tr>
		</thead>
	</table> 
	</div>
</div>


</div>
</div>
</div>




<script>  
site ="<?php echo($site) ?>";

var tablex = $('#tables').dataTable( {
 "bProcessing": true,
 "bServerSide": true,  
 "order" : [[0, 'desc']],
    "ajax" : { 
        url:  site+"server_master/user_secret.php", 
        type:"POST"
    } ,
	
 "aoColumns": [
 
 
	null,
	{ "mclass":"wall", "mData": "1", "mRender": function ( data, type, full ) {
		return '<div class=""  style="white-space: normal;word-break: break-word;" > '+data+ '</div>';
	}},
	null,
	{ "mclass":"wall", "mData": "3", "mRender": function ( data, type, full ) {
		del="showdel('"+data+"','Hapus Data "+full[0]+"')"; 
		conf="showconf('"+data+"','Konfirmasi Deposit Ini "+(full[0])+"')";  
		
		div = '';
		div += '<div class="dropdown" > <button onclick="$(\'#dropdown_menu_'+data+'\').slideToggle()" class="btn btn-sm btn-primary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Option </button>';
		div += '<div class="dropdown-menu" style="right:0px!Important; left:auto"   id="dropdown_menu_'+data+'" aria-labelledby="dropdownMenuButton">';
		div += '<a class="dropdown-item"  style="cursor:pointer !important;"  onclick="'+del+'">Hapus User</a>'; 
		div += '<a class="dropdown-item"  style="cursor:pointer !important;" href="'+site+'baim/user_edit/'+data+'" >Edit User</a>';  
		
		div += '</div>';
		div += '</div>';
		return div;
		
	}},
	
	
	
	
 ]
 } );
   
 


</script> 
