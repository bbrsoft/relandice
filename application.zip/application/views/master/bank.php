<?php if(isset($_POST['delete'])){
	$id = in($_POST['id']);
	$row = $this->model->row("bank","id='$id'");
	if($row >= 1){
			
		$this->db->query("DELETE FROM bank WHERE id='$id' ");
		$alert = "success";
		$respon = "Berhasil Menghapus Data Bank ";
	} 
}  


if(isset($_POST['new'])){
	 
	$bank_nama = in($_POST['bank_nama']);
	$bank_rekening = in($_POST['bank_rekening']);
	$bank_jenis = in($_POST['bank_jenis']);
	 
	
	$table = "bank";
	$sql = "bank_rekening='$bank_rekening'   ";
	$row = $this->model->row($table,$sql);
	if($row >= 1){
		$alert = "danger";
		$respon = "Maaf. Data ini sudah ada sebelumnya ";
	} else {
		 
		$datax = array();
		$datax['bank_jenis'] = $bank_jenis ;
		$datax['bank_rekening'] = $bank_rekening ;
		$datax['bank_nama'] = $bank_nama ; 
 		$this->db->insert('bank',$datax);
 
		$alert = "success";
		$respon = "Berhasil Memperbaharui Data ";
	}
} 
 

?>

<?php include("alert.php"); ?>

<link rel="stylesheet" href="<?php echo($site) ?>assets/modules/datatables/datatables.min.css">
<link rel="stylesheet" href="<?php echo($site) ?>assets/modules/datatables/DataTables-1.10.16/css/dataTables.bootstrap4.min.css">
<link rel="stylesheet" href="<?php echo($site) ?>assets/modules/datatables/Select-1.2.4/css/select.bootstrap4.min.css">  


 <div class="container-fluid">
<div class="row"> 
	<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 col-12  ">
		
		<div class="card">
			<div class="card-header">
				<h4>Tambah Data Bank</h4>
			</div>
			<div class="card-body">
				<form method="post" enctype="multipart/form-data"> 
				 
					<span> Jenis Bank </span> 
					<input type="text" required class="form-control" name="bank_jenis" value="" placeholder="Jenis Bank"    />
					<br />
					
					<span> Nomor Rekening </span> 
					<input type="text" required class="form-control" name="bank_rekening" value="" placeholder="Nomor rekening "    />
					<br />
					<span> Atas Nama</span> 
					<input type="text" required class="form-control" name="bank_nama" value="" placeholder="Atas Nama"    />
					<br />
					
					<button name="new" type="submit" class="btn btn-primary" > <i class="la la-ticket">  </i> Masukkan Data</button>
				</form>
			</div>
		</div>
	</div>
	
	
	
	<div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 col-12 ">
		<div class="card">
			<div class="card-header">
				<h4>Data Bank  </h4>
			</div>
			<div class="card-body">
				<div class="table-responsive">
					<table id="tables" class="table table-striped">
						<thead>
						<tr>  			
							<th>Jenis Bank</th>					
							<th>AN </th>					
							<th>Nomor Rekening</th>				
							<th>#</th>
						</tr>
						</thead>
					</table> 
				</div>
					
			</div>
		</div>	
	</div>
</div>
</div>

 

<script>  
site ="<?php echo($site) ?>";

var tablex = $('#tables').dataTable( {
 "bProcessing": true,
 "bServerSide": true,   
  
    "ajax" : { 
        url:  site+"server_master/bank.php", 
        type:"POST"
    } ,
	
 "aoColumns": [ 
	null,  
	null,  
	null,  
	
	{ "mclass":"wall", "mData": "3", "mRender": function ( data, type, full ) {
		del="showdel('"+data+"','"+full[0]+"')";
		div = '';
		div += '<a class="btn btn-sm btn-danger"  style="cursor:pointer !important;"  onclick="'+del+'">Hapus</a>';
		div += '<a class="btn btn-sm btn-info"  style="cursor:pointer !important;"  href="'+site+'baim/bank-edit/'+data+'" >Edit</a>';
		 
		return div;
		
	}},
	
	
 ]
 } );
 
 
 
function table_reload(){
	$('#tables').DataTable().ajax.reload(null, false);
}

 

</script> 

	

	


