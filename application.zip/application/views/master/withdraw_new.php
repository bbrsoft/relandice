<?php 
if(isset($_POST['konfirmasi'])){
	$id = in($_POST['id']);	
	$row = $this->model->row("withdraw","id='$id' and status ='Waiting'  "); 
	if($row >= 1){
		$alert = "success";
		$respon = "Success Confirm Withdrawal ";
		$this->db->query("UPDATE withdraw SET `status`='Finish' where id='$id'  ");
	} 
} 


if(isset($_POST['reject'])){
	$id = in($_POST['id']);
	$row = $this->model->row("withdraw","id='$id' and status='Waiting'  ");
	if($row >= 1){
		$alert = "danger";
		$respon = "Success Rejected Withdrawal ";
		$this->db->query("UPDATE withdraw SET `status`='Reject' where id='$id'  ");
	} 
} 


$d = file_get_contents('https://relandice.site/cronjob/check_invest.php');


?>


<div class="container-fluid bg-light min-vh-100"> 

	<?php include("alert_form.php"); ?>
<div class="row">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 col-12 "> 
 
<div class="card ">
<div class="card-header bg-primary">
	<h5 class="m-0  text-light"> Withdraw Request  </h5>  
</div>
<div class="card-body shadow-sm"> 
<div class="table-responsive">

	<table id="tables" class="table table-striped table-bordered">
		<thead>
		<tr>
			<th> Secret ID </th> 
			<th> Withdraw Destination </th>
			<th> ID VA </th>
			<th> Action </th>  
		</tr>
		</thead>
	</table> 
	</div>
	</div>
</div>


</div>
</div>
</div>




<script>  
site ="<?php echo($site) ?>";

var tablex = $('#tables').dataTable( {
 "bProcessing": true,
 "bServerSide": true,  
 "order" : [[3, 'desc']],
    "ajax" : { 
        url:  site+"server_master/withdraw_new.php", 
        type:"POST"
    } ,
	
 "aoColumns": [
		 
	null, 
	{ "mclass":"wall", "mData": "2", "mRender": function ( data, type, full ) {
		return full[1]+"<br />"+data; 	
	}},
	{ "mclass":"wall", "mData": "3", "mRender": function ( data, type, full ) {
		dx = '';
		if((data != "") && (data != null)){
			dx = "BRICK PROCCESS";
		}else {
			dx = "-";
		}
		
		if((full[5] != "") & (full[5] != null)){
			dx += '<br /><small class="text-danger"> '+full[5]+' - Brick Gagal Melakukan pengiriman (Perlu Tindakan Manual) </small>  ';
		} 
		return dx;
	}},
	
	{ "mclass":"wall", "mData": "4", "mRender": function ( data, type, full ) {
		del="showrej('"+data+"','Hapus Data "+full[0]+"')"; 
		conf="showconf('"+data+"','Konfirmasi Deposit Ini "+(full[0])+"')";  
		div = '';
		div += '<div class="dropdown" > <button onclick="$(\'#dropdown_menu_'+data+'\').slideToggle()" class="btn btn-sm btn-primary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Option </button>';
		div += '<div class="dropdown-menu" style="right:0px!Important; left:auto"   id="dropdown_menu_'+data+'" aria-labelledby="dropdownMenuButton">';
		div += '<a class="dropdown-item"  style="cursor:pointer !important;"  onclick="'+del+'">Tolak Permintaan</a>'; 
		div += '<a class="dropdown-item"  style="cursor:pointer !important;"  onclick="'+conf+'">Selesai</a>';    
		div += '</div>';
		div += '</div>';
		return div;
		
	}},
	
	
	
	
 ]
 } );
   
 


</script> 
