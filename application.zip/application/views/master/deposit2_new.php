<?php 
if(isset($_POST['konfirmasi'])){
	$id = in($_POST['id']);	
	
	$table = "1x_api";
	$sql = "id='$id' and active ='Waiting Payments' and evidence_status='Checked'  ";
	$row = $this->model->row($table,$sql);
	if($row >= 1){
		$dd = $this->model->get_obj($table,$sql)[0];
		$month = $dd->month; 
		$id_user = $dd->id_user;
		$now = date('Y-m-d');
		
		$expired =  date('Y-m-d',strtotime($now . " +".$month." month"));
		$this->db->query("UPDATE 1x_api SET `active`='Yes',`evidence_status`='Accept',`expired`='$expired' where id='$id'  ");
		
		
	} 
}  






if(isset($_POST['reject'])){
	$id = in($_POST['id']);
	$row = $this->model->row("1x_api","id='$id' and active='Waiting Payments' and evidence_status='Checked' ");
	if($row >= 1){
		$alert = "danger";
		$respon = "Success Rejected Withdrawal ";
		$this->db->query("UPDATE 1x_api SET `evidence_status`='Reject' where id='$id'  ");
	} 
} 

?>


<div class="container-fluid bg-light min-vh-100"> 

	<?php include("alert_form.php"); ?>
<div class="row">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 col-12 "> 
 
<div class="card ">
<div class="card-header bg-primary">
	<h5 class="m-0  text-light"> Deposit 1x Request  </h5>  
</div>
<div class="card-body shadow-sm"> 
<div class="table-responsive">

	<table id="tables" class="table table-striped table-bordered">
		<thead>
		<tr> 
			<th> Secret ID </th>
			<th> Subscribe </th>
			
			<th> Total Payment </th>
			<th> Evidence </th>
			<th> Action </th>  
		</tr>
		</thead>
	</table> 
	</div>
	</div>
</div>


</div>
</div>
</div>




<script>  
site ="<?php echo($site) ?>";

var tablex = $('#tables').dataTable( {
 "bProcessing": true,
 "bServerSide": true,  
 "order" : [[0, 'desc']],
    "ajax" : { 
        url:  site+"server_master/deposit2_new.php", 
        type:"POST"
    } ,
	
 "aoColumns": [
		
	null,
	{ "mclass":"wall", "mData": "1", "mRender": function ( data, type, full ) {
		return data+" Month ";
	}},
	{ "mclass":"wall", "mData": "2", "mRender": function ( data, type, full ) {
		return uang(data , 0);
	}},
	 
{ "mclass":"wall", "mData": "3", "mRender": function ( data, type, full ) {
		if(data){
			
			url_img = "https://relandice.site/1x/";
			  
			imgx = "showimg('"+url_img+"/image/"+data+"')";
			img = '<img src="'+url_img+'/image/'+data+'" onclick="'+imgx+'"  style="height: 30px;"  />';
			return img; 
		} else {
			return "Tidak Ada";
		}
	}},
	
	{ "mclass":"wall", "mData": "4", "mRender": function ( data, type, full ) {
		del="showrej('"+data+"','Hapus Data "+full[0]+"')"; 
		conf="showconf('"+data+"','Konfirmasi Deposit Ini "+(full[0])+"')";  
		div = '';
		div += '<div class="dropdown" > <button onclick="$(\'#dropdown_menu_'+data+'\').slideToggle()" class="btn btn-sm btn-primary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Option </button>';
		div += '<div class="dropdown-menu" style="right:0px!Important; left:auto"   id="dropdown_menu_'+data+'" aria-labelledby="dropdownMenuButton">';
		div += '<a class="dropdown-item"  style="cursor:pointer !important;"  onclick="'+conf+'">Konfirmasi</a>';    
		div += '<a class="dropdown-item"  style="cursor:pointer !important;"  onclick="'+del+'">Tolak Permintaan</a>'; 
		div += '</div>';
		div += '</div>';
		return div;
		
	}},
	
	
	
	
 ]
 } );
   
 


</script> 
