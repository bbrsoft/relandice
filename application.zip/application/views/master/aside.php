
<aside class="left-sidebar">
<!-- Sidebar scroll-->
<div>
<div class="brand-logo d-flex align-items-center justify-content-between">
	<a href="<?php echo($site) ?>baim/home" class="text-nowrap logo-img"  style="font-size : 20px; color:black; font-weight : bold;" >
		<img src="<?php echo($site) ?>image/32.png" class="mr-2 d-inline-block" /> <?php echo($settings->nama) ;  ?>
	</a>
	<div class="close-btn d-xl-none d-block sidebartoggler cursor-pointer" id="sidebarCollapse">
	<i class="ti ti-x fs-8"></i>
	</div>
</div>
<!-- Sidebar navigation-->
<nav class="sidebar-nav scroll-sidebar" data-simplebar="">
<ul id="sidebarnav">
<li class="nav-small-cap"> <i class="ti ti-dots nav-small-cap-icon fs-4"></i> <span class="hide-menu">Home</span> </li>
<li class="sidebar-item"> <a class="sidebar-link" href="<?php echo($site) ?>baim/home" aria-expanded="false"> <span> <i class="ti ti-layout-dashboard"></i> </span> <span class="hide-menu">Dashboard</span> </a> </li>
<li class="sidebar-item"> <a class="sidebar-link" href="<?php echo($site) ?>baim/user_secret" aria-expanded="false"> <span> <i class="ti ti-users"></i> </span> <span class="hide-menu">Pengguna Secret</span> </a> </li>
<li class="sidebar-item"> <a class="sidebar-link" href="<?php echo($site) ?>baim/user_earning" aria-expanded="false"> <span> <i class="ti ti-users"></i> </span> <span class="hide-menu">Pengguna Earning</span> </a> </li>
<li class="sidebar-item"> <a class="sidebar-link" href="<?php echo($site) ?>baim/user_notibot" aria-expanded="false"> <span> <i class="ti ti-users"></i> </span> <span class="hide-menu">Pengguna NotiBot</span> </a> </li>
<li class="sidebar-item"> <a class="sidebar-link" href="<?php echo($site) ?>baim/user_active" aria-expanded="false"> <span> <i class="ti ti-users"></i> </span> <span class="hide-menu">Pengguna Aktif Buy</span> </a> </li>
<li class="sidebar-item"> <a class="sidebar-link" href="<?php echo($site) ?>baim/copy_invest" aria-expanded="false"> <span> <i class="ti ti-copy"></i> </span> <span class="hide-menu">Copy Trade Invests</span> </a> </li>
<li class="sidebar-item"> <a class="sidebar-link" href="<?php echo($site) ?>baim/copy_invest_history" aria-expanded="false"> <span> <i class="ti ti-history"></i> </span> <span class="hide-menu">Copy Trade History</span> </a> </li>

<li class="nav-small-cap"> <i class="ti ti-dots nav-small-cap-icon fs-4"></i> <span class="hide-menu">KYC</span> </li>   
<li class="sidebar-item"> <a class="sidebar-link" href="<?php echo($site) ?>baim/kyc_new" aria-expanded="false"> <span> <i class="ti ti-wallet"></i> </span> <span class="hide-menu">KYC Request</span> </a> </li>
<li class="sidebar-item"> <a class="sidebar-link" href="<?php echo($site) ?>baim/kyc_finish" aria-expanded="false"> <span> <i class="ti ti-check"></i> </span> <span class="hide-menu">KYC Approval</span> </a> </li>

<li class="nav-small-cap"> <i class="ti ti-dots nav-small-cap-icon fs-4"></i> <span class="hide-menu">Withdrawal</span> </li>   
<li class="sidebar-item"> <a class="sidebar-link" href="<?php echo($site) ?>baim/withdraw_new" aria-expanded="false"> <span> <i class="ti ti-wallet"></i> </span> <span class="hide-menu">Withdraw Request</span> </a> </li>
<li class="sidebar-item"> <a class="sidebar-link" href="<?php echo($site) ?>baim/withdraw_finish" aria-expanded="false"> <span> <i class="ti ti-check"></i> </span> <span class="hide-menu">Withdraw Finish</span> </a> </li>


<li class="nav-small-cap"> <i class="ti ti-dots nav-small-cap-icon fs-4"></i> <span class="hide-menu">Withdrawal Notibot</span> </li>   
<li class="sidebar-item"> <a class="sidebar-link" href="<?php echo($site) ?>baim/withdraw_new2" aria-expanded="false"> <span> <i class="ti ti-wallet"></i> </span> <span class="hide-menu">Withdraw Request</span> </a> </li>
<li class="sidebar-item"> <a class="sidebar-link" href="<?php echo($site) ?>baim/withdraw_finish2" aria-expanded="false"> <span> <i class="ti ti-check"></i> </span> <span class="hide-menu">Withdraw Finish</span> </a> </li>



<li class="nav-small-cap"> <i class="ti ti-dots nav-small-cap-icon fs-4"></i> <span class="hide-menu">Deposit</span> </li>   
<li class="sidebar-item"> <a class="sidebar-link" href="<?php echo($site) ?>baim/deposit_new" aria-expanded="false"> <span> <i class="ti ti-wallet"></i> </span> <span class="hide-menu">Deposit Request</span> </a> </li>
<li class="sidebar-item"> <a class="sidebar-link" href="<?php echo($site) ?>baim/deposit_finish" aria-expanded="false"> <span> <i class="ti ti-check"></i> </span> <span class="hide-menu">Deposit Finish</span> </a> </li>

<li class="nav-small-cap"> <i class="ti ti-dots nav-small-cap-icon fs-4"></i> <span class="hide-menu">Deposit 1x</span> </li>   
<li class="sidebar-item"> <a class="sidebar-link" href="<?php echo($site) ?>baim/deposit2_new" aria-expanded="false"> <span> <i class="ti ti-wallet"></i> </span> <span class="hide-menu">Deposit Request</span> </a> </li>
<li class="sidebar-item"> <a class="sidebar-link" href="<?php echo($site) ?>baim/deposit2_finish" aria-expanded="false"> <span> <i class="ti ti-check"></i> </span> <span class="hide-menu">Deposit Finish</span> </a> </li>

<li class="nav-small-cap"> <i class="ti ti-dots nav-small-cap-icon fs-4"></i> <span class="hide-menu">Copytrade</span> </li>   
<li class="sidebar-item"> <a class="sidebar-link" href="<?php echo($site) ?>baim/copy_bagihasil" aria-expanded="false"> <span> <i class="ti ti-history"></i> </span> <span class="hide-menu">History Bagi Hasil</span> </a> </li>

<li class="nav-small-cap"> <i class="ti ti-dots nav-small-cap-icon fs-4"></i> <span class="hide-menu">Earning</span> </li>   
<li class="sidebar-item"> <a class="sidebar-link" href="<?php echo($site) ?>baim/earning_level" aria-expanded="false"> <span> <i class="ti ti-history"></i> </span> <span class="hide-menu">Level Earning</span> </a> </li>


<li class="nav-small-cap"> <i class="ti ti-dots nav-small-cap-icon fs-4"></i> <span class="hide-menu">Pengaturan</span> </li>   
<li class="sidebar-item"> <a class="sidebar-link" href="<?php echo($site) ?>baim/strategy" aria-expanded="false"> <span> <i class="ti ti-link"></i> </span> <span class="hide-menu">Strategy</span> </a> </li>
<li class="sidebar-item"> <a class="sidebar-link" href="<?php echo($site) ?>baim/copy_plan" aria-expanded="false"> <span> <i class="ti ti-copy"></i> </span> <span class="hide-menu">Plan Copytrade</span> </a> </li> 
<li class="sidebar-item"> <a class="sidebar-link" href="<?php echo($site) ?>baim/copy_trade" aria-expanded="false"> <span> <i class="ti ti-copy"></i> </span> <span class="hide-menu">Copy Trade</span> </a> </li> 
<li class="sidebar-item"> <a class="sidebar-link" href="<?php echo($site) ?>baim/bc" aria-expanded="false"> <span> <i class="ti ti-settings"></i> </span> <span class="hide-menu">Buat SC Bcgame</span> </a> </li> 
<li class="sidebar-item"> <a class="sidebar-link" href="<?php echo($site) ?>baim/bank" aria-expanded="false"> <span> <i class="ti ti-settings"></i> </span> <span class="hide-menu">Pengaturan Bank</span> </a> </li> 
<li class="sidebar-item"> <a class="sidebar-link" href="<?php echo($site) ?>baim/pengaturan_wallet" aria-expanded="false"> <span> <i class="ti ti-settings"></i> </span> <span class="hide-menu">Pengaturan Wallet</span> </a> </li> 
<li class="sidebar-item"> <a class="sidebar-link" href="<?php echo($site) ?>baim/pengaturan_informasi" aria-expanded="false"> <span> <i class="ti ti-settings"></i> </span> <span class="hide-menu">Pengaturan Informasi</span> </a> </li> 
<li class="sidebar-item"> <a class="sidebar-link" href="<?php echo($site) ?>baim/pengaturan_api" aria-expanded="false"> <span> <i class="ti ti-settings"></i> </span> <span class="hide-menu">Pengaturan API</span> </a> </li> 
<li class="sidebar-item"> <a class="sidebar-link" href="<?php echo($site) ?>baim/pengaturan_earning" aria-expanded="false"> <span> <i class="ti ti-settings"></i> </span> <span class="hide-menu">Pengaturan Earning</span> </a> </li> 
<li class="sidebar-item"> <a class="sidebar-link" href="<?php echo($site) ?>baim/pengaturan_website" aria-expanded="false"> <span> <i class="ti ti-settings"></i> </span> <span class="hide-menu">Pengaturan Website</span> </a> </li> 
<li class="sidebar-item"> <a class="sidebar-link" href="<?php echo($site) ?>baim/pengaturan_password" aria-expanded="false"> <span> <i class="ti ti-settings"></i> </span> <span class="hide-menu">Pengaturan Password</span> </a> </li>




</nav>
<!-- End Sidebar navigation -->
</div>
<!-- End Sidebar scroll-->
</aside>

