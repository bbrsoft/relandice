<div class="container-fluid">
<?php include("alert_form.php"); ?>
<div class="row">  
	
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 col-12  ">
		<div class="card">
			<div class="card-header">
				<h4>Data Wallet  </h4>
			</div>
			<div class="card-body">
				<div class="table-responsive">
					<table id="tables" class="table table-striped">
						<thead>
						<tr> 
							<th>Crypto</th>					
							<th>Wallet</th>				 		
							<th>#</th>
						</tr>
						</thead>
						<tbody>
							<?php $table = "crypto";
							$sql = "`id`<> -1";
							$row = $this->model->row($table,$sql);
							if($row >= 1){
								$dd = $this->model->get_obj($table,$sql);
								foreach($dd as $data){
									?> 
									<tr>  
										<td> <?php echo strtoupper($data->nama) ;  ?> </td>
										<td> <?php echo($data->wallet) ;  ?> </td>
										<td>  
										<a class="btn btn-primary btn-sm" href="<?php echo($site) ?>baim/pengaturan_wallet_edit/<?php echo($data->id) ;  ?>" > Edit </a> 
										</td>
									</tr> 
									<?php 
								}
							} 
							 ?>
						</tbody> 
					</table> 
				</div>
					
			</div>
		</div>	
	</div>
</div>

 

	



</div>
