<?php  
$table = "user";
$sql = "`id`='$id' and secret <> '' ";
$row = $this->model->row($table,$sql);
if($row >= 1){
$user = $this->model->get_obj($table,$sql)[0];




if(isset($_POST['new'])){
	$secret = in($_POST['secret']);
	$token = in($_POST['token']);
	$bet = in($_POST['bet']);
		
	$row = $this->model->row("user","secret='$secret' and id<>'$id' ");
	if($row >= 1){
		$alert = "danger";
		$respon = "Maaf. Secret Ini sudah ada sebelumnya ";
	}else {
		
		$data = array();
		$data['secret'] = $secret ;
		$data['token'] = $token ;
		$data['bet'] = $bet;
		
		$this->db->where('id',$id);
		$this->db->update('user',$data);
		
		$alert = "success";
		$respon = "Berhasil Memperbaharui User Secret Baru ";
	}
}


?>

<div class="container-fluid">
<div class="row">
	<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 col-12 ">
		
		<div class="card">
			<div class="card-header">
				<h4>Edit User Secret </h4>
			</div>
			<div class="card-body">
				<form method="post"  enctype="multipart/form-data"> 
					 <?php include("alert_form.php"); ?>
					<span> Secret *</span> 
					<input type="text" required class="form-control" name="secret"  value="<?php echo($user->secret) ;  ?>"   placeholder="Secret Login"    />
					<br />
					
					<span> Token  </span> 
					<textarea type="text"   class="form-control" name="token"  value="<?php echo($user->token) ;  ?>"    placeholder="Token Bermain"   ></textarea>
					<br />
					
					<span> Saldo Bermain *</span> 
					<input type="number" required class="form-control" name="bet" value="<?php echo($user->bet) ;  ?>" placeholder="Total Jumlah Permainan"    />
					<br />
					
					
					<button name="new" type="submit" class="btn btn-primary" >Edit User</button> 
				</form>
			</div>
		</div>
</div> 
</div> 
</div> 


 
			
<?php } ?>

