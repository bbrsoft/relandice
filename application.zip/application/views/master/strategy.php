 <?php 
if(isset($_POST['delete'])){
	$id = in($_POST['id']);
	$this->db->query("DELETE FROM strategy WHERE id='$id' ");
	$alert = "success";
	$respon = "Berhasil Menghapus Strategy "; 
}  



if(isset($_POST['new'])){
	$nama = in($_POST['nama']);
	$secret = $nama.rand(0,99);
	$password = $nama.rand(0,99);
	
	
	$table = "copy_trade_view";
	$sql = "`id`<>-1 ORDER BY id ASC LIMIT 1 ";
	$row = $this->model->row($table,$sql);
	if($row >= 1){
		$master_trade = $this->model->get_obj($table,$sql)[0];
		
		
		$row = $this->model->row("strategy","nama='$nama' ");
		if($row >= 1){
			$alert = "danger";
			$respon = "Maaf. Data ini sudah ada sebelumnya ";
		} else {
			
			$token = $master_trade->token ; 
				
			$data = array();
			$data['token'] = $token ;
			$data['strategy'] = 'Yes' ;
			$data['bet'] = '9999999999999';
			$data['secret'] = $secret;
			$data['password'] = $password;
			$this->db->insert('user',$data);
			$id_user  = $this->db->insert_id(); 
			
			
			
			$this->db->query("INSERT INTO strategy (`nama`,`secret`,`password`,`id_user`) VALUES ('$nama','$secret','$password','$id_user') ");
			$alert = "success";
			$respon = "Berhasil Memasukkan Data Baru ";
		}
		
		
	}
} 
?>


<div class="container-fluid bg-light min-vh-100"> 
<?php include("alert_form.php"); ?>
<div class="row">
<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 col-12   ">
	<div class="card ">
<div class="card-header bg-primary">
	<h5 class="m-0  text-light"> Strategy Baru</h5>  
</div>
<div class="card-body shadow-sm">
<form method="post" enctype="multipart/form-data"> 
		
		<span>Nama Strategy </span> 
		<input type="text" required class="form-control" name="nama" value="" placeholder="Masukkan Nama Strategy"    />
		<br />
		
				  	
		<button type="submit" name="new" class="btn btn-primary" >Tambah Data</button> 
		
</form>
</div>
</div>
	
	 
</div>



<div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 col-12 "> 
<div class="card ">
<div class="card-header bg-primary">
	<h5 class="m-0  text-light"> Data Strategy </h5>  
	<p class="text-light mb-0"> Silahkan Login Menggunakan Secret Dan Password untuk mengatur strategy </p> 
	
</div>
<div class="card-body shadow-sm">
 
	<table id="tables" class="table table-striped table-bordered">
		<thead>
		<tr>
			<th  style="min-width : 100px" > Strategy </th> 
			<th  style="min-width : 100px" > Secret Login </th> 
			<th  style="min-width : 100px" > Password Login </th> 
			<th> Action </th>  
		</tr>
		</thead>
	</table> 
	</div>
</div>


</div>
</div>
</div>




<script>  
site ="<?php echo($site) ?>";

var tablex = $('#tables').dataTable( {
 "bProcessing": true,
 "bServerSide": true,  
 "order" : [[0, 'desc']],
    "ajax" : { 
        url:  site+"server_master/strategy.php", 
        type:"POST"
    } ,
	
 "aoColumns": [
 
 
	null, 
	null, 
	null, 
	{ "mclass":"wall", "mData": "3", "mRender": function ( data, type, full ) {
		del="showdel('"+data+"','Hapus Data "+full[0]+"')";  
		div = '';
		div += '<div class="dropdown" > <button onclick="$(\'#dropdown_menu_'+data+'\').slideToggle()" class="btn btn-sm btn-primary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Option </button>';
		div += '<div class="dropdown-menu" style="right:0px!Important; left:auto"   id="dropdown_menu_'+data+'" aria-labelledby="dropdownMenuButton">';
		div += '<a class="dropdown-item"  style="cursor:pointer !important;"  onclick="'+del+'">Hapus Data</a>'; 
		div += '<a class="dropdown-item"  style="cursor:pointer !important;" href="'+site+'baim/strategy_edit/'+data+'" >Edit Data</a>';  
		div += '<a class="dropdown-item"  style="cursor:pointer !important;" href="'+site+'/?secret='+full[1]+'&password='+full[2]+'" >Atur Sekarang</a>';  
		
		div += '</div>';
		div += '</div>';
		return div;
		
	}},
	
	
	
	
 ]
 } );
   
 


</script> 
