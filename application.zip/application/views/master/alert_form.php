<?php  if(!empty($alert)){ ?>
<div class="alert alert-<?php echo($alert) ;  ?> bg-<?php echo($alert) ;  ?> border-0 shadow-sm text-light alert-dismissable">
	<a class="close" data-dismiss="alert" aria-label="close">&times;</a>
	<?php echo($respon) ;  ?> 
</div> 
<?php }  ?>			

