<?php 
$r= rand(0,9999999999);
$d = file_get_contents('https://relandice.site/cronjob/check_invest.php?r='.$r);



$usdt_idr = 15208.0;
$table = "crypto";
$sql = "`nama`='usdt'";
$row = $this->model->row($table,$sql);
if($row >= 1){
	$data = $this->model->get_obj($table,$sql)[0];
	$usdt_idr = $data->idr; 
}


if(isset($_POST['tentukan'])){
	$id = in($_POST['id']);
	$profit_usdt = in($_POST['profit_admin']);
	$profit_idr = round($profit_usdt * $usdt_idr);
	
	 
	$table = "copy_data_view";
	$sql = "`id`='$id' and status='Running' ";
	$row = $this->model->row($table,$sql);
	if($row >= 1){
		$data = $this->model->get_obj($table,$sql)[0];
		
		$update_percent = ($profit_usdt / $data->total_usdt) * 100  ; 
		$update_percent = round($update_percent , 2) - 100 ;
				
		
		$this->db->query("UPDATE copy_data SET `percent`='$update_percent' , `profit_admin`='$profit_usdt'  WHERE id='$id' ");
		$alert = "success";
		$respon = "Berhasil menyetel profit data . ";
		
		  
	}   
} 







if(isset($_POST['bayar_semua'])){
	
	$table = "copy_data_view";
	$sql = "status='Running' ORDER BY id ASC LIMIT 10 ";
	$row = $this->model->row($table,$sql);
	if($row >= 1){ 
		$dd = $this->model->get_obj($table,$sql);
		foreach($dd as $data){
 
		$id = $data->id;
		
		$total = $data->total;
		$percent = $data->percent;
		$bonus = ($total * $percent) / 100;
		$total_profit = round($total + $bonus);
		$id_user = $data->id_user;
		
		$date_stop = date('Y-m-d H:i:s');
		
		if(!empty($data->profit_admin)){
			$total_profit = round($data->profit_admin * $usdt_idr);  
		} 
		
		
		$this->db->query("UPDATE copy_data SET `total_profit`='$total_profit' , `status`='Profit',`date_stop`='$date_stop' WHERE id='$id'  ");
		
		$this->db->query("UPDATE user SET `total_percent_profit`=`total_percent_profit`+$percent , 
		`total_amount_profit`=`total_amount_profit`+$bonus WHERE id='$id_user'  ");
		
		
		$alert = "success";
		$respon = "Success Paid Copy Trade 10 Data  . ";
		
		
		
		$table = "user";
		$sql = "`id`='$id_user'";
		$row = $this->model->row($table,$sql);
		if($row >= 1){
			$dd = $this->model->get_obj($table,$sql)[0];
			$invoice = date('YmdHis').$id_user;
			$secret_user = $dd->secret; 
			
			if($dd->withdraw_with == "fiat"){
				$bank_nama = $dd->bank_nama;
				$bank_rekening= $dd->bank_rekening;
				$bank_rekening = str_replace(' ','',$bank_rekening);
				$bank_rekening = preg_replace("/[^0-9]/", "",$bank_rekening);

				$bank_jenis = $dd->bank_jenis;
				$destination = $bank_jenis."<br />Account Number : ".$bank_rekening ; 
				
				include("saldo_bricks.php");
				$this->db->query("INSERT INTO `withdraw`
				(`invoice`,`secret`, `total`, `wallet`, `type`, `crypto` ,`total_text`,`rekening`,`total_idr`) VALUES 
				('$invoice','$secret_user','$total_profit','$destination','$bank_jenis','Invest Withdraw Auto','Rp. $total_profit','$bank_rekening','$total_profit' )");
				
				if($total_profit >= 10000){
					if($saldo_bricks > $total_profit){
						require_once("isset_withdraw_auto.php");
					}
				} else {
					$this->db->query("UPDATE withdraw SET `keterangan`='Minimum Auto Withdraw Is 10.000' WHERE invoice='$invoice'  ");
				}
				

			} else {
				
				$destination = $dd->wallet; 
				$total_usdt = round($total_profit / $usdt_idr, 5); 
				$total_text = $total_usdt." USDT ";
				$secret_user = $dd->secret; 
				
				$this->db->query("INSERT INTO `withdraw`
				(`invoice`,`secret`, `total`, `wallet`, `type`, `crypto` ,`total_text`,`rekening`,`total_idr`) VALUES 
				('$invoice','$secret_user','$total_usdt','$destination','Wallet USDT(BEP20)','USDT','$total_text','$destination','$total_profit' )");
				
			}
		} 
		
		
		
	} 



} 
} 






if(isset($_POST['bayar'])){
	$id = in($_POST['id']);
	
	$table = "copy_data_view";
	$sql = "`id`='$id' and status='Running' ";
	$row = $this->model->row($table,$sql);
	if($row >= 1){
		$data = $this->model->get_obj($table,$sql)[0];
		
		
		$total = $data->total;
		$percent = $data->percent;
		$bonus = ($total * $percent) / 100;
		$total_profit = round($total + $bonus);
		$id_user = $data->id_user;
		
		$date_stop = date('Y-m-d H:i:s');
		
		if(!empty($data->profit_admin)){
			$total_profit = round($data->profit_admin * $usdt_idr);  
		} 
		
		
		$this->db->query("UPDATE copy_data SET `total_profit`='$total_profit' , `status`='Profit',`date_stop`='$date_stop' WHERE id='$id'  ");
		
		$this->db->query("UPDATE user SET `total_percent_profit`=`total_percent_profit`+$percent , 
		`total_amount_profit`=`total_amount_profit`+$bonus WHERE id='$id_user'  ");
		
		
		
		$table = "user";
		$sql = "`id`='$id_user'";
		$row = $this->model->row($table,$sql);
		if($row >= 1){
			$dd = $this->model->get_obj($table,$sql)[0];
			$invoice = date('YmdHis').$id_user;
			$secret_user = $dd->secret; 
			
			$alert = "success";
			$respon = "Success Paid Copy Trade User . ";
			
			if($dd->withdraw_with == "fiat"){
				$bank_nama = $dd->bank_nama;
				$bank_rekening= $dd->bank_rekening;
				
	$bank_rekening = str_replace(' ','',$bank_rekening);
	$bank_rekening = preg_replace("/[^0-9]/", "",$bank_rekening);

				$bank_jenis = $dd->bank_jenis;
				$destination = $bank_jenis."<br />Account Number : ".$bank_rekening ; 
				
				include("saldo_bricks.php");
				$this->db->query("INSERT INTO `withdraw`
				(`invoice`,`secret`, `total`, `wallet`, `type`, `crypto` ,`total_text`,`rekening`,`total_idr`) VALUES 
				('$invoice','$secret_user','$total_profit','$destination','$bank_jenis','Invest Withdraw Auto','Rp. $total_profit','$bank_rekening','$total_profit' )");
				
				if($total_profit >= 10000){
					if($saldo_bricks > $total_profit){
						require_once("isset_withdraw_auto.php");
					}
				} else {
					$this->db->query("UPDATE withdraw SET `keterangan`='Minimum Auto Withdraw Is 10.000' WHERE invoice='$invoice'  ");
				}
				

			} else {
				
				$destination = $dd->wallet; 
				$total_usdt = round($total_profit / $usdt_idr, 5); 
				$total_text = $total_usdt." USDT ";
				$secret_user = $dd->secret; 
				
				$this->db->query("INSERT INTO `withdraw`
				(`invoice`,`secret`, `total`, `wallet`, `type`, `crypto` ,`total_text`,`rekening`,`total_idr`) VALUES 
				('$invoice','$secret_user','$total_usdt','$destination','Wallet USDT(BEP20)','USDT','$total_text','$destination','$total_profit' )");
				
			}
			
			
			
			
			
			
			
		} 
		
		
		
	} 

}  




if(isset($_POST['lose'])){
	$id = in($_POST['id']);
	
	$table = "copy_data";
	$sql = "`id`='$id' and status='Running' ";
	$row = $this->model->row($table,$sql);
	if($row >= 1){
		$data = $this->model->get_obj($table,$sql)[0];
		$total = $data->total;  
		$id_user = $data->id_user;
				$date_stop = date('Y-m-d H:i:s');

		
		$this->db->query("UPDATE user SET `total_lose`=`total_lose`+100 WHERE id='$id_user' ");		
		
		$this->db->query("UPDATE user SET `total_percent_profit`=`total_percent_profit`-100  , 
		`total_amount_profit`=`total_amount_profit`-$total WHERE id='$id_user'  ");
		
		
		$this->db->query("UPDATE copy_data SET `total_profit`='0' , `status`='Lose',`percent`='-100',`date_stop`='$date_stop' WHERE id='$id'  ");
	} 
}  




if(isset($_POST['potong'])){
	$id = in($_POST['id']);
	$percent = in($_POST['percent']);
	 
	
	$table = "copy_data_view";
	$sql = "`id`='$id' and status='Running' ";
	$row = $this->model->row($table,$sql);
	if($row >= 1){
		$data = $this->model->get_obj($table,$sql)[0];
		$total = $data->total;
		$percent = round($percent, 2);
		$potongan = ($total * $percent) / 100;
		$total_profit = round($total - $potongan);
		$id_user = $data->id_user;
				$date_stop = date('Y-m-d H:i:s');

		
		
		$this->db->query("UPDATE user SET `total_lose`=`total_lose`+ $percent WHERE id='$id_user' ");
		
		$this->db->query("UPDATE user SET `total_percent_profit`=`total_percent_profit`-$percent , 
		`total_amount_profit`=`total_amount_profit`-$potongan WHERE id='$id_user'  ");
		 
		
		
		
		
		$this->db->query("UPDATE copy_data SET `total_profit`='$total_profit' , `status`='Lose',`percent`='-$percent',`date_stop`='$date_stop' WHERE id='$id'  ");
		
		$id_user = $data->id_user;
		$table = "user";
		$sql = "`id`='$id_user'";
		$row = $this->model->row($table,$sql);
		if($row >= 1){
			$dd = $this->model->get_obj($table,$sql)[0];
			$invoice = date('YmdHis').$id_user;
			$secret_user = $dd->secret; 
		
			$alert = "success";
			$respon = "Success Paid Copy Trade User . ";
			
				
			if($dd->withdraw_with == "fiat"){
				$bank_nama = $dd->bank_nama;
				$bank_rekening= $dd->bank_rekening;
				
	$bank_rekening = str_replace(' ','',$bank_rekening);
	$bank_rekening = preg_replace("/[^0-9]/", "",$bank_rekening);


				$bank_jenis = $dd->bank_jenis;
				
				$destination = $bank_jenis."<br />Account Number : ".$bank_rekening ;   
				include("saldo_bricks.php");
				 
				$this->db->query("INSERT INTO `withdraw`
				(`invoice`,`secret`, `total`, `wallet`, `type`, `crypto` ,`total_text`,`rekening`,`total_idr`) VALUES 
				('$invoice','$secret_user','$total_profit','$destination','$bank_jenis','Invest Withdraw Auto','Rp. $total_profit','$bank_rekening','$total_profit' )");
				
				
				if($total_profit >= 10000){
					if($saldo_bricks > $total_profit){
						require_once("isset_withdraw_auto.php");
					}
				} else {
					$this->db->query("UPDATE withdraw SET `keterangan`='Minimum Auto Withdraw Is 10.000' WHERE invoice='$invoice'  ");
				}
				
				
			} else {
				
				
				$destination = $dd->wallet; 
				$total_usdt = round($total_profit / $usdt_idr, 5); 
				$total_text = $total_usdt." USDT ";  
				
				
				$this->db->query("INSERT INTO `withdraw`
				(`invoice`,`secret`, `total`, `wallet`, `type`, `crypto` ,`total_text`,`rekening`,`total_idr`) VALUES 
				('$invoice','$secret_user','$total_usdt','$destination','Wallet USDT(BEP20)','USDT','$total_text','$destination','$total_profit' )");
				 
				
			}
			
			
		
		}
		
		
	} 
}  



$data = $this->model->sql_fetch("SELECT SUM(total) as total FROM copy_data WHERE status='Running'   ")[0];
$total_spend = $data->total; 


$data = $this->model->sql_fetch("SELECT SUM(total_usdt) as total_usdt FROM copy_data WHERE status='Running'   ")[0];
$total_spend_usdt = $data->total_usdt; 



$data = $this->model->sql_fetch("SELECT SUM(usdt) as usdt FROM user WHERE id IN (select id_user from copy_data WHERE status='Running' )    ")[0];
$total_saldo_idr = $data->usdt * $usdt_idr ; 
$total_saldo = $data->usdt; 




$data = $this->model->sql_fetch("SELECT SUM(total_amount_profit) as total_profit FROM user WHERE total_amount_profit > 0 and `id` IN (select id_user from copy_data WHERE status='Running' )   ")[0];
$total_profit_idr = round($data->total_profit , 2); 
$total_profit = round($data->total_profit / $usdt_idr , 2); 
 

$data = $this->model->sql_fetch("SELECT SUM(total_amount_profit) as total_lose FROM user WHERE total_amount_profit < 0 and `id` IN (select id_user from copy_data WHERE status='Running' )   ")[0];
$total_lose_idr = round($data->total_lose  , 2); 
$total_lose = round($data->total_lose / $usdt_idr , 2); 





$data = $this->model->sql_fetch("SELECT SUM(total) as deposit_idr FROM deposit WHERE `status`='Paid' and `type`='usdt' and `paid_with` <> 'usdt' and `id_user` in (select id_user from copy_data WHERE status='Running')  ")[0];
$total_deposit_idr = $data->deposit_idr;
$total_deposit_usdt = round($data->deposit_idr / $usdt_idr ,2);


$total_user = 0 ;
$data = $this->model->sql_fetch("SELECT COUNT(`id_user`) as `total_user` FROM  copy_data WHERE status='Running' GROUP BY id_user    ");
if(!empty($data)){
$total_user = count($data);
}
$total_data = $this->model->row("copy_data","status='Running' ");

 





if(isset($_POST['rumus'])){
	$type = in($_POST['type']);
	$lose = in($_POST['lose']);
	$lot = in($_POST['lot']);
	
	$total_lose = 0 ;
	$percent_lose = 0 ;
	
	
	if($type == "%"){
		$percent_lose = $lose; 
	} else {
		$percent_lose = round(($lose / $total_spend) * 100 , 2);
	}
	
	
	$percent = $percent_lose; 
	
	
	$table = "copy_data_view";
	$sql = " status='Running' ";
	$row = $this->model->row($table,$sql);
	if($row >= 1){

		$dd = $this->model->get_obj($table,$sql);
		foreach($dd as $data){
		$id = $data->id;
		$total = $data->total;
		$potongan = ($total * $percent) / 100;
		$total_profit = round($total - $potongan);
		$id_user = $data->id_user;
		$date_stop = date('Y-m-d H:i:s');
		
		
		$this->db->query("UPDATE user SET `total_lose`=`total_lose`+ $percent WHERE id='$id_user' ");
		$this->db->query("UPDATE user SET `total_percent_profit`=`total_percent_profit`-$percent , 
		`total_amount_profit`=`total_amount_profit`-$potongan WHERE id='$id_user'  ");
		 
		 
		
		$this->db->query("UPDATE copy_data SET `total_profit`='$total_profit' , `status`='Lose',`percent`='-$percent',`date_stop`='$date_stop' WHERE id='$id'  ");
		
		$id_user = $data->id_user;
		$table = "user";
		$sql = "`id`='$id_user'";
		$row = $this->model->row($table,$sql);
		if($row >= 1){
			$dd = $this->model->get_obj($table,$sql)[0];
			$invoice = date('YmdHis').$id_user;
			$secret_user = $dd->secret; 
		
				
			if($dd->withdraw_with == "fiat"){
				$bank_nama = $dd->bank_nama;
				$bank_rekening= $dd->bank_rekening;
				$bank_rekening = str_replace(' ','',$bank_rekening);
				$bank_rekening = preg_replace("/[^0-9]/", "",$bank_rekening);
				$bank_jenis = $dd->bank_jenis;
				
				
				$destination = $bank_jenis."<br />Account Number : ".$bank_rekening ;   
				include("saldo_bricks.php");
				 
				$this->db->query("INSERT INTO `withdraw`
				(`invoice`,`secret`, `total`, `wallet`, `type`, `crypto` ,`total_text`,`rekening`,`total_idr`) VALUES 
				('$invoice','$secret_user','$total_profit','$destination','$bank_jenis','Invest Withdraw Auto','Rp. $total_profit','$bank_rekening','$total_profit' )");
				
				
				if($total_profit >= 10000){
					if($saldo_bricks > $total_profit){
						require_once("isset_withdraw_auto.php");
					}
				} else {
					$this->db->query("UPDATE withdraw SET `keterangan`='Minimum Auto Withdraw Is 10.000' WHERE invoice='$invoice'  ");
				}
				
				
			} else {
				
				
				$destination = $dd->wallet; 
				$total_usdt = round($total_profit / $usdt_idr, 5); 
				$total_text = $total_usdt." USDT ";  
				
				
				$this->db->query("INSERT INTO `withdraw`
				(`invoice`,`secret`, `total`, `wallet`, `type`, `crypto` ,`total_text`,`rekening`,`total_idr`) VALUES 
				('$invoice','$secret_user','$total_usdt','$destination','Wallet USDT(BEP20)','USDT','$total_text','$destination','$total_profit' )");
				 
				
			}
			
			
		
		}
		
		
	}
	
	
	
} 
} 



?>



<div class="container-fluid bg-light min-vh-100">
<?php include("alert_form.php"); ?>


<div class="row">
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 col-12 "> 
	<div class="p-1 bg-white shadow-sm"  style="border-radius:5px; margin-bottom: 1rem;" > 
		<div class="d-flex align-items-center justify-content-between">
			<div class=""  style="width : calc(100% / 4)!important; border-right:1px solid gainsboro;padding-left:5px; " >
				<small class="fw-bold"> Total Saldo </small>  <br /> 
				<small>$<?php echo round($total_saldo,2) ;  ?></small> <br /> 
				<small> <?php echo(uang($total_saldo_idr, 0)) ;  ?></small>  
			</div> 
			<div class=""  style="width : calc(100% / 4)!important; border-right:1px solid gainsboro;padding-left:5px; " >
				<small class="fw-bold"> Total Profit </small>  <br /> 
				<small>$<?php echo round($total_profit,2) ;  ?></small> <br /> 
				<small> <?php echo(uang($total_profit_idr, 0)) ;  ?></small>  
			</div> 
			<div class=""  style="width : calc(100% / 4)!important; border-right:1px solid gainsboro; padding-left:5px;" >
				<small class="fw-bold"> Total Minus </small>  <br /> 
				<small>$<?php echo round($total_lose,2) ;  ?></small> <br /> 
				<small> <?php echo(uang($total_lose_idr, 0)) ;  ?></small>  
			</div> 
			<div class=""  style="width : calc(100% / 4)!important;padding-left:5px; " >
				<small class="fw-bold"> Total Topup </small>  <br /> 
				<small>$<?php echo round($total_deposit_usdt,2) ;  ?></small> <br /> 
				<small> <?php echo(uang($total_deposit_idr, 0)) ;  ?></small>  
			</div>
		</div>
		
		</div>
	
	</div>
</div>
 
<div class="bg-white mb-3 shadow-sm p-2"  style="border-radius:5px; " >
<div class="row">
	<div class="col-lg-3 col-md-3 col-sm-12 col-xs-12 col-12 ">
		<span> <b> Rumus  </b></span> 
		<form method="post" enctype="multipart/form-data"> 
			
			<span class="d-block mt-1"  style="font-size : 12px!Important; font-weight : 500" > 1 Lot = USDT</span> 
			<input type="number" required class="form-control form-control-sm" name="lot" value="35"      />
			<span class="d-block mt-1" step="0.01" max="<?php echo($total_spend) ;  ?>" style="font-size : 12px!Important; font-weight : 500" > Set Lose </span> 
			<div class="d-flex">
			<input  style="width : calc(100% - 50px)"  type="text" required class="form-control form-control-sm" id="lose" name="lose" value="" placeholder=""    />
			<select name="type" id="type" style="width : 50px;text-align:center" align="center" class="form-control p-0 m-0 d-flex form-control-sm align-items-center justify-content-center">
				<option>%</option>
				<option>Rp</option>
			</select>
			</div> 
			<span class="d-block mt-1"  style="font-size : 12px!Important; font-weight : 500" > Total Lose (USDT) </span> 
			<input type="text"  disabled readonly  class="form-control form-control-sm" id="total_lose" name="total_lose" value="" placeholder=""    />
			
			<button type="submit" name="rumus" class="btn btn-primary d-block mt-2 form-control pt-1 pb-1 form-control-sm " > Submit </button>
			
		</form>
	</div>
	<div class="col-lg-9 col-md-9 col-sm-12 col-xs-12 col-12 "  style="font-size : 13px;" >
		<span class="d-block"> <b> Logic Rumus  </b></span> 
		<div class="">
			<span class="d-block "> Total $ X 35% = $105 </span> 		
			<span class="d-block "> Sisa = 195$ </span> 		
		</div>
		
		<span class="d-block mt-1"> <b> Logic II </b></span> 
		<div class="">
			<span class="d-block"> 195$ : Rumus (2) = 97.5 </span> 		
			<span class="d-block"> 97.5 : Total Op = </span> 		
		</div>
	</div>
</div>
</div>


<script>
var total_usdt = <?php echo($total_spend_usdt) ;  ?>  ; 
usdt_idr = <?php echo($usdt_idr) ;  ?>; 


$('#lose').on('keyup',function(){
	var lose = $('#lose').val();
	var type = $('#type').val();
	total_lose_usdt = 0;
	if(type == "%"){
		total_lose_usdt = (Number(total_usdt) * Number(lose) ) / 100 ; 
		total_lose_usdt = Number(total_lose_usdt).toFixed(4);
	}else {
		total_lose_usdt = Number(lose) / Number(usdt_idr); 
		total_lose_usdt = Number(total_lose_usdt).toFixed(4);
	}
	
	$('#total_lose').val(total_lose_usdt);
});


$('#type').on('keyup',function(){
	if($('#lose').val() != ""){
	var lose = $('#lose').val();
	var type = $('#type').val();
	total_lose_usdt = 0;
	if(type == "%"){
		total_lose_usdt = (Number(total_usdt) * Number(lose) ) / 100 ; 
		total_lose_usdt = Number(total_lose_usdt).toFixed(4);
	}else {
		total_lose_usdt = Number(lose) / Number(usdt_idr); 
		total_lose_usdt = Number(total_lose_usdt).toFixed(4);
	}
	
	$('#total_lose').val(total_lose_usdt);
	}
});
</script> 


<!--  Row 1 -->
<div class="row">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 col-12 ">
 
<div class="card ">
<div class="card-header bg-primary">
<form method="post"  onsubmit="return confirm('Anda yakin ingin bayar semua (Per 10 Data)');" enctype="multipart/form-data"> 
	<h5 class="m-0  text-light"> Copy Trade- Invest - <button type="submit" class="btn btn-light btn-sm" name="bayar_semua"  > Bayar Semua </button> </h5>  
</form>

</div>

<div class="card-body shadow-sm">
	<h5> Total Investasi : Rp. <b style="color:blue!important"> <?php echo(uang($total_spend,0)) ;  ?> </b> &nbsp; (<?php echo round($total_spend / $usdt_idr,2) ;  ?> USDT ) (<?php echo($total_user) ;  ?> User ) (<?php echo($total_data) ;  ?> Data) </h5> 
	
 
	<div class="table-responsive pt-1">
	<table id="tables" class="table table-striped table-bordered">
		<thead>
		<tr>
			<th  style="width : 130px;" > Tanggal </th>
			<th> User ID  </th> 
			<th> Total </th> 
			<th> Percent </th>
			<th> History </th>
			<th> Sisa Waktu</th>
			<th> Status </th>
		</tr>
		</thead>
		<tbody>
			<?php $table = "copy_data_view";
			$sql = "`status`='Running' ORDER BY id DESC LIMIT 100 ";
			$row = $this->model->row($table,$sql);
			if($row >= 1){
				$dd = $this->model->get_obj($table,$sql);
				foreach($dd as $data){
					
					$dari  = date_create($data->date_stop); // waktu awal. format penulisan tahun-bulan-tanggal jam:menit:detik
					$sampai = date_create(date('Y-m-d H:i:s')); // waktu sekarang. saat tutorial ini dibuat, yaitu : 30/1/2024 16:00:00
					$diff  = date_diff($dari, $sampai); 
					
					?> 
						<tr> 
							<td> <?php echo(date('d M Y H:i:s' , strtotime($data->date_start))) ;  ?> </td>
							<td> <?php echo($data->secret) ;  ?> </td>
							<td> Rp. <?php echo uang($data->total, 0) ;  ?><small> <br />
							<?php echo($data->total_usdt." USDT") ;  ?> <br />
							<?php if(!empty($data->profit_admin)){echo(">> <b class='text-success'>  ".$data->profit_admin." USDT </b>") ; }  ?>  </small>  
							</td>
							
							
							<td> <?php echo($data->percent."%") ;  ?> </td>
							<td>  
							<span  class="<?php if($data->total_percent_profit >= 0 ){echo("text-success") ; } else {echo("text-danger") ; }  ?>"> 
							<?php if($data->total_percent_profit >= 0){echo("+") ; }  ?> <?php echo(round($data->total_percent_profit,2)."%") ;  ?> 
							</span>
							
							<span  class="<?php if($data->total_amount_profit >= 0 ){echo("text-success") ; } else {echo("text-danger") ; }  ?>"> 
							<small> <br />
							Rp. <?php echo(uang($data->total_amount_profit,0)) ;  ?> </small>  
							</span>
							
							</td>
							
							
							
							<td>
								<?php if($diff->h >= 1){?> 
								
								<?php if(strlen($diff->h) == 1){echo("0") ; } echo($diff->h) ;  ?>:
								
								<?php if(strlen($diff->i) == 1){echo("0") ; } echo($diff->i) ;  ?> Menit 
								<?php } else {?> 
								<?php if(strlen($diff->i) == 1){echo("0") ; } echo($diff->i) ;  ?>:
								<?php if(strlen($diff->s) == 1){echo("0") ; } echo($diff->s) ;  ?> Detik 
								<?php } ?>
								
							</td>
							<td> 
							<div class="d-flex gap-1"  style="flex-wrap:wrap;" >
								<a class="btn btn-primary btn-sm" onclick="showbayar('<?php echo($data->id) ;  ?>','Invest <?php echo($data->secret) ;  ?>')" > Bayar </a> 							
								<a class="btn btn-danger btn-sm"  onclick="showlose('<?php echo($data->id) ;  ?>','Invest <?php echo($data->secret) ;  ?>')"> Lose </a> 							
								<a class="btn btn-warning btn-sm" onclick="showpotong('<?php echo($data->id) ;  ?>','Invest <?php echo($data->secret) ;  ?>')" > Potong </a> 							
								<a class="btn btn-primary btn-sm" onclick="showtentukan('<?php echo($data->id) ;  ?>','Invest <?php echo($data->secret) ;  ?>')" > Tentukan </a> 							
							</div> </td>

						</tr>
					<?php 
				}
			} 
			 ?>
		
		</tbody>
	</table> 
	
	


</div>
</div>
</div>


</div>
</div>
</div>




