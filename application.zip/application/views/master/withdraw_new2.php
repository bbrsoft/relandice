<?php 
$client = $settings->client;
$secret = $settings->secret;
$url_api = "https://api.onebrick.io";

 

if(isset($_POST['konfirmasi'])){
	$id = in($_POST['id']);	
		
	$table = "withdraw2";
	$sql = "`id`='$id' and status='Processed' ";
	$row = $this->model->row($table,$sql);
	if($row >= 1){
		$data = $this->model->get_obj($table,$sql)[0];
		$id_user = $data->id_user; 
		
		$this->db->query("UPDATE `investor_history` SET `status`='Sucesfully' WHERE id_user='$id_user' and type='Sell'");
		$alert = "success";
		$respon = "Success Confirm Withdrawal ";
		$this->db->query("UPDATE withdraw2 SET `status`='Finish' where id='$id'  ");
	} 
} 


if(isset($_POST['reject'])){
	$id = in($_POST['id']);
	
	$table = "withdraw2";
	$sql = "`id`='$id' and status='Processed' ";
	$row = $this->model->row($table,$sql);
	if($row >= 1){
		$data = $this->model->get_obj($table,$sql)[0];
		$id_user = $data->id_user; 
		
		$this->db->query("DELETE FROM `investor_history`  WHERE id_user='$id_user' and type='Sell'");
		$alert = "danger";
		$respon = "Success Rejected Withdrawal ";
		$this->db->query("UPDATE withdraw2 SET `status`='Reject' where id='$id'  ");		
	} 
} 

 
if(isset($_POST['process'])){
	$table = "withdraw2";
	$sql = "`status`='Processed' and with_pg='No' and type_money='Rp' LIMIT 10  ";
	$row = $this->model->row($table,$sql);
	if($row >= 1){
		$dd = $this->model->get_obj($table,$sql);
		foreach($dd as $data){
			
			$bank_rekening = $data->bank_rekening;
			$bank_jenis = $data->bank_jenis;
			$total = $data->total_idr; 
			$secret_user = $data->secret;
			$id_data = $data->id;
			$id_userx = $data->id_user;
			$ticket = "TICKET".date('ymdhis').$data->id_user;							
			
			include("withdraw_new2_proccess.php");
		
		}		
		$alert = "success";
		$respon = "Update Withdrawal To Payment Gateway,  $row Data Withdrawal . ";
	
	} 
} 

if(isset($_POST['check'])){
	$table = "withdraw2";
	$sql = "`status`='Processed' and with_pg='Yes' and type_money='Rp' LIMIT 10  ";
	$row = $this->model->row($table,$sql);
	if($row >= 1){
		$dd = $this->model->get_obj($table,$sql);
		foreach($dd as $data){
			include("withdraw_new2_check.php");
		}
		
		$alert = "success";
		$respon = "Checking $row Data Withdrawal . ";
	
	}   
} 

?>



<div class="container-fluid bg-light min-vh-100"> 
<?php include("alert_form.php"); ?>
<div class="row">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 col-12 "> 
 
<div class="card ">
<div class="card-header bg-primary">
	<div class="">
		<h5 class="m-0  text-light"> Withdraw Request  </h5>  
		<form method="post" class="pt-2" enctype="multipart/form-data"> 
			<button type="submit" class="btn btn-success" name="process" >Process 10 Data </button>
			<button type="submit" class="btn btn-warning" name="check"  > Check Status </button>
		</form>		 
	</div>
</div>


<div class="card-body shadow-sm"> 
	<div class="table-responsive">
	<table id="tables" class="table table-striped table-bordered">
		<thead>
		<tr>
			<th> Secret ID </th>
			<th> Total Shib </th>
			<th> Total </th>
			<th> Bank / Wallet </th>
			<th> With PG </th>
			<th> ID PG </th>
			<th> Action </th>  
		</tr>
		</thead>
	</table> 
	</div>
	</div>
</div>


</div>
</div>
</div>




<script>  
site ="<?php echo($site) ?>";
var tablex = $('#tables').dataTable( {
 "bProcessing": true,
 "bServerSide": true,  
 "order" : [[0, 'desc']],
    "ajax" : { 
        url:  site+"server_master/withdraw_new2.php", 
        type:"POST"
    } ,
	
 "aoColumns": [
	null,
	null,
	{ "mclass":"wall", "mData": "2", "mRender": function ( data, type, full ) {
		if(full[7] == "Rp"){
			return "Rp. "+uang(data);
		} else {
			return (data + " USDT");
		}
	}},
	null,
	null,
	null,
	{ "mclass":"wall", "mData": "6", "mRender": function ( data, type, full ) {
		del="showrej('"+data+"','Hapus Data "+full[0]+"')"; 
		conf="showconf('"+data+"','Konfirmasi Deposit Ini "+(full[0])+"')";  
		div = '';
		div += '<div class="dropdown" > <button onclick="$(\'#dropdown_menu_'+data+'\').slideToggle()" class="btn btn-sm btn-primary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Option </button>';
		div += '<div class="dropdown-menu" style="right:0px!Important; left:auto"   id="dropdown_menu_'+data+'" aria-labelledby="dropdownMenuButton">';
		div += '<a class="dropdown-item"  style="cursor:pointer !important;"  onclick="'+del+'">Tolak Permintaan</a>'; 
		div += '<a class="dropdown-item"  style="cursor:pointer !important;"  onclick="'+conf+'">Selesai</a>';    
		div += '</div>';
		div += '</div>';
		return div;
		
	}},
	
	
	
	
 ]
 } );
   
 


</script> 
