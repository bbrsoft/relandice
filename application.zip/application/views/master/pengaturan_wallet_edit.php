<?php 
$row = $this->model->row('crypto'," `id`='$id' ");
if($row >= 1){
$data = $this->model->get_obj('crypto'," `id`='$id' ")[0];

if(isset($_POST['edit'])){
	$wallet = in($_POST['wallet']);
	$this->db->query("update crypto set `wallet`='$wallet' where id='$id'  "); 
$data = $this->model->get_obj('crypto'," `id`='$id' ")[0];

} 






?>
 <div class="container-fluid">
<div class="row"> 
	<div class="col-lg-5 col-md-5 col-sm-12 col-xs-12 col-12   ">
		 
		<div class="card">
			<div class="card-header">
				<h4>Edit Data Wallet </h4>
			</div>
			<div class="card-body">
				<form method="post" enctype="multipart/form-data"> 
					<?php include("alert_form.php"); ?>
					 
					<span> Crypto </span> 
					<input type="text" required disabled class="form-control" name="nama" value="<?php echo($data->nama) ;  ?>" placeholder=""    />
					<br />
					<span> Wallet </span> 
					<input type="text" required class="form-control" name="wallet" value="<?php echo($data->wallet) ;  ?>" placeholder="Wallet"    />
					<br />
					
					<button name="edit" type="submit" class="btn btn-primary" > <i class="la la-ticket">  </i> Edit Data</button>
				</form>
			</div>
		</div>
	</div> 
	
	
	 
</div>
</div>

 
<?php } else {?> 
<script>  document.location.href="<?php echo($site) ?>baim/pengaturan_wallet";   </script>  
<?php
exit();
 } ?>

