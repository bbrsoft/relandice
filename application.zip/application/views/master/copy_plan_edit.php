<?php 
$row = $this->model->row('copy_plan'," `id`='$id' ");
if($row >= 1){
$data = $this->model->get_obj('copy_plan'," `id`='$id' ")[0];


if(isset($_POST['edit_bank'])){
	$total = in($_POST['total']);
	$jam = in($_POST['jam']);
	$min = in($_POST['min']);
	$max = in($_POST['max']);
	  
	
	$table = "copy_plan";
	$sql = "total='$total' and id <> '$id' ";
	$row = $this->model->row($table,$sql);
	if($row >= 1){
		$alert = "danger";
		$respon = "Maaf. Data ini sudah ada sebelumnya ";
	} else {
		 
		$datax = array();
		
		$datax['total'] = $total ;
		$datax['jam'] = $jam ;
		$datax['min'] = $min; 
		$datax['max'] = $max ; 
		$this->db->where('id',$id);
		$this->db->update('copy_plan',$datax);
		 
		
		$alert = "success";
		$respon = "Berhasil Memperbaharui Data ";
		?> 
		<script>  document.location.href="<?php echo($site) ?>baim/copy_plan";   </script>  
		<?php
		exit();
	
		
	}
		
		
} 


?>
 <div class="container-fluid">
<div class="row"> 
	<div class="col-lg-5 col-md-5 col-sm-12 col-xs-12 col-12   ">
		 
		<div class="card">
			<div class="card-header">
				<h4>Edit Data Plan </h4>
			</div>
			<div class="card-body">
				<form method="post" enctype="multipart/form-data"> 
					<?php include("alert_form.php"); ?> 
						<span> Minimal Deposit </span> 
					<input type="text" required class="form-control" name="total" value="<?php echo($data->total) ;  ?>" placeholder="Min Deposit"    />
					<br />
					
					<span> Detik </span> 
					<input type="text" required class="form-control" name="jam" value="<?php echo($data->jam) ;  ?>" placeholder="Detik "    />
					<br />
					<span> Min Profit (%) </span> 
					<input type="text" required class="form-control" name="min" value="<?php echo($data->min) ;  ?>" placeholder="Min Profit"    />
					<br />
					
					<span> Max Profit (%)</span> 
					<input type="text" required class="form-control" name="max" value="<?php echo($data->max) ;  ?>" placeholder="Max Profit"    />
					<br />
					
					<button name="edit_bank" type="submit" class="btn btn-primary" > <i class="la la-ticket">  </i> Edit Data</button>
				</form>
			</div>
		</div>
	</div> 
	
	
	 
</div>
</div>

 
<?php } else {?> 
<script>  document.location.href="<?php echo($site) ?>baim/copy_plan";   </script>  
<?php
exit();
 } ?>

