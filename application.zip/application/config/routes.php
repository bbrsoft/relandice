<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$route['default_controller'] = 'app';
 
$route['arbitrage/'] = 'Arbitrage/index';
$route['arbitrage/(:any)'] = 'Arbitrage/index/$1';
$route['arbitrage/(:any)/(:any)'] = 'Arbitrage/index/$1/$2';
$route['arbitrage/(:any)/(:any)/(:any)'] = 'Arbitrage/index/$1/$2/$3';


$route['master/'] = 'Master/index';
$route['master/(:any)'] = 'Master/index/$1';
$route['master/(:any)/(:any)'] = 'Master/index/$1/$2';
$route['master/(:any)/(:any)/(:any)'] = 'Master/index/$1/$2/$3';

$route['baim/'] = 'Baim/index';
$route['baim/(:any)'] = 'Baim/index/$1';
$route['baim/(:any)/(:any)'] = 'Baim/index/$1/$2';
$route['baim/(:any)/(:any)/(:any)'] = 'Baim/index/$1/$2/$3';

$route['page/'] = 'App/page';
$route['page/(:any)'] = 'App/page/$1';
$route['page/(:any)/(:any)'] = 'App/page/$1/$2';
$route['page/(:any)/(:any)/(:any)'] = 'App/page/$1/$2/$3';

$route['info/'] = 'App/info';
$route['info/(:any)'] = 'App/info/$1';
$route['info/(:any)/(:any)'] = 'App/info/$1/$2';
$route['info/(:any)/(:any)/(:any)'] = 'App/info/$1/$2/$3';


$route['game/'] = 'Game/index';
$route['game/(:any)'] = 'Game/index/$1';

 
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

