<?php
defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Jakarta');

class Test extends CI_Controller {	
 
	public function index()
	{ 


		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, 'https://wolfbet.com/api/v1/user/balances');
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');

	 
		$headers = array();
		$headers[] = 'X-Requested-With: XMLHttpRequest';
		$headers[] = 'Authorization: Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiI1IiwianRpIjoiZWI0MzcwMjViNmQ3ZTNjMTZiMTg0Mzk0NWMwYjgwMTU5ZDE0NGI3ZDA2NTE4NzkyMDU0MDUwNjQ4ZmE4NzM3NDExYmY1MDY0NDYzYTY5YjMiLCJpYXQiOjE3MjM4MTI0MzIuMjA4MDMyLCJuYmYiOjE3MjM4MTI0MzIuMjA4MDM2LCJleHAiOjE3NTUzNDg0MzIuMjAzNjk4LCJzdWIiOiI0NjA5MjAiLCJzY29wZXMiOltdfQ.Hv8immYhV4McWv9igWIu9DVuD0pvzX2iUAzWOVJe1s1Qy1OaZRTY2djpncYJfIxx0CBd4XTAHlVsezG5FJldTOU0mMeKo-sNhIejJGCRWxcJaRohFznvpOrltdJzxFicWPYoUbjKKxIKytAXifn2ueEAU-yiR_hKPHnQkFVgkidgTwoMNnS5sicNccoYJjYLIxzJZiayyz_pdRVg-f-kkTI3UCfuQqQ_YrVvtqzx3X-9IG6YZaPvAhXvVXLpIYtIG805qb-HMXh1N3Ww4DT8Y5gemw0nSwlOGmXuGBbtS26NGnoxqFo0cZ90E5JvW0UVTRSQD7t3Qi26Rej1j-rtDUjYGyQSqXjx8I4ZBhinDxglBpcYFR2SlMdMCKUfim8lgr7kDrT7shbXw5aY9kP53kWp847vHgLc017aeYmfgHUhPgx6WKYPKO1_ZroQRwuLJQ0gLKSkUUfG0_Bm7F5p_kaj0vnBx798yKpPyuyXRuKsspOvRmrwZw_oCUwfkAX3sZ3OjuWvqVSjobE-7UXcZqJKd78JQITodyVpx3woCmSqVR9Cs1PCDWMJS_GHbVDn6wyamjD4-1RaJEEDwzQ2QPt3Tk1f7xtLYFPNLjmi2JrguM6KDUHrV9TFW3A-aF3-ZjZyFExAzM2EANQdgHWtMTFREsSTYPZkjfRSZ_os47Y';
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

		$result = curl_exec($ch);  
		print_r($result);
		echo("asd") ; 


		
	} 
} 
?> 



				