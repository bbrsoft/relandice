<?php
defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Jakarta');


class Change_token extends CI_Controller {	
 
	public function index()
	{ 
		require_once("user/data_user.php");
		if(!empty($user)){
			$id_user = $user->id;
			$this->db->query("UPDATE user SET `token`='' WHERE id='$id_user'   ");
			
			$table = "user";
			$sql = "`id`='$id_user'";
			$row = $this->model->row($table,$sql);
			if($row >= 1){
				$user = $this->model->get_obj($table,$sql)[0];
				$_SESSION['user'] = $user;
				echo("<script>  document.location.href='".base_url()."';   </script> ") ; 
				exit();
			} 
		} 
		
		
	} 
	
	  

	
} 

?> 