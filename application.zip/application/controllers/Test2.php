<?php
defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Jakarta');

class Test2 extends CI_Controller {	
 
	public function index()
	{ 
	
		echo("asd") ; 
	
	} 
} 
?> 