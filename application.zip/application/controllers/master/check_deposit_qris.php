<?php 

$client = "63b8d73d-725b-475a-933e-7cb488519acf";
$secret = "XqyTQf1o1R8nKn09cGsysW5McCZyhv";

$url_api = "https://api.onebrick.io";

	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url_api.'/v2/payments/auth/token');
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');

	curl_setopt($ch, CURLOPT_USERPWD, $client . ':' . $secret);

	$result = curl_exec($ch); 
	curl_close($ch);

	if(!empty($result)){
	$obj = json_decode($result);
	$token = $obj->data->accessToken;


	if(!empty($token)){
	

	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url_api.'/v2/payments/gs/qris/dynamic/'.$data->invoice);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
	
	
	$headers = array();
	$headers[] = 'Publicaccesstoken: Bearer '.$token;
	$headers[] = 'Content-Type: application/json';
	curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);



		$result = curl_exec($ch);   
		
		curl_close($ch);

		if(!empty($result)){  

			$obj = json_decode($result);
			if($obj->status == "200"){
				$data_respon = $obj->data;
				$status = strtolower($data_respon->status) ;
				
				if(($status == "paid") or ($status == "completed") ){
					
					$this->db->query("UPDATE deposit SET `status`='Paid' WHERE id='$id_deposit' "); 
					$total_usdt = $data->total_rfc;
					$id_user = $data->id_user;
					
					$this->db->query("UPDATE user SET `usdt`=`usdt`+'$total_usdt' WHERE id='$id_user'  ");
				


				} else {
					if($status == "expired"){
						$this->db->query("UPDATE deposit SET `status`='Expired' WHERE id='$id_deposit' "); 
					} 
				}
				
				
			}
									
		} 

		
	}
	}
 
?>