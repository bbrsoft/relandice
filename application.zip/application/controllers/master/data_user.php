<?php 
$login = "";
$user = "";
  

if((!empty($_SESSION['user_master']))){
	$user  = ($_SESSION['user_master']);
	$login = "ok";
}

if(isset($_POST['login'])){
	$user_id = in($_POST['user_id']);
	$password = in($_POST['password']);
	
	$row = $this->model->row('master'," user_id='$user_id' and password='$password'  ");
	if($row >= 1){
		 
		$user = $this->model->get_obj('master'," user_id='$user_id' and password='$password' ")[0];
		$_SESSION['user_master'] = $user;   
		$login = "ok";		
		$response['alert'] = "success";
		$response['respon'] = "Selamat Datang Di Dashboard Administrator ";	
	
	} else {
		$response['alert'] = "danger";
		$response['respon'] = "Maaf. Password Anda salah , Harap Masukkan dengan benar ";
	} 
	 
}






$table = "withdraw";
$sql = " with_pg='Yes' and status='Waiting' LIMIT 3";
$row = $this->model->row($table,$sql);
if($row >= 1){
	$dd = $this->model->get_obj($table,$sql);
	foreach($dd as $data){
		include("check_withdraw_auto.php");
	}
}
 

require_once("check_deposit.php");




?>