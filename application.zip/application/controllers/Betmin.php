<?php
defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Jakarta');


class Betmin extends CI_Controller {	
 
	public function index()
	{ 
		
		//require_once("user/data_user.php");
		
		if(!empty($_SESSION['user'])){
			
			$user  = ($_SESSION['user']);   
			if(!empty($user)){
				$id_user = $user->id;
				$this->db->query("UPDATE user SET `bet`=`bet`- 1 WHERE id='$id_user'   ");
			}  
			
			$minus = "";
			if(!empty($_GET['minus'])){  
			$minus = in($_GET['minus']) + 0 ; 
			if($minus > 0){
				$this->db->query("UPDATE user SET `bet`=`bet`- $minus WHERE id='$id_user'   ");
			} 
			}
			 
			$table = "user";
			$sql = "`id`='$id_user'";
			$row = $this->model->row($table,$sql);
			if($row >= 1){
				$user = $this->model->get_obj($table,$sql)[0];			
				if($user->bet <= 0){
					$this->db->query("update user set `bet`=0 where id='$id_user' ");									
				} 
			} 
			
			if($user->bet <= 0){
				echo("0") ; 
			}else {
				echo($user->bet) ; 
			}
			
	
		} else {
			echo(0) ; 
		}
			
		
	} 
	
	  

	
} 

?> 