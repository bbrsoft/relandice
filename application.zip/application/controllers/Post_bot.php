<?php
defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Jakarta');

class Post_bot extends CI_Controller {	
 
	public function index()
	{ 
		
		
		function remove_zero($string){
			$string = $string."#"; 
			$string = str_replace('0000000000000000#','',$string);
			$string = str_replace('000000000000000#','',$string); 
			$string = str_replace('00000000000000#','',$string); 
			$string = str_replace('0000000000000#','',$string); 
			$string = str_replace('000000000000#','',$string); 
			$string = str_replace('00000000000#','',$string); 
			$string = str_replace('0000000000#','',$string); 
			$string = str_replace('000000000#','',$string); 
			$string = str_replace('00000000#','',$string); 
			$string = str_replace('0000000#','',$string); 
			$string = str_replace('000000#','',$string); 
			$string = str_replace('00000#','',$string); 
			$string = str_replace('0000#','',$string); 
			$string = str_replace('000#','',$string); 
			$string = str_replace('00#','',$string); 
			$string = str_replace('0#','',$string); 
			$string = str_replace('#','',$string); 
			
			
			$exp = explode('.',$string);
			if(!empty($exp[1])){
				if($exp[0] <= 100){
					$len = strlen($exp[1]);
					if($len >= 5){
						$num = $exp[0].".";
						$numx = $exp[1];
						$num .= $numx[0].$numx[1].$numx[2].$numx[3].$numx[4].$numx[5];
						$string = $num ; 
					} 
				} else {
					$string = $exp[0];
				}
			}
			
			
			return $string; 
		}
		
		
		
		
		header("Content-type:application/json");
		$response = "error";
		$message = "Maaf. Terjadi Kesalahan Saat Mengirim Respon Ke Server ";

		require_once("user/data_user.php"); 
				
				
		if(!empty($user)){		
		$token = $user->token ;
		
		
		$amount = "";
		if(!empty($_GET['amount'])){ 
		$amount = in($_GET['amount']); 
		}
		$rule = "";
		if(!empty($_GET['rule'])){ 
		$rule = in($_GET['rule']); 
		}
		$multiplier = "";
		if(!empty($_GET['multiplier'])){ 
		$multiplier = in($_GET['multiplier']); 
		}
		$bet_value = "";
		if(!empty($_GET['bet_value'])){ 
		$bet_value = in($_GET['bet_value']); 
		}
		$crypto_active = "";
		if(!empty($_GET['crypto_active'])){ 
		$crypto_active = in($_GET['crypto_active']); 
		}
		 
		$money = "usd";
		if(!empty($_GET['money'])){ 
		$money = in($_GET['money']); 
		}
		 
		
		
		
		
		$table = "crypto";
		$sql = "`nama`='$crypto_active'";
		$row = $this->model->row($table,$sql);
		if($row >= 1){
		
		$data_crypto = $this->model->get_obj($table,$sql)[0];
		  
		$price = (number_format($data_crypto->$money , 20)) ; 
		
		if($price >= 100){
			$price = round($price);
		} 
		
		$price = remove_zero($price);
		
		$data = array(
			"currency" => $crypto_active,
			"game" => "dice",
			"amount" => $amount,
			"rule" => $rule,
			"multiplier" => $multiplier,
			"bet_value" => $bet_value 
		);


		$postdata = json_encode($data);
		echo($post_data) ; 
			

		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, 'https://wolfbet.com/api/v1/bet/place');
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 

		$headers = array();
		$headers[] = 'X-Requested-With: XMLHttpRequest';
		$headers[] = 'Authorization: Bearer '.$token;
		$headers[] = 'Content-Type: application/json';
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		 
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
		$error = "";


 
		$result = curl_exec($ch);
		if(!empty($result)){
			$result = json_decode($result);
			if(!empty($result->bet)){
				 
				
				$data = $result->bet;
				$hash = $data->hash; 
				$nonce = $data->nonce; 
				$currency = $data->currency; 
				$amount = $data->amount; 
				$profit = $data->profit; 
				$multiplier = $data->multiplier; 
				$bet_value = $data->bet_value; 
				$result_value = $data->result_value; 
				$state = $data->state;  
				$balance = $result->userBalance->amount; 
				$id_user = $user->id;
				
				 
				  
				 if($rule == "over"){
					 $rule2 = "High";
				 } else {
					 $rule2 = "Low";
				 }
				 
				$total_money = $profit * $price; 
				$total_money = (number_format($total_money , 20)) ; 
				$total_money = remove_zero($total_money);
				
				if($money == "usd"){
					$total_money = "$ ".$total_money;
				}else {
					$total_money = "Rp. ".$total_money;
				}
				
				$profit = remove_zero($profit);
				
				$this->db->query("INSERT INTO `history`
				(`rule`,`hash`, `nonce`, `currency`, `amount`, `profit`, `multiplier`, `bet_value`, `result_value`, `state`, `balance`, `id_user`,`money`,`total_money`) VALUES 
				('$rule2','$hash','$nonce','$currency','$amount','$profit','$multiplier','$bet_value','$result_value','$state','$balance','$id_user','$money','$total_money')
				");
				 
				
				$table = "history";
				$sql = " `hash`='$hash' ORDER BY id DESC LIMIT 1 ";
				$row = $this->model->row($table,$sql);
				if($row >= 1){
					$dd = $this->model->get_obj($table,$sql)[0];
					$message = $dd;
					 
					$response = "success";
				}
				
				 
			}  else {
				
				if(!empty($result->amount[0])){ $error = $result->amount[0]." ( $amount ) "; } else 
				if(!empty($result->rule[0])){ $error = $result->rule[0]." ( $rule ) "; } else 
				if(!empty($result->multiplier[0])){ $error = $result->multiplier[0]." ( $multiplier ) "; } else 
				if(!empty($result->bet_value[0])){ $error = $result->bet_value[0]." ( $bet_value ) "; } 				
				$message = $error;
			 
			
			}
		} else {
			$message = "Error Posting Bet On Server ";
		} 
				
		} else {
			$message = "Cryptocurrency Has Not found on server ";
		}
		} else {
			$message = "Please Login With Your Token Before Start BOT ";
		}
				
	$result_data = array();
	$result_data['response'] = $response;
	$result_data['message'] = $message;
	
	$result_data = json_encode($result_data);
	echo($result_data);

	
	} 
} 
?> 