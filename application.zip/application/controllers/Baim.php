<?php
defined('BASEPATH') OR exit('No direct script access allowed');

date_default_timezone_set('Asia/Jakarta');


class Baim extends CI_Controller {	 
	public function index($page = 'home',$id = -1,$filter = '')
	{
		
		
		$response = array();  
		$response['site'] = base_url();
		$response['id'] = $id;
		
		include("master/data_user.php");
		include("globe/settings.php");
		$response['login'] = $login;
		
		if($page <> "logout"){
		if(!empty($login)){	
			$response['user'] = $user;
			$this->load->view('master/index1',$response); 
			$this->load->view('master/'.$page,$response); 
			$this->load->view('master/index9',$response);
			
		} else {	
			$this->load->view('master/login',$response);  
		}
		
		} else {
			
			$_SESSION['user_master'] = ""; 
			echo('<script>  document.location.href="'.base_url().'";   </script> ') ; 
			exit();
			
		} 
	} 
	

	
	
	
} 

?> 

