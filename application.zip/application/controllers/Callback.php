<?php
defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Jakarta');

class Callback extends CI_Controller {	
 
	public function index()
	{ 
		echo("Callback") ;  
	} 
} 

?> 


