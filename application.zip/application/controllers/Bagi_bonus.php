<?php
defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Jakarta');


class Bagi_bonus extends CI_Controller {	
 
	public function index()
	{ 
		
		
		if(!empty($_SESSION['user'])){ 
			
			
			$time = "";
			if(!empty($_GET['date'])){ 
			$time = in($_GET['date']); 
			} else {
				$time = date('H:i:s');
			}
			
			$table = "settings";
			$sql = "`id`<>-1 LIMIT 1";
			$row = $this->model->row($table,$sql);
			if($row >= 1){
			$settings = $this->model->get_obj($table,$sql)[0];
			$bonus = $settings->ref_bonus;
			
				$user  = ($_SESSION['user']);  
				$secret = $user->secret; 
				$id_ref = $user->referral;
				$row = $this->model->row("user","id='$id_ref' ");
				if($row >= 1){
					 
					 $date = date('Y-m-d');
					$this->db->query("INSERT INTO `referral_bonus`
					(`id_user`,`total`,`asal`,`time`,`date`) VALUES 
					('$id_ref','$bonus','$secret','$time','$date')");
					 
					$this->db->query("update user set `usdt`=`usdt`+'$bonus' WHERE id='$id_ref'  ");
					
										  
				}
			}  
		}
		
		
	} 
	
	  

	
} 

?> 