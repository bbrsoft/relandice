<?php 							
		$result_point = rand(1, 99);
		$result_comma = rand(0, 99);
		$result_all = $result_point.".".$result_comma;
		$result_all += 0 ; 
		
		if($rule == "over"){
			if($bet_value <= $result_all){
					$state = "win";
			} else{
					$state = "loss";
			}
		} else {
			if($bet_value >= $result_all){
					$state = "win";
			} else{
					$state = "loss";
			}
		}
		
		if($state == "win"){
			$profit = $amount * $multiplier ; 
		} else {
			$profit = 0 - $amount; 
		} 
		
		$profit = round($profit, 2);
	
	
		if($profit > 0){
			$admin_lose = $profit - $amount;
			$this->db->query("UPDATE settings SET `total_lose`=`total_lose`+$admin_lose  ,`total_win`='0'  ");			
		} else {
			$this->db->query("UPDATE settings SET `total_lose`=`total_lose`-$amount  ,`total_win`='0'  ");
		} 
		
		
		$table = "settings";
		$sql = "`id` <> -1";
		$row = $this->model->row($table,$sql);
		if($row >= 1){
			$settings = $this->model->get_obj($table,$sql)[0];
			if($settings->total_lose >= $settings->target){
				$target = $settings->target * $settings->x; 
				$this->db->query("UPDATE `settings` SET `status_game`='boom' , `target`='$target' ,`total_lose`='0', `total_win`='0'  ");
			} 
		} 
		
		
		
		
		
	?>