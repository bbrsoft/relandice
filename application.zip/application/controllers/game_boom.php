<?php 							
		if($rule == "over"){
			$result_point = rand(1,  round ($bet_value) -1  );
			$result_comma = rand(0, 99);			
		} else {
			$result_point = rand(round ($bet_value) + 1,  99  );
			$result_comma = rand(0, 99);			
		}

		$result_all = $result_point.".".$result_comma;
		$result_all += 0 ; 

		if($rule == "over"){
			if($bet_value <= $result_all){
					$state = "win";
			} else{
					$state = "loss";
			}
		} else {
			if($bet_value >= $result_all){
					$state = "win";
			} else{
					$state = "loss";
			}
		}
		
		if($state == "win"){
			$profit = $amount * $multiplier ; 
		} else {
			$profit = 0 - $amount; 
		} 
		
		$profit = round($profit, 2);
	

		$this->db->query("UPDATE settings SET `total_win`=`total_win`+$amount  ,`total_lose`='0'  ");
	
		$table = "settings";
		$sql = "`id` <> -1";
		$row = $this->model->row($table,$sql);
		if($row >= 1){
			$settings = $this->model->get_obj($table,$sql)[0];
			if($settings->total_win >= $settings->target){ 
				$this->db->query("UPDATE `settings` SET `status_game`='normal' , `total_lose`='0', `total_win`='0'  ");
			} 
		}


?>