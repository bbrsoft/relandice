<?php
defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Jakarta');

class Arbitrage extends CI_Controller {	
 
	public function index($page = "home")
	{ 

		$success = "";
		if(!empty($_GET['success'])){ 
		$success = in($_GET['success']); 
		$alert = "success";
		$respon = $success; 
		}
		 
		if(empty($page)){
			$page = "home";
		} 
	
		$date = date('Y-m-d'); 
		$response = array();  
		$response['site'] = base_url(); 
		$response['page'] = $page; 
		 
		 			 
		$usdt_idr = 14208.0;
		$table = "crypto";
		$sql = "`nama`='usdt'";
		$row = $this->model->row($table,$sql);
		if($row >= 1){
			$data = $this->model->get_obj($table,$sql)[0];
			$usdt_idr = $data->idr  ; 
		}
		
		$response['usdt_idr'] = $usdt_idr;
		
		

		include("globe/settings.php"); 
		include("user/data_user.php"); 
		 
		$response['saldo'] = $saldo; 
		$response['saldo_active'] = 0; 
		$response['crypto_active'] = 'btc'; 
		 
		if($page <> "logout"){
			
			$response['user'] = $user;
			$this->load->view('frontend/index',$response); 
			$this->load->view('frontend/arbitrage/header',$response);
			$this->load->view('frontend/arbitrage/'.$page,$response);
			$this->load->view('frontend/arbitrage/footer',$response);
			$this->load->view('frontend/index9',$response);
			
		} else {
			$_SESSION['user'] = ""; 
			$_SESSION['broker'] = "";
			$_SESSION['test'] = "";
			
			echo('<script>  document.location.href="'.base_url().'?page=profile";   </script> ') ; 
			exit();
			
		}
		 
	}
	
	
	   
	  
	 

	
} 

?> 


