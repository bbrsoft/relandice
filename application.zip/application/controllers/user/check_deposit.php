<?php 
	$table = "deposit";
	$sql = "`id_user`='$id_user'  and paid_with='bri' and status='Waiting Payments' and type='usdt' and pg='Yes' ORDER BY id DESC ";
	$row = $this->model->row($table,$sql);
	if($row >= 1){
		$data = $this->model->get_obj($table,$sql)[0];
		$id_deposit = $data->id;
		$total_usdt = $data->total_usdt;
		include("check_deposit_va.php");
	} 
	 
	
	
	$table = "deposit";
	$sql = "`id_user`='$id_user'  and paid_with='qris' and status='Waiting Payments' and type='usdt' and pg='Yes' ORDER BY id DESC ";
	$row = $this->model->row($table,$sql);
	if($row >= 1){
		$data = $this->model->get_obj($table,$sql)[0];
		$id_deposit = $data->id;
		$total_usdt = $data->total_usdt; 
		
		include("check_deposit_qris.php");
	} 
	
	
	$table = "deposit";
	$sql = "`id_user`='$id_user'  and paid_with='dana' and status='Waiting Payments' and type='usdt' and pg='Yes' ORDER BY id DESC ";
	$row = $this->model->row($table,$sql);
	if($row >= 1){
		$data = $this->model->get_obj($table,$sql)[0];
		$id_deposit = $data->id;
		$total_usdt = $data->total_usdt; 
		
		include("check_deposit_dana.php");
	} 
	
	
?>