<?php  

$alert = "danger";
$respon = "Sorry - Deposit / Payment With VA BRI Is Maintennace . Please change your transfer destination ";
  
  
$client = $settings->client;
$secret = $settings->secret;
$url_api = "https://api.onebrick.io";
 

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url_api.'/v2/payments/auth/token');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');

curl_setopt($ch, CURLOPT_USERPWD, $client . ':' . $secret);

$result = curl_exec($ch);
if (curl_errno($ch)) {
	$alert = "danger";
	$respon = "Sorry - An error occurred while creating the Virtual Account ";
}
curl_close($ch); 


if(!empty($result)){
	$obj = json_decode($result);
	$token = $obj->data->accessToken;
	
	
	if(!empty($token)){
		
		
		$ch = curl_init();

		curl_setopt($ch, CURLOPT_URL, $url_api.'/v2/payments/gs/va/close');
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
		curl_setopt($ch, CURLOPT_POST, 1); 
		
		
		curl_setopt($ch, CURLOPT_POSTFIELDS, "{\n    \"amount\": $total_idr,\n    \"referenceId\": \"$invoice\",\n    \"expiredAt\": \"60\",\n    \"description\": \"Topup Balance\",\n    \"bankShortCode\": \"BRI\",\n    \"displayName\": \"$secret_user\"\n}");

		$headers = array();
		$headers[] = 'Publicaccesstoken: Bearer '.$token;
		$headers[] = 'Content-Type: application/json';
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

		$result = curl_exec($ch);
		  
		if (curl_errno($ch)) {
			$alert = "danger";
			$respon = "Sorry - An error occurred while creating the Virtual Account . Please Change Bank Destination ";
		}
		
		
		if(!empty($result)){
			
			
			$obj = json_decode($result);
			if($obj->status == "200"){
				
				$data_respon = $obj->data;
				
				$id_va = $data_respon->id;
				$bank_nama = $data_respon->displayName;
				$bank_rekening = $data_respon->accountNo;
				
				
				$expired = date('Y-m-d H:i:s',strtotime($data_respon->expiredAt.' +1 hours'));
				$tujuan = strtoupper($paid_with)." Virtual <br /> Account No : ".$bank_rekening."<br /> AN : ".$bank_nama;
				
				  
				$this->db->query("INSERT INTO `deposit`
				(`earn`,`total_rfc`, `total`, `tujuan`, `id_user`,  `invoice`, `secret`, `type`, `type_money`, `pg`, `pg_bank`, `pg_rekening`, `pg_nama`, `pg_id`,  `paid_with`,`id_copy`,`expired`) VALUES 
				('$earn','$total_usdt','$total_idr','$tujuan','$id_user','$invoice','$secret_user','usdt','Rp','Yes','BRI','$bank_rekening','$bank_nama','$id_va','$paid_with','$id_copy','$expired' )");
				
				echo("<script>  document.location.href='".$redirect."';   </script> ") ; 
				exit();
 
			} 
		} 
		
		curl_close($ch);
		
		
	}
} 


 


 
?>
