<?php 
$client = $settings->client;
$secret = $settings->secret;
$url_api = "https://api.onebrick.io";
$saldo_bricks = 0 ;
 

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url_api.'/v2/payments/auth/token');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');

curl_setopt($ch, CURLOPT_USERPWD, $client . ':' . $secret);

$result = curl_exec($ch);
if (curl_errno($ch)) {
	$alert = "danger";
	$respon = "Sorry - An error occurred while creating the Virtual Account ";
}
curl_close($ch); 

if(!empty($result)){
	$obj = json_decode($result);
	$token = $obj->data->accessToken;
	
	
	if(!empty($token)){
		
		
		$ch = curl_init();

		curl_setopt($ch, CURLOPT_URL, $url_api.'/v2/payments/gs/balance');
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);  
		$headers = array();
		$headers[] = 'Publicaccesstoken: Bearer '.$token;
		$headers[] = 'Content-Type: application/json';
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

		$result = curl_exec($ch);
		  
		if (curl_errno($ch)) {
			$alert = "danger";
			$respon = "Sorry - An error occurred while creating the Virtual Account . Please Change Bank Destination ";
		}
		
		if(!empty($result)){
			
			$obj = json_decode($result);
			if($obj->status == "200"){
				
				
				$saldo_bricks = ($obj->data->totalAvailableBalance) - 10000;
				
			}
		
			
			
		} 
		
		curl_close($ch);
		
		
	}
} 
 
	
	
?>