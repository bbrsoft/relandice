<?php 
$login = "";
$user = "";
$response['saldo'] = 0;
$response['id_user']  = 0; 
$this->db->query("UPDATE `user` set `bet`= 0 WHERE  `bet` < 0  ");
$id_user = 0 ;



$kode_uang = "$";
$round_uang = 0; 
$kali_uang = 1; 

if(!empty($_SESSION['arcur'])){
	$arcur = $_SESSION['arcur']; 
	$response['arcur']= $arcur; 
	
	
	if($arcur == "idr"){ $kode_uang = "Rp.";  $round_uang = 0 ; $kali_uang = 1; } 
	if($arcur == "myr"){ $kode_uang = "RM."; $round_uang = 5;  $kali_uang = 0.00027; } 
	if($arcur == "usd"){ $kode_uang = "$"; $round_uang = 8; $kali_uang = 0.000064; } 
	if($arcur == "rupee"){ $kode_uang = "₹"; $round_uang = 4; $kali_uang = 0.0054;  } 


} 

$response['round_uang'] = $round_uang; 
$response['kali_uang'] = $kali_uang; 
$response['kode_uang'] = $kode_uang; 
				
				
if(isset($_POST['register_secret'])){
	$secret = in($_POST['secret']);
	$password = in($_POST['password']);
	$referral = in($_POST['referral']);

	$table = "user";
	$sql = "`secret`='$referral'";
	$row = $this->model->row($table,$sql);
	if($row >= 1){
	$ref = $this->model->get_obj($table,$sql)[0];
	$id_ref = $ref->id; 
	
	$tersedia = $settings->ref_bonus;
	
	
	$row = $this->model->row("user","secret='$secret' ");
	if($row >= 1){
		$alert = "danger";
		$respon = "Sorry - This Secret/Username Is Not Allowed, Please Change";
	}else {
		$alert = "success";
		$respon = "Your Account Has Created . Now You can setup BOT With your TOKEN . ";
		
		
		$this->db->query("INSERT INTO `user` (`secret` , `password`,`bet`,`referral`,`tersedia`,`tersedia_max` )VALUES ('$secret','$password','0','$id_ref','$tersedia','$tersedia' )  ");
		$table = "user";
		$sql = "`secret`='$secret' ";
		$row = $this->model->row($table,$sql);
		if($row >= 1){
			$user = $this->model->get_obj($table,$sql)[0];
			$_SESSION['user'] = $user; 
		} 
	}
	} else {
		$alert = "danger";
		$respon = "Sorry . Referral Code Is Not Valid/Not Found ";
		
	}
} 



if((!empty($_SESSION['user']))){
	$user  = ($_SESSION['user']);  
 	
	$response['id_user'] = $user->id ;
	$login = "ok";
	$id_user = $user->id;
	$secret = $user->secret;
	$table = "user"; 
	$sql = "`secret`='$secret'";
	$row = $this->model->row($table,$sql);
	if($row >= 1){
		$user = $this->model->get_obj($table,$sql)[0];
		$session_code = $user->session_code; 
		
		$_SESSION['user'] = $user ;  
		$response['user'] = $user;   
		$response['id_user'] = $user->id ;
		
		$token = $user->token ;
		
		if(!empty($_SESSION['session_code'])){
			if($_SESSION['session_code'] <> $session_code){
				logout();
				echo('<script>document.location.href="'.base_url().'/?page=profile";</script> ') ; 
			} 
		} else {
				logout();
				echo('<script>document.location.href="'.base_url().'/?page=profile";</script> ') ; 
		}
		  
		if(!empty($user->token)){ 
		$saldo['rfc'] = $user->bet;
		
		
		$response['saldo'] = $saldo;   
		} else {
			$response['saldo'] = [];   
		}
	}  
}



if(isset($_POST['login_token'])){
	$token = in($_POST['token']);
	 
	if(!empty($user)){
		$id_user = $user->id;
		$secret = $user->secret;
		$this->db->query("UPDATE user SET `token`='$token' WHERE secret='$secret'  ");
		
		$table = "user";
		$sql = "`id`='$id_user'";
		$row = $this->model->row($table,$sql);
		if($row >= 1){
			$user = $this->model->get_obj($table,$sql)[0];
			$_SESSION['user'] =$user ; 
			$response['user'] = $user;  
			
				$saldo['rfc'] = $user->bet; 
				$response['saldo'] = $saldo;   
			echo('<script>document.location.href="'.base_url().'/";</script> ') ; 
			exit();
		}
	} 
} 




   

if(isset($_POST['login_secret'])){
	$secret = in($_POST['secret']);
	$password = in($_POST['password']);
	$broker = in($_POST['broker']);
	$session_code = date('ymdhis').rand(0,999999);
	
	$table = "user";
	$sql = "`secret`='$secret' and password='$password' ";
	$row = $this->model->row($table,$sql);
	if($row >= 1){ 
		$user = $this->model->get_obj($table,$sql)[0];
		$_SESSION['user'] = $user; 
		$login = "Yes";
		$response['user'] = $user;    
		$id_user = $user->id;
		$_SESSION['session_code'] = $session_code; 
		$_SESSION['logout_all'] = "yes";
		$this->db->query("UPDATE user SET `session_code`='$session_code' WHERE id='$id_user'  ");
		
		
		if(!empty($user->token)){
					
			$saldo['rfc'] = $user->bet;
			$response['saldo'] = $saldo;   
		}
		
		if($broker == "wolf"){ 
			$_SESSION['broker'] = "wolf"; 		
			echo('<script>document.location.href="'.base_url().'/";</script> ') ; 
			exit();
		}
		
		
		if($broker == "arbitrage"){ 
			$_SESSION['broker'] = "arbitrage"; 			
			echo('<script>document.location.href="'.base_url().'/arbitrage";</script> ') ; 
			exit();
		}
		
		
		
	} else {
		$alert = "danger";
		$respon = "Sorry - Username / Password is wrong";
		
	}
} 

   
   

if(!empty($_GET['secret'])){ 
$secret = in($_GET['secret']); 
$password = "";
if(!empty($_GET['password'])){ 
$password = in($_GET['password']); 
}

	
	$table = "user";
	$sql = "`secret`='$secret' and password='$password' and strategy='Yes' ";
	$row = $this->model->row($table,$sql);
	if($row >= 1){ 
		$user = $this->model->get_obj($table,$sql)[0];
		$id_user = $user->id;
		$login = "Yes";
		$response['user'] = $user;    
		$response['id_user'] = $id_user;    
		
		if(!empty($user->token)){
			
			$saldo['rfc'] = $user->bet;
			$response['saldo'] = $saldo;   
		}
		
		
		
		$alert = "success";
		$respon = "You Are Login By Strategy Now ";
		
		
	} else {
		$alert = "danger";
		$respon = "Sorry - Username / Password is wrong";
		
	}
} 




   
   
if(isset($_POST['update_password'])){
	$new_secret = in($_POST['new_secret']);
	$new_password = in($_POST['new_password']);
	$old_password = in($_POST['old_password']);
	$id_user = $user->id;
	
	$row = $this->model->row("user","secret='$new_secret' and id<>'$id_user' ");
	if($row >= 1){
		$alert = "danger";
		$respon = "Sorry - This Username has already exits";
	}else {		
		if(strtolower($user->password) == strtolower($old_password)){
		$this->db->query("UPDATE user SET `secret`='$new_secret' , `password`='$new_password' WHERE id='$id_user' ");
		$alert = "success";
		$respon = "Success Update Username and password"; 
		
		$table = "user";
		$sql = "`id`='$id_user' ";
		$row = $this->model->row($table,$sql);
		if($row >= 1){ 
			$user = $this->model->get_obj($table,$sql)[0];
			$_SESSION['user'] = $user; 
			$login = "Yes";
			$response['user'] = $user;    
		}
		
		} else {
			$alert = "danger";
			$respon = "Sorry - Old Password is Wrong ";
		}
	}
} 


$alert_withdraw = "";


if(!empty($user)){
$secret = $user->secret; 



if(isset($_POST['withdraw_now_usdt'])){
	$wallet = in($_POST['wallet']);
	$total = in($_POST['total']);
	$type = in($_POST['type']);
	
	
	$usdt_idr = 14208.0;
	$table = "crypto";
	$sql = "`nama`='usdt'";
	$row = $this->model->row($table,$sql);
	if($row >= 1){
		$data = $this->model->get_obj($table,$sql)[0];
		$usdt_idr = $data->idr - 1000 ; 
	}


	$destination = "";
	if($type == "Wallet USDT(BEP20)"){
		$destination = $wallet; 
		$total_text = $total." USDT ";
	} else {
		$total_text = "Rp. ".uang($total * $usdt_idr,0);	
		$destination .= $type."<br />Account Number : ".$wallet ; 
	}
	
	
	if($total >= 1){
		
		if($user->usdt >= $total){
			
			$invoice = date('YmdHis').$user->id;
			 $total_idr = round($total * $usdt_idr);
			
			$this->db->query("UPDATE user SET `usdt`=`usdt`-$total WHERE id='$id_user'  ");
			$this->db->query("INSERT INTO `withdraw`
			(`invoice`,`secret`, `total`, `wallet`, `type`, `crypto` ,`total_text`,`rekening`,`total_idr`) VALUES 
			('$invoice','$secret','$total','$destination','$type','USDT','$total_text','$wallet','$total_idr' )");
			
			
			 
			 
			 include("saldo_bricks.php");
			 if($type <> "Wallet USDT(BEP20)"){
				if($saldo_bricks > $total_idr){
					
					$bank_rekening = $wallet;
					$bank_jenis = $type;
					$secret_user = $user->secret;		
					
					require_once("isset_withdraw_auto.php");
				} else {
					echo("No saldo") ; 
				}
			 }
			 
			
			
			$alert = "success";
			$respon = "Success Request Withdrawal ($total USDT) ";
		}
		
	} else {
		$alert = "danger";
		$respon = "Sorry. Minimum Withdrawal Is 1 USDT";
	}
}  




if(isset($_POST['withdraw_now_usdt_earn'])){
	$wallet = in($_POST['wallet']);
	$total = in($_POST['total']);
	$type = in($_POST['type']);
	
	
	$usdt_idr = 14208.0;
	$table = "crypto";
	$sql = "`nama`='usdt'";
	$row = $this->model->row($table,$sql);
	if($row >= 1){
		$data = $this->model->get_obj($table,$sql)[0];
		$usdt_idr = $data->idr - 1000 ; 
	}


	$destination = "";
	if($type == "Wallet USDT(BEP20)"){
		$destination = $wallet; 
		$total_text = $total." USDT ";
	} else {
		$total_text = "Rp. ".uang($total * $usdt_idr,0);	
		$destination .= $type."<br />Account Number : ".$wallet ; 
	}
	
	
	if($total >= 1){
		
		if($user->usdt_earn_all >= $total){
			
			$invoice = date('YmdHis').$user->id;
			 $total_idr = round($total * $usdt_idr);
			
			$this->db->query("UPDATE user SET `usdt_earn_all`=`usdt_earn_all`-$total WHERE id='$id_user'  ");
			$this->db->query("INSERT INTO `withdraw`
			(`invoice`,`secret`, `total`, `wallet`, `type`, `crypto` ,`total_text`,`rekening`,`total_idr`) VALUES 
			('$invoice','$secret','$total','$destination','$type','USDT','$total_text','$wallet','$total_idr' )");
			
			
			 
			 
			 include("saldo_bricks.php");
			 if($type <> "Wallet USDT(BEP20)"){
				if($saldo_bricks > $total_idr){
					
					$bank_rekening = $wallet;
					$bank_jenis = $type;
					$secret_user = $user->secret;		
					
					require_once("isset_withdraw_auto.php");
				} else {
					echo("No saldo") ; 
				}
			 }
			 
			
			
			$alert = "success";
			$respon = "Success Request Withdrawal ($total USDT) ";
		}
		
	} else {
		$alert = "danger";
		$respon = "Sorry. Minimum Withdrawal Is 1 USDT";
	}
}

}





   
if(!empty($alert)){
	$response['alert'] = $alert;
	$response['respon'] = $respon;
} 

	$response['alert_withdraw'] = $alert_withdraw;







if(!empty($user)){
	
if(isset($_POST['save_settings'])){
	$data = '';
	foreach($_POST as $name => $val){
		if($data == ""){
			$data .= $name.":".$val; 
		} else {
			$data .= ",".$name.":".$val ; 
		}
	}
	if($data){
		
		$money = "";
		if(!empty($_POST['money'])){ 
			$money = in($_POST['money']); 
			$this->db->query("UPDATE user SET `cur_reland`='$money' WHERE id='$id_user'  ");
		}
		 
		
		$row = $this->model->row("user_settings","id_user='$id_user' ");
		if($row >= 1){
			$this->db->query("UPDATE user_settings SET `settings`='$data' WHERE id_user='$id_user'  ");
			
		}else {
			$this->db->query("INSERT INTO `user_settings`(`id_user`, `settings`) VALUES ('$id_user','$data') ");
		}
		
		
		
			
		$id_user = $user->id;
		$table = "user"; 
		$sql = "`id`='$id_user'";
		$row = $this->model->row($table,$sql);
		if($row >= 1){
			$user = $this->model->get_obj($table,$sql)[0];
			$_SESSION['user'] = $user ;  
			$response['user'] = $user;   
		}
		
	} 
}  
} 











if(isset($_POST['deposit_now_usdt'])){
	$deposit_idrx = in($_POST['deposit_idrx']);
	$paid_with = in($_POST['paid_with']);
	
	$total_idr = $deposit_idrx;
	$total_usdt = in($_POST['deposit_usdtx']);
	 
	
	$usdt_idr = 15208.0;
	$table = "crypto";
	$sql = "`nama`='usdt'";
	$row = $this->model->row($table,$sql);
	if($row >= 1){
		$data = $this->model->get_obj($table,$sql)[0];
		$usdt_idr = $data->idr; 
	}

	
	if($deposit_idrx >= 20000){
		
		
		
		
		if($paid_with <> "usdt"){
		$len = strlen($deposit_idrx);
		$last = $len - 3; 
		$tt = "";
		for ($i = 0; $i <= $len -1; $i++) {
		if($i >= $last){
		$tt .= 0;
		} else {
		$tt .= $deposit_idrx[$i];
		}
		} 
		$total_idr = $tt;
		$total_usdt = $total_idr / $usdt_idr;
		$total_usdt = round($total_usdt, 5);
		}
		
		
		$invoice = date('Ymdhis').$user->id;
		$secret_user = $user->secret; 
		
		$alert = "danger";
		$respon = "Sorry. We Have Maintennace in payment with ".$paid_with;
		
		$redirect = $site."/?page=payment&inv=".$invoice ;
		$id_copy = "0";
		$earn = "No";


		if($paid_with == "qris"){
			require_once("deposit_isset_qris.php");
		} 
		
		if($paid_with == "bri"){
			require_once("deposit_isset_va.php");
		} 
		
		
		if($paid_with == "dana"){
			require_once("deposit_isset_dana.php");
		} 
		
		if($paid_with == "usdt"){
		
				$wallet_usdt = $settings->wallet_usdt ;
				$tujuan = "USDT (BEP20)<br />".$wallet_usdt;
				
				$this->db->query("INSERT INTO `deposit`
				(`earn`,`total_rfc`, `total`, `tujuan`, `id_user`,  `invoice`, `secret`, `type`, `type_money`, `pg`,  `paid_with`,`id_copy`) VALUES 
				('$earn','$total_usdt','$total_usdt','$tujuan','$id_user','$invoice','$secret_user','usdt','USDT','No','$paid_with','$id_copy' )");
				
				
				echo("<script>  document.location.href='".$site."/?page=payment&inv=".$invoice."';   </script> ") ; 
				exit();
 
 
		} 
		
		 
			
	} else {
		$alert = "danger";
		$respon = "Sorry . Minimum Deposit is Rp 10,000";
		
	}
} 











if(isset($_POST['deposit_now_usdt_earn'])){
	$deposit_idrx = in($_POST['deposit_idrx']);
	$paid_with = in($_POST['paid_with']);
	
	$total_idr = $deposit_idrx;
	$total_usdt = in($_POST['deposit_usdtx']);
	 
	
	$usdt_idr = 15208.0;
	$table = "crypto";
	$sql = "`nama`='usdt'";
	$row = $this->model->row($table,$sql);
	if($row >= 1){
		$data = $this->model->get_obj($table,$sql)[0];
		$usdt_idr = $data->idr; 
	}

	
	if($deposit_idrx >= 20000){
		
		
		
		
		if($paid_with <> "usdt"){
		$len = strlen($deposit_idrx);
		$last = $len - 3; 
		$tt = "";
		for ($i = 0; $i <= $len -1; $i++) {
		if($i >= $last){
		$tt .= 0;
		} else {
		$tt .= $deposit_idrx[$i];
		}
		} 
		$total_idr = $tt;
		$total_usdt = $total_idr / $usdt_idr;
		$total_usdt = round($total_usdt, 5);
		}
		
		
		$invoice = date('Ymdhis').$user->id;
		$secret_user = $user->secret; 
		
		$alert = "danger";
		$respon = "Sorry. We Have Maintennace in payment with ".$paid_with;
		
		$redirect = $site."/?page=payment&inv=".$invoice ;
		$id_copy = "0";
		$earn = "Yes";
		
		if($paid_with == "qris"){
			require_once("deposit_isset_qris.php");
		} 
		
		if($paid_with == "bri"){
			require_once("deposit_isset_va.php");
		} 
		
		
		if($paid_with == "dana"){
			require_once("deposit_isset_dana.php");
		} 
		
		if($paid_with == "usdt"){
		
				$wallet_usdt = $settings->wallet_usdt ;
				$tujuan = "USDT (BEP20)<br />".$wallet_usdt;
				
				$this->db->query("INSERT INTO `deposit`
				(`earn`,`total_rfc`, `total`, `tujuan`, `id_user`,  `invoice`, `secret`, `type`, `type_money`, `pg`,  `paid_with`,`id_copy`) VALUES 
				('earn','$total_usdt','$total_usdt','$tujuan','$id_user','$invoice','$secret_user','usdt','USDT','No','$paid_with','$id_copy' )");
				
				
				echo("<script>  document.location.href='".$site."/?page=payment&inv=".$invoice."';   </script> ") ; 
				exit();
 
 
		} 
		
		 
			
	} else {
		$alert = "danger";
		$respon = "Sorry . Minimum Deposit is Rp 10,000";
		
	}
} 






















if(isset($_POST['invest'])){
	
	$total_usdt = in($_POST['total_usdt']);   
	
	
	$row = $this->model->row("copy_data","total_usdt='$total_usdt' and id_user='$id_user' and status='Running' ");
	if($row >= 1){
		$alert = "danger";
		$respon = "Sorry. You have duplicate open position with same amount ($total_usdt) ";
	}else { 
	
	$auto_wd = false; 
	if($user->withdraw_with == "usdt"){
		if(!empty($user->wallet)){
			$auto_wd = true; 
		} 
	} else {
		if((!empty($user->bank_jenis)) and (!empty($user->bank_nama)) and (!empty($user->bank_rekening))){
			$auto_wd = true;
		}	
	}
	
	
	
	
	
	if($auto_wd == true){
	
	$usdt_idr = 15208.0;
	$table = "crypto";
	$sql = "`nama`='usdt'";
	$row = $this->model->row($table,$sql);
	if($row >= 1){
		$data = $this->model->get_obj($table,$sql)[0];
		$usdt_idr = $data->idr; 
	}
	
	
	
	 
	$total_usdt = in($_POST['total_usdt']);
	$total_idr = $total_usdt * $usdt_idr;
	$deposit_idrx = $total_idr; 




	
	if($total_usdt >= 2){
		if($user->usdt >= $total_usdt){
		
		$table = "copy_plan";
		$sql = "`total` <= $deposit_idrx ORDER BY percent DESC LIMIT 1";
		$row = $this->model->row($table,$sql);
		if($row >= 1){
			$dd = $this->model->get_obj($table,$sql)[0];
			$min = $dd->min;
			$max = $dd->max;
			$percent = random($min, $max);
			
			$jam = $dd->jam;
		} 
		
		
		
		
		$invoice = date('Ymdhis').$user->id;
		$secret_user = $user->secret; 
		 
		$newtimestamp = strtotime(date('Y-m-d H:i:s'). ' +'.$jam.' seconds');
		$date_stop =  date('Y-m-d H:i:s', $newtimestamp);
		$date_start= date('Y-m-d H:i:s'); 
		
		$this->db->query("UPDATE user SET `usdt`=`usdt`-$total_usdt WHERE id='$id_user'  ");
		
		
		$data = array();
		$data['id_user'] = $id_user ;
		$data['total'] = $total_idr ;
		$data['total_usdt'] = $total_usdt ;
		$data['percent'] = $percent;
		$data['date_start'] = $date_start;
		$data['date_stop'] = $date_stop;
		$data['invoice'] = $invoice;
		$data['status'] = "Running";
		$this->db->insert('copy_data',$data);
		$id_copy  = $this->db->insert_id(); 
		
		echo("<script>  document.location.href='".$site."/arbitrage/';   </script> ") ;  
			 
			 
		} else {
			$alert = "danger";
			$respon = "Sorry . Your Balance Not Enought   ";
		}
		
	} else {
		$alert = "danger";
		$respon = "Sorry . Minimum amount is 2 USDT  ";
	}
	
	} else {
		$alert = "danger";
		$respon = "Sorry , You must Setup Auto Withdraw / Bank Account Before Invest Auto Trade";
		
	}
	
}

}







if(isset($_POST['save_bank'])){
	$bank_jenis = in($_POST['bank_jenis']);
	$bank_rekening = in($_POST['bank_rekening']);
	$bank_rekening = str_replace(' ','',$bank_rekening);
	$bank_rekening = preg_replace("/[^0-9]/", "",$bank_rekening);

	
	$bank_nama = in($_POST['bank_nama']); 
	
	$withdraw_with = in($_POST['withdraw_with']);
	$wallet = in($_POST['wallet']);
	  
		
	$this->db->query("UPDATE user SET `bank_jenis`='$bank_jenis',`bank_rekening`='$bank_rekening',`bank_nama`='$bank_nama',`withdraw_with`='$withdraw_with',`wallet`='$wallet' WHERE id='$id_user' ");
	
	$alert = "success";
	$respon = "Success Update Bank Accounts ";
	
} 













if(isset($_POST['kyc_upload'])){
	$nama = in($_POST['nama']);
	$alamat = in($_POST['alamat']);
	require_once("isset_image.php");
	if(!empty($image)){
		
		if(!empty($image2)){
			
			$this->db->query("UPDATE user SET `kyc_name`='$nama',`kyc_address`='$alamat',`kyc_ktp`='$image',`kyc_selfie`='$image' ,`kyc_status`='Waiting'  WHERE id='$id_user' ");
			$alert = "success";
			$respon = "Success. Upload Your Identity . Please wait for approval within 1-3 business days ";
			
		} else {
			$alert = "danger";
			$respon = "Sorry. Your Selfie Image is not valid , Please Upload With (jpg,png) Extension";
		}
		
	} else {
		$alert = "danger";
		$respon = "Sorry. Your ID Card Image is not valid , Please Upload With (jpg,png) Extension";
	}
	
} 








if(isset($_POST['claim'])){
		
		
	$table = "user";
	$sql = "`referral`='$id_user' and `total_lose` > 0 and `tersedia` > 0";
	$row = $this->model->row($table,$sql);
	if($row >= 1){
		$dd = $this->model->get_obj($table,$sql);
		foreach($dd as $ref){
			$total_dibagikan = ($ref->total_lose * $ref->tersedia_max)/ 100;
			if($total_dibagikan >= $ref->tersedia){
				$total_dibagikan = $ref->tersedia ; 
			} 
			
			$id_ref = $ref->id;
			$this->db->query("UPDATE user SET `total_lose`='0' , `total_dibagikan`=`total_dibagikan`+$total_dibagikan , 
			`tersedia`=`tersedia`-$total_dibagikan  WHERE id='$id_ref' ");	
			
			$this->db->query("UPDATE user SET `usdt`=`usdt`+$total_dibagikan WHERE id='$id_user'  ");
	
		}
	} 
	
	
	$alert = "success";
	$respon = "Success Claim Your Commision to your wallet ";
	
} 






































if(!empty($alert)){
	$response['alert'] = $alert;
	$response['respon'] = $respon;
	
	$table = "user";
	$sql = "`id`='$id_user'";
	$row = $this->model->row($table,$sql);
	if($row >= 1){
		$user = $this->model->get_obj($table,$sql)[0];
		$response['user'] = $user;
	} 
	
	
} 





$arcur = "";
if(!empty($_GET['arcur'])){ 
$arcur = in($_GET['arcur']); 
$_SESSION['arcur'] = $arcur;
}



 







$usdt_idr = 15208.0;

$table = "crypto";
$sql = "`nama`='usdt'";
$row = $this->model->row($table,$sql);
if($row >= 1){
	$data = $this->model->get_obj($table,$sql)[0];
	$usdt_idr = $data->idr; 
}
$response['usdt_idr'] = $usdt_idr;






include("check_deposit.php");
include("check_withdraw.php");
 
if(isset($_POST['wolf'])){
	$_SESSION['broker'] = "wolf"; 
	echo("<script>  document.location.href='".$site."/';   </script> ") ; 
	exit();
}

if(isset($_POST['copytrade'])){
	$_SESSION['broker'] = "copytrade"; 
	echo("<script>  document.location.href='".$site."/arbitrage';   </script> ") ; 
	exit();
}


?>



