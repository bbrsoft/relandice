<?php 
	$id_api = "";
	if(!empty($_GET['id_api'])){ 
	$id_api = in($_GET['id_api']); 
	
	$table = "1x_api";
	$sql = "`id`='$id_api'";
	$row = $this->model->row($table,$sql);
	if($row >= 1){
		$data_api = $this->model->get_obj($table,$sql)[0];
		$api = $data_api->api;
		
		
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, 'https://wolfbet.com/api/v1/user/balances');
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');

	 
		$headers = array();
		$headers[] = 'X-Requested-With: XMLHttpRequest';
		$headers[] = 'Authorization: Bearer '.$api;
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		$result = curl_exec($ch); 
		curl_close($ch); 
		$saldo = [];
		
		if(!empty($result)){			
			$result = json_decode($result); 
			if(empty($result->error)){  
				foreach($result->balances as $data){
					$saldo[$data->currency] = $data->amount;
				}
			}
		} 
		$saldo['rfc'] = 99999999999 ;
		$response['saldo'] = $saldo; 
				
		$user = new stdClass();
		$user->id = -1 ;
		$user->secret = 'Iframe' ;
		$user->bet = 9999999999  ;
		$user->token = $api  ;
		
		
		
	} 
	}
	
	
	
?>