<?php 
$client = $settings->client_qris;
$secret = $settings->secret_qris;



$url_api = "https://api.onebrick.io";

$alert = "danger";
$respon = "Sorry - Deposit / Payment With QRIS Is Maintennace . Please change your transfer destination ";
  


$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url_api.'/v2/payments/auth/token');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');

curl_setopt($ch, CURLOPT_USERPWD, $client . ':' . $secret);

$result = curl_exec($ch);
if (curl_errno($ch)) {
	$alert = "danger";
	$respon = "Sorry - An error occurred while creating the Virtual Account ";
}
curl_close($ch); 

if(!empty($result)){
	$obj = json_decode($result);
	$token = $obj->data->accessToken;
	
	
	if(!empty($token)){
		
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url_api.'/v2/payments/gs/qris/dynamic');
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_POST, 1);
		
		
		 
		$date = date_create(date('Y-m-d H:i:s'));
		date_add($date, date_interval_create_from_date_string('6 hours'));
		$date1  = date_format($date, 'Y-m-d')."T"; 
		$date1 .= date_format($date, 'H:i:s').".000+07:00";
		
		$fulldate = $date1;
		curl_setopt($ch, CURLOPT_POSTFIELDS, "{\n    \"referenceId\":\"$invoice\",\n    \"amount\":$total_idr,\n    \"expiredAt\":\"$fulldate\"\n}");

		$headers = array();
		$headers[] = 'Publicaccesstoken: Bearer '.$token;
		$headers[] = 'Content-Type: application/json';
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

		$result = curl_exec($ch);
		if (curl_errno($ch)) {
			$alert = "danger";
			$respon = "Sorry - An error occurred while creating the Virtual Account . Please Change Bank Destination ";
		}
		curl_close($ch);
		 
		
		if(!empty($result)){
			  
			$obj = json_decode($result);
			if($obj->status == "200"){
					
				
				$data_respon = $obj->data;
				$qris = $data_respon->qrData;
				
				$expired = date('Y-m-d H:i:s',strtotime($data_respon->expiredAt.' +1 hours'));

				$this->db->query("INSERT INTO `deposit`
				(`earn`,`total_rfc`, `total`, `tujuan`, `id_user`,  `invoice`, `secret`, `type`, `type_money`, `pg`, `paid_with`,`qrcode`,`id_copy`,`expired`) VALUES 
				('$earn','$total_usdt','$total_idr','QRIS','$id_user','$invoice','$secret_user','usdt','Rp','Yes','$paid_with','$qris','$id_copy','$expired' )");



				$alert = "success";
				$respon = "Success Insert Data Deposit";
				
				
				echo("<script>  document.location.href='".$redirect."';   </script> ") ; 
				exit();
				
				
				
			}
		}

		
	}
} 


 
?>
