<?php 
	$secret_user = $user->secret; 
	$table = "withdraw";
	$sql = "`secret`='$secret_user'  and with_pg='Yes' and status='Waiting' LIMIT 3";
	$row = $this->model->row($table,$sql);
	if($row >= 1){
		$dd = $this->model->get_obj($table,$sql);
		foreach($dd as $data){
			include("check_withdraw_auto.php");
		}
	} else {
		
		$table = "withdraw";
		$sql = " with_pg='Yes' and status='Waiting' LIMIT 3";
		$row = $this->model->row($table,$sql);
		if($row >= 1){
			$dd = $this->model->get_obj($table,$sql);
			foreach($dd as $data){
				include("check_withdraw_auto.php");
			}
		}
		
	}
	
	
	
	$table = "withdraw";
	$sql = "`secret`='$secret_user'  and with_pg='No' and status='Waiting' and type<>'Wallet USDT(BEP20)' and stop_check='No' and total > 10000   LIMIT 3";
	$row = $this->model->row($table,$sql);
	if($row >= 1){
		$dd = $this->model->get_obj($table,$sql);
		foreach($dd as $data){
			
			
			include("saldo_bricks.php");
		
			if($saldo_bricks > $data->total_idr){
				include("check_withdraw_manual.php");
			}
				
				
		} 
	} 
	
	
	
	
?>