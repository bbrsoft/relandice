<?php 

$client = $settings->client_qris;
$secret = $settings->secret_qris;

$url_api = "https://api.onebrick.io";

	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url_api.'/v2/payments/auth/token');
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');

	curl_setopt($ch, CURLOPT_USERPWD, $client . ':' . $secret);

	$result = curl_exec($ch); 
	curl_close($ch);

	if(!empty($result)){
	$obj = json_decode($result);
	$token = $obj->data->accessToken;


	if(!empty($token)){
	

	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url_api.'/v2/payments/gs/qris/dynamic/'.$data->invoice);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
	
	
	$headers = array();
	$headers[] = 'Publicaccesstoken: Bearer '.$token;
	$headers[] = 'Content-Type: application/json';
	curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);



		$result = curl_exec($ch);   
		
		$brick = "";
		if(!empty($_GET['brick'])){ 
		$brick = in($_GET['brick']); 
		print_r($result);
		}
		 
		
		
		
		curl_close($ch);
		if(!empty($result)){  

			$obj = json_decode($result);
			if($obj->status == "200"){
				$data_respon = $obj->data;
				$status = strtolower($data_respon->status) ;
				
				if(($status == "paid") or ($status == "completed") ){
					
					$this->db->query("UPDATE deposit SET `status`='Paid' WHERE id='$id_deposit' "); 
					$total_usdt = $data->total_rfc;
					
					
					$id_copy = $data->id_copy;				
					$total_usdt = $data->total_rfc;
							

					$earn = $data->earn;		
					if($earn == "No"){					
						if($id_copy >= 1){
							$this->db->query("UPDATE copy_data SET `status`='Running' WHERE id='$id_copy'  ");
						}else {
							$this->db->query("UPDATE user SET `usdt`=`usdt`+'$total_usdt' WHERE id='$id_user'  ");
						}
					} else {
								$total_max = $total_usdt * 3; 
								$potongan = ($total_usdt * $settings->earn_potongan) / 100; 
								$usdt_earn_deposit = $total_usdt - $potongan; 								
								$this->db->query("UPDATE user SET `earn_total_profit`=0,  `usdt_earn_deposit`=`usdt_earn_deposit`+'$total_usdt',`earn_withdraw`='0',`earn_last_deposit`='$total_usdt'  WHERE id='$id_user'  ");
								$this->db->query("UPDATE settings SET `earn_deposit`=`earn_deposit` + $usdt_earn_deposit ");
								$this->db->query("UPDATE user SET `usdt_earn_max`='$total_max' WHERE $total_max >= `usdt_earn_max` and id='$id_user'    ");

								$table = "earn_level";
								$sql = " min_deposit <= $total_usdt ORDER BY profit DESC LIMIT 1; ";
								$row = $this->model->row($table,$sql);
								if($row >= 1){
									$dd = $this->model->get_obj($table,$sql)[0];
									$detik = $dd->time;
									$profit = $dd->profit; 
									$this->db->query("UPDATE user SET `earn_sisa_waktu`=$detik  , `earn_waktu_profit`='$profit',`earn_waktu_dasar`='$detik'  WHERE id='$id_user'   ");
								} 
								
								

					}
				


				} else {
					if($status == "expired"){
						$this->db->query("UPDATE deposit SET `status`='Expired' WHERE id='$id_deposit' "); 
					
						$id_copy = $data->id_copy;							
						if($id_copy >= 1){
							$this->db->query("UPDATE copy_data SET `status`='Expired' WHERE id='$id_copy'  ");
						}
					
					} 
				}
				
				
			}
									
		} 

		
	}
	}
 
?>