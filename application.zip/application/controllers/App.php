<?php
defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Jakarta');

class App extends CI_Controller {	
 
	public function index()
	{ 
	


		$success = "";
		if(!empty($_GET['success'])){ 
		$success = in($_GET['success']); 
		$alert = "success";
		$respon = $success; 
		}
		 
	
		$date = date('Y-m-d');
		$table = "settings";
		$sql = "`id`<>-1 LIMIT 1";
		$row = $this->model->row($table,$sql);
		if($row >= 1){
		$settings = $this->model->get_obj($table,$sql)[0];
		if($settings->last_update <> $date){
			
		
		$this->db->query("UPDATE settings SET `last_update`='$date' ");
		$this->db->query("UPDATE `user` set `bet` = `bet`-1 WHERE  `bet` >= 1  ");
		$this->db->query("UPDATE `user` set `bet`= 0 WHERE  `bet` < 0  ");
		$this->db->query("DELETE FROM profit_user ");
		
		
		$c = '';
		$c2 = [];
		$table = "crypto"; 
		$sql = "`id`<>-1 and nama<>'rfc'";
		$row = $this->model->row($table,$sql);
		if($row >= 1){
			$dd = $this->model->get_obj($table,$sql);
			foreach($dd as $data){
				
				$nama = $data->nama;
				if($nama == "optim"){
					$nama = "op";
				} 
				if(empty($c)){
					$c .= $nama;
				} else {
					$c .= ",".$nama;
				}
				
				$c2[] = $nama;
			}
			
			$url = 'https://min-api.cryptocompare.com/data/pricemulti?fsyms='.$c.'&tsyms=IDR,USD&api_key=156739e5ab2b2b693905901ed2565144b51a96b1c331bf38164d4cd7c4ba8ca9';
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL,$url );
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);   
			$result = curl_exec($ch);
			 
			if(!empty($result)){
				$respon = json_decode($result); 
				foreach($c2 as $nama){
   
					$nama2 = strtoupper($nama);
					
					$usd = $respon->$nama2->USD ;
					$idr = $respon->$nama2->IDR ;
					
					$usd = number_format($usd,10);
					$idr = number_format($idr,10);
					
					$usd = str_replace(',','',$usd);
					$idr = str_replace(',','',$idr);
					
					$usd = $usd + 0; 
					$idr = $idr + 0;
					
					
					if($nama == "op"){
						$nama = "optim";
					} 
					
					if(!empty($idr)){
						$this->db->query("UPDATE crypto SET `usd`='$usd' , `idr`='$idr' WHERE nama='$nama'  ");
					}
				
				}
				
			}
			 
			
		}
		
		
		
		
		
		}
		}
		
		
		
	
	
	
		$page = "home"; 
		$response = array();  
		$response['site'] = base_url(); 
		$response['page'] = $page; 
		
		$saldo = [];
		$min_bet = [] ;
		$price_usd = [];
		$price_rp = [];
		
		$table = "crypto";
		$sql = "`id`<>-1";
		$row = $this->model->row($table,$sql);
		if($row >= 1){
			$dd = $this->model->get_obj($table,$sql);
			foreach($dd as $data){
				$saldo[$data->nama] = 0; 
				$min_bet[$data->nama] = $data->min;  
				$price_usd[$data->nama] = $data->usd;  
				$price_rp[$data->nama] = $data->idr;  
			} 
		}    
		  
		$response['price_usd'] = $price_usd;
		$response['price_rp'] = $price_rp;
		$response['min_bet'] = $min_bet;



		
		include("user/data_user.php");
		include("user/data_iframe.php");
		include("globe/settings.php"); 
		
		$response['saldo'] = $saldo; 
		$response['saldo_active'] = 0; 
		$response['crypto_active'] = 'btc'; 
		 
		if($page <> "logout"){
			
			$response['user'] = $user;
			$this->load->view('frontend/index',$response); 
			$this->load->view('frontend/'.$page,$response);
			$this->load->view('frontend/index9',$response);
			
	
		} else {
			$_SESSION['arcur'] = ""; 
			$_SESSION['user'] = ""; 
			
			echo('<script>  document.location.href="'.base_url().'";   </script> ') ; 
			exit();
			
		}
		 
	}
	
	
	 
	public function page($page = "home" , $id = "", $param="")
	{
		


$success = "";
if(!empty($_GET['success'])){ 
$success = in($_GET['success']); 
$alert = "success";
$respon = $success; 
}
 
		$response = array();  
		$response['site'] = base_url(); 
		$response['page'] = $page;  
		$response['id'] = $id;
		
		include("user/data_user.php");
		include("globe/settings.php");
		$response['login'] = $login; 
		if($page <> "logout"){ 
		
			$response['user'] = $user;
			$this->load->view('frontend/index',$response); 
			$this->load->view('frontend/'.$page,$response);
			$this->load->view('frontend/index9',$response);
		
		
		} else {
			$_SESSION['user'] = ""; 
			$_SESSION['arcur'] = ""; 
			$_SESSION['broker'] = ""; 
			echo('<script>  document.location.href="'.base_url().'";   </script> ') ; 
			exit();
			
		}
	} 
	
	
	
	
	
	
	

	   
	
} 

?> 


