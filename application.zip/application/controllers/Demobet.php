<?php
defined('BASEPATH') OR exit('No direct script access allowed');
date_default_timezone_set('Asia/Jakarta');
header("Content-type:application/json");


class Demobet extends CI_Controller {	
 
	public function index()
{ 
		$ar = array();
		
		if(!empty($_SESSION['user'])){
			$user  = ($_SESSION['user']);   
			
			
			$table = "settings";
			$sql = "`id`<> - 1 ";
			$row = $this->model->row($table,$sql);
			if($row >= 1){
				$settings = $this->model->get_obj($table,$sql)[0];
			} 
			  
					
					$id_user = $user->id; 
					if($user->bet >= $amount){
					
					if(!empty($_POST)){
						
							$currency = in($_POST['currency']);
							$rule = in($_POST['rule']);
							$bet_value = in($_POST['bet_value']);
							$multiplier = in($_POST['multiplier']);
							$amount = in($_POST['amount']);
							

					if($amount > 0){
							$this->db->query("UPDATE user SET `bet`=`bet` - $amount WHERE id='$id_user'    ");
							$ar['sql1'] = "UPDATE user SET `bet`=`bet` - $amount WHERE id='$id_user'    ";
							
							if(($settings->status_game == "Normal" ) or ($settings->status_game == "normal" )){ 
							include("game_normal.php"); 
							} else { 
							include("game_boom.php");
							}
							
							if($profit > 0 ){
								$this->db->query("UPDATE user SET `bet`=`bet`+$profit WHERE id='$id_user'  ");
							} 
						

							$ar['bet']['hash'] = substr(hash('sha256', openssl_random_pseudo_bytes(20)),-20);
							$ar['bet']['nonce'] =  rand(2222222,9999999); 
							$ar['bet']['currency'] =  "rfc"; 
							$ar['bet']['amount'] =  $amount; 
							$ar['bet']['profit'] = "$profit" ; 
							$ar['bet']['multiplier'] = $multiplier  ; 
							$ar['bet']['bet_value'] =  $bet_value; 
							$ar['bet']['rule'] =  $rule; 
							$ar['bet']['result_value'] =  "$result_all" ; 
							$ar['bet']['state'] =  $state; 
							$ar['bet']['published_at'] =  date('ymdhis') ;  
							$ar['bet']['game']['name'] =  "dice"; 
							

							$table = "user";
							$sql = "`id`='$id_user'";
							$row = $this->model->row($table,$sql);
							if($row >= 1){
								$user = $this->model->get_obj($table,$sql)[0]; 
								
								if($user->bet <= 0){
									$this->db->query("update user set `bet`=0 where id='$id_user' ");
									
								} 
							} 
 

							$ar['userBalance']['amount'] =  $user->bet; 
							$ar['userBalance']['currency'] =  "rfc"; 
							  

					} else {
						$ar['error'] = "amount error ".$amount;
					} 

					}else {
						$ar['error'] = "empty post";
					}
					} else {
						$ar['error'] = "Balance not enought";
					
					}
			
		}else {
			$ar['error'] = "Not login";
		}

		$ar = json_encode($ar);
		echo($ar);

	}
	
	   
	
	  

	
} 

?> 