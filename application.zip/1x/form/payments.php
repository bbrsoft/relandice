<?php $id = "";
if(!empty($_GET['id'])){ 
$id = in($_GET['id']); 
}


if(isset($_POST['upload_evidence'])){
	require_once("isset_image.php");
	if(!empty($image)){
		eksekusi($pdo,"UPDATE 1x_api SET `evidence`='$image' , `evidence_status`='Checked' WHERE id='$id' and active<>'Yes' ");
	} 
} 


$check_data = select($pdo,"SELECT * FROM 1x_api WHERE `id`='$id' and total_payment IS NOT NULL and id_user='$id_user' "); 
$check_data->execute();
$row_data = row($check_data);
if($row_data >= 1){
$data = fetch_obj($check_data);



$check_bank = select($pdo,"SELECT * FROM bank LIMIT 1"); 
$check_bank->execute();
$row_bank = row($check_bank);
if($row_bank >= 1){
$bank = fetch_obj($check_bank);
}	
?>


<div class="p-3 relative"  style="min-height: 100%;" >
	<h4 class="fs-18 mb-0"> Payment #<?php echo($data->nama) ;  ?> (<?php echo($data->month ." Month") ;  ?>) </h4> 
	<p class="fs-14"> Please make payment to the account number provided. </p> 
	<hr>
	
	<div class="table-responsive">
		<table class="table table-striped table-bordered w-100 fs-14"> 
			<tbody>
				<tr>  <th> Payment </th>  <td> AutoAPI Subscribe </td> </tr>
				<tr>  <th> Subscribe </th>  <td> <?php echo($data->month) ;  ?> Month</td> </tr>
				<tr>  <th> Price / Month </th>  <td> Rp. <?php echo uang($settings->price_autobot) ;  ?> / Month  </td> </tr>
				<tr>  <th> Status </th>  <td> <?php if($data->active == "Yes"){echo(" Active ") ; } else {echo($data->active) ; }  ?> </td> </tr>
				<tr>  <th> Proof/Evidence </th>  <td> 
					<?php if(!empty($data->evidence)){?> 
						<img onclick="show_image('<?php echo($site) ?>image/<?php echo($data->evidence) ;  ?>')" src="<?php echo($site) ?>image/<?php echo($data->evidence) ;  ?>"  style="height: 20px;"  class="" />
					<?php } else {echo(" - ") ; } ?>
				</td> </tr>
				<tr>  <th> Proof Status </th>  <td class="text-<?php if($data->evidence_status == "Reject"){echo("danger") ; } else {echo("warning") ; }  ?> "> <?php echo($data->evidence_status) ;  ?> </td> </tr>
				<tr>  
				<th  style="text-align:center!important;"  align="center " colspan="2"> Total Payment  <br />
				<h3 class="text-primary">   Rp. <?php echo(uang($data->total_payment)) ;  ?> </h3> <?php if($data->active == "Yes"){echo(" PAID ") ; 
				}  ?> </td> </tr>
				
				
		<?php if($data->active <> "Yes"){?> 
				<tr>  <th colspan="2"> Transfer Destination </th> </tr>
				<tr>  <th> Bank Transfer </th>  <td> <?php echo($bank->bank_jenis) ;  ?></td> </tr>
				<tr>  <th> Account Number </th>  <td> <?php echo($bank->bank_rekening) ;  ?></td> </tr>
				<tr>  <th> Account Name </th>  <td> <?php echo($bank->bank_nama) ;  ?></td> </tr>
		<?php } ?>
		
		</tbody>
		</table> 
		<hr>
		
		<?php if($data->active <> "Yes"){?> 
		 
		<h5 class="mb-0 fs-18"> Proof / Evidence </h5> 
		<p class="fs-12"> After Transfer Your Payments Please Upload Proof/Evidence on this Form </p> 
		<form method="post" enctype="multipart/form-data"> 
			<div class="p-3 bg-white radius-5 shadow">
				
				<span> Screenshot/Image </span> 
				<input type="file" required class="form-control" name="image" value="" placeholder=""    />
				<button type="submit" name="upload_evidence" class="btn form-control btn-primary" >Upload Proof</button> 
				
			</div>
		
		</form>
		<?php }   ?>
		
		
	
	</div>
	
	
<a class="btn bg-white btn-light form-control mb-2 border"  href="<?php echo($site) ?>" ><i class="la la-home mr-1">  </i> Back To Homepage </a> 
</div>



<?php } ?>
