<div class="card_gradient h-100 w-100 p-3 pt-5">
			
	<div class="d-flex w-100 align-items-center justify-content-center"  style="" >
	<div class="w-100">
	<div class="" align="center">
		<img src="<?php echo($site) ?>image/logo_white.png"  style="height: 50px; background: var(--bs-primary); border-radius:100%; padding:5px; "  />
		<h5 class="mt-1 mb-0"> <?php echo($website_name) ;  ?></h5> 
		<p class="fs-12"> Get Shiba profit Every day with contract server mining </p> 
	</div>
	<hr>
	
	<div class="pt-3">
		
		<form method="post" enctype="multipart/form-data" align="center"> 

			 
			<p> <b> Sorry </b>. Forgot Password Must be contact administrator .  </p> 
			<a class="btn btn-primary" href="<?php echo($site) ?>page/login" > Back To Login </a> 
			
		</form>
		
	
	</div>
	</div>
	</div>
	

	
<img src="<?php echo($site) ?>image/mining.webp"  style="width : 100px; transform:rotate(15deg);right:30px; bottom:20px;"  class="absolute_background" />


</div>

