<div class="card_gradient h-100 w-100 p-3 pt-5">			
	<div class="d-flex w-100 relative align-items-center justify-content-center"  style="z-index:2" >
	<div class="w-100">
	<div class="" align="center">
		<img src="<?php echo($site) ?>image/logo_white.png"  style="height: 50px; background: var(--bs-primary); border-radius:100%; padding:5px; "  />
		<h5 class="mt-1 mb-0"> <?php echo($website_name) ;  ?></h5> 
		<p class="fs-12"> Get Shiba profit Every day with contract server mining </p> 
	</div>
	<hr>
	<?php include("alert_form.php"); ?>
	<div class="pt-3">
		<form method="post" enctype="multipart/form-data"> 
			<span><i class="fa fa-user">  </i> User ID *</span> 
			<input type="text" required class="form-control" name="user_id" value="" placeholder="UserID Access"    />
			 
			<span><i class="fa fa-lock">  </i> Password  *</span> 
			<input type="text" required class="form-control password" name="password" value="" placeholder="Password Access"    />
			
			<div class="d-flex fs-12 align-items-center justify-content-between mb-3">
				<a class="link" href="<?php echo($site) ?>page/forgot" > <i class="fa fa-info-circle">  </i> Forgot Password ? </a> 
				<a class="link" href="<?php echo($site) ?>page/register" > <i class="fa fa-edit">  </i> Create New Account  </a> 
			</div>
			
			<button type="submit" class="btn btn-primary form-control" name="login" ><i class="fa fa-sign-in">  </i> Login To Dashboard</button> 			
		</form>
		
	
	</div>
	</div>
	</div>
	

	
<img src="<?php echo($site) ?>image/mining.webp"  style="width : 100px; transform:rotate(15deg);right:30px; bottom:20px;"  class="absolute_background" />
<img src="<?php echo($site) ?>image/wing2.png"  style="width : 120%;  opacity:0.3!important;left:0px;right:-30px; bottom:0px;"  class="absolute_background" />


</div>

