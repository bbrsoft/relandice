<?php 
$_SESSION['user_id'] = ''; 
$_SESSION['password'] = ''; 
echo("<script>  document.location.href= '".$site."';   </script> ") ; 
exit();
?>