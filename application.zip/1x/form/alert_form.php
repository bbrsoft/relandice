<style>
	.alert{
		position:relative;		
	}

	.alert .close{
		cursor:pointer; 
		font-size : 18px;
		color:white!important;
		text-decoration:none;
		position:absolute;
		right:15px;
		top:5px;
		font-weight : bold;
		
	}
</style>
<?php  if(!empty($alert)){ ?>
<div class="alert alert-<?php echo($alert) ;  ?> bg-<?php echo($alert) ;  ?> text-light fs-14 border-0 m-0  alert-dismissable">
	<a class="close" data-dismiss="alert" aria-label="close">x</a>
	<?php echo($respon) ;  ?> 
</div> <?php }  ?>		



<script>  
	$('.alert .close').click(function(){
		$('.alert').remove();
	})
</script> 