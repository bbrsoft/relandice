<style>
.dot_list{
	width : 10px;
}
.dot{
	width : 8px;
	height: 8px;
	border-radius:100%; 	
}

.server_background{
	border-radius:10px;
	background: #273844; 
	color:white;
	position:relative;
	margin-bottom: 25px;
}


	.server_item{
		width : 100%;
		display:flex;
		align-items:center;
		justify-content:space-between;
	}
	
	
	
	.server_profit{
		background: black;
		color:white;
		padding:0px!important;
		display:flex;
		align-items:center;
		justify-content:center; 
		text-align:center;
		width : 80px;
		height: 30px; 
		border-radius:5px; 
		border:0px!Important;
		
	}
	
	
	.server_div_1{
		width : 100%;
		display:flex;
		align-items:center;
		justify-content:space-between;
		margin-bottom: 3px;
		margin-top: 3px;
	}
	
	
	
	.server_progress_main{
		height: 5px;
		width : 100%;
		background: #f1f1f1;
		border-radius:5px; 
	}
	
	.server_progress{
		height: 5px;
		border-radius:5px;
		width : 80%; 
	}
	

.server_green{ background: #03ef03; }
.server_blue{ background: blue; }
.server_red{ background: red; }
.server_list_item{
	width : calc(100% - 130px);
	padding-right:10px;
}


.server_horizontal_div{
	display:flex;
	align-items:center;	
	justify-content:space-around!important;
	width : 50px;
	padding-right:10px;
 }

.server_horizontal{
	width : 5px;
	height: 30px;
	border-radius:5px;
}

.server_background:before{
	content:"";
	background: #273844;
	width : 5px;
	height: 25px;
	position:absolute;
	left:calc((100% - 5px) / 2);
	bottom: -25px;
}


.server_finish{
	background: #273844;
	height: 5px;
	width : 50%;
	margin:auto;
	border-radius:5px; 
}

</style>
<div class="p-3 relative"  style="min-height: 100%;" >
	<h4 class="fs-18 mb-0"> Contract Servers </h4> 
	<p class="fs-14"> Here is the Server you are currently contracting .</p> 




	<div class="server_background px-3 pt-2 pb-2">
		<span class="fs-14"> Server #1  - 20 RFC / Day </span> 
		<div class="server_item pt-2 pb-2">
		
			<div class="server_list_item">
			<div class="server_div_1 gap-1">
				<div class="dot server_green" > </div>
				<div class="server_progress_main">
					<div class="server_progress server_green" ></div>				
				</div>
			</div>
			
			
			<div class="server_div_1 gap-1">
				<div class="dot server_blue" > </div>
				<div class="server_progress_main">
					<div class="server_progress server_blue" ></div>				
				</div>
			</div>
			
			<div class="server_div_1 gap-1">
				<div class="dot server_red" > </div>
				<div class="server_progress_main">
					<div class="server_progress server_red" ></div>				
				</div>
			</div>
			</div>
			
			<div class="server_horizontal_div">
				<div class="server_horizontal server_green"></div>
				<div class="server_horizontal server_blue"></div>
				<div class="server_horizontal server_red"></div>
			 
			</div>
			<div class="server_profit"  >1239</div>
		</div>
	</div>
	
	
	

	<div class="server_background px-3 pt-2 pb-2">
		<span class="fs-14"> Server #2  - 35 RFC / Day </span> 
		<div class="server_item pt-2 pb-2">
		
			<div class="server_list_item">
			<div class="server_div_1 gap-1">
				<div class="dot server_green" > </div>
				<div class="server_progress_main">
					<div class="server_progress server_green" ></div>				
				</div>
			</div>
			
			
			<div class="server_div_1 gap-1">
				<div class="dot server_blue" > </div>
				<div class="server_progress_main">
					<div class="server_progress server_blue" ></div>				
				</div>
			</div>
			
			<div class="server_div_1 gap-1">
				<div class="dot server_red" > </div>
				<div class="server_progress_main">
					<div class="server_progress server_red" ></div>				
				</div>
			</div>
			</div>
			
			<div class="server_horizontal_div">
				<div class="server_horizontal server_green"></div>
				<div class="server_horizontal server_blue"></div>
				<div class="server_horizontal server_red"></div>
			 
			</div>
			<div class="server_profit"  >3999</div>
		</div>
	</div>
	
	
	
	<div class="server_finish">
	</div>
	
	<div class="p-3 fs-14" align="center">
		Total Profit : 39923 RFC <br /> 
		Profit Today : 388 RFC 
	</div>
	
	
	

</div>
