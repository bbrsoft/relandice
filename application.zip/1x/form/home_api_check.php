<?php 
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://wolfbet.com/api/v1/user/balances');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');


$headers = array();
$headers[] = 'X-Requested-With: XMLHttpRequest';
$headers[] = 'Authorization: Bearer '.$api;
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$result = curl_exec($ch); 
curl_close($ch); 
$saldo = [];

if(!empty($result)){			
	$result_decode = json_decode($result); 
	if(empty($result_decode->errors)){  
	 
		$newtimestamp = strtotime(date('Y-m-d H:i:s').' + 1 minute');
		$next_update = date('Y-m-d H:i:s', $newtimestamp);

		eksekusi($pdo,"INSERT INTO `1x_api`
		(`id_user`, `api`, `nama`, `respon_balance`, `respon_stat`, `next_update`) VALUES 
		('$id_user','$api','$name','$result','', '$next_update' )");
		
		$alert = "success";
		$respon = "Success Add Your API Key ";
		
		
		
	} else {
		$alert = "danger";
		$respon = "Sorry - Your API Key Is Not Valid ";
	} 

} else {
	$alert = "danger";
	$respon = "Sorry - Your API Key Is Not Valid ";
} 



if($alert == "success"){


$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://wolfbet.com/api/v1/user/stats/bets');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');


$headers = array();
$headers[] = 'X-Requested-With: XMLHttpRequest';
$headers[] = 'Authorization: Bearer '.$api;
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$result = curl_exec($ch); 
curl_close($ch); 
$saldo = [];

if(!empty($result)){			
	$result_decode = json_decode($result); 
	if(empty($result_decode->error)){  
	 
	  
		eksekusi($pdo,"UPDATE `1x_api` SET `respon_stat`='$result' WHERE api='$api'    ");
		
	}  
} 
} 

?>