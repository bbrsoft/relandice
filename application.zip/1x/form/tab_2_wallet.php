<div class="p-3 relative"  style="min-height: 100%;" >
	<h4 class="fs-18 mb-0"> Wolfbet Account </h4> 
	<p class="fs-14"> This your balance in wolfbet account .</p> 
	
	
<div class="dropdown "  style="position:absolute; top:10px; right:10px;" >
  <button class="btn btn-light btn-sm dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
   <i class="la la-coins">  </i> SHIBA  
  </button>
  <ul class="dropdown-menu">
    <?php $check_crypto = select($pdo,"SELECT * FROM crypto WHERE nama<>'rfc'"); 
	$check_crypto->execute();
	$row_crypto = row($check_crypto);
	if($row_crypto >= 1){
		while($crypto = fetch_obj($check_crypto)){
			?> 
			 <li><a class="dropdown-item" href="#"><?php echo strtoupper($crypto->nama) ;  ?></a></li>
			<?php 
		}
	}  
	 ?>
    
	
  </ul>
</div>



	<div class="card_gradient border-blue px-3 pt-2 pb-2 radius-3 mb-3"  style="box-shadow:0px 0px 20px 0px rgba(0,0,0,.2)" >
		<div class="relative"  style="z-index:2!important;" >
			<span class="op-9 fs-11 nowrap"> API KEY : eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiI1IiwianRpIjoiNjVjMjE5NjFhOWMwZmI4MGJhNzc5YzczMWE1YzYzMDQ2MDc3ZDM5ZDhkNTBlY2ViMTU0NTllMzIzOTUzNjlkMDIzODk5MjNjMGFkNmM3ZDgiLCJpYXQiOjE3MjExMDI5NTguNjI3NzYyLCJuYmYiOjE3MjExMDI5NTguNjI3NzY2LCJleHAiOjE3NTI2Mzg5NTguNjIyNzExLCJzdWIiOiI0NTY1OTgiLCJzY29wZXMiOltdfQ.Lzz_EiN-bIG6zGx6zg8Z6SR4pDydLLvQEA99LRj3bGzb8JFHe4L0C8wfP_hMvzodjgV1qJ3GKYY4tpjHb90726LGeb5A37Hc_LYBAW_cpwivpfZ_lXTl3RtCnNOyCvjEk31CTaFMGpTvr2nSrIQQyuf1EeYOLhB4oVaAHNcqH_RAGav5cZsKcfOVmu9rJQknUI2IY0_82LZkEao5pqdAW4p9gCCU8BVU74ZHUTaMP0zU8jyGt8ErwxBj2PYGYgBXpFRD1Fw-sozds1WfTEMQPTAENPBRmP0X-5LeV0pr9ePORlfbnR-5Hsae1oZevjE71ZNfMdZ6Gf8GXuYL86lccgjEW6BRNVVYoqzE4UjqqwbhRGUQOkkiYu6_pxLqaJnOEyBm5ZAiFZboj5tr90uGOfWn1d3A96j-7LblamkSiI_mBZtUY5xPdooD_5yTyh4H5mD878U91nsL3i33b_7oIac886cOAQ9jYhB-e2BYEL-knmBqh0mzX9GoRAiDcZ0EVnDnbiVTQ2sHBCYpekDFN9ITpDj2aZiGwyUWBi2qkdhtSI4mMNprHZOmyfi7adLyf_EmdbYKOvQLeHUJKbZMdB4VpO3U3yirrCGuB6MBs97xyUNc7CXebtIrslE3FH33ZY5DMgD5ZccqeoVjJBFfHkxG_8U3YNDVpzwGiTfJC38 </span> 
			<h4 class="fs-18 "  style="margin-top: 5px;" ><i class="far fa-user-circle fs-18">  </i> Account #1 </h4> 
			
			<span class="op-9 fs-13"><i class="fas fa-coins">  </i>  Balance </span> 
			<h5 class="fs-18 " >339299.38 Shiba</h5> 				
			
			<div class="d-flex align-items-center justify-content-start gap-10 fs-11">
				<span> Win : 1x , Lose : 3x,  Waggered : 0 , Profit : 0 </span> 
			</div>
		</div>
			
		<img src="<?php echo($site) ?>image/wolf.webp"  style="width : 100px; transform:rotate(15deg);right:-10px; bottom:15px;"  class="absolute_background" />
		<img src="<?php echo($site) ?>image/wing2.png"  style="width : 100%;  opacity:0.3!important;left:0px; bottom:0px;"  class="absolute_background" />
	</div>
	

	<div class="card_gradient border-blue px-3 pt-2 pb-2 radius-3 mb-3"  style="box-shadow:0px 0px 20px 0px rgba(0,0,0,.2)" >
		<div class="relative"  style="z-index:2!important;" >
			<span class="op-9 fs-11 nowrap"> API KEY : eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiI1IiwianRpIjoiNjVjMjE5NjFhOWMwZmI4MGJhNzc5YzczMWE1YzYzMDQ2MDc3ZDM5ZDhkNTBlY2ViMTU0NTllMzIzOTUzNjlkMDIzODk5MjNjMGFkNmM3ZDgiLCJpYXQiOjE3MjExMDI5NTguNjI3NzYyLCJuYmYiOjE3MjExMDI5NTguNjI3NzY2LCJleHAiOjE3NTI2Mzg5NTguNjIyNzExLCJzdWIiOiI0NTY1OTgiLCJzY29wZXMiOltdfQ.Lzz_EiN-bIG6zGx6zg8Z6SR4pDydLLvQEA99LRj3bGzb8JFHe4L0C8wfP_hMvzodjgV1qJ3GKYY4tpjHb90726LGeb5A37Hc_LYBAW_cpwivpfZ_lXTl3RtCnNOyCvjEk31CTaFMGpTvr2nSrIQQyuf1EeYOLhB4oVaAHNcqH_RAGav5cZsKcfOVmu9rJQknUI2IY0_82LZkEao5pqdAW4p9gCCU8BVU74ZHUTaMP0zU8jyGt8ErwxBj2PYGYgBXpFRD1Fw-sozds1WfTEMQPTAENPBRmP0X-5LeV0pr9ePORlfbnR-5Hsae1oZevjE71ZNfMdZ6Gf8GXuYL86lccgjEW6BRNVVYoqzE4UjqqwbhRGUQOkkiYu6_pxLqaJnOEyBm5ZAiFZboj5tr90uGOfWn1d3A96j-7LblamkSiI_mBZtUY5xPdooD_5yTyh4H5mD878U91nsL3i33b_7oIac886cOAQ9jYhB-e2BYEL-knmBqh0mzX9GoRAiDcZ0EVnDnbiVTQ2sHBCYpekDFN9ITpDj2aZiGwyUWBi2qkdhtSI4mMNprHZOmyfi7adLyf_EmdbYKOvQLeHUJKbZMdB4VpO3U3yirrCGuB6MBs97xyUNc7CXebtIrslE3FH33ZY5DMgD5ZccqeoVjJBFfHkxG_8U3YNDVpzwGiTfJC38 </span> 
			<h4 class="fs-18 "  style="margin-top: 5px;" ><i class="far fa-user-circle fs-18">  </i> Account #1 </h4> 
			
			<span class="op-9 fs-13"><i class="fas fa-coins">  </i>  Balance </span> 
			<h5 class="fs-18 " >339299.38 Shiba</h5> 				
			
			<div class="d-flex align-items-center justify-content-start gap-10 fs-11">
				<span> Win : 1x , Lose : 3x,  Waggered : 0 , Profit : 0 </span> 
			</div>
		</div>
			
		<img src="<?php echo($site) ?>image/wolf.webp"  style="width : 100px; transform:rotate(15deg);right:-10px; bottom:15px;"  class="absolute_background" />
		<img src="<?php echo($site) ?>image/wing2.png"  style="width : 100%;  opacity:0.3!important;left:0px; bottom:0px;"  class="absolute_background" />
	</div>
	
	
</div>
