<?php 
$now = date('Y-m-d H:i:s');


$check_data = select($pdo,"SELECT * FROM `1x_api` WHERE  `id_user`='$id_user' and `next_update` <= '$now' LIMIT 2"); 
$check_data->execute();
$row_data = row($check_data);
if($row_data >= 1){
while($data = fetch_obj($check_data)){


$api = $data->api;  

		
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://wolfbet.com/api/v1/user/balances');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');


$headers = array();
$headers[] = 'X-Requested-With: XMLHttpRequest';
$headers[] = 'Authorization: Bearer '.$api;
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$result = curl_exec($ch); 
curl_close($ch); 
$saldo = [];

if(!empty($result)){			
	$result_decode = json_decode($result); 
	if(empty($result_decode->errors)){  
	if(!empty($result_decode->balances)){
		$newtimestamp = strtotime(date('Y-m-d H:i:s').' + 1 minute');
		$next_update = date('Y-m-d H:i:s', $newtimestamp);
		eksekusi($pdo,"UPDATE `1x_api` SET `respon_balance`='$result' , `next_update`='$next_update' , `valid`='Yes' WHERE api='$api'    ");
	}  else {
		eksekusi($pdo,"UPDATE 1x_api SET `valid`='No' WHERE api='$api'  ");
	}
	}  else {
		eksekusi($pdo,"UPDATE 1x_api SET `valid`='No' WHERE api='$api'  ");
	}
} else {
	eksekusi($pdo,"UPDATE 1x_api SET `valid`='No' WHERE api='$api'  ");
} 

 
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, 'https://wolfbet.com/api/v1/user/stats/bets');
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');


	$headers = array();
	$headers[] = 'X-Requested-With: XMLHttpRequest';
	$headers[] = 'Authorization: Bearer '.$api;
	curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

	$result = curl_exec($ch); 
	curl_close($ch); 
	$saldo = [];

	if(!empty($result)){			
		$result_decode = json_decode($result); 
		if(empty($result_decode->error)){  
		 
		  if(!empty($result_decode->dice)){
				eksekusi($pdo,"UPDATE `1x_api` SET `respon_stat`='$result' WHERE api='$api'    ");
		  }
		  
		}  
	} 

		
	}
}


?>

