
<div class="p-3">
	
	<?php include("home_api.php"); ?>
	<div class="card_gradient border-blue px-3 pt-2 pb-2 radius-3 "  style="box-shadow:0px 0px 20px 0px rgba(0,0,0,.2); display:none!important;" >
		<div class="relative"  style="z-index:2!important;" >
			<span class="op-9 fs-11"> Welcome To Dashboard </span> 
			<h4 class="fs-18 "  style="margin-top: -3px;" ><i class="far fa-user-circle fs-18">  </i> <?php echo ucwords($user->secret) ;  ?></h4> 
			
			<span class="op-9 fs-13"><i class="fas fa-coins">  </i>  RFC Balance</span> 
			<h5 class="fs-18 " ><?php echo($user->bet) ;  ?></h5> 				
			
			<div class="d-flex align-items-center justify-content-start gap-10 fs-11">
				<span> Profit : +100Shib , Percentage : +10%,  Running : 10'm </span> 
			</div>
		</div>
			
		<img src="<?php echo($site) ?>image/pig.png"  style="width : 100px; transform:rotate(15deg);right:-10px; bottom:15px;"  class="absolute_background" />
		<img src="<?php echo($site) ?>image/wing2.png"  style="width : 100%;  opacity:0.3!important;left:0px; bottom:0px;"  class="absolute_background" />
	</div>
	
	
	<div class="pt-3 pb-2">
		<p class="fs-16 m-0"><i class="fas fa-list">  </i> List Contract Server </p> 	
	</div>
	
	
	
	
	<div class="">
	 <div class="swiper"  id="mySwiper">
		<div class="swiper-wrapper">
		  <div class="swiper-slide">
			<div class="server_contract">
			<span class="fs-16"  style="font-weight : bold;" > Server #1 </span> 
			<div class="server_flex">
				
				<div class=""  style="width : 60px;" >
					<img src="<?php echo($site) ?>image/server.png"  style="width : 60px;"  />
				</div>
				<div class="pl-2"  style="width : calc(100% - 60px)" >
					<div class=""  style="line-height:16px;" >
					<div class="d-flex fs-12 align-items-center justify-content-between">
						<span> Contract Price </span> 
						<span align="right"> 300 RFC </span> 
					</div>
					<div class="d-flex fs-12 align-items-center justify-content-between">
						<span> Maximum Profit </span> 
						<span align="right"> 300% </span> 
					</div>
					<div class="d-flex fs-12 align-items-center justify-content-between">
						<span> Profit / Day </span> 
						<span align="right"> 30 RFC </span> 
					</div>
					</div>
				</div>
			</div>
			
			<a class="btn btn-primary d-block btn-sm mt-2" > Contract Server (300 RFC) </a> 
			
			</div>
		  </div>
		  
		  
		  
		  <div class="swiper-slide">
			<div class="server_contract">
			<span class="fs-16"  style="font-weight : bold;" > Server #2 </span> 
			<div class="server_flex">
				
				<div class=""  style="width : 60px;" >
					<img src="<?php echo($site) ?>image/server.png"  style="width : 60px;"  />
				</div>
				<div class="pl-2"  style="width : calc(100% - 60px)" >
					<div class=""  style="line-height:16px;" >
					<div class="d-flex fs-12 align-items-center justify-content-between">
						<span> Contract Price </span> 
						<span align="right"> 600 RFC </span> 
					</div>
					<div class="d-flex fs-12 align-items-center justify-content-between">
						<span> Maximum Profit </span> 
						<span align="right"> 350% </span> 
					</div>
					<div class="d-flex fs-12 align-items-center justify-content-between">
						<span> Profit / Day </span> 
						<span align="right"> 35 RFC </span> 
					</div>
					</div>
				</div>
			</div>
			
			<a class="btn btn-primary d-block btn-sm mt-2" > Contract Server (300 RFC) </a> 
			
			</div>
		  </div>
		  
		  
		  <div class="swiper-slide">
			<div class="server_contract">
			<span class="fs-16"  style="font-weight : bold;" > Server #3 </span> 
			<div class="server_flex">
				
				<div class=""  style="width : 60px;" >
					<img src="<?php echo($site) ?>image/server.png"  style="width : 60px;"  />
				</div>
				<div class="pl-2"  style="width : calc(100% - 60px)" >
					<div class=""  style="line-height:16px;" >
					<div class="d-flex fs-12 align-items-center justify-content-between">
						<span> Contract Price </span> 
						<span align="right"> 1000 RFC </span> 
					</div>
					<div class="d-flex fs-12 align-items-center justify-content-between">
						<span> Maximum Profit </span> 
						<span align="right"> 500% </span> 
					</div>
					<div class="d-flex fs-12 align-items-center justify-content-between">
						<span> Profit / Day </span> 
						<span align="right"> 45 RFC </span> 
					</div>
					</div>
				</div>
			</div>
			
			<a class="btn btn-primary d-block btn-sm mt-2" > Contract Server (300 RFC) </a> 
			
			</div>
		  </div>
		  
		  
		  
		  
		</div>
		<div class="swiper-pagination"></div>
	  </div>
	</div>
	
	
	
	
	
</div>



<link rel="stylesheet"    href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>


<!-- Initialize Swiper -->
  <script> 
    var swiper = new Swiper("#mySwiper", {
      slidesPerView: "auto", 
      spaceBetween: 10,
      pagination: {
        el: ".swiper-pagination",
        clickable: true,
      },
    });
  </script>
  
