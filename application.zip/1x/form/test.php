<?php 


$api = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiI1IiwianRpIjoiZDE4MDczNDYxYzdmMTVkNjI2ZGRjZWE5OGMwYzcwYmFiNWY2ZTg0NGJhZDNlMGQ5NzU3ZDRlN2Y4MjJlNjBlMjQyNzkzOTVkMjVkOTRmY2EiLCJpYXQiOjE3MjI2NTgxMjcuNDY0OTU1LCJuYmYiOjE3MjI2NTgxMjcuNDY0OTU4LCJleHAiOjE3NTQxOTQxMjcuNDYwNTcxLCJzdWIiOiI0NjA0NDAiLCJzY29wZXMiOltdfQ.PRuvzi66FeV77rDkZCezBqzHLbXSALUxNAufm1j1683fejJPqMEU7B3yMPRu9cryZlK6bOUxm9PZgzPl-7QSr5mWIuZbwI15aK2eroEgiwPM-R2Q0ch1Nv61E_wIi6nEYcoPGS9fgTfX85K3VikDvbUGC_Dd91arBXWPhjMHUXGxwHAC_wStvM4y3clsO42lLqqVWsAiWHCZK6K5MwqcrDYjgnjyakk2COHrfzSckMXm6H8jeUeTJDOroY1t0kB2wZ9qL84UCc5LKdWCVKGqrbAwAYAvxne6VPHQjjruzkULceTzxLA6iBxis_bS6a5w-LjifHCqjiitikq0nfm0MUblkl0hLIehbBOBLpShsKYgOjSbu0eZwItXINa0nxquSm0C1Ny1dRTEhzN7klPOCfLKpq9r5SbDgpOlReei00mV2NPgtFSj8CLxXkZXsptq4jlLIYy77tPNiVKKuDzgrp7P_vCL0UlRi1LjiBdjaC_FFUNa6xBhPrwHKVfL_fiXPbEd-LsjeSPzpbxuOr18T5MU-FMSJz1miH8VSNg-Y2WN11tV66lfmVevOB8JIJQ2S2yJn_IwXZqMbZ74vo-fEpzSagA2kr3xWqoZ4zzRqN0URue5gOdeKG8naGf5W49x0gZlp1h_-ens9c3lltRZsjzpV02wcPwFIuCsU179c_Y";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://wolfbet.com/api/v1/user/balances');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');


$headers = array();
$headers[] = 'X-Requested-With: XMLHttpRequest';
$headers[] = 'Authorization: Bearer '.$api;
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$result = curl_exec($ch); 
curl_close($ch); 
$saldo = [];

if(!empty($result)){			
	print_r($result);	
}
 

 ?>
 
 
 