<div class="p-3 relative"  style="min-height: 100%;" >
	<h4 class="fs-18 mb-0"> Referral </h4> 
	<p class="fs-14 mb-1"> You can get a referral bonus by inviting friends to join using your referral code. </p> 
	<div class="d-flex justify-content-between align-items-center gap-1">
	<input type="text"  style="width : calc(100% - 100px)"  required class="form-control fs-13" name="" value="<?php echo($site) ?>?ref=<?php echo($user->secret) ;  ?>" placeholder=""    />
	<a  style="width : 100px;"  class="btn btn-sm btn-primary" ><i class="la la-copy">  </i> Copy </a> 
	</div>
	<hr>
	
	<div class="table-responsive">
	<table class="table table-striped table-bordered fs-14">
		<thead>
		<tr>
			<th> Join </th>
			<th> User </th>
			<th> Active </th>
		</tr>
		</thead>
		<tbody>
		<tr> 
			<td> 20 Aug 2024</td>
			<td> Indra21 </td>
			<td> No </td>
		</tr>
		</tbody>
	</table> 
	</div>
	

</div>
