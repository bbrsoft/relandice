<div class="tab-content w-100 p-0" id="nav-tabContent" >
  <div class="tab-pane fade show active" id="nav-1" role="tabpanel" aria-labelledby="nav-1-tab" tabindex="0"><?php include("tab_1_home.php"); ?></div>
  <div class="tab-pane fade" id="nav-2" role="tabpanel" aria-labelledby="nav-2-tab" tabindex="0"><?php include("tab_2_wallet.php"); ?></div>
  <div class="tab-pane fade" id="nav-3" role="tabpanel" aria-labelledby="nav-3-tab" tabindex="0"><?php include("tab_3_server.php"); ?></div>
  <div class="tab-pane fade" id="nav-4" role="tabpanel" aria-labelledby="nav-4-tab" tabindex="0"><?php include("tab_4_transaction.php"); ?></div>
  <div class="tab-pane fade" id="nav-5" role="tabpanel" aria-labelledby="nav-5-tab" tabindex="0"><?php include("tab_5_referral.php"); ?></div>
</div> 