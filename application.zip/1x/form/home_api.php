<?php 
if(isset($_POST['run_bot'])){
	$id = in($_POST['id']);
	$id_strategy = in($_POST['id_strategy']);
	 
	
	eksekusi($pdo,"UPDATE 1x_api SET `status_play`='Play',`id_strategy`='$id_strategy' WHERE id='$id'  ");
}


if(isset($_POST['stop_bot'])){
	$id = in($_POST['id']);
	eksekusi($pdo,"UPDATE 1x_api SET `status_play`='Stop' WHERE id='$id'  ");	
} 



if(isset($_POST['add_api'])){
	$name = in($_POST['name']);
	$api = in($_POST['api']);
	$check_api = select($pdo,"SELECT * FROM `1x_api` WHERE id_user= '$id_user' and api='$api'  "); 
	$check_api->execute();
	$row_api = row($check_api);
	if($row_api >= 1){
		$alert = "danger";
		$respon = "Sorry - This API Has Already exists on your account ";
	} else {
		include("home_api_check.php");
	} 
} 

include("home_refresh_api.php");
?>




<div style="min-height: 100%;" >
	<div class="d-flex align-items-end justify-content-between">
	<h4 class="fs-18 mb-0"> Wolfbet Account </h4> 
		<div class="" align="right"  style="line-height:14px;" >
			<small class="d-block fs-10"> Profit Global </small> 
			<span class="profit_global"> Rp. 0 </span> 
		</div>
	</div>
	
	
	<p class="fs-14 mb-1"> This Your List API in wolfbet account .</p> 
</div>
	
<div class="d-flex mb-3 align-items-center justify-content-between">
<a class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#modal_api" > + API Wolfbet </a> 
	
<div class="dropdown "    >
  <button class="btn btn-light btn-sm dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
   <i class="la la-coins">  </i> <?php echo(strtoupper($user->select_cur)) ;  ?>
  </button> 
  <ul class="dropdown-menu">
    <?php $check_crypto = select($pdo,"SELECT * FROM crypto WHERE nama<>'rfc'"); 
	$check_crypto->execute();
	$row_crypto = row($check_crypto); 
	if($row_crypto >= 1){ 
		while($crypto = fetch_obj($check_crypto)){
			?> 
			 <li><a class="dropdown-item" href="<?php echo($site) ?>?change_cur=<?php echo($crypto->nama) ;  ?>"><?php echo strtoupper($crypto->nama) ;  ?></a></li>
			<?php 
		}
	}  
	 ?>
    
	
  </ul>
</div>
</div>

 
 
	<?php 
	$check_data = select($pdo,"SELECT * FROM `1x_api` WHERE id_user='$id_user' "); 
	$check_data->execute();
	$row_data_api = row($check_data);
	if($row_data_api >= 1){
		while($data = fetch_obj($check_data)){
			$balance = read_balance($data->respon_balance, $user->select_cur);
			$stat = read_stat($data->respon_stat, $user->select_cur);
			$win = uang($stat->win);
			$profit = round($stat->profit,2);
			$lose = uang($stat->lose);
			$id_strategy = $data->id_strategy;
			
			
			
			if($data->active == "Yes"){
				$expired = $data->expired ;
			} else {
				$expired = "Not Active";
			}
			
			if($data->valid == "No"){
				$balance = "API ERROR - CHECK AGAIN";
				$win = "ERROR";
				$profit = "ERROR";
				$lose = "ERROR";
			} 
			
		?> 
			<div  class="card_gradient border-blue px-3 pt-2 pb-2 radius-3 mb-3"  style="box-shadow:0px 0px 20px 0px rgba(0,0,0,.2)" >
			<form class=" relative w-100 h- w-100 gap-1  pt-2"  method="post" enctype="multipart/form-data"> 
			<div class="relative"  style="z-index:2!important;" >
				<div class="relative">
					<span class="op-9 fs-11 nowrap"> API KEY : <?php echo (custom_echo($data->api , 50)); ?> </span> 
					<div class="btn-group btn-group-sm" style="position:absolute; right:-1rem; top:-10px; " >
					<a class="fs-10 btn btn-light btn-sm"  onclick="show_update('<?php echo($data->id) ;  ?>', '<?php echo($data->api) ;  ?>','<?php echo($data->nama) ;  ?>')"   > <i class="fa fa-edit">  </i> Edit </a> 
					<a class="fs-10 btn btn-danger btn-sm" onclick="show_delete('<?php echo($data->id) ;  ?>', '<?php echo($data->api) ;  ?>','<?php echo($data->nama) ;  ?>')"   > <i class="fa fa-trash">  </i> Delete </a> 
					</div>
				</div>
				
				<h4 class="fs-18 d-flex align-items-center justify-content-between"  style="margin-top: 5px;" >
					<span  style="display:block; width : 80%!important; text-overflow:ellipsis; overflow:hidden;white-space:nowrap;"  > <i class="far fa-user-circle fs-18">  </i> <?php echo($data->nama) ;  ?> </span> 
					<span  style="width : 20%;" align="right" id="status_<?php echo($data->id) ;  ?>" class="text-danger"> STOP </span> 
				</h4> 
				
				<span class="op-9 fs-13"><i class="fas fa-coins">  </i>  Balance  &nbsp;&nbsp; | &nbsp;&nbsp; Expired : <?php echo($expired) ;  ?> </span> 
				<h5 class="fs-18 " ><span class="balance_<?php echo($data->id) ;  ?>"> <?php echo($balance) ;  ?></span><?php echo("<b class=''> ". strtoupper($user->select_cur)."</b> ") ;  ?> </h5> 				
				
				<div class="d-flex align-items-center justify-content-start gap-10 fs-12">
					<span> Win : <b class="win_<?php echo($data->id) ;  ?>"> <?php echo ($win) ;  ?> </b>  &nbsp;&nbsp; | &nbsp;&nbsp; Lose : <b class="lose_<?php echo($data->id) ;  ?>"> <?php echo($lose) ;  ?> </b>  <br />
					Profit : <b class="profit_<?php echo($data->id) ;  ?>"> <?php echo($profit) ;  ?> </b> <?php echo(strtoupper($user->select_cur)) ;  ?> <br />
					Strategy :  
					<select class="form-control-sm" name="id_strategy" id="strategy_<?php echo($data->id) ;  ?>"> 
					<?php $check_s = select($pdo,"SELECT * FROM strategy "); 
					$check_s->execute();
					$row_s = row($check_s);
					if($row_s >= 1){
						while($s = fetch_obj($check_s)){
							?> 
							<option <?php if($s->id == $id_strategy){echo(" selected ") ; }  ?> value="<?php echo($s->id) ;  ?>"  ><?php echo($s->nama) ;  ?></option> 
							<?php 
						}
					}  
					 ?>
					</select>  <br />  <br />
					Now : <b class="now_<?php echo($data->id) ;  ?>"> <?php echo(round($data->now,  8)) ;  ?> </b>  &nbsp;&nbsp; | &nbsp;&nbsp;  Total : <b class="total_<?php echo($data->id) ;  ?>"> <?php echo(round($data->total, 8)) ;  ?> </b> </span> 
				</div>				
			</div>
				
			<img src="<?php echo($site) ?>image/wolf.webp"  style="width : 100px; transform:rotate(15deg);right:-10px; bottom:15px;"  class="absolute_background" />
			<img src="<?php echo($site) ?>image/wing2.png"  style="width : 100%;  opacity:0.3!important;left:0px; bottom:0px;"  class="absolute_background" />
				
				<?php if($data->active == "Yes"){?> 
				<div class="d-flex gap-1 justify-content-between relative"  style="z-index:2!Important;" >
				<input type="hidden" required name="id" class="form-control" value="<?php echo($data->id) ;  ?>"  />
					<button type="submit" class="btn btn-primary btn-sm" id="run_<?php echo($data->id) ;  ?>" style="width : 100%;" name="run_bot"  > Run Autobot </button> 
					<button type="submit" class="btn btn-danger d-none btn-sm" id="stop_<?php echo($data->id) ;  ?>"  style="width : 100%;" name="stop_bot"   > Stop </button> 
				</div>
				
				<?php } else 
				if($data->active == "No"){
				?> 
				<div class="d-flex w-100 gap-1 relative pt-2"> 
					<a class="btn btn-primary btn-sm"  style="width : 100%;" onclick="show_payment('<?php echo($data->id) ;  ?>','<?php echo($data->api) ;  ?>')" > Run Autobot</a>   
				</div>					
				<?php 
				} else {?> 
				<div class="d-flex w-100 gap-1 relative pt-2"> 
					<a class="btn btn-primary btn-sm"  style="width : 100%;" href="<?php echo($site) ?>page/payments?id=<?php echo($data->id) ;  ?>" > Check Payment Status </a>   
				</div>					 
				<?php } ?>
				
				</form>
			</div>	
			
			
			
			<?php 
		}
	} 
	 ?>
	 
	 
	 
<script>  
	 
		var wait_stat = [] ; 
		var wait = [] ; 
		var data = [];
		var stat = [];
		var api = []
		var cur = "<?php echo($user->select_cur) ;  ?>";
		var old_amount = [];
		var profit = [];
		var total_profit = 0 ;
		

		<?php 
		$check_data = select($pdo,"SELECT * FROM `1x_api` WHERE id_user='$id_user' "); 
		$check_data->execute();
		$row_data = row($check_data);
		if($row_data >= 1){
			$x= 0 ;
			while($data = fetch_obj($check_data)){ ?>
			api[<?php echo($x) ;  ?>] = "<?php echo($data->api) ;  ?>";
			stat[<?php echo($x) ;  ?>] = "";
			data[<?php echo($x) ;  ?>] = "";
			old_amount[<?php echo($x) ;  ?>] = 0;
			wait[<?php echo($x) ;  ?>] = false;
			wait_stat[<?php echo($x) ;  ?>] = false;
			
			data[<?php echo($x) ;  ?>] = new XMLHttpRequest();
			data[<?php echo($x) ;  ?>].onload = () => {	
				if(data[<?php echo($x) ;  ?>].readyState == 4){
					
					try {
					let response = JSON.parse(data[<?php echo($x) ;  ?>].response);
					
					if(response.balances){
						let balances = response.balances;
						balances.forEach(function(b){
							
							
							if(b.currency == cur){
								amount = b.amount;  
								$('.balance_<?php echo($data->id) ;  ?>').removeClass('text-success');
								$('.balance_<?php echo($data->id) ;  ?>').removeClass('text-danger');
								if(Number(amount) > Number(old_amount[<?php echo($x) ;  ?>])){
									$('.balance_<?php echo($data->id) ;  ?>').addClass('text-success');
								}  else {
									$('.balance_<?php echo($data->id) ;  ?>').addClass('text-danger');
								}
								
								$('.balance_<?php echo($data->id) ;  ?>').html(amount);
							
								old_amount[<?php echo($x) ;  ?>] =  amount ;
							} 
							
							
							
						});
					} 
					}
					
					catch(err) {
						console.log(err);
					}

	 				
				}
				wait[<?php echo($x) ;  ?>] = false;
			}
			
			
			
			stat[<?php echo($x) ;  ?>] = new XMLHttpRequest();
			stat[<?php echo($x) ;  ?>].onload = () => {	
				if(stat[<?php echo($x) ;  ?>].readyState == 4){
					let response = JSON.parse(stat[<?php echo($x) ;  ?>].response); 
					
					if(response.dice){
						let dice = response.dice.<?php echo($user->select_cur) ;  ?>; 
						
						$('.win_<?php echo($data->id) ;  ?>').html(uang(dice.win));
						$('.lose_<?php echo($data->id) ;  ?>').html(uang(dice.lose));
						$('.profit_<?php echo($data->id) ;  ?>').html(Number(dice.profit).toFixed(2)); 
						
						profit[<?php echo($x) ;  ?>] = dice.profit; 
						
						$('.profit_<?php echo($data->id) ;  ?>').removeClass('text-danger');
						$('.profit_<?php echo($data->id) ;  ?>').removeClass('text-success');

						if(Number(dice.profit).toFixed(2) > 0){
							$('.profit_<?php echo($data->id) ;  ?>').addClass('text-success');
						} else {
							$('.profit_<?php echo($data->id) ;  ?>').addClass('text-danger');
						}
						
					} 
	 				
				}
				wait_stat[<?php echo($x) ;  ?>] = false;
			}
			
					
			
			stat[<?php echo($x) ;  ?>].onerror = function() {  
				wait_stat[<?php echo($x) ;  ?>] = false;
			}
			data[<?php echo($x) ;  ?>].onerror = function() {  
				wait[<?php echo($x) ;  ?>] = false;
			}

			setInterval(function () {
				if(wait[<?php echo($x) ;  ?>] == false){
					wait[<?php echo($x) ;  ?>] = true; 
					
					data[<?php echo($x) ;  ?>].open("GET", 'https://wolfbet.com/api/v1/user/balances?r='+Math.random());
					data[<?php echo($x) ;  ?>].setRequestHeader("Authorization", 'Bearer <?php echo($data->api) ;  ?>');
					data[<?php echo($x) ;  ?>].send();
				}
				
				
				total_profit = 0 ;
				profit.forEach(function(item){
					total_profit = Number(total_profit) + Number(item);
				});
				
				$('#profit_global').html(total_profit);
				
				if(wait_stat[<?php echo($x) ;  ?>] == false){
					wait_stat[<?php echo($x) ;  ?>] = true; 
					
					stat[<?php echo($x) ;  ?>].open("GET", 'https://wolfbet.com/api/v1/user/stats/bets?r='+Math.random());
					stat[<?php echo($x) ;  ?>].setRequestHeader("Authorization", 'Bearer <?php echo($data->api) ;  ?>');
					stat[<?php echo($x) ;  ?>].send();
				}
				
			}, 5000);	
			
			<?php 	
			$x++;
			}
		}
		?>

 
</script> 

<div class="iframe_main">
	

</div>


<?php 
$check_dx = select($pdo,"SELECT * FROM 1x_api WHERE id_user='$id_user' and active='Yes' "); 
$check_dx->execute();
$row_dx = row($check_dx);
if($row_dx >= 1){
?> 

<script type="module"> 
import { io } from "https://cdn.socket.io/4.7.5/socket.io.esm.min.js";
const socket = io('wss://77.37.47.67:3005');

var id = '';
var now = '';
var total = '';
var data_msg = '';
var wait_emit = false; 

setInterval(function () {
	if(wait_emit == false){
		wait_emit = true; 
		socket.emit('get_data_api','{"id_user":"<?php echo($id_user) ;  ?>" } ', function (msg) { 
		if(msg){
			data_msg = (msg); 
			data_msg.forEach(function(item){
				
				id = item.id;
				total = item.total;
				now = item.now;
				
				$('.now_'+id).html(Number(now).toFixed(8));
				$('.total_'+id).html(Number(total).toFixed(8));
				
				if(Number(now) > 0){
					$('.now_'+id).addClass('text-success')
					$('.now_'+id).removeClass('text-danger')
				} else {
					$('.now_'+id).addClass('text-danger')
					$('.now_'+id).removeClass('text-success')
				}
				
				if(Number(total) > 0){
					$('.total_'+id).addClass('text-success')
					$('.total_'+id).removeClass('text-danger')
				} else {
					$('.total_'+id).addClass('text-danger')
					$('.total_'+id).removeClass('text-success')
				}
				
			});
			wait_emit = false ; 
		}
		});
	}
} ,1000); 
</script> 
<?php 
}
?>
 
 
 
 
<script>  
function run_autobot(id){
	strategy = $('#strategy_'+id).val();
	
	var ifrm = document.createElement("iframe");
	ifrm.setAttribute("id", "iframe_"+id);
	ifrm.setAttribute("src", "https://relandice.site?id_api="+id+"&id_strategy="+strategy+"&auto=yes");
	ifrm.style.width = "10px";
	ifrm.style.height = "10px";
	ifrm.style.display = "none";

	$('.iframe_main').append(ifrm);
	
	$('#run_'+id).addClass('d-none');
	$('#stop_'+id).removeClass('d-none');
	$('#status_'+id).html('RUN');
	$('#status_'+id).removeClass('text-danger');
	$('#status_'+id).addClass('text-success');
	
}


function stop_autobot(id){
	$('#iframe_'+id).remove();
	$('#run_'+id).removeClass('d-none');
	$('#stop_'+id).addClass('d-none');
	$('#status_'+id).html('STOP');
	$('#status_'+id).removeClass('text-success');
	$('#status_'+id).addClass('text-danger');

}


<?php 
	$check_data = select($pdo,"SELECT * FROM `1x_api` WHERE id_user='$id_user' and status_play='Play' and active='Yes' "); 
	$check_data->execute();
	$row_data_api = row($check_data);
	if($row_data_api >= 1){
		while($data = fetch_obj($check_data)){ ?>
			run_autobot('<?php echo($data->id) ;  ?>');
		<?php 
		}
	}		
	?>


</script> 