<?php if(!empty($alert)){ ?>
<div  style="position:absolute; top:-50px; right:10px;width : 300px; padding:8px; font-size : 14px; z-index:99!important; "  class="alert alert-<?php echo($alert) ;  ?> bg-<?php echo($alert) ;  ?> border-0 m-0 text-light alert-dismissable">
	<a class="close" data-dismiss="alert" aria-label="close">&times;</a>
	<?php echo($respon) ;  ?> 
</div> 
<?php }  ?>		



<script>  
	$('.alert .close').click(function(){
		$('.alert').remove();
	});


</script> 

