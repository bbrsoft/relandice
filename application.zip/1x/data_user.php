<?php 
$login = "";
$user = "";
$id_user = "";
$secret = "";
$secret_user = "";


if((!empty($_SESSION['user_id'])) and (!empty($_SESSION['password']))){
$user_id = $_SESSION['user_id']; 
$password = $_SESSION['password']; 

$change_cur = "";
if(!empty($_GET['change_cur'])){ 
$change_cur = in($_GET['change_cur']); 
eksekusi($pdo,"UPDATE user SET `select_cur`='$change_cur'  WHERE secret='$user_id'  ");
}
	

$check_user = select($pdo,"SELECT * FROM `user` WHERE `secret`='$user_id' or `password`='$password'  "); 
$check_user->execute();
$row_user = row($check_user);
if($row_user >= 1){
	$user = fetch_obj($check_user); 
	$login = "yes";
	$user_id = $user->secret;
	$secret = $user->secret;
	$secret_user = $user->secret;
	$id_user = $user->id; 
	
	
	
} 
}



 
?>

