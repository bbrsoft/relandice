<!-- Modal -->
<div class="modal fade" id="modal_api" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="modal_api_label" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content bg-light">
      <form method="post" enctype="multipart/form-data"> 

		<div class="modal-header">
			<h1 class="modal-title fs-5" id="modal_api_label">Add New API</h1>
			<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
		</div>
		<div class="modal-body">

			<span> API Key </span> 
			<input type="text" required class="form-control" name="api" value="" placeholder="Wolfbet API Key"    />
			
			<span> Tag Name (Identifier) </span> 
			<input type="text" required class="form-control" name="name" value="" placeholder="Ex : MyAPI #1"    />
			
			 
			<div class="d-flex align-items-center justify-content-between ">
				<button type="button" class="btn btn-danger" data-bs-dismiss="modal">Cancel</button>
				<button type="submit" name="add_api" class="btn btn-primary">Insert New Data</button>
			</div>


		</div>
		</form>
    </div>
  </div>
</div><!-- Modal -->






<div class="modal fade" id="modal_payment" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="modal_payment_label" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content bg-light">
      <form method="post" enctype="multipart/form-data"> 

		<div class="modal-header">
			<h1 class="modal-title fs-5" id="modal_payment_label">Subscribe Monthly </h1>
			<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
		</div>
		<div class="modal-body">

			<span>Your API Key </span> 
			<input type="text" required readonly class="form-control" id="payment_api" name="api" value="" placeholder="Wolfbet API Key"    />
			<input type="hidden" required class="form-control" id="payment_id" name="id" value=""    />
			
			<span> Subscribe </span> 
			<select  required class="form-control" name="subscribe"   placeholder="Ex : MyAPI #1"  >
				<option  value="1"  >1 Month (Rp. <?php echo uang($settings->price_autobot * 1) ;  ?>) </option>
				<option  value="6"  >6 Month (Rp. <?php echo uang($settings->price_autobot * 6) ;  ?>) </option>
				<option  value="12"  >12 Month (Rp. <?php echo uang($settings->price_autobot * 12) ;  ?>) </option>
			</select>
						 
			<div class="d-flex align-items-center mt-3 justify-content-between ">
				<button type="button" class="btn btn-danger" data-bs-dismiss="modal">Cancel</button>
				<button type="submit" name="create_invoice" class="btn btn-primary">Subscribe Now</button>
			</div>


		</div>
		</form>
    </div>
  </div>
</div>


<script>  
function show_payment(id, api){
	$('#modal_payment').modal('show');
	$('#payment_api').val(api);
	$('#payment_id').val(id);
}

</script> 





<div class="modal fade" id="modal_image" data-bs-keyboard="false" tabindex="-1" aria-labelledby="modal_image_label" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content bg-light">
      <form method="post" enctype="multipart/form-data"> 

		<div class="modal-header">
			<h1 class="modal-title fs-5" id="modal_image_label">Preview Image </h1>
			<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
		</div>
		<div class="modal-body">

			<img src="" id="preview_image"  class="w-100" />
			 
		</div>
		</form>
    </div>
  </div>
</div>


<script>  
function show_image(url){
	$('#preview_image').attr('src',url);
	$('#modal_image').modal('show');
}

</script> 







<div class="modal fade" id="modal_api_update" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="modal_api_update_label" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content bg-light">
      <form method="post" enctype="multipart/form-data"> 

		<div class="modal-header">
			<h1 class="modal-title fs-5" id="modal_api_update_label">Update API</h1>
			<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
		</div>
		<div class="modal-body">
		
			<span> API Key </span> 
			<input type="text" required class="form-control" name="api" id="update_api" value="" placeholder="Wolfbet API Key"    />
			<input type="hidden" required class="form-control" name="id" id="update_id" value="" placeholder="Wolfbet API Key"    />
			
			<span> Tag Name (Identifier) </span> 
			<input type="text" required class="form-control" name="name" id="update_name" value="" placeholder="Ex : MyAPI #1"    />
			
			 
			<div class="d-flex align-items-center justify-content-between ">
				<button type="button" class="btn btn-danger" data-bs-dismiss="modal">Cancel</button>
				<button type="submit" name="update_data_api" class="btn btn-primary">Update Data</button>
			</div>


		</div>
		</form>
    </div>
  </div>
</div><!-- Modal -->





<script>  
function show_update(id, api,name){
	$('#update_api').val(api);
	$('#update_id').val(id);
	$('#update_name').val(name);
	$('#modal_api_update').modal('show');
	
	
}

</script> 




<div class="modal fade" id="modal_api_delete" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="modal_api_delete_label" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content bg-light">
      <form method="post" enctype="multipart/form-data"> 

		<div class="modal-header">
			<h1 class="modal-title fs-5" id="modal_api_delete_label">Delete API Key</h1>
			<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
		</div>
		<div class="modal-body">
		
			<span> API Key </span> 
			<input type="text" required class="form-control" name="api" id="delete_api" value="" placeholder="Wolfbet API Key"    />
			<input type="hidden" required class="form-control" name="id" id="delete_id" value="" placeholder="Wolfbet API Key"    />
			
			<span> Tag Name (Identifier) </span> 
			<input type="text" required class="form-control" name="name" id="delete_name" value="" placeholder="Ex : MyAPI #1"    />
			
			 
			<div class="d-flex align-items-center justify-content-start pt-2 pb-3">
				<input type="checkbox" id="check_delete" required  class="m-0" name="check" value="" placeholder=""    />
				<label for="check_delete" class="m-0 px-2 d-block">I Understand About the risk </label>
			</div>
			 
			<div class="d-flex align-items-center justify-content-between ">
				<button type="button" class="btn btn-danger" data-bs-dismiss="modal">Cancel</button>
				<button type="submit" name="delete_data_api" class="btn btn-primary">DELETE API KEY</button>
			</div>


		</div>
		</form>
    </div>
  </div>
</div><!-- Modal -->




<script>  
function show_delete(id, api,name){
	$('#delete_api').val(api);
	$('#delete_id').val(id);
	$('#delete_name').val(name);
	$('#modal_api_delete').modal('show');
}

</script> 


