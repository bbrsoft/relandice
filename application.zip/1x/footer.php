<?php if($page == "home"){?>  
<div class="footer" role="tablist"  style="position:relative" > 
	<?php include("alert_fixed.php"); ?>
	<a  id="nav-1-tab" data-bs-toggle="tab" data-bs-target="#nav-1" type="button" role="tab" aria-controls="nav-1" aria-selected="true" class="footer_item active" > <div><i class="la la-home">  </i> <small> Homepage </small> </div> </a> 
	<a  id="nav-2-tab" data-bs-toggle="tab" data-bs-target="#nav-2" type="button" role="tab" aria-controls="nav-2" aria-selected="true" class="footer_item" > <div> <i class="la la-wallet">  </i> <small> Wallet Wolf </small> </div> </a> 
	<a  id="nav-3-tab" data-bs-toggle="tab" data-bs-target="#nav-3" type="button" role="tab" aria-controls="nav-3" aria-selected="true" class="footer_item"  > <div> <i class="la la-server">  </i> <small> Servers </small> </div> </a> 
	<a  id="nav-4-tab" data-bs-toggle="tab" data-bs-target="#nav-4" type="button" role="tab" aria-controls="nav-4" aria-selected="true" class="footer_item"  > <div> <i class="la la-history">  </i> <small> Transaction </small></div>  </a> 
	<a  id="nav-5-tab" data-bs-toggle="tab" data-bs-target="#nav-5" type="button" role="tab" aria-controls="nav-5" aria-selected="true" class="footer_item"  > <div> <i class="la la-users">  </i> <small> Referral </small> </div> </a> 
</div>
<?php } else {?> 
<style>
	
	body .page{
		height: calc(100% - 60px)!important;
	}
	
</style> 
<?php } ?>





 
 