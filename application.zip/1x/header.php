<div class="header bg-blue"  >
	<div class="header_logo" onclick="document.location.href='<?php echo($site) ?>'; ">
		<img src="<?php echo($site) ?>image/logo_white.png" class="logo" />
		<div class="block_all px-2 pt-1 "  style="padding-top:2px; line-height:16px" >
			<span  style="font-weight : bold;" ><?php echo($website_name) ;  ?></span> 
			<small class="fs-10"> Get Profit Every Day</small> 
		</div>
	</div>
	<div class="">
		<a class="link" href="<?php echo($site) ?>page/logout" > <i class="fa fa-sign-out">  </i> </a> 
		
	</div>
</div>

