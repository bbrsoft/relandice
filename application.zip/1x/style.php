<style>
.fs-8{font-size : 8px!important}.fs-9{font-size : 9px!important}.fs-10{font-size : 10px!important}.fs-11{font-size : 11px!important}.fs-12{font-size : 12px!important}.fs-13{font-size : 13px!important}.fs-14{font-size : 14px!important}.fs-15{font-size : 15px!important}.fs-16{font-size : 16px!important}.fs-17{font-size : 17px!important}.fs-18{font-size : 18px!important}.fs-19{font-size : 19px!important}.fs-20{font-size : 20px!important}.fs-21{font-size : 21px!important}.fs-22{font-size : 22px!important}.fs-23{font-size : 23px!important}.fs-24{font-size : 24px!important}.fs-25{font-size : 25px!important}.fs-26{font-size : 26px!important}.fs-27{font-size : 27px!important}.fs-28{font-size : 28px!important}.fs-29{font-size : 29px!important}.fs-30{font-size : 30px!important}
.gap-1{gap: .5rem;}
.gap-2{gap: 1rem;}
.gap-3{gap: 1.5rem;}
.gap-4{gap: 2rem;}

.gap-5px{gap : 5px}
.gap-10px{gap : 10px}
.gap-15px{gap : 15px}
.gap-20px{gap : 20px}
.gap-25px{gap : 15px}


@media(max-width: 500px){
.max-1 > *{ max-width:100%!important; }
.max-2 > *{ max-width:50%!important; }
.max-3 > *{ max-width:33.33%!important; }
.max-4 > *{ max-width:25%!important; }
.max-5 > *{ max-width:20%!important; }
.max-6 > *{ max-width:16.66%!important; }
.max-7 > *{ max-width:14.285%!important; }
.max-8 > *{ max-width:12.5%!important; }
.max-9 > *{ max-width:11.1111%!important; }
.max-10 > *{ max-width:10%!important; }
}

.radius-2{border-radius:2px; }
.radius-3{border-radius:3px; }
.radius-4{border-radius:4px; }
.radius-5{border-radius:5px; }
.radius-6{border-radius:6px; }
.radius-7{border-radius:7px; }
.radius-8{border-radius:8px; }
.radius-9{border-radius:9px; }
.radius-10{border-radius:10px; }
.radius-20{border-radius:20px; }
.radius-30{border-radius:30px; }

.absolute_title{
	position:absolute; left:5px; top:5px;
}	
.absolute_background{
	position:absolute;
	bottom:10px; ;
	right:10px;
	opacity:0.6;
	z-index:1;
}

	body,html{
		
		display:block;
		position:relative;
		width : 100%;
		height: 100%;
		overflow:hidden;
		background: #f9f9f9;
		font-family : "Poppins","Roboto" ;
	}
	
	
	
	.main{
		display:block;
		margin:auto;
		position:relative;
		height: 100%;
		width : 400px;
		max-width:100%; 
	}
	
	
	.bg-light{
		background: #f6f6fe!important;
	}	
	
	.card_gradient{
		background: rgb(187,198,254);
		background: linear-gradient(225deg, rgba(187,198,254,1) 0%, rgba(207,226,255,1) 100%);
		position:relative;
	}
	
	.link{
		text-decoration:none!important;
		color:inherit!important;
	}
	
	
	form span{
		display:block!important;
		font-size : 14px;
	}
	
	
	form span i{
		width : 13px;
		opacity:0.8;
	}
	form input:focuse,
	form input:active
	{
		box-shadow:none!important;
		outline:none!important;
		border:1px solid blue;
	}
	
	
	form input{
		display:block!important;
		margin-bottom: 10px!Important;
		font-size : 14px;
		box-shadow:none!important;
		outline:none!important;
	}
	
	.alert{
		position:relative;		
	}

	.alert .close{
		cursor:pointer; 
		font-size : 18px;
		color:white!important;
		text-decoration:none;
		position:absolute;
		right:15px;
		top:5px;
		font-weight : bold;
		
	}
	
	.password{		  -webkit-text-security: disc;	}

.header{
	display:flex;
	width : 100%;
	height: 60px;
	justify-content:space-between;
	align-items:center;
	padding-left:1rem;
	padding-right:1rem;
}

.header_logo img{
	height: 40px;
}

.header_logo{
	display:flex;
}

.block_all *{
	display:block;
}


.bg-blue{
	background: #7000ff!important;
	color:white;
}
.nowrap{
	    text-overflow: ellipsis;
    overflow: hidden;
    display: block;
    white-space: nowrap;
}

.relative{
	position:relative;
	z-index:2;
}
.card_gradient{
	overflow:hidden;
	position:relative;
}

.border-blue{
	border:1px solid #7000ff63;
}

.btn-light{
	border:1px solid #7000ff63;
}

.dropdown-menu{
	max-height:250px!Important;
	overflow:auto;
}

form span i{
			width : 18px;
		}

.text-success{
	color:green!important;
}
		
		
	.form-control-sm{
		font-size : 12px!Important;
		padding:2px!Important;
		padding-top:0px!important;
		padding-bottom:0px!important;
		height: 20px!important;
		min-height:unset!important;
		border:0px!Important;
	}
	
	
	.server_contract{
		background: white;
		border-radius:5px;
		box-shadow:0px 0px 10px 0px gainsboro; 
		width : 100%; 
		padding-top:.5rem;
		padding-bottom:.5rem;
		padding-left:1rem;
		padding-right:1rem;
		
	}
	
	.server_flex{
		display:flex;
		align-items:center;
		justify-content:space-between;

	}
	 
    .swiper {
      width: 100%;
      height: 175px;
    }


    .swiper-slide img {
      display: block;
      width: 100%;
      height: 100%;
      object-fit: cover;
    }

    .swiper-slide { 
      width: 80%!important;
	  text-align:left!important; 
    }
	
	.footer{
		height: 60px; 
		display:flex;
		align-items:center;
		justify-content:space-between;
		gap:5px;
		white-space:nowrap;
		background: white;
		box-shadow:0px 0px 10px 0px rgba(0,0,0,.1);
		border-top:1px solid gainsboro;
		padding:1rem;
	}
	
	.page{
		height: calc(100% - 120px)!important;
		overflow:auto;
	}
	
	.footer_item.active{
		background: #7000ff!important;
		color:white!important; 
	}
	
	.footer_item small{
		display:block;
		font-size : 10px;
	}
	.footer_item div{
		text-align:center;
		line-height:14px;
	}
	.footer_item{
		display:flex;
		align-items:center;
		justify-content:center;
		width : calc(100% / 5)!important; 
		color:black;
		border-radius:3px;
		height: 45px;
		text-decoration:none!important;
		font-size : 22px;
	}
	
	
</style>