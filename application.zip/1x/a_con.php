<?php 
ERROR_REPORTING(E_ALL);
header("Access-Control-Allow-Origin: *");
$host = "localhost";
$user_db = "bot";
$password_db = "Aku3313231";
$database = "bot";
$pdo = new PDO("mysql:host=$host;dbname=$database", $user_db, $password_db, array( PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION )); 
$site = "https://relandice.site/1x/";
$website_name = "Miner";

date_default_timezone_set('Asia/Makassar');
$date = date('Y-m-d');
$d = date('d');
$m= date('m');
$y = date('Y');

if(!empty($_SERVER['HTTP_CLIENT_IP'])){ $ip=$_SERVER['HTTP_CLIENT_IP']; } else if(!empty($_SERVER['HTTP_X_FORWARDED_FOR'])){  $ip=$_SERVER['HTTP_X_FORWARDED_FOR']; } else{ $ip=$_SERVER['REMOTE_ADDR']; }
$hostname = gethostbyaddr($_SERVER['REMOTE_ADDR']);

	
function angka($data){ $data2 = str_replace(",", "",$data); $data2 = str_replace('.', "",$data2 ); $data2 = preg_replace("/[^0-9]/", "",$data2);  return $data2;	 }
function in($data) { $data = trim($data);    $data = stripslashes($data);    $data = htmlspecialchars($data); $data2 = str_replace("'", "`",$data );   $data2 = str_replace('"', "`",$data2 );    return $data2; }
function ssl($str){	$str = str_replace("_","__9*",$str);	$str = str_replace("a","__8*",$str);	$str = str_replace("b","__7*",$str);	$str = str_replace("c","__6*",$str);	$str = str_replace("d","__5*",$str);	$str = str_replace("e","__4*",$str);	$str = str_replace("f","__3*",$str);	$str = str_replace("g","__2*",$str);	$str = str_replace("h","__1*",$str);	$str = str_replace("i","__9#",$str);	$str = str_replace("j","__8#",$str);	$str = str_replace("k","__7#",$str);	$str = str_replace("l","__6#",$str);	$str = str_replace("m","__5#",$str);	$str = str_replace("n","__4#",$str);	$str = str_replace("o","__3#",$str);	$str = str_replace("p","__2#",$str);	$str = str_replace("q","__1#",$str);	$str = str_replace("r","__9",$str);	$str = str_replace("s","__8",$str);	$str = str_replace("t","__7",$str);	$str = str_replace("u","__6",$str);	$str = str_replace("v","__5",$str);	$str = str_replace("w","__4",$str);	$str = str_replace("x","__3",$str);	$str = str_replace("y","__2",$str);	$str = str_replace("z","__1",$str);	$str = base64_encode(base64_encode($str));	return $str;}
function de_ssl($str){	$str = base64_decode(base64_decode($str));	$str = str_replace("__9*","_",$str);	$str = str_replace("__8*","a",$str);	$str = str_replace("__7*","b",$str);	$str = str_replace("__6*","c",$str);	$str = str_replace("__5*","d",$str);	$str = str_replace("__4*","e",$str);	$str = str_replace("__3*","f",$str);	$str = str_replace("__2*","g",$str);	$str = str_replace("__1*","h",$str);	$str = str_replace("__9#","i",$str);	$str = str_replace("__8#","j",$str);	$str = str_replace("__7#","k",$str);	$str = str_replace("__6#","l",$str);	$str = str_replace("__5#","m",$str);	$str = str_replace("__4#","n",$str);	$str = str_replace("__3#","o",$str);	$str = str_replace("__2#","p",$str);	$str = str_replace("__1#","q",$str);	$str = str_replace("__9","r",$str);	$str = str_replace("__8","s",$str);	$str = str_replace("__7","t",$str);	$str = str_replace("__6","u",$str);	$str = str_replace("__5","v",$str);	$str = str_replace("__4","w",$str);	$str = str_replace("__3","x",$str);	$str = str_replace("__2","y",$str);	$str = str_replace("__1","z",$str);	return $str;}
function eksekusi($pdo, $query){ 	$exe = $pdo->prepare($query); 	$exe->execute(); }
function select($pdo,$query){ return $pdo->prepare($query); }
function row($var){ return $var->rowCount(); }
function fetch($var){ return $var->fetch(PDO::FETCH_BOTH); }
function fetch_obj($var){ return $var->fetch(PDO::FETCH_OBJ); }
function uang($money, $round = 0){
		if (( $money <> 0 ) and ($money <> '')) {
			$uang = number_format((float)$money, $round, '.', ',');
			return $uang;
		}
		else{
			$uang = "0";return $uang;
		}
	}
function title($title){$title = strtolower($title);$title = preg_replace("/[^A-Za-z0-9 ]/", '', $title);$t = explode(' ',$title);$txx = "";$x =0;foreach($t as $tx){		if($tx != ""){		if($x == 0){		$txx = $tx;	} else {		$txx .= "-".$tx;	}	$x++;	}}return $txx;}	
function judul($title,$count){$t = explode(' ',$title);$txx = "";$x =0;$xxx = "";foreach($t as $tx){		if($x <> $count){	if($x == 0){		$txx = $tx;	} else {		$txx .= " ".$tx;	}	$x++;	} else {		$xxx = "...";	}}return $txx.$xxx;}   
function planText($text){    $text = strip_tags($text, '<br><p><li>');	    $text = preg_replace ('/<[^>]*>/', "", $text);	$text= html_entity_decode(htmlspecialchars_decode($text));	$text = str_replace('\r','',$text);	$text = str_replace('\n','',$text);	$text = strip_tags($text, '<br><p><li>');    $text = preg_replace ('/<[^>]*>/', "", $text);	return $text;	}  
function bulan($b){if($b == "Jan" ){return "Januari";} else if($b == "Feb" ){return "Februari";} else if($b == "Mar" ){return "Maret";} else if($b == "Apr" ){return "April";} else if($b == "May" ){return "Mei";} else if($b == "Jun" ){return "Juni";} else if($b == "Jul" ){return "Juli";} else if($b == "Aug" ){return "Agustus";} else if($b == "Sep" ){return "September";} else if($b == "Oct" ){return "Oktober";} else if($b == "Nov" ){return "November";} else if($b == "Dec" ){return "Desember";} else {	return ("-") ; }}
function hari($b){if($b == "Mon" ){return "Senin";} else if($b == "Tue" ){return "Selasa";} else if($b == "Wed" ){return "Rabu";} else if($b == "Thu" ){return "Kamis";} else if($b == "Fri" ){return "Jum`at";} else if($b == "Sat" ){return "Sabtu";} else if($b == "Sun" ){return "Minggu";} else {return "";}}


$idr = 0.31851;
$usd = 0.00002;
$check_crypto = select($pdo,"SELECT * FROM crypto WHERE nama='shib' "); 
$check_crypto->execute();
$row_crypto = row($check_crypto);
if($row_crypto >= 1){
	$crypto = fetch_obj($check_crypto);
	$idr = $crypto->idr;
	$usd = $crypto->usd;
	$usdt = $crypto->usd;
}  


$check_settings = select($pdo,"SELECT * FROM settings"); 
$check_settings->execute();
$row_settings = row($check_settings);
if($row_settings >= 1){
	$settings = fetch_obj($check_settings);
}  


function custom_echo($x, $length)
{
	$param = "";
	for ($i = 1; $i <= $length; $i++) {
		if($x[$i]){
			$param .= $x[$i];
		} 
	} 
	return $param;
}

function read_balance($respon, $cur){
	$amount = 0; 
	if(!empty($respon)){
	$data= json_decode($respon);
	if(empty($data->error)){
		foreach($data->balances as $d){
				
			if($d->currency == $cur){
				$amount = $d->amount;
			} 
		}
	}
	}
	
	return $amount; 
	
}




function read_stat($respon, $cur){

   $dice = new stdClass();
   $dice->total_bets = 0;
   $dice->win = 0;
   $dice->lose = 0;
   $dice->waggered = 0;
   $dice->waggered_usd = 0;
   $dice->profit = 0;
   
   
	if(!empty($respon)){
	$data= json_decode($respon);
	if(empty($data->error)){
		if(!empty($data->dice->$cur)){
			$dice = $data->dice->$cur; 
		} 
	}
	}
	
	return $dice; 
}


 ?>