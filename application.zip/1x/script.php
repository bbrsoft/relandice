<script>   
	
	
	
	
		
	function uang(nums) {
	var vals = String(nums);
	
	if (vals == null){
		vals = "0";
	}
		vals = vals.replace(/,/g, "");
		vals += '';
		x = vals.split('.');
		x1 = x[0];
		x2 = x.length > 1 ? '.' + x[1] : '';
	
		var rgx = /(\d+)(\d{3})/;
	
		while (rgx.test(x1)) {
			x1 = x1.replace(rgx, '$1' + ',' + '$2');
		}
	
		xx = x1 + x2;
		
	if (xx == "0"){
		xx = "0";
	}
		
		return xx;
	
	
	}
	
	
	
	 
</script> 