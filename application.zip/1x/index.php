<?php 
session_start();
require_once("a_con.php"); 
require_once("data_user.php");
require_once("isset.php");

$pwa = "";
if(!empty($_GET['pwa'])){ 
$pwa = in($_GET['pwa']); 
$_SESSION['pwa'] = "pwa"; 
}


$page = "home";
if(!empty($_GET['page'])){ 
$page = in($_GET['page']); 
} 

?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="description">
		<meta name="author" content="">
		
		<title>Relandice.site 1x</title>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
		<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.3/css/bootstrap.min.css" integrity="sha512-jnSuA4Ss2PkkikSOLtYs8BlYIeeIK1h99ty4YfvRPAlzr377vr3CXDb7sb7eEEBYjDtcYj+AjBH3FLv5uSJuXg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
		<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.3/js/bootstrap.bundle.min.js" integrity="sha512-7Pi/otdlbbCR+LnW+F7PwFcSDJOuUJB3OxtEHbg4vSMvzvJjde4Po1v4BR9Gdc9aXNUNFVUY+SK51wWT8WF0Gg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
		<link rel= "stylesheet" href= "https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css" >
		<?php include("style.php"); ?>
		<?php include("script.php"); ?>
</head>
<body>



	<div class="main overflow-style bg-light">
		<?php include("modal.php"); 
		
			if(!empty($user)){
				include("header.php"); 
				?> 
				<div class="page">
					<?php 
						if(file_exists("form/".$page.".php")){
							include("form/".$page.".php");
						}else {
							include("form/home.php");
						}				
					?>
				</div> 
				<?php 
				
				include("footer.php");
			} else {
				
				
				
				if(($page <>'register') & ($page <>'forgot')){
					include("form/login.php");
				} else {
					include("form/".$page.".php");	 
				}
				
				
			}
			?>
		  
	</div>
		
		
		
 
 
</body>
</html>

 