<?php 
if(isset($_POST['login'])){
	$username = in($_POST['user_id']);
	$password = in($_POST['password']);
	 
	$check_user = select($pdo,"SELECT * FROM user WHERE secret='$username' and password='$password' "); 
	$check_user->execute();
	$row_user = row($check_user);
	if($row_user >= 1){
		$_SESSION['user_id'] = $username; 
		$_SESSION['password'] = $password;
		
				
		$date = date('Y-m-d');
		eksekusi($pdo,"UPDATE `1x_api` SET `active`='No' WHERE `expired` <= '$date'");
		 
		 
		echo("<script>  document.location.href='".$site."';   </script> ") ; 
		exit();
	} else {
		$alert = "danger";
		$respon = "Sorry . Your Username / Password is wrong ";
	}  
}  



if(isset($_POST['register'])){
	$secret = in($_POST['secret']);
	$password = in($_POST['password']);
	$referral = in($_POST['referral']);


	$check_ref = select($pdo,"SELECT * FROM user WHERE `secret`='$referral'"); 
	$check_ref->execute();
	$row_ref = row($check_ref);
	if($row_ref >= 1){
		$ref = fetch_obj($check_ref);
		$id_ref = $ref->id; 
	
	
	$check_user = select($pdo,"SELECT * FROM user WHERE secret='$secret' "); 
	$check_user->execute();
	$row_user = row($check_user);
	if($row_user >= 1){
		$alert = "danger";
		$respon = "Sorry - This Secret/Username Is Not Allowed, Please Change";
	}else {
		$alert = "success";
		$respon = "Your Account Has Created . Now You can setup BOT With your TOKEN . ";
		
		
		eksekusi($pdo,"INSERT INTO `user` (`secret` , `password`,`bet`,`referral` )VALUES ('$secret','$password','0','$id_ref' )  ");
		
		$check_user = select($pdo,"SELECT * FROM user WHERE secret='$secret' "); 
		$check_user->execute();
		$row_user = row($check_user);
		if($row_user >= 1){
			$user = fetch_obj($check_user);
			$_SESSION['user'] = $user; 
		} 
	}
	} else {
		$alert = "danger";
		$respon = "Sorry . Referral Code Is Not Valid/Not Found ";
		
	}
} 



if(!empty($user)){
	
	
	/* * Create invoice  * -------------- */
	if(isset($_POST['create_invoice'])){
		
		$id = in($_POST['id']);
		$subscribe = in($_POST['subscribe']);
		
		$total = $settings->price_autobot * $subscribe; 
		
		$check_api = select($pdo,"SELECT * FROM 1x_api WHERE active<>'Yes' and id='$id' "); 
		$check_api->execute();
		$row_api = row($check_api);
		if($row_api >= 1){
			$api = fetch_obj($check_api);
			eksekusi($pdo,"UPDATE 1x_api SET `month`='$subscribe' ,`active`='Waiting Payments' , `total_payment`='$total' , `evidence_status`='Waiting Payments' WHERE id='$id'   ");
			echo("<script>  document.location.href='".$site."page/payments?id=".$id."';   </script> ") ; 
			exit();
		}
		
	}  
	
	
	if(isset($_POST['update_data_api'])){
		$id = in($_POST['id']);
		$api = in($_POST['api']);
		$name = in($_POST['name']);
		

		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, 'https://wolfbet.com/api/v1/user/balances');
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');


		$headers = array();
		$headers[] = 'X-Requested-With: XMLHttpRequest';
		$headers[] = 'Authorization: Bearer '.$api;
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

		$result = curl_exec($ch); 
		curl_close($ch); 
		$saldo = [];

		if(!empty($result)){			
		$result_decode = json_decode($result); 
		
			if(empty($result_decode->errors)){  

			$newtimestamp = strtotime(date('Y-m-d H:i:s').' + 1 minute');
			$next_update = date('Y-m-d H:i:s', $newtimestamp);


			
			$id_user = $user->id;
			eksekusi($pdo,"UPDATE 1x_api SET `api`='$api' , `nama`='$name' , `valid`='Yes' WHERE id='$id' and id_user='$id_user'    ");
			
			$alert = "success";
			$respon = "Success Update API $name";
			
		
			} else {
				$alert = "danger";
				$respon = "Sorry - Your API key is not valid , Please check again";
			}
		} else{
				$alert = "danger";
				$respon = "Sorry - Your API key is not valid , Please check again";
		}
		
		
	}
	
	
	
	
	
	if(isset($_POST['delete_data_api'])){
		$id = in($_POST['id']);
		$name = in($_POST['name']);
		
		
		eksekusi($pdo,"DELETE FROM 1x_api WHERE id='$id' and id_user='$id_user'  ");
		$alert = "success";
		$respon = "Success Delete API $name ";
		
	} 
	
	

/*
 * Close !empty user 
 * --------------
 */

}  

?>

