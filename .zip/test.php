<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="description">
		<meta name="author" content="">
		<title>Your Title Website</title>
	</head>
	<body>
	
	
	
	
	
	</body>
	
	<script>  


const ws = new WebSocket("wss://ws.kraken.com/v2");
const message = {
    method: "subscribe",
    params: {
      channel: "ticker",
      symbol: ["SHIB/USD"]
    }
  }; 
  
ws.onopen = function() {
  ws.send(JSON.stringify(message)); 
};


ws.onmessage = function(event) {
  const data = JSON.parse(event.data);
  if(data.channel){
	if(data.type){
	if((data.channel == "ticker") && (data.type == "update")){
		console.log("Received:", data); 
	} else {
	
  	console.error( data); }
	} 
  } 
  
	
  
};

ws.onerror = function(error) {
  console.error("WebSocket error:", error);
};

	</script> 
</html>